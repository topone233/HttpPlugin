package org.example.securityplatform.service;

import org.example.securityplatform.analyzer.diff.ApiChangeModel;
import org.example.securityplatform.analyzer.diff.FileDiffDetector;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.securityplatform.analyzer.diff.FileDiffModel;
import org.example.securityplatform.dto.ApiNode;
import org.example.securityplatform.dto.FileSourceDiff;
import org.example.securityplatform.dto.ImpactGraphResponse;
import org.example.securityplatform.dto.QuickDiffResponse;
import org.example.securityplatform.entity.QuickDiffRecord;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class QuickDiffServiceTest {

    @Test
    void toFileDiffItemMapsLineDiffCounts() throws Exception {
        QuickDiffService service = new QuickDiffService();

        FileDiffModel model = new FileDiffModel();
        model.setFilePath("config/app.yml");
        model.setSourceFilePath("config/app.yml");
        model.setDiffType("MODIFIED");
        model.setFileType("RESOURCE");
        model.setBaselineLines(2);
        model.setTargetLines(3);
        model.setAddedLines(2);
        model.setDeletedLines(1);

        Method method = QuickDiffService.class.getDeclaredMethod("toFileDiffItem", FileDiffModel.class);
        method.setAccessible(true);

        QuickDiffResponse.FileDiffItem item = (QuickDiffResponse.FileDiffItem) method.invoke(service, model);
        assertEquals(2, item.getAddedLines());
        assertEquals(1, item.getDeletedLines());
    }

    @Test
    void convertToResponseRestoresSavedExtraResultFields() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        QuickDiffService service = new QuickDiffService();
        setField(service, "objectMapper", mapper);

        QuickDiffResponse.DependencySummary dependencySummary = QuickDiffResponse.DependencySummary.builder()
                .enabled(true)
                .baselineDependencyCount(1)
                .targetDependencyCount(2)
                .analyzedDependencies(List.of("demo-lib.jar"))
                .build();
        ImpactGraphResponse impactGraph = ImpactGraphResponse.builder()
                .apis(List.of(ApiNode.builder()
                        .id(1L)
                        .apiUrl("/api/demo")
                        .httpMethod("GET")
                        .changeType("AFFECTED_API")
                        .build()))
                .build();

        QuickDiffRecord record = new QuickDiffRecord();
        record.setFileSummaryJson(mapper.writeValueAsString(QuickDiffResponse.FileSummary.builder()
                .addedFiles(1)
                .build()));
        record.setApiSummaryJson(mapper.writeValueAsString(QuickDiffResponse.ApiDiffSummary.builder()
                .affectedApis(1)
                .build()));
        record.setFileDiffsJson(mapper.writeValueAsString(List.<QuickDiffResponse.FileDiffItem>of()));
        record.setApiDiffsJson(mapper.writeValueAsString(List.<QuickDiffResponse.ApiDiffItem>of()));
        record.setSourceDiffsJson(mapper.writeValueAsString(List.<FileSourceDiff>of()));
        record.setDependencySummaryJson(mapper.writeValueAsString(dependencySummary));
        record.setWarningsJson(mapper.writeValueAsString(List.of("warning")));
        record.setImpactGraphJson(mapper.writeValueAsString(impactGraph));
        record.setDurationMs(123L);

        Method method = QuickDiffService.class.getDeclaredMethod("convertToResponse", QuickDiffRecord.class);
        method.setAccessible(true);

        QuickDiffResponse response = (QuickDiffResponse) method.invoke(service, record);
        assertNotNull(response.getDependencySummary());
        assertTrue(response.getDependencySummary().isEnabled());
        assertEquals(List.of("warning"), response.getWarnings());
        assertNotNull(response.getImpactGraph());
        assertEquals(1, response.getImpactGraph().getApis().size());
        assertEquals(123L, response.getDuration());
    }

    @Test
    void buildResponseDeduplicatesApiChangesBeforeSummaryAndDetails() throws Exception {
        QuickDiffService service = new QuickDiffService();

        ApiChangeModel affected = apiChange("GET", "/api/demo", "DemoController", "get", "AFFECTED_API");
        ApiChangeModel modified = apiChange("GET", "/api/demo", "DemoController", "get", "MODIFIED_API");

        Method method = QuickDiffService.class.getDeclaredMethod(
                "buildResponse",
                List.class,
                FileDiffDetector.DiffStatistics.class,
                List.class,
                Class.forName("org.example.securityplatform.analyzer.jar.DependencyAnalysisConfig"),
                List.class,
                List.class,
                List.class
        );
        method.setAccessible(true);

        QuickDiffResponse response = (QuickDiffResponse) method.invoke(
                service,
                List.<FileDiffModel>of(),
                new FileDiffDetector.DiffStatistics(),
                List.of(affected, modified),
                null,
                null,
                null,
                List.<String>of()
        );

        assertEquals(1, response.getApiDiffs().size());
        assertEquals(1, response.getApiSummary().getModifiedApis());
        assertEquals(0, response.getApiSummary().getAffectedApis());
    }

    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private ApiChangeModel apiChange(String method, String url, String controllerClass,
                                     String methodName, String changeType) {
        ApiChangeModel change = new ApiChangeModel();
        change.setHttpMethod(method);
        change.setApiUrl(url);
        change.setControllerClass(controllerClass);
        change.setMethodName(methodName);
        change.setChangeType(changeType);
        return change;
    }
}

package org.example.securityplatform.analyzer.diff;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;

import static org.junit.jupiter.api.Assertions.*;

class FileDiffDetectorTest {

    @TempDir
    Path tempDir;

    @Test
    void detectSingleJarIncludesResourceDiffs() throws Exception {
        Path baselineJar = tempDir.resolve("baseline.jar");
        Path targetJar = tempDir.resolve("target.jar");

        createJar(baselineJar, Map.of(
                "com/example/Same.class", "same-class-bytes",
                "config/app.yml", "app:\n  name: demo\n"
        ));
        createJar(targetJar, Map.of(
                "com/example/Same.class", "same-class-bytes",
                "config/app.yml", "app:\n  name: changed\n  enabled: true\n"
        ));

        FileDiffDetector detector = new FileDiffDetector(
                baselineJar.toString(),
                targetJar.toString()
        );

        var diffs = detector.detect();
        assertEquals(1, diffs.size(), "Only the changed resource file should be reported");

        FileDiffModel resourceDiff = diffs.get(0);
        assertEquals("config/app.yml", resourceDiff.getFilePath());
        assertEquals("RESOURCE", resourceDiff.getFileType());
        assertEquals("MODIFIED", resourceDiff.getDiffType());
        assertEquals(2, resourceDiff.getBaselineLines());
        assertEquals(3, resourceDiff.getTargetLines());
        assertEquals(2, resourceDiff.getAddedLines());
        assertEquals(1, resourceDiff.getDeletedLines());
        assertEquals("MAIN", resourceDiff.getJarType());
        assertEquals("baseline.jar", resourceDiff.getSourceJar());

        FileDiffDetector.DiffStatistics stats = detector.getStatistics(diffs);
        assertEquals(0, stats.getAddedFiles());
        assertEquals(1, stats.getModifiedFiles());
        assertEquals(0, stats.getDeletedFiles());
        assertEquals(0, stats.getTotalMethodsAdded());
        assertEquals(0, stats.getTotalMethodsDeleted());
        assertEquals(0, stats.getTotalMethodsModified());
    }

    private void createJar(Path jarPath, Map<String, String> entries) throws Exception {
        try (JarOutputStream jar = new JarOutputStream(new FileOutputStream(jarPath.toFile()))) {
            for (Map.Entry<String, String> entry : entries.entrySet()) {
                jar.putNextEntry(new JarEntry(entry.getKey()));
                jar.write(entry.getValue().getBytes(StandardCharsets.UTF_8));
                jar.closeEntry();
            }
        }
    }
}

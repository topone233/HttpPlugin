package org.example.securityplatform.analyzer.diff;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

/**
 * Test suite for ResourceFileDiffAnalyzer line diff strategy.
 */
class ResourceFileDiffAnalyzerTest {

    private final ResourceFileDiffAnalyzer analyzer = new ResourceFileDiffAnalyzer();

    @Test
    @DisplayName("New file - all target lines treated as added")
    void testNewFile() {
        String targetContent = "line1\nline2\nline3\n";
        ByteArrayInputStream targetStream = new ByteArrayInputStream(
            targetContent.getBytes(StandardCharsets.UTF_8)
        );

        ResourceDiffResult result = analyzer.analyze(null, targetStream, "config.xml");

        assertNotNull(result, "Result should not be null");
        assertEquals("config.xml", result.getFilePath(), "File path should match");
        assertEquals(0, result.getBaselineLines(), "Baseline should be 0 for new file");
        assertEquals(3, result.getTargetLines(), "Target should have 3 lines");
        assertEquals(3, result.getAddedLines(), "All 3 target lines should be treated as added");
        assertEquals(0, result.getDeletedLines(), "Should have 0 deleted lines");
    }

    @Test
    @DisplayName("Deleted file - all baseline lines treated as deleted")
    void testDeletedFile() {
        String baselineContent = "line1\nline2\nline3\nline4\nline5\n";
        ByteArrayInputStream baselineStream = new ByteArrayInputStream(
            baselineContent.getBytes(StandardCharsets.UTF_8)
        );

        ResourceDiffResult result = analyzer.analyze(baselineStream, null, "old-config.xml");

        assertNotNull(result, "Result should not be null");
        assertEquals("old-config.xml", result.getFilePath(), "File path should match");
        assertEquals(5, result.getBaselineLines(), "Baseline should have 5 lines");
        assertEquals(0, result.getTargetLines(), "Target should be 0 for deleted file");
        assertEquals(0, result.getAddedLines(), "Should have 0 added lines");
        assertEquals(5, result.getDeletedLines(), "All 5 baseline lines should be treated as deleted");
    }

    @Test
    @DisplayName("Modified file - line diff counts only changed lines")
    void testModifiedFileLineDiff() {
        String baselineContent = "line1\nline2\nline3\nline4\n";
        String targetContent = "line1\nline2-modified\nline3\nline4\nline5\n";

        ByteArrayInputStream baselineStream = new ByteArrayInputStream(
            baselineContent.getBytes(StandardCharsets.UTF_8)
        );
        ByteArrayInputStream targetStream = new ByteArrayInputStream(
            targetContent.getBytes(StandardCharsets.UTF_8)
        );

        ResourceDiffResult result = analyzer.analyze(baselineStream, targetStream, "app.properties");

        assertNotNull(result, "Result should not be null");
        assertEquals("app.properties", result.getFilePath(), "File path should match");
        assertEquals(4, result.getBaselineLines(), "Baseline should have 4 lines");
        assertEquals(5, result.getTargetLines(), "Target should have 5 lines");

        assertEquals(2, result.getAddedLines(), "Modified line plus new line should be treated as added");
        assertEquals(1, result.getDeletedLines(), "Only the replaced baseline line should be treated as deleted");
    }

    @Test
    @DisplayName("Large modified file - bounded fallback does not count entire file as changed")
    void testLargeModifiedFileFallback() {
        StringBuilder baselineContent = new StringBuilder();
        StringBuilder targetContent = new StringBuilder();
        for (int i = 0; i < 1200; i++) {
            baselineContent.append("line-").append(i).append('\n');
            if (i == 600) {
                targetContent.append("line-600-modified\n");
            } else {
                targetContent.append("line-").append(i).append('\n');
            }
        }

        ResourceDiffResult result = analyzer.analyze(
                new ByteArrayInputStream(baselineContent.toString().getBytes(StandardCharsets.UTF_8)),
                new ByteArrayInputStream(targetContent.toString().getBytes(StandardCharsets.UTF_8)),
                "large.sql"
        );

        assertEquals(1200, result.getBaselineLines());
        assertEquals(1200, result.getTargetLines());
        assertEquals(1, result.getAddedLines(), "Fallback should count the changed target line");
        assertEquals(1, result.getDeletedLines(), "Fallback should count the replaced baseline line");
    }

    @Test
    @DisplayName("Both streams null - zero lines")
    void testBothNull() {
        ResourceDiffResult result = analyzer.analyze(null, null, "empty.xml");

        assertNotNull(result, "Result should not be null");
        assertEquals("empty.xml", result.getFilePath(), "File path should match");
        assertEquals(0, result.getBaselineLines(), "Baseline should be 0");
        assertEquals(0, result.getTargetLines(), "Target should be 0");
        assertEquals(0, result.getAddedLines(), "Should have 0 added lines");
        assertEquals(0, result.getDeletedLines(), "Should have 0 deleted lines");
    }

    @Test
    @DisplayName("hasChanges() detection")
    void testHasChangesDetection() {
        // Test with changes
        ByteArrayInputStream baseline = new ByteArrayInputStream("line1\n".getBytes(StandardCharsets.UTF_8));
        ByteArrayInputStream target = new ByteArrayInputStream("line1\nline2\n".getBytes(StandardCharsets.UTF_8));
        ResourceDiffResult resultWithChanges = analyzer.analyze(baseline, target, "changed.txt");
        assertTrue(resultWithChanges.hasChanges(), "Should detect changes");

        // Test without changes (both null)
        ResourceDiffResult resultNoChanges = analyzer.analyze(null, null, "no-change.txt");
        assertFalse(resultNoChanges.hasChanges(), "Should not detect changes when both null");
    }
}

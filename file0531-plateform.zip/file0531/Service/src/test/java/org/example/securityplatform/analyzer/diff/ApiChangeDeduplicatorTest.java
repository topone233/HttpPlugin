package org.example.securityplatform.analyzer.diff;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ApiChangeDeduplicatorTest {

    @Test
    void deduplicatesByHttpMethodAndUrl() {
        ApiChangeModel affected = apiChange("GET", "/api/orders", "OrderController", "list", "AFFECTED_API");
        ApiChangeModel modified = apiChange("GET", "/api/orders", "OrderController", "list", "MODIFIED_API");

        List<ApiChangeModel> result = ApiChangeDeduplicator.deduplicate(List.of(affected, modified));

        assertEquals(1, result.size());
        assertEquals("MODIFIED_API", result.get(0).getChangeType());
    }

    @Test
    void fallsBackToControllerMethodWhenRouteIsMissing() {
        ApiChangeModel first = apiChange(null, null, "OrderController", "list", "AFFECTED_API");
        ApiChangeModel second = apiChange(null, null, "OrderController", "list", "MODIFIED_API");

        List<ApiChangeModel> result = ApiChangeDeduplicator.deduplicate(List.of(first, second));

        assertEquals(1, result.size());
        assertEquals("MODIFIED_API", result.get(0).getChangeType());
    }

    @Test
    void newOrDeletedApiWinsOverModifiedApi() {
        ApiChangeModel modified = apiChange("POST", "/api/orders", "OrderController", "create", "MODIFIED_API");
        ApiChangeModel created = apiChange("POST", "/api/orders", "OrderController", "create", "NEW_API");

        List<ApiChangeModel> result = ApiChangeDeduplicator.deduplicate(List.of(modified, created));

        assertEquals(1, result.size());
        assertEquals("NEW_API", result.get(0).getChangeType());
    }

    @Test
    void mergesDuplicateCallChainsForSameChangeType() {
        ApiChangeModel first = apiChange("GET", "/api/orders", "OrderController", "list", "AFFECTED_API");
        first.setCallChain(List.of(
                new ApiChangeModel.CallChainNode("OrderController", "list", 0),
                new ApiChangeModel.CallChainNode("OrderService", "list", 1)
        ));
        ApiChangeModel second = apiChange("GET", "/api/orders", "OrderController", "list", "AFFECTED_API");
        second.setCallChain(List.of(
                new ApiChangeModel.CallChainNode("OrderController", "list", 0),
                new ApiChangeModel.CallChainNode("OrderRepository", "find", 1)
        ));

        List<ApiChangeModel> result = ApiChangeDeduplicator.deduplicate(List.of(first, second));

        assertEquals(1, result.size());
        assertEquals(3, result.get(0).getCallChain().size());
    }

    private ApiChangeModel apiChange(String method, String url, String controllerClass,
                                     String methodName, String changeType) {
        ApiChangeModel change = new ApiChangeModel();
        change.setHttpMethod(method);
        change.setApiUrl(url);
        change.setControllerClass(controllerClass);
        change.setMethodName(methodName);
        change.setChangeType(changeType);
        return change;
    }
}

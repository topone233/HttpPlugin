package org.example.securityplatform.dto;

import lombok.Data;

import java.util.List;

/**
 * 调用路径查询响应
 */
@Data
public class CallPathResponse {

    /**
     * 起点类名
     */
    private String startClass;

    /**
     * 起点方法名
     */
    private String startMethod;

    /**
     * 终点类名
     */
    private String endClass;

    /**
     * 终点方法名
     */
    private String endMethod;

    /**
     * 找到的路径总数
     */
    private Integer totalPaths;

    /**
     * 路径列表
     */
    private List<CallPath> paths;

    /**
     * 是否因maxPaths限制而截断
     */
    private Boolean truncated;
}
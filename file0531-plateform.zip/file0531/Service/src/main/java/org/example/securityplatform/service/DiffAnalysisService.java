package org.example.securityplatform.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.diff.*;
import org.example.securityplatform.common.ArtifactStatus;
import org.example.securityplatform.common.TaskStatus;
import org.example.securityplatform.dto.*;
import org.example.securityplatform.entity.*;
import org.example.securityplatform.exception.BusinessException;
import org.example.securityplatform.repository.*;
import org.example.securityplatform.service.analysis.AnalysisEngineService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * 差异分析总控服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DiffAnalysisService {

    private final DiffAnalysisTaskRepository diffTaskRepository;
    private final FileDiffRepository fileDiffRepository;
    private final ApiDiffRepository apiDiffRepository;
    private final MethodCallEdgeRepository methodCallEdgeRepository;
    private final DiffAnalysisProgressRepository progressRepository;
    private final ArtifactRepository artifactRepository;
    private final ApiInfoRepository apiInfoRepository;
    private final DangerFunctionRepository dangerFunctionRepository;
    private final ProjectRepository projectRepository;

    private final AnalysisEngineService analysisEngineService;
    private final DiffReportExporter diffReportExporter;
    private final QuickDiffService quickDiffService;  // 新增：注入QuickDiffService使用共享逻辑

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 创建差异分析任务
     */
    @Transactional
    public Long createDiffAnalysisTask(CreateDiffAnalysisRequest request) {
        log.info("创建差异分析任务: projectId={}, baselineId={}, targetId={}",
                request.getProjectId(), request.getBaselineArtifactId(), request.getTargetArtifactId());

        // 验证制品存在
        Artifact baseline = artifactRepository.findById(request.getBaselineArtifactId())
                .orElseThrow(() -> new BusinessException("基线制品不存在"));
        Artifact target = artifactRepository.findById(request.getTargetArtifactId())
                .orElseThrow(() -> new BusinessException("目标制品不存在"));

        // 创建任务
        DiffAnalysisTask task = new DiffAnalysisTask();
        task.setProjectId(request.getProjectId());
        task.setBaselineArtifactId(request.getBaselineArtifactId());
        task.setTargetArtifactId(request.getTargetArtifactId());
        task.setStatus(TaskStatus.PENDING);
        task.setCreatedAt(LocalDateTime.now());

        DiffAnalysisTask savedTask = diffTaskRepository.save(task);
        log.info("差异分析任务创建成功: taskId={}", savedTask.getId());

        // 初始化进度
        initProgress(savedTask.getId());

        return savedTask.getId();
    }

    /**
     * 异步执行差异分析
     */
    @Async
    @Transactional
    public CompletableFuture<Void> executeDiffAnalysisAsync(Long taskId) {
        log.info("开始执行差异分析: taskId={}", taskId);
        long startTime = System.currentTimeMillis();

        try {
            DiffAnalysisTask task = diffTaskRepository.findById(taskId)
                    .orElseThrow(() -> new RuntimeException("任务不存在: " + taskId));

            // 更新状态
            task.setStatus(TaskStatus.ANALYZING);
            diffTaskRepository.save(task);

            // Step 1: 分析基线制品
            updateProgress(taskId, "BASELINE_ANALYSIS", "正在分析基线制品...", 10);
            ensureArtifactAnalyzed(task.getBaselineArtifactId());

            // Step 2: 分析目标制品
            updateProgress(taskId, "TARGET_ANALYSIS", "正在分析目标制品...", 20);
            ensureArtifactAnalyzed(task.getTargetArtifactId());

            // Step 3: 文件差异检测
            updateProgress(taskId, "FILE_DIFF", "正在检测文件差异...", 30);
            List<FileDiffModel> fileDiffs = detectFileDiffs(task);
            saveFileDiffs(taskId, fileDiffs);
            updateProgress(taskId, "FILE_DIFF", "文件差异检测完成", 40);

            // Step 4: 构建调用图
            updateProgress(taskId, "CALL_GRAPH", "正在构建调用图...", 50);
            List<MethodCallEdge> callEdges = buildCallGraph(task);
            saveCallEdges(task.getTargetArtifactId(), callEdges);
            updateProgress(taskId, "CALL_GRAPH", "调用图构建完成", 60);

            // Step 5: API影响追溯
            updateProgress(taskId, "API_IMPACT", "正在追溯API影响...", 70);
            List<ApiChangeModel> apiChanges = analyzeApiImpact(task, fileDiffs, callEdges);
            saveApiDiffs(taskId, apiChanges);
            updateProgress(taskId, "API_IMPACT", "API影响追溯完成", 80);

            // Step 6: 关联危险函数
            updateProgress(taskId, "DANGER_LINK", "正在关联危险函数...", 85);
            linkDangerFunctions(taskId, task.getTargetArtifactId());

            // 完成
            task.setStatus(TaskStatus.COMPLETED);
            task.setCompletedAt(LocalDateTime.now());
            diffTaskRepository.save(task);

            updateProgress(taskId, "COMPLETED", "分析完成", 100);

            long endTime = System.currentTimeMillis();
            log.info("差异分析完成: taskId={}, 耗时={}ms", taskId, endTime - startTime);

            return CompletableFuture.completedFuture(null);

        } catch (Exception e) {
            log.error("差异分析失败: taskId={}", taskId, e);
            markTaskFailed(taskId, e.getMessage());
            throw new RuntimeException("差异分析失败", e);
        }
    }

    /**
     * 确保制品已分析
     */
    private void ensureArtifactAnalyzed(Long artifactId) {
        Artifact artifact = artifactRepository.findById(artifactId)
                .orElseThrow(() -> new RuntimeException("制品不存在"));

        if (!ArtifactStatus.ANALYZED.equals(artifact.getStatus())) {
            log.info("制品未分析，开始分析: artifactId={}", artifactId);
            analysisEngineService.analyzeArtifact(artifactId);
        }
    }

    /**
     * 检测文件差异
     */
    private List<FileDiffModel> detectFileDiffs(DiffAnalysisTask task) {
        Artifact baseline = artifactRepository.findById(task.getBaselineArtifactId()).orElseThrow();
        Artifact target = artifactRepository.findById(task.getTargetArtifactId()).orElseThrow();

        log.info("检测文件差异: baseline={}, filePath={}, md5={}, target={}, filePath={}, md5={}",
                baseline.getArtifactName(), baseline.getFilePath(), baseline.getMd5(),
                target.getArtifactName(), target.getFilePath(), target.getMd5());

        // 检查是否是同一个文件
        if (baseline.getMd5().equals(target.getMd5())) {
            log.warn("警告：基线和目标制品的MD5相同，文件差异将为0！");
            log.warn("原因：上传了相同的文件，或系统复用了物理文件");
            log.warn("建议：重新上传不同的文件进行差异对比");
        }

        FileDiffDetector detector = new FileDiffDetector(baseline.getFilePath(), target.getFilePath());
        try {
            List<FileDiffModel> diffs = detector.detect();
            log.info("检测结果: {} 个文件差异", diffs.size());
            return diffs;
        } catch (Exception e) {
            log.error("文件差异检测失败", e);
            throw new RuntimeException("文件差异检测失败", e);
        }
    }

    /**
     * 构建调用图
     */
    private List<MethodCallEdge> buildCallGraph(DiffAnalysisTask task) {
        Artifact target = artifactRepository.findById(task.getTargetArtifactId()).orElseThrow();

        try {
            CallGraphBuilder builder = new CallGraphBuilder(target.getFilePath());
            List<MethodCallModel> calls = builder.build();
            // 转换为 MethodCallEdge 列表
            return calls.stream().map(call -> {
                MethodCallEdge edge = new MethodCallEdge();
                edge.setCallerClass(call.getCallerClass());
                edge.setCallerMethod(call.getCallerMethod());
                edge.setCalleeClass(call.getCalleeClass());
                edge.setCalleeMethod(call.getCalleeMethod());
                edge.setCallType(call.getCallType());
                return edge;
            }).collect(Collectors.toList());
        } catch (Exception e) {
            log.error("调用图构建失败", e);
            return new ArrayList<>();
        }
    }

    /**
     * 分析API影响（使用与QuickDiffService相同的共享逻辑）
     */
    private List<ApiChangeModel> analyzeApiImpact(DiffAnalysisTask task,
                                                   List<FileDiffModel> fileDiffs,
                                                   List<MethodCallEdge> callEdges) {
        try {
            // 获取制品文件路径
            Artifact baseline = artifactRepository.findById(task.getBaselineArtifactId()).orElseThrow();
            Artifact target = artifactRepository.findById(task.getTargetArtifactId()).orElseThrow();

            // Step 1: 从JAR文件提取API（使用QuickDiffService的共享逻辑）
            log.info("Step 1: 从JAR文件提取API（使用共享逻辑）");
            List<ApiInfo> baselineApis = quickDiffService.extractApisFromJar(baseline.getFilePath(), "baseline");
            List<ApiInfo> targetApis = quickDiffService.extractApisFromJar(target.getFilePath(), "target");
            log.info("提取到 {} 个基线API, {} 个目标API", baselineApis.size(), targetApis.size());

            // Step 2: 先检测新增和删除的API（使用QuickDiffService的共享逻辑）
            log.info("Step 2: 检测新增和删除的API");
            List<ApiChangeModel> newDeletedApis = quickDiffService.detectNewAndDeletedApis(baselineApis, targetApis);
            log.info("检测到 {} 个新增/删除的API", newDeletedApis.size());

            // Step 3: 提取新增API的Controller方法
            Set<String> newApiControllerMethods = new HashSet<>();
            for (ApiChangeModel change : newDeletedApis) {
                if ("NEW_API".equals(change.getChangeType()) && change.getControllerClass() != null) {
                    String methodKey = change.getControllerClass() + "#" + change.getMethodName();
                    newApiControllerMethods.add(methodKey);
                    log.debug("新增API的Controller方法: {}", methodKey);
                }
            }
            log.info("提取到 {} 个新增API的Controller方法，将过滤这些方法避免重复检测", newApiControllerMethods.size());

            // Step 4: 提取变更方法并过滤（使用QuickDiffService的共享逻辑）
            Set<String> changedMethods = quickDiffService.extractChangedMethods(fileDiffs);
            Set<String> modifiedMethods = changedMethods.stream()
                    .filter(m -> !newApiControllerMethods.contains(m))
                    .collect(Collectors.toSet());
            log.info("过滤前: {} 个变更方法, 过滤后: {} 个真正修改的方法",
                    changedMethods.size(), modifiedMethods.size());

            // Step 5: API影响追溯
            List<ApiChangeModel> apiChanges = new ArrayList<>(newDeletedApis);
            if (!modifiedMethods.isEmpty() && !callEdges.isEmpty() && !targetApis.isEmpty()) {
                ApiImpactAnalyzer analyzer = new ApiImpactAnalyzer(callEdges, targetApis, modifiedMethods);
                List<ApiChangeModel> affectedChanges = analyzer.analyze();
                log.info("API影响追溯检测到 {} 个受影响的API", affectedChanges.size());

                // Step 6: 去重
                Set<String> existingApiKeys = apiChanges.stream()
                        .map(c -> c.getHttpMethod() + " " + c.getApiUrl())
                        .collect(Collectors.toSet());
                for (ApiChangeModel change : affectedChanges) {
                    String key = change.getHttpMethod() + " " + change.getApiUrl();
                    if (!existingApiKeys.contains(key)) {
                        apiChanges.add(change);
                        existingApiKeys.add(key);
                        log.debug("新增受影响API: {} {}", change.getHttpMethod(), change.getApiUrl());
                    } else {
                        log.debug("跳过重复API: {} {}", change.getHttpMethod(), change.getApiUrl());
                    }
                }
            }

            apiChanges = ApiChangeDeduplicator.deduplicate(apiChanges);

            log.info("最终API变更列表: {} 个 (新增: {}, 删除: {}, 修改/受影响: {})",
                    apiChanges.size(),
                    apiChanges.stream().filter(c -> "NEW_API".equals(c.getChangeType())).count(),
                    apiChanges.stream().filter(c -> "DELETED_API".equals(c.getChangeType())).count(),
                    apiChanges.stream().filter(c -> "MODIFIED_API".equals(c.getChangeType()) || "AFFECTED_API".equals(c.getChangeType())).count());

            return apiChanges;
        } catch (Exception e) {
            log.error("API影响分析失败", e);
            throw new RuntimeException("API影响分析失败", e);
        }
    }

    /**
     * 保存文件差异
     */
    @Transactional
    public void saveFileDiffs(Long taskId, List<FileDiffModel> fileDiffs) {
        for (FileDiffModel model : fileDiffs) {
            FileDiff entity = new FileDiff();
            entity.setDiffTaskId(taskId);
            entity.setFilePath(model.getFilePath());
            entity.setSourceFilePath(model.getSourceFilePath());
            entity.setDiffType(model.getDiffType());
            entity.setBaselineLines(model.getBaselineLines());
            entity.setTargetLines(model.getTargetLines());
            entity.setAddedLines(model.getAddedLines());
            entity.setDeletedLines(model.getDeletedLines());
            entity.setMethodsAdded(model.getMethodsAdded());
            entity.setMethodsDeleted(model.getMethodsDeleted());
            entity.setMethodsModified(model.getMethodsModified());
            fileDiffRepository.save(entity);
        }
        log.info("保存 {} 条文件差异记录", fileDiffs.size());
    }

    /**
     * 保存调用边
     */
    @Transactional
    public void saveCallEdges(Long artifactId, List<MethodCallEdge> edges) {
        for (MethodCallEdge edge : edges) {
            edge.setArtifactId(artifactId);
            methodCallEdgeRepository.save(edge);
        }
        log.info("保存 {} 条调用边记录", edges.size());
    }

    /**
     * 保存API差异
     */
    @Transactional
    public void saveApiDiffs(Long taskId, List<ApiChangeModel> apiChanges) {
        for (ApiChangeModel model : apiChanges) {
            ApiDiff entity = new ApiDiff();
            entity.setDiffTaskId(taskId);
            entity.setApiUrl(model.getApiUrl());
            entity.setHttpMethod(model.getHttpMethod());
            entity.setControllerClass(model.getControllerClass());
            entity.setMethodName(model.getMethodName());
            entity.setChangeType(model.getChangeType());
            entity.setChangeReason(model.getChangeReason());

            try {
                if (model.getCallChain() != null && !model.getCallChain().isEmpty()) {
                    entity.setCallChain(objectMapper.writeValueAsString(model.getCallChain()));
                }
            } catch (JsonProcessingException e) {
                log.warn("序列化调用链失败", e);
            }

            apiDiffRepository.save(entity);
        }
        log.info("保存 {} 条API差异记录", apiChanges.size());
    }

    /**
     * 关联危险函数
     */
    @Transactional
    public void linkDangerFunctions(Long taskId, Long artifactId) {
        List<ApiDiff> apiDiffs = apiDiffRepository.findByDiffTaskId(taskId);
        List<DangerFunction> dangerFunctions = dangerFunctionRepository.findByArtifactId(artifactId);

        // 构建危险函数索引（按类名）
        Map<String, List<DangerFunction>> dangerByClass = dangerFunctions.stream()
                .collect(Collectors.groupingBy(DangerFunction::getClassName));

        for (ApiDiff apiDiff : apiDiffs) {
            List<String> relatedDangers = new ArrayList<>();

            // 检查控制器类是否有危险函数
            if (apiDiff.getControllerClass() != null) {
                String className = apiDiff.getControllerClass().replace('.', '/');
                List<DangerFunction> dangers = dangerByClass.get(className);
                if (dangers != null) {
                    for (DangerFunction df : dangers) {
                        relatedDangers.add(df.getFunctionName() + ":" + df.getFunctionType());
                    }
                }
            }

            if (!relatedDangers.isEmpty()) {
                try {
                    apiDiff.setDangerFunctions(objectMapper.writeValueAsString(relatedDangers));
                    apiDiffRepository.save(apiDiff);
                } catch (JsonProcessingException e) {
                    log.warn("序列化危险函数列表失败", e);
                }
            }
        }
    }

    /**
     * 初始化进度
     */
    private void initProgress(Long taskId) {
        DiffAnalysisProgress progress = new DiffAnalysisProgress();
        progress.setDiffTaskId(taskId);
        progress.setCurrentStep("初始化");
        progress.setStepStatus("PENDING");
        progress.setProgressPercentage(0);
        progress.setUpdatedAt(LocalDateTime.now());
        progressRepository.save(progress);
    }

    /**
     * 更新进度
     */
    private void updateProgress(Long taskId, String step, String message, int progress) {
        List<DiffAnalysisProgress> progressList = progressRepository.findByDiffTaskId(taskId);
        if (!progressList.isEmpty()) {
            DiffAnalysisProgress p = progressList.get(0);
            p.setCurrentStep(step);
            p.setMessage(message);
            p.setProgressPercentage(progress);
            // 根据进度百分比判断状态
            if (progress >= 100) {
                p.setStepStatus("COMPLETED");
            } else {
                p.setStepStatus("IN_PROGRESS");
            }
            p.setUpdatedAt(LocalDateTime.now());
            progressRepository.save(p);
        }
        log.info("差异分析进度更新: taskId={}, step={}, progress={}%", taskId, step, progress);
    }

    /**
     * 标记任务失败
     */
    private void markTaskFailed(Long taskId, String errorMessage) {
        diffTaskRepository.findById(taskId).ifPresent(task -> {
            task.setStatus(TaskStatus.FAILED);
            task.setCompletedAt(LocalDateTime.now());
            diffTaskRepository.save(task);
        });

        List<DiffAnalysisProgress> progressList = progressRepository.findByDiffTaskId(taskId);
        if (!progressList.isEmpty()) {
            DiffAnalysisProgress p = progressList.get(0);
            p.setStepStatus("FAILED");
            p.setCurrentStep(errorMessage);
            p.setUpdatedAt(LocalDateTime.now());
            progressRepository.save(p);
        }
    }

    /**
     * 获取差异分析结果
     */
    public DiffAnalysisResultResponse getDiffResult(Long taskId) {
        DiffAnalysisTask task = diffTaskRepository.findById(taskId)
                .orElseThrow(() -> new BusinessException("任务不存在"));

        DiffAnalysisResultResponse response = new DiffAnalysisResultResponse();
        response.setDiffTaskId(taskId);
        response.setStatus(task.getStatus());

        // 获取制品信息
        artifactRepository.findById(task.getBaselineArtifactId())
                .ifPresent(a -> response.setBaseline(toArtifactSummary(a)));
        artifactRepository.findById(task.getTargetArtifactId())
                .ifPresent(a -> response.setTarget(toArtifactSummary(a)));

        // 获取文件差异
        List<FileDiff> fileDiffs = fileDiffRepository.findByDiffTaskId(taskId);
        response.setFileDiffs(fileDiffs.stream().map(this::toFileDiffSummary).collect(Collectors.toList()));

        // 获取API差异
        List<ApiDiff> apiDiffs = apiDiffRepository.findByDiffTaskId(taskId);
        response.setApiDiffs(apiDiffs.stream().map(this::toApiDiffSummary).collect(Collectors.toList()));

        // 计算统计
        response.setSummary(calculateSummary(fileDiffs, apiDiffs));

        return response;
    }

    /**
     * 获取进度
     */
    public DiffAnalysisProgressResponse getProgress(Long taskId) {
        List<DiffAnalysisProgress> progressList = progressRepository.findByDiffTaskId(taskId);
        if (progressList.isEmpty()) {
            throw new BusinessException("进度信息不存在");
        }
        DiffAnalysisProgress progress = progressList.get(0);

        DiffAnalysisProgressResponse response = new DiffAnalysisProgressResponse();
        response.setDiffTaskId(taskId);
        response.setStatus(progress.getStepStatus());
        response.setCurrentStep(progress.getCurrentStep());
        response.setProgress(progress.getProgressPercentage());
        return response;
    }

    /**
     * 导出报告
     */
    public byte[] exportReport(Long taskId) {
        DiffAnalysisResultResponse result = getDiffResult(taskId);
        try {
            return diffReportExporter.exportToExcel(result);
        } catch (Exception e) {
            log.error("导出报告失败: taskId={}", taskId, e);
            throw new BusinessException("导出报告失败: " + e.getMessage());
        }
    }

    // ==================== 辅助方法 ====================

    private DiffAnalysisResultResponse.ArtifactSummary toArtifactSummary(Artifact artifact) {
        DiffAnalysisResultResponse.ArtifactSummary summary = new DiffAnalysisResultResponse.ArtifactSummary();
        summary.setArtifactId(artifact.getId());
        summary.setArtifactName(artifact.getArtifactName());
        summary.setFileSize(artifact.getFileSize());
        return summary;
    }

    private FileDiffSummary toFileDiffSummary(FileDiff entity) {
        FileDiffSummary summary = new FileDiffSummary();
        summary.setId(entity.getId());
        summary.setFilePath(entity.getFilePath());
        summary.setSourceFilePath(entity.getSourceFilePath());
        summary.setDiffType(entity.getDiffType());
        summary.setBaselineLines(entity.getBaselineLines());
        summary.setTargetLines(entity.getTargetLines());
        summary.setAddedLines(entity.getAddedLines());
        summary.setDeletedLines(entity.getDeletedLines());
        summary.setMethodsAdded(entity.getMethodsAdded());
        summary.setMethodsDeleted(entity.getMethodsDeleted());
        summary.setMethodsModified(entity.getMethodsModified());
        return summary;
    }

    private ApiDiffSummary toApiDiffSummary(ApiDiff entity) {
        ApiDiffSummary summary = new ApiDiffSummary();
        summary.setId(entity.getId());
        summary.setApiUrl(entity.getApiUrl());
        summary.setHttpMethod(entity.getHttpMethod());
        summary.setControllerClass(entity.getControllerClass());
        summary.setMethodName(entity.getMethodName());
        summary.setChangeType(entity.getChangeType());
        summary.setChangeReason(entity.getChangeReason());

        // 解析调用链
        if (entity.getCallChain() != null) {
            try {
                List<ApiDiffSummary.CallChainNode> nodes = objectMapper.readValue(
                        entity.getCallChain(),
                        objectMapper.getTypeFactory().constructCollectionType(
                                List.class, ApiDiffSummary.CallChainNode.class));
                summary.setCallChain(nodes);
            } catch (JsonProcessingException e) {
                log.warn("解析调用链失败", e);
            }
        }

        return summary;
    }

    private DiffAnalysisResultResponse.DiffSummary calculateSummary(List<FileDiff> fileDiffs, List<ApiDiff> apiDiffs) {
        DiffAnalysisResultResponse.DiffSummary summary = new DiffAnalysisResultResponse.DiffSummary();

        // 文件统计
        for (FileDiff fd : fileDiffs) {
            switch (fd.getDiffType()) {
                case "ADDED": summary.setAddedFiles(summary.getAddedFiles() + 1); break;
                case "MODIFIED": summary.setModifiedFiles(summary.getModifiedFiles() + 1); break;
                case "DELETED": summary.setDeletedFiles(summary.getDeletedFiles() + 1); break;
            }
        }

        // API统计
        for (ApiDiff ad : apiDiffs) {
            switch (ad.getChangeType()) {
                case "NEW_API": summary.setNewApis(summary.getNewApis() + 1); break;
                case "MODIFIED_API": summary.setModifiedApis(summary.getModifiedApis() + 1); break;
                case "AFFECTED_API": summary.setAffectedApis(summary.getAffectedApis() + 1); break;
                case "DELETED_API": summary.setDeletedApis(summary.getDeletedApis() + 1); break;
            }
        }

        return summary;
    }

    /**
     * 获取变更影响图谱
     */
    public ImpactGraphResponse getImpactGraph(Long taskId, ImpactGraphFilterRequest filter) {
        DiffAnalysisTask task = diffTaskRepository.findById(taskId)
                .orElseThrow(() -> new BusinessException("任务不存在: " + taskId));

        List<MethodChange> changes = new ArrayList<>();
        List<AffectedNode> affected = new ArrayList<>();
        List<ApiNode> apis = new ArrayList<>();
        List<CallEdge> callEdges = new ArrayList<>();
        List<ImpactEdge> impactEdges = new ArrayList<>();

        // 获取API差异作为API节点
        List<ApiDiff> apiDiffs = apiDiffRepository.findByDiffTaskId(taskId);
        log.info("任务 {} 共有 {} 个API差异", taskId, apiDiffs.size());

        for (ApiDiff api : apiDiffs) {
            apis.add(ApiNode.builder()
                    .id(api.getId())
                    .apiUrl(api.getApiUrl())
                    .httpMethod(api.getHttpMethod())
                    .controllerClass(api.getControllerClass())
                    .methodName(api.getMethodName())
                    .changeType(api.getChangeType())
                    .build());
        }

        // 简化实现：基于文件差异构建变更节点
        List<FileDiff> fileDiffs = fileDiffRepository.findByDiffTaskId(taskId);
        log.info("任务 {} 共有 {} 个文件差异", taskId, fileDiffs.size());

        long changeId = 1L;
        for (FileDiff fileDiff : fileDiffs) {
            // 创建修改方法变更节点
            int modifiedMethods = fileDiff.getMethodsModified() != null ? fileDiff.getMethodsModified() : 0;
            if (modifiedMethods > 0) {
                MethodChange change = MethodChange.builder()
                        .id(changeId)
                        .className(extractClassName(fileDiff.getFilePath()))
                        .methodName("modifiedMethod" + changeId)
                        .changeType("MODIFIED")
                        .impactDepth(2)
                        .affectedApis(modifiedMethods)
                        .build();
                changes.add(change);

                // 创建从变更到API的影响边（简化：随机关联一些API）
                if (!apis.isEmpty()) {
                    int numEdges = Math.min(modifiedMethods, apis.size());
                    for (int i = 0; i < numEdges; i++) {
                        ApiNode api = apis.get(i % apis.size());
                        impactEdges.add(ImpactEdge.builder()
                                .id((long) impactEdges.size() + 1)
                                .sourceId(changeId)
                                .targetId(api.getId())
                                .build());
                    }
                }

                changeId++;
            }
        }

        log.info("变更影响图谱: {} 个变更节点, {} 个API节点, {} 条影响边",
                changes.size(), apis.size(), impactEdges.size());

        return ImpactGraphResponse.builder()
                .changes(changes)
                .affected(affected)
                .apis(apis)
                .callEdges(callEdges)
                .impactEdges(impactEdges)
                .build();
    }

    /**
     * 从文件路径提取类名
     */
    private String extractClassName(String filePath) {
        if (filePath == null) return "Unknown";
        int lastSlash = filePath.lastIndexOf('/');
        if (lastSlash < 0) lastSlash = filePath.lastIndexOf('\\');
        if (lastSlash >= 0 && lastSlash < filePath.length() - 1) {
            return filePath.substring(lastSlash + 1);
        }
        return filePath;
    }
}

package org.example.securityplatform.analyzer.mybatis;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * MyBatis Mapper模型
 * 表示一个Mapper XML文件的内容
 */
@Data
public class MyBatisMapperModel {

    /**
     * Mapper命名空间（通常是接口类全名）
     */
    private String namespace;

    /**
     * XML文件路径
     */
    private String filePath;

    /**
     * SQL语句列表
     */
    private List<SqlStatement> statements = new ArrayList<>();

    /**
     * SQL片段映射表（<sql id="...">片段内容）
     * key: fragment id
     * value: SQL片段内容
     */
    private Map<String, String> sqlFragments = new HashMap<>();

    /**
     * SQL语句模型
     */
    @Data
    public static class SqlStatement {
        /**
         * statement id（方法名）
         */
        private String id;

        /**
         * 语句类型：SELECT, INSERT, UPDATE, DELETE
         */
        private String type;

        /**
         * SQL文本内容
         */
        private String sql;

        /**
         * 行号
         */
        private Integer lineNumber;

        /**
         * 包含${}占位符的参数列表
         */
        private List<String> dollarParams = new ArrayList<>();
    }
}
package org.example.securityplatform.repository;

import org.example.securityplatform.entity.Artifact;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * 制品数据访问接口
 */
@Repository
public interface ArtifactRepository extends JpaRepository<Artifact, Long> {
    List<Artifact> findByTaskId(Long taskId);
    List<Artifact> findByStatus(String status);
    Optional<Artifact> findByTaskIdAndArtifactName(Long taskId, String artifactName);

    /**
     * 根据MD5查询所有匹配的制品记录
     * 注意：多个制品可能共享相同MD5（复用物理文件）
     */
    List<Artifact> findByMd5(String md5);

    /**
     * 查询taskId为null的制品（差异分析场景）
     */
    List<Artifact> findByTaskIdIsNull();

    /**
     * 根据任务ID删除所有关联的制品
     * 用于任务删除时的级联清理
     */
    @Modifying(clearAutomatically = true)
    void deleteByTaskId(Long taskId);
}
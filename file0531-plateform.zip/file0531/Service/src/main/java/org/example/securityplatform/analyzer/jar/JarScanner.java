package org.example.securityplatform.analyzer.jar;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.core.AnalysisException;
import org.example.securityplatform.analyzer.core.AnalysisErrorCode;

import java.io.IOException;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Collectors;

/**
 * JAR扫描器
 * 统一JAR扫描逻辑，消除QuickDiffService和TaintAnalysisService中的重复代码
 */
@Slf4j
public class JarScanner {

    private final FrameworkPackageFilter frameworkFilter;
    private final PackageExtractor packageExtractor;

    public JarScanner() {
        this.frameworkFilter = new FrameworkPackageFilter();
        this.packageExtractor = new PackageExtractor();
    }

    public JarScanner(FrameworkPackageFilter frameworkFilter, PackageExtractor packageExtractor) {
        this.frameworkFilter = frameworkFilter;
        this.packageExtractor = packageExtractor;
    }

    /**
     * 扫描依赖JAR列表
     * 从Spring Boot Fat JAR中扫描BOOT-INF/lib/和WEB-INF/lib/下的依赖JAR
     *
     * @param jarPath JAR文件路径
     * @return 依赖JAR名称列表
     */
    public List<String> scanDependencyJars(String jarPath) {
        List<String> dependencyJars = new ArrayList<>();

        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jarFile.entries();

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();

                if ((name.startsWith("BOOT-INF/lib/") || name.startsWith("WEB-INF/lib/"))
                        && name.endsWith(".jar")) {
                    dependencyJars.add(name);
                }
            }
        } catch (IOException e) {
            throw new AnalysisException(
                    AnalysisErrorCode.JAR_PARSE_ERROR,
                    "扫描依赖JAR失败: " + jarPath,
                    e
            );
        }

        log.info("扫描到 {} 个依赖JAR: {}", dependencyJars.size(), jarPath);
        return dependencyJars;
    }

    /**
     * 扫描业务包名列表
     *
     * @param jarPath          JAR文件路径
     * @param excludeFramework 是否排除框架包
     * @return 业务包名列表
     */
    public List<String> scanBusinessPackages(String jarPath, boolean excludeFramework) {
        List<String> classPaths = new ArrayList<>();

        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jarFile.entries();

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();

                if (name.endsWith(".class") && !entry.isDirectory()) {
                    classPaths.add(name);
                }
            }
        } catch (IOException e) {
            throw new AnalysisException(
                    AnalysisErrorCode.JAR_PARSE_ERROR,
                    "扫描类文件失败: " + jarPath,
                    e
            );
        }

        if (excludeFramework) {
            return packageExtractor.extractBusinessPackages(classPaths, frameworkFilter);
        } else {
            return classPaths.stream()
                    .map(packageExtractor::extractPackageName)
                    .filter(Objects::nonNull)
                    .distinct()
                    .sorted()
                    .collect(Collectors.toList());
        }
    }

    /**
     * 扫描JAR中所有类路径
     *
     * @param jarPath JAR文件路径
     * @return 类路径列表
     */
    public List<String> scanClassPaths(String jarPath) {
        List<String> classPaths = new ArrayList<>();

        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jarFile.entries();

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();

                if (name.endsWith(".class") && !entry.isDirectory()) {
                    classPaths.add(name);
                }
            }
        } catch (IOException e) {
            throw new AnalysisException(
                    AnalysisErrorCode.JAR_PARSE_ERROR,
                    "扫描类路径失败: " + jarPath,
                    e
            );
        }

        return classPaths;
    }
}

package org.example.securityplatform.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.entity.DangerFunctionRule;
import org.example.securityplatform.repository.DangerFunctionRuleRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 危险函数规则初始化器
 * 在应用启动时检查并初始化默认规则
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DangerFunctionRuleInitializer implements CommandLineRunner {

    private final DangerFunctionRuleRepository ruleRepository;

    @Override
    public void run(String... args) {
        if (ruleRepository.count() == 0) {
            log.info("初始化默认危险函数规则...");
            initDefaultRules();
            log.info("默认危险函数规则初始化完成");
        }
    }

    private void initDefaultRules() {
        List<DangerFunctionRule> defaultRules = List.of(
            // 命令执行规则
            createRule(
                "Runtime.exec",
                "COMMAND_EXECUTION",
                "java/lang/Runtime",
                "exec",
                "Runtime.exec() 可执行系统命令",
                "HIGH",
                "命令注入可导致远程代码执行(RCE)",
                "使用 ProcessBuilder 并进行严格的输入验证",
                "CWE-78"
            ),
            createRule(
                "ProcessBuilder.start",
                "COMMAND_EXECUTION",
                "java/lang/ProcessBuilder",
                "start",
                "ProcessBuilder.start() 可执行系统命令",
                "HIGH",
                "命令注入可导致远程代码执行(RCE)",
                "验证并清理所有输入参数",
                "CWE-78"
            ),

            // 反序列化规则
            createRule(
                "ObjectInputStream.readObject",
                "DESERIALIZATION",
                "*ObjectInputStream",
                "readObject",
                "ObjectInputStream.readObject() 反序列化操作",
                "HIGH",
                "不安全的反序列化可导致远程代码执行",
                "避免反序列化不可信数据；使用安全替代方案",
                "CWE-502"
            ),
            createRule(
                "ObjectInputStream.readUnshared",
                "DESERIALIZATION",
                "*ObjectInputStream",
                "readUnshared",
                "ObjectInputStream.readUnshared() 反序列化操作",
                "HIGH",
                "不安全的反序列化可导致远程代码执行",
                "验证输入并使用白名单",
                "CWE-502"
            ),

            // 文件操作规则
            createRule(
                "FileInputStream",
                "FILE_IO",
                "*FileInputStream",
                "*",
                "FileInputStream 文件读取操作",
                "MEDIUM",
                "未授权的文件访问可能导致敏感信息泄露",
                "验证文件路径并强制执行访问控制",
                "CWE-22"
            ),
            createRule(
                "FileOutputStream",
                "FILE_IO",
                "*FileOutputStream",
                "*",
                "FileOutputStream 文件写入操作",
                "MEDIUM",
                "未授权的文件修改可能导致数据损坏",
                "验证文件路径和权限",
                "CWE-22"
            ),
            createRule(
                "Files operations",
                "FILE_IO",
                "java/nio/file/Files",
                "*",
                "NIO 文件操作",
                "MEDIUM",
                "路径遍历漏洞可能导致任意文件读写",
                "清理文件路径并使用安全方法",
                "CWE-22"
            ),
            createRule(
                "RandomAccessFile",
                "FILE_IO",
                "*RandomAccessFile",
                "*",
                "RandomAccessFile 随机访问文件操作",
                "MEDIUM",
                "任意文件读写可能导致数据泄露或损坏",
                "限制文件访问并进行验证",
                "CWE-22"
            )
        );

        ruleRepository.saveAll(defaultRules);
    }

    private DangerFunctionRule createRule(String ruleName, String functionType,
            String classPattern, String methodPattern, String description,
            String riskLevel, String securityImpact, String remediation, String cweId) {
        DangerFunctionRule rule = new DangerFunctionRule();
        rule.setRuleName(ruleName);
        rule.setFunctionType(functionType);
        rule.setClassPattern(classPattern);
        rule.setMethodPattern(methodPattern);
        rule.setDescription(description);
        rule.setRiskLevel(riskLevel);
        rule.setSecurityImpact(securityImpact);
        rule.setRemediation(remediation);
        rule.setCweId(cweId);
        rule.setEnabled(true);
        return rule;
    }
}

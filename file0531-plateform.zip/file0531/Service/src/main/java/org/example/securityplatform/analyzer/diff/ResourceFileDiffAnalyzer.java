package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Analyzer for non-Java resource files (config files, SQL scripts, XML, etc.)
 * Performs exact line diff for normal files and bounded approximate diff for
 * very large files.
 */
@Slf4j
public class ResourceFileDiffAnalyzer {

    private static final long EXACT_LCS_CELL_LIMIT = 1_000_000L;

    /**
     * Analyze line counts for resource file diff
     *
     * @param baselineStream baseline version content (null if new file)
     * @param targetStream target version content (null if deleted file)
     * @param filePath file path being analyzed
     * @return ResourceDiffResult with line counts
     */
    public ResourceDiffResult analyze(InputStream baselineStream,
                                       InputStream targetStream,
                                       String filePath) {
        ResourceDiffResult result = new ResourceDiffResult();
        result.setFilePath(filePath);

        try {
            List<String> baselineContent = baselineStream != null
                    ? readLines(baselineStream)
                    : List.of();
            List<String> targetContent = targetStream != null
                    ? readLines(targetStream)
                    : List.of();

            int baselineLines = baselineContent.size();
            int targetLines = targetContent.size();
            result.setBaselineLines(baselineLines);
            result.setTargetLines(targetLines);

            if (baselineStream != null && targetStream != null) {
                int commonLines = countCommonLines(baselineContent, targetContent);
                result.setAddedLines(targetLines - commonLines);
                result.setDeletedLines(baselineLines - commonLines);
            } else if (baselineStream == null && targetStream != null) {
                result.setAddedLines(targetLines);
                result.setDeletedLines(0);
            } else if (baselineStream != null && targetStream == null) {
                result.setAddedLines(0);
                result.setDeletedLines(baselineLines);
            } else {
                result.setAddedLines(0);
                result.setDeletedLines(0);
            }

            log.debug("Resource file analysis complete: {}", filePath);
        } catch (IOException e) {
            log.warn("Failed to count lines: {}", filePath, e);
            result.setBaselineLines(0);
            result.setTargetLines(0);
            result.setAddedLines(0);
            result.setDeletedLines(0);
        }

        return result;
    }

    /**
     * Read lines in UTF-8. Resource files in this analyzer are expected to be text.
     */
    private List<String> readLines(InputStream inputStream) throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            List<String> lines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            return lines;
        }
    }

    private int countCommonLines(List<String> baselineLines, List<String> targetLines) {
        long cells = (long) baselineLines.size() * (long) targetLines.size();
        if (cells <= EXACT_LCS_CELL_LIMIT) {
            return longestCommonSubsequenceSize(baselineLines, targetLines);
        }

        log.info("Resource diff too large for exact LCS, using bounded line-frequency diff: "
                        + "baselineLines={}, targetLines={}, cells={}",
                baselineLines.size(), targetLines.size(), cells);
        return lineFrequencyCommonCount(baselineLines, targetLines);
    }

    private int longestCommonSubsequenceSize(List<String> baselineLines, List<String> targetLines) {
        int[] previous = new int[targetLines.size() + 1];
        int[] current = new int[targetLines.size() + 1];

        for (String baselineLine : baselineLines) {
            for (int j = 0; j < targetLines.size(); j++) {
                if (baselineLine.equals(targetLines.get(j))) {
                    current[j + 1] = previous[j] + 1;
                } else {
                    current[j + 1] = Math.max(previous[j + 1], current[j]);
                }
            }
            int[] tmp = previous;
            previous = current;
            current = tmp;
            java.util.Arrays.fill(current, 0);
        }

        return previous[targetLines.size()];
    }

    private int lineFrequencyCommonCount(List<String> baselineLines, List<String> targetLines) {
        Map<String, Integer> baselineCounts = new HashMap<>();
        for (String line : baselineLines) {
            baselineCounts.merge(line, 1, Integer::sum);
        }

        int commonLines = 0;
        for (String line : targetLines) {
            Integer count = baselineCounts.get(line);
            if (count != null && count > 0) {
                commonLines++;
                if (count == 1) {
                    baselineCounts.remove(line);
                } else {
                    baselineCounts.put(line, count - 1);
                }
            }
        }

        return commonLines;
    }
}

package org.example.securityplatform.analyzer.graph;

import lombok.extern.slf4j.Slf4j;

import java.util.*;

/**
 * 调用图遍历器
 * 提供DFS和BFS标准实现，用于查找方法间的调用路径
 */
@Slf4j
public class CallGraphTraverser {

    /** 最大搜索深度 */
    private final int maxDepth;

    public CallGraphTraverser() {
        this.maxDepth = 20;
    }

    public CallGraphTraverser(int maxDepth) {
        this.maxDepth = maxDepth;
    }

    /**
     * BFS查找最短路径
     *
     * @param graph 正向调用图 Map<调用者键, List<被调用者键>>
     * @param start 起始方法键
     * @param end   目标方法键
     * @return 最短路径（从start到end），如果找不到返回null
     */
    public List<String> bfsFindShortestPath(Map<String, List<String>> graph, String start, String end) {
        if (start.equals(end)) {
            return Collections.singletonList(start);
        }

        Queue<List<String>> queue = new LinkedList<>();
        Set<String> visited = new HashSet<>();

        queue.offer(Collections.singletonList(start));
        visited.add(start);

        while (!queue.isEmpty()) {
            List<String> path = queue.poll();
            String current = path.get(path.size() - 1);

            if (path.size() > maxDepth) {
                continue;
            }

            List<String> neighbors = graph.get(current);
            if (neighbors == null) {
                continue;
            }

            for (String neighbor : neighbors) {
                if (neighbor.equals(end)) {
                    List<String> result = new ArrayList<>(path);
                    result.add(neighbor);
                    return result;
                }

                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    List<String> newPath = new ArrayList<>(path);
                    newPath.add(neighbor);
                    queue.offer(newPath);
                }
            }
        }

        return null;
    }

    /**
     * DFS查找所有路径
     *
     * @param graph 正向调用图
     * @param start 起始方法键
     * @param end   目标方法键
     * @return 所有路径列表
     */
    public List<List<String>> dfsFindAllPaths(Map<String, List<String>> graph, String start, String end) {
        List<List<String>> allPaths = new ArrayList<>();
        List<String> currentPath = new ArrayList<>();
        Set<String> visited = new HashSet<>();

        dfsBacktrack(graph, start, end, currentPath, visited, allPaths);

        return allPaths;
    }

    /**
     * DFS回溯算法查找所有路径
     */
    private void dfsBacktrack(Map<String, List<String>> graph, String current, String end,
                               List<String> currentPath, Set<String> visited, List<List<String>> allPaths) {
        // 深度限制
        if (currentPath.size() >= maxDepth) {
            return;
        }

        currentPath.add(current);

        // 找到目标
        if (current.equals(end)) {
            allPaths.add(new ArrayList<>(currentPath));
            currentPath.remove(currentPath.size() - 1);
            return;
        }

        // 循环检测
        if (visited.contains(current)) {
            currentPath.remove(currentPath.size() - 1);
            return;
        }
        visited.add(current);

        // 遍历邻居
        List<String> neighbors = graph.get(current);
        if (neighbors != null) {
            for (String neighbor : neighbors) {
                dfsBacktrack(graph, neighbor, end, currentPath, visited, allPaths);
            }
        }

        // 回溯
        visited.remove(current);
        currentPath.remove(currentPath.size() - 1);
    }

    /**
     * 反向BFS查找最短路径
     *
     * @param reverseGraph 反向调用图 Map<被调用者键, List<调用者键>>
     * @param start        起始方法键（被调用者）
     * @param end          目标方法键（顶层调用者）
     * @return 最短路径（从start到end的反向路径）
     */
    public List<String> bfsFindShortestPathReverse(Map<String, List<String>> reverseGraph, String start, String end) {
        if (start.equals(end)) {
            return Collections.singletonList(start);
        }

        Queue<List<String>> queue = new LinkedList<>();
        Set<String> visited = new HashSet<>();

        queue.offer(Collections.singletonList(start));
        visited.add(start);

        while (!queue.isEmpty()) {
            List<String> path = queue.poll();
            String current = path.get(path.size() - 1);

            if (path.size() > maxDepth) {
                continue;
            }

            List<String> callers = reverseGraph.get(current);
            if (callers == null) {
                continue;
            }

            for (String caller : callers) {
                if (caller.equals(end)) {
                    List<String> result = new ArrayList<>(path);
                    result.add(caller);
                    return result;
                }

                if (!visited.contains(caller)) {
                    visited.add(caller);
                    List<String> newPath = new ArrayList<>(path);
                    newPath.add(caller);
                    queue.offer(newPath);
                }
            }
        }

        return null;
    }
}

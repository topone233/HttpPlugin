package org.example.securityplatform.dto;

import lombok.Data;

import java.util.List;

/**
 * 单条调用路径
 */
@Data
public class CallPath {

    /**
     * 调用链节点列表
     */
    private List<CallNode> nodes;

    /**
     * 路径深度（节点数-1）
     */
    private Integer depth;
}
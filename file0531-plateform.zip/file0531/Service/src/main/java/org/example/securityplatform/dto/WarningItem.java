package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 风险预警项DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WarningItem {
    private Long id;
    private String level; // HIGH | MEDIUM | LOW
    private String type; // SECURITY | COMPATIBILITY | PERFORMANCE
    private String title;
    private String description;
    private String className;
    private String methodName;
}
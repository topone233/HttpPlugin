package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 受影响节点DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AffectedNode {
    private Long id;
    private String className;
    private String methodName;
    private String methodDesc;
    private String riskLevel; // HIGH | MEDIUM | LOW
    private Integer depth; // 调用深度
    private List<Long> callerIds; // 调用者ID列表
}
package org.example.securityplatform.analyzer.diff;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Shared API change de-duplication used by quick diff and formal diff analysis.
 */
public final class ApiChangeDeduplicator {

    private ApiChangeDeduplicator() {
    }

    public static List<ApiChangeModel> deduplicate(List<ApiChangeModel> changes) {
        if (changes == null || changes.isEmpty()) {
            return new ArrayList<>();
        }

        Map<String, ApiChangeModel> uniqueChanges = new LinkedHashMap<>();
        int unkeyedIndex = 0;

        for (ApiChangeModel change : changes) {
            if (change == null) {
                continue;
            }

            String key = getDeduplicationKey(change);
            if (key == null) {
                key = "__unkeyed__:" + unkeyedIndex++;
            }

            ApiChangeModel existing = uniqueChanges.get(key);
            if (existing == null) {
                uniqueChanges.put(key, change);
                continue;
            }

            if (priority(change.getChangeType()) > priority(existing.getChangeType())) {
                mergeSupplementalDetails(change, existing);
                uniqueChanges.put(key, change);
            } else {
                mergeSupplementalDetails(existing, change);
            }
        }

        return new ArrayList<>(uniqueChanges.values());
    }

    static String getDeduplicationKey(ApiChangeModel change) {
        if (hasText(change.getHttpMethod()) && hasText(change.getApiUrl())) {
            return "route:" + change.getHttpMethod().trim().toUpperCase()
                    + " " + change.getApiUrl().trim();
        }

        if (hasText(change.getControllerClass()) && hasText(change.getMethodName())) {
            return "method:" + change.getControllerClass().trim()
                    + "#" + change.getMethodName().trim();
        }

        return null;
    }

    static int priority(String changeType) {
        if ("NEW_API".equals(changeType) || "DELETED_API".equals(changeType)) {
            return 3;
        }
        if ("MODIFIED_API".equals(changeType)) {
            return 2;
        }
        if ("AFFECTED_API".equals(changeType)) {
            return 1;
        }
        return 0;
    }

    private static void mergeSupplementalDetails(ApiChangeModel target, ApiChangeModel source) {
        target.setCallChain(target.getCallChain() == null
                ? new ArrayList<>()
                : new ArrayList<>(target.getCallChain()));
        if (source.getCallChain() != null) {
            Set<String> existingChainKeys = new LinkedHashSet<>();
            for (ApiChangeModel.CallChainNode node : target.getCallChain()) {
                existingChainKeys.add(callChainKey(node));
            }
            for (ApiChangeModel.CallChainNode node : source.getCallChain()) {
                if (existingChainKeys.add(callChainKey(node))) {
                    target.getCallChain().add(node);
                }
            }
        }

        if (source.getRelatedFiles() != null && !source.getRelatedFiles().isEmpty()) {
            if (target.getRelatedFiles() == null) {
                target.setRelatedFiles(new ArrayList<>());
            }
            Set<String> relatedFiles = new LinkedHashSet<>(target.getRelatedFiles());
            relatedFiles.addAll(source.getRelatedFiles());
            target.setRelatedFiles(new ArrayList<>(relatedFiles));
        }

        if (source.getDangerFunctions() != null && !source.getDangerFunctions().isEmpty()) {
            if (target.getDangerFunctions() == null) {
                target.setDangerFunctions(new ArrayList<>());
            }
            Set<ApiChangeModel.DangerFunctionRef> dangerFunctions =
                    new LinkedHashSet<>(target.getDangerFunctions());
            dangerFunctions.addAll(source.getDangerFunctions());
            target.setDangerFunctions(new ArrayList<>(dangerFunctions));
        }
    }

    private static String callChainKey(ApiChangeModel.CallChainNode node) {
        if (node == null) {
            return "null";
        }
        return String.valueOf(node.getClassName()) + "#"
                + String.valueOf(node.getMethodName()) + "#"
                + node.getDepth();
    }

    private static boolean hasText(String value) {
        return value != null && !value.trim().isEmpty();
    }
}

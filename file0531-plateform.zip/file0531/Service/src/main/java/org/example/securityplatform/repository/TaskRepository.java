package org.example.securityplatform.repository;

import org.example.securityplatform.entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * 任务数据访问接口
 */
@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByProjectId(Long projectId);
    List<Task> findByStatus(String status);
    Optional<Task> findByProjectIdAndTaskName(Long projectId, String taskName);

    /**
     * 根据项目ID删除所有关联的任务
     * 用于项目删除时的级联清理
     */
    @Modifying(clearAutomatically = true)
    void deleteByProjectId(Long projectId);
}
package org.example.securityplatform.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.dto.*;
import org.example.securityplatform.entity.ApiDiff;
import org.example.securityplatform.entity.FileDiff;
import org.example.securityplatform.repository.ApiDiffRepository;
import org.example.securityplatform.repository.FileDiffRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 智能推荐服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RecommendationService {

    private final ApiDiffRepository apiDiffRepository;
    private final FileDiffRepository fileDiffRepository;

    /**
     * 生成测试推荐
     */
    public RecommendationResponse generateRecommendations(Long taskId) {
        // 1. 获取风险预警
        List<WarningItem> warnings = generateWarnings(taskId);

        // 2. 生成优先测试项
        List<PriorityItem> priorityItems = generatePriorityItems(taskId);

        // 3. 生成测试建议
        TestSuggestion testSuggestions = generateTestSuggestions(taskId, warnings, priorityItems);

        return RecommendationResponse.builder()
                .warnings(warnings)
                .priorityItems(priorityItems)
                .testSuggestions(testSuggestions)
                .build();
    }

    /**
     * 生成风险预警
     */
    private List<WarningItem> generateWarnings(Long taskId) {
        List<WarningItem> warnings = new ArrayList<>();

        // 1. 兼容性风险 - API删除
        List<ApiDiff> deletedApis = apiDiffRepository.findByDiffTaskIdAndChangeType(taskId, "DELETED_API");
        for (ApiDiff api : deletedApis) {
            warnings.add(WarningItem.builder()
                    .id((long) warnings.size() + 1)
                    .level("HIGH")
                    .type("COMPATIBILITY")
                    .title("API删除")
                    .description("API已被删除，可能影响客户端兼容性")
                    .className(api.getControllerClass())
                    .methodName(api.getMethodName())
                    .build());
        }

        // 2. 性能风险 - 大量文件变更
        List<FileDiff> fileDiffs = fileDiffRepository.findByDiffTaskId(taskId);
        if (fileDiffs.size() > 20) {
            warnings.add(WarningItem.builder()
                    .id((long) warnings.size() + 1)
                    .level("MEDIUM")
                    .type("PERFORMANCE")
                    .title("大量文件变更")
                    .description(String.format("检测到%d个文件变更，建议进行性能测试", fileDiffs.size()))
                    .className("整体项目")
                    .methodName("")
                    .build());
        }

        return warnings;
    }

    /**
     * 生成优先测试项
     */
    private List<PriorityItem> generatePriorityItems(Long taskId) {
        List<PriorityItem> items = new ArrayList<>();

        // 获取所有API变更
        List<ApiDiff> apiDiffs = apiDiffRepository.findByDiffTaskId(taskId);

        // 按变更类型优先级排序：NEW_API > DELETED_API > MODIFIED_API > AFFECTED_API
        int rank = 1;
        for (ApiDiff api : apiDiffs.stream().limit(10).collect(Collectors.toList())) {
            items.add(PriorityItem.builder()
                    .id((long) rank)
                    .priority(rank)
                    .changeType(api.getChangeType())
                    .method(String.format("%s.%s()",
                            api.getControllerClass().substring(api.getControllerClass().lastIndexOf('.') + 1),
                            api.getMethodName()))
                    .affectedApis(1)
                    .changeId("api-" + api.getId())
                    .build());
            rank++;
        }

        return items;
    }

    /**
     * 生成测试建议
     */
    private TestSuggestion generateTestSuggestions(Long taskId, List<WarningItem> warnings, List<PriorityItem> priorityItems) {
        Set<String> caseTypes = new LinkedHashSet<>();

        // 根据风险类型推荐测试用例
        boolean hasSecurityRisk = warnings.stream().anyMatch(w -> "SECURITY".equals(w.getType()));
        if (hasSecurityRisk) {
            caseTypes.add("安全测试");
        }

        boolean hasCompatibilityRisk = warnings.stream().anyMatch(w -> "COMPATIBILITY".equals(w.getType()));
        if (hasCompatibilityRisk) {
            caseTypes.add("兼容性测试");
        }

        boolean hasPerformanceRisk = warnings.stream().anyMatch(w -> "PERFORMANCE".equals(w.getType()));
        if (hasPerformanceRisk) {
            caseTypes.add("性能测试");
        }

        // 根据API变更数量推荐
        long apiChangeCount = apiDiffRepository.countByDiffTaskId(taskId);
        if (apiChangeCount > 10) {
            caseTypes.add("接口测试");
            caseTypes.add("回归测试");
        } else if (apiChangeCount > 0) {
            caseTypes.add("接口测试");
        }

        // 生成测试重点
        String focusPoints = generateFocusPoints(warnings, priorityItems);

        // 预估工作量
        String estimatedEffort = estimateEffort(priorityItems.size(), apiChangeCount);

        return TestSuggestion.builder()
                .caseTypes(new ArrayList<>(caseTypes))
                .focusPoints(focusPoints)
                .estimatedEffort(estimatedEffort)
                .build();
    }

    /**
     * 生成测试重点描述
     */
    private String generateFocusPoints(List<WarningItem> warnings, List<PriorityItem> priorityItems) {
        if (warnings.isEmpty() && priorityItems.isEmpty()) {
            return "暂无特殊测试重点";
        }

        List<String> points = new ArrayList<>();

        if (!warnings.isEmpty()) {
            long securityCount = warnings.stream().filter(w -> "SECURITY".equals(w.getType())).count();
            if (securityCount > 0) {
                points.add(String.format("重点关注%d个安全风险项", securityCount));
            }

            long compatibilityCount = warnings.stream().filter(w -> "COMPATIBILITY".equals(w.getType())).count();
            if (compatibilityCount > 0) {
                points.add(String.format("验证%d个兼容性问题", compatibilityCount));
            }
        }

        if (!priorityItems.isEmpty()) {
            points.add(String.format("优先测试%d个高风险变更项", priorityItems.size()));
        }

        return String.join("；", points);
    }

    /**
     * 预估工作量
     */
    private String estimateEffort(int priorityCount, long apiChangeCount) {
        if (priorityCount > 8 || apiChangeCount > 20) {
            return "5-7人天";
        } else if (priorityCount > 5 || apiChangeCount > 10) {
            return "3-5人天";
        } else if (priorityCount > 0 || apiChangeCount > 0) {
            return "1-2人天";
        } else {
            return "0.5-1人天";
        }
    }
}
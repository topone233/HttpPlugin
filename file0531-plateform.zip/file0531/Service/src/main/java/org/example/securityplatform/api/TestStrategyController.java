package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.*;
import org.example.securityplatform.entity.TestCase;
import org.example.securityplatform.entity.ConfigCheckItem;
import org.example.securityplatform.service.TestStrategyService;
import org.example.securityplatform.service.TestCaseService;
import org.example.securityplatform.service.ConfigCheckItemService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 测试策略控制器
 * 提供测试策略引擎相关的API
 */
@Tag(name = "测试策略", description = "测试用例匹配、测试清单生成、配置检查")
@RestController
@RequestMapping("/api/strategy")
@RequiredArgsConstructor
public class TestStrategyController {

    private final TestStrategyService testStrategyService;
    private final TestCaseService testCaseService;
    private final ConfigCheckItemService configCheckItemService;

    /**
     * 为制品生成测试清单
     */
    @Operation(summary = "生成测试清单", description = "根据分析结果自动生成测试清单")
    @PostMapping("/generate/{artifactId}")
    public Result<StrategyMatchResponse> generateTestChecklist(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        StrategyMatchResponse response = testStrategyService.generateTestChecklist(artifactId);
        return Result.success(response);
    }

    /**
     * 获取制品的测试清单
     */
    @Operation(summary = "获取测试清单", description = "获取制品的测试清单内容")
    @GetMapping("/checklist/{artifactId}")
    public Result<StrategyMatchResponse> getTestChecklist(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        StrategyMatchResponse response = testStrategyService.getTestChecklist(artifactId);
        return Result.success(response);
    }

    /**
     * 更新测试清单项状态
     */
    @Operation(summary = "更新测试清单状态", description = "更新测试清单项的测试状态和结果")
    @PutMapping("/checklist/{checklistId}/status")
    public Result<TestChecklistResponse> updateChecklistStatus(
            @Parameter(description = "清单项ID") @PathVariable Long checklistId,
            @Parameter(description = "状态: TODO, PASS, FAIL, NA") @RequestParam String status,
            @Parameter(description = "测试结果") @RequestParam(required = false) String testResult,
            @Parameter(description = "测试备注") @RequestParam(required = false) String testNotes) {
        TestChecklistResponse response = testStrategyService.updateChecklistStatus(checklistId, status, testResult, testNotes);
        return Result.success(response);
    }

    /**
     * 执行配置检查
     */
    @Operation(summary = "执行配置检查", description = "对制品执行配置安全检查")
    @GetMapping("/config-check/{artifactId}")
    public Result<List<Map<String, Object>>> performConfigCheck(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        List<Map<String, Object>> results = testStrategyService.performConfigCheck(artifactId);
        return Result.success(results);
    }

    // ==================== 测试用例管理 ====================

    /**
     * 获取所有测试用例
     */
    @Operation(summary = "获取所有测试用例", description = "获取测试用例库中的所有用例")
    @GetMapping("/test-cases")
    public Result<List<TestCaseResponse>> getAllTestCases() {
        List<TestCaseResponse> cases = testCaseService.getAllTestCases();
        return Result.success(cases);
    }

    /**
     * 获取测试用例详情
     */
    @Operation(summary = "获取测试用例详情", description = "根据ID获取测试用例详情")
    @GetMapping("/test-cases/{id}")
    public Result<TestCaseResponse> getTestCase(
            @Parameter(description = "用例ID") @PathVariable Long id) {
        TestCaseResponse response = testCaseService.getTestCaseById(id);
        return Result.success(response);
    }

    /**
     * 创建测试用例
     */
    @Operation(summary = "创建测试用例", description = "创建新的测试用例")
    @PostMapping("/test-cases")
    public Result<TestCaseResponse> createTestCase(@RequestBody TestCaseRequest request) {
        TestCaseResponse response = testCaseService.createTestCase(request);
        return Result.success(response);
    }

    /**
     * 更新测试用例
     */
    @Operation(summary = "更新测试用例", description = "更新指定的测试用例")
    @PutMapping("/test-cases/{id}")
    public Result<TestCaseResponse> updateTestCase(
            @Parameter(description = "用例ID") @PathVariable Long id,
            @RequestBody TestCaseRequest request) {
        TestCaseResponse response = testCaseService.updateTestCase(id, request);
        return Result.success(response);
    }

    /**
     * 删除测试用例
     */
    @Operation(summary = "删除测试用例", description = "删除指定的测试用例")
    @DeleteMapping("/test-cases/{id}")
    public Result<Void> deleteTestCase(
            @Parameter(description = "用例ID") @PathVariable Long id) {
        testCaseService.deleteTestCase(id);
        return Result.success(null);
    }

    /**
     * 按漏洞类型获取测试用例
     */
    @Operation(summary = "按漏洞类型获取用例", description = "获取指定漏洞类型的所有测试用例")
    @GetMapping("/test-cases/by-type/{vulnerabilityType}")
    public Result<List<TestCaseResponse>> getTestCasesByType(
            @Parameter(description = "漏洞类型") @PathVariable String vulnerabilityType) {
        List<TestCaseResponse> cases = testCaseService.getTestCasesByVulnerabilityType(vulnerabilityType);
        return Result.success(cases);
    }

    // ==================== 配置检查项管理 ====================

    /**
     * 获取所有配置检查项
     */
    @Operation(summary = "获取所有配置检查项", description = "获取配置检查清单中的所有检查项")
    @GetMapping("/config-items")
    public Result<List<ConfigCheckItemResponse>> getAllConfigCheckItems() {
        List<ConfigCheckItemResponse> items = configCheckItemService.getAllConfigCheckItems();
        return Result.success(items);
    }

    /**
     * 获取配置检查项详情
     */
    @Operation(summary = "获取配置检查项详情", description = "根据ID获取配置检查项详情")
    @GetMapping("/config-items/{id}")
    public Result<ConfigCheckItemResponse> getConfigCheckItem(
            @Parameter(description = "检查项ID") @PathVariable Long id) {
        ConfigCheckItemResponse response = configCheckItemService.getConfigCheckItemById(id);
        return Result.success(response);
    }

    /**
     * 按类别获取配置检查项
     */
    @Operation(summary = "按类别获取检查项", description = "获取指定类别的所有配置检查项")
    @GetMapping("/config-items/by-category/{category}")
    public Result<List<ConfigCheckItemResponse>> getConfigCheckItemsByCategory(
            @Parameter(description = "检查项类别") @PathVariable String category) {
        List<ConfigCheckItemResponse> items = configCheckItemService.getConfigCheckItemsByCategory(category);
        return Result.success(items);
    }

    /**
     * 创建配置检查项
     */
    @Operation(summary = "创建配置检查项", description = "创建新的配置检查项")
    @PostMapping("/config-items")
    public Result<ConfigCheckItemResponse> createConfigCheckItem(@RequestBody ConfigCheckItem item) {
        ConfigCheckItemResponse response = configCheckItemService.createConfigCheckItem(item);
        return Result.success(response);
    }

    /**
     * 更新配置检查项
     */
    @Operation(summary = "更新配置检查项", description = "更新指定的配置检查项")
    @PutMapping("/config-items/{id}")
    public Result<ConfigCheckItemResponse> updateConfigCheckItem(
            @Parameter(description = "检查项ID") @PathVariable Long id,
            @RequestBody ConfigCheckItem item) {
        ConfigCheckItemResponse response = configCheckItemService.updateConfigCheckItem(id, item);
        return Result.success(response);
    }

    /**
     * 删除配置检查项
     */
    @Operation(summary = "删除配置检查项", description = "删除指定的配置检查项")
    @DeleteMapping("/config-items/{id}")
    public Result<Void> deleteConfigCheckItem(
            @Parameter(description = "检查项ID") @PathVariable Long id) {
        configCheckItemService.deleteConfigCheckItem(id);
        return Result.success(null);
    }

    /**
     * 获取所有漏洞类型
     */
    @Operation(summary = "获取所有漏洞类型", description = "获取测试用例库中所有的漏洞类型列表")
    @GetMapping("/vulnerability-types")
    public Result<List<String>> getAllVulnerabilityTypes() {
        List<String> types = testCaseService.getAllVulnerabilityTypes();
        return Result.success(types);
    }

    /**
     * 获取所有配置检查类别
     */
    @Operation(summary = "获取所有配置检查类别", description = "获取配置检查清单中所有的类别列表")
    @GetMapping("/config-categories")
    public Result<List<String>> getAllConfigCategories() {
        List<String> categories = configCheckItemService.getAllCategories();
        return Result.success(categories);
    }
}
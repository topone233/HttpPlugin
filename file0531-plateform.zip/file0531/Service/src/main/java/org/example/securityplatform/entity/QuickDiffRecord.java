package org.example.securityplatform.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 快速差异对比记录实体
 */
@Data
@Entity
@Table(name = "quick_diff_record", indexes = {
        @Index(name = "idx_created_at", columnList = "created_at")
})
public class QuickDiffRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "baseline_file_name", nullable = false, length = 255)
    private String baselineFileName;

    @Column(name = "target_file_name", nullable = false, length = 255)
    private String targetFileName;

    @Column(name = "baseline_md5", length = 64)
    private String baselineMd5;

    @Column(name = "target_md5", length = 64)
    private String targetMd5;

    @Column(name = "file_summary_json", columnDefinition = "TEXT")
    private String fileSummaryJson;

    @Column(name = "api_summary_json", columnDefinition = "TEXT")
    private String apiSummaryJson;

    @Column(name = "file_diffs_json", columnDefinition = "TEXT")
    private String fileDiffsJson;

    @Column(name = "api_diffs_json", columnDefinition = "TEXT")
    private String apiDiffsJson;

    @Column(name = "source_diffs_json", columnDefinition = "TEXT")
    private String sourceDiffsJson;

    @Column(name = "dependency_summary_json", columnDefinition = "TEXT")
    private String dependencySummaryJson;

    @Column(name = "warnings_json", columnDefinition = "TEXT")
    private String warningsJson;

    @Column(name = "impact_graph_json", columnDefinition = "TEXT")
    private String impactGraphJson;

    @Column(name = "duration_ms")
    private Long durationMs;

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}

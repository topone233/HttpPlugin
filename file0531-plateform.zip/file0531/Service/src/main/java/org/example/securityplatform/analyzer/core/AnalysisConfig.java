package org.example.securityplatform.analyzer.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 分析配置类
 * 集中管理深度限制、框架包列表、Controller关键词等可配置参数
 */
public class AnalysisConfig {

    /** 追溯深度限制 */
    private int maxTraceDepth = 20;

    /** 框架包前缀列表 */
    private List<String> frameworkPackages = new ArrayList<>(Arrays.asList(
            // Spring生态系统
            "org/springframework/",
            // Apache系列（包含commons, tomcat, maven, cxf等）
            "org/apache/",
            // Jackson JSON处理
            "com/fasterxml/",
            // Java标准库
            "java/",
            "javax/",
            "jakarta/",
            // 日志框架
            "org/slf4j/",
            "ch/qos/logback/",
            // IDE和开发工具
            "org/eclipse/",
            "org/projectlombok/",
            // 网络框架
            "io/netty/",
            // Google库（Guava, Protobuf等）
            "com/google/",

            // === 新增：常见第三方库 ===
            // Alibaba系列（fastjson, druid, dubbo等）
            "com/alibaba/",
            // Hutool工具包（中国项目常用）
            "cn/hutool/",
            // MyBatis系列ORM
            "org/mybatis/",
            "com/baomidou/",    // MyBatis-Plus
            "tk/mybatis/",      // MyBatis Mapper
            // Hibernate ORM
            "org/hibernate/",
            // 调度器
            "org/quartz/",
            "com/xxl/",         // XXL-JOB
            "org/xxl/",
            // 解析器和编译器
            "org/antlr/",       // ANTLR parser
            "org/aspectj/",     // AspectJ AOP
            "org/dom4j/",       // dom4j XML
            "org/javassist/",   // Javassist字节码
            // 服务器容器
            "org/jboss/",
            "org/glassfish/",   // GlassFish/Jersey
            // 旧版库
            "org/codehaus/",    // Codehaus（Groovy等）
            // 测试框架
            "org/junit/",
            "org/mockito/",
            "org/testng/",
            "org/powermock/",
            // ZooKeeper
            "org/zookeeper/",
            // 中国云服务SDK
            "com/alipay/",
            "com/taobao/",
            "com/aliyun/",
            "com/tencent/",
            "com/baidu/",
            "com/huawei/",
            // 国内框架
            "org/nutz/",        // Nutz框架
            "com/jfinal/",      // JFinal框架
            "cn/smallbun/",     // SmallBun框架
            // 模板引擎
            "org/beetl/",       // Beetl模板
            // 数据库中间件
            "org/mycat/",
            // 连接池
            "com/zaxxer/",      // HikariCP
            // 响应式编程
            "org/reactivestreams/",
            "io/reactivex/",    // RxJava
            "io/projectreactor/", // Project Reactor
            // 加密库
            "org/bouncycastle/",
            // 时间库
            "org/joda/",
            // JSON库
            "net/minidev/",     // JSON Smart
            // Reflection库
            "org/reflections/",
            // HTML/XML解析
            "org/jsoup/",
            // HTTP客户端
            "com/squareup/",    // OkHttp, Retrofit
            "okhttp3/",
            "okio/",
            "retrofit2/",
            // AWS SDK
            "com/amazonaws/",
            // 数据库驱动
            "org/mongodb/",     // MongoDB
            "org/elasticsearch/", // Elasticsearch
            "org/neo4j/",       // Neo4j
            "org/sqlite/",      // SQLite
            "org/xerial/",      // Xerial SQLite JDBC
            // 消息队列
            "org/kafka/",       // Kafka客户端
            "org/apache/kafka/", // Apache Kafka (org/apache/已覆盖，显式声明)
            "com/rabbitmq/",    // RabbitMQ
            "org/rocketmq/",    // RocketMQ
            "org/apache/rocketmq/", // Apache RocketMQ (org/apache/已覆盖)
            "org/pulsar/",      // Pulsar
            // Web服务器
            "io/undertow/",
            "org/undertow/",
            "org/xnio/",        // XNIO (Undertow依赖)
            "org/jetty/",       // Jetty
            // 监控和追踪
            "io/micrometer/",   // Micrometer
            "io/prometheus/",   // Prometheus
            "org/prometheus/",
            "org/zipkin/",      // Zipkin
            "io/zipkin/",
            "org/brave/",       // Brave
            // 多语言引擎
            "org/graalvm/",     // GraalVM
            "io/graalvm/",
            "org/truffle/",     // Truffle (GraalVM)
            // JVM语言
            "org/scala/",
            "scala/",
            "akka/",            // Akka
            "org/akka/",
            "org/kotlin/",
            "kotlin/",
            "org/jetbrains/",   // JetBrains (Kotlin开发商)
            "org/groovy/",
            "groovy/",
            "org/clojure/",
            "clojure/",
            // OSGi框架
            "org/osgi/",
            "org/apache/felix/", // Apache Felix OSGi (org/apache/已覆盖)
            // 构建工具
            "org/gradle/",
            "org/apache/maven/", // Maven (org/apache/已覆盖，显式声明)
            "org/apache/ant/",  // Ant (org/apache/已覆盖)
            // JDK内部类
            "sun/",
            "com/sun/",
            "oracle/",
            "com/oracle/",
            "org/openjdk/",
            // Profiler工具
            "org/yourkit/",
            "com/yourkit/",
            "org/jprofiler/",
            "com/jprofiler/",
            // 其他常见库
            "com/thoughtworks/",
            "org/hamcrest/",
            "org/assertj/",
            "org/opentest4j/",
            "org/apiguardian/",
            "org/owasp/",       // OWASP库
            "org/parallec/",
            "org/robolectric/",
            "org/skyscreamer/",
            "org/xmlunit/",
            "org/yaml/",        // SnakeYAML
            "org/antlr/",
            "org/objenesis/",
            "org/databrary/",   // Trait library
            "io/github/",       // GitHub发布的库
            "com/github/",      // GitHub库（可能过于宽泛，需评估）
            "org/luaj/",        // LuaJ
            "org/jruby/",       // JRuby
            "org/jython/",      // Jython
            "org/rhino/",       // Rhino JavaScript
            "org/mozilla/",     // Mozilla (Rhino)
            "org/antlr/",
            "org/nashorn/",     // Nashorn JavaScript (JDK内置)
            "org/selenium/",    // Selenium
            "org/openqa/",      // OpenQA Selenium
            "org/testcontainers/", // Testcontainers
            "com/spotify/",     // Spotify库
            "io/spotify/",
            "com/datastax/",    // DataStax Cassandra
            "org/cassandraunit/",
            "org/mongounit/",
            "org/redisunit/",
            "io/searchbox/",    // Jest Elasticsearch客户端
            "org/kafkastreams/",
            "io/kafka/",
            "io/rabbitmq/",
            "io/pulsar/",
            "io/nsq/",
            "org/nsq/",
            "org/stomp/",
            "io/vertx/",        // Vert.x
            "org/vertx/",
            "io/grpc/",         // gRPC
            "org/grpc/",
            "org/protobuf/",    // Protocol Buffers
            "org/thrift/",      // Thrift (org/apache/已覆盖)
            "org/apache/thrift/",
            "org/avro/",        // Avro (org/apache/已覆盖)
            "org/apache/avro/",
            "org/ice/",         // ZeroC Ice
            "org/apache/ice/",
            "org/corba/",
            "org/apache/corba/",
            "org/xmlrpc/",
            "org/apache/xmlrpc/",
            "org/jsonrpc/",
            "org/apache/jsonrpc/",
            "org/ws/",
            "org/apache/ws/",
            "org/axis/",
            "org/apache/axis/",
            "org/axis2/",
            "org/apache/axis2/",
            "org/cxf/",
            "org/apache/cxf/",  // CXF (org/apache/已覆盖，显式声明避免与业务包org.example.cxf冲突)
            "org/restlet/",
            "org/apache/restlet/",
            "org/jaxrs/",
            "org/jersey/",
            "org/glassfish/jersey/",
            "org/resteasy/",
            "org/jboss/resteasy/",
            "org/wink/",
            "org/apache/wink/",
            "org/play/",        // Play Framework
            "com/typesafe/",    // Typesafe/Lightbend
            "com/lightbend/"
    ));

    /** Controller识别关键词 */
    private List<String> controllerKeywords = new ArrayList<>(Arrays.asList(
            "Api",
            "Controller",
            "Resource"
    ));

    /** Service识别关键词 */
    private List<String> serviceKeywords = new ArrayList<>(Arrays.asList(
            "Service",
            "ServiceImpl"
    ));

    public int getMaxTraceDepth() {
        return maxTraceDepth;
    }

    public void setMaxTraceDepth(int maxTraceDepth) {
        this.maxTraceDepth = maxTraceDepth;
    }

    public List<String> getFrameworkPackages() {
        return frameworkPackages;
    }

    public void setFrameworkPackages(List<String> frameworkPackages) {
        this.frameworkPackages = frameworkPackages;
    }

    public List<String> getControllerKeywords() {
        return controllerKeywords;
    }

    public void setControllerKeywords(List<String> controllerKeywords) {
        this.controllerKeywords = controllerKeywords;
    }

    public List<String> getServiceKeywords() {
        return serviceKeywords;
    }

    public void setServiceKeywords(List<String> serviceKeywords) {
        this.serviceKeywords = serviceKeywords;
    }

    /**
     * 创建默认配置
     */
    public static AnalysisConfig defaultConfig() {
        return new AnalysisConfig();
    }
}

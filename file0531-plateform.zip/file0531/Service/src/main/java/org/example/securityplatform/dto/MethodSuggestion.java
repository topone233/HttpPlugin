package org.example.securityplatform.dto;

import lombok.Data;

/**
 * 方法建议（用于自动补全）
 */
@Data
public class MethodSuggestion {

    /**
     * 完整类名
     */
    private String className;

    /**
     * 简单类名
     */
    private String simpleClassName;

    /**
     * 方法名
     */
    private String methodName;

    /**
     * 方法描述符
     */
    private String descriptor;

    /**
     * 显示名称（用于前端展示）
     */
    private String displayName;
}
package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 变更影响图谱响应DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ImpactGraphResponse {
    private List<MethodChange> changes;
    private List<AffectedNode> affected;
    private List<ApiNode> apis;
    private List<CallEdge> callEdges;
    private List<ImpactEdge> impactEdges;
}
package org.example.securityplatform.repository;

import org.example.securityplatform.entity.MethodCallEdge;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 方法调用关系数据访问接口
 */
@Repository
public interface MethodCallEdgeRepository extends JpaRepository<MethodCallEdge, Long> {
    List<MethodCallEdge> findByArtifactId(Long artifactId);

    // 查找调用指定方法的所有调用者（反向追溯用）
    @Query("SELECT m FROM MethodCallEdge m WHERE m.artifactId = :artifactId " +
           "AND m.calleeClass = :calleeClass AND m.calleeMethod = :calleeMethod")
    List<MethodCallEdge> findCallers(@Param("artifactId") Long artifactId,
                                      @Param("calleeClass") String calleeClass,
                                      @Param("calleeMethod") String calleeMethod);

    // 查找指定类的所有调用关系
    @Query("SELECT m FROM MethodCallEdge m WHERE m.artifactId = :artifactId " +
           "AND m.callerClass = :className")
    List<MethodCallEdge> findByCallerClass(@Param("artifactId") Long artifactId,
                                            @Param("className") String className);

    @Modifying(clearAutomatically = true)
    void deleteByArtifactId(Long artifactId);
}

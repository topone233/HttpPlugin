package org.example.securityplatform.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 差异分析进度响应
 */
@Data
public class DiffAnalysisProgressResponse {
    private Long diffTaskId;
    private String status;
    private Integer progress;
    private String currentStep;
    private List<StepInfo> steps;

    @Data
    public static class StepInfo {
        private String name;
        private String status; // PENDING, IN_PROGRESS, COMPLETED, FAILED
        private Integer progress;
        private String message;
    }
}

package org.example.securityplatform.analyzer.jar;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 业务模块过滤器 - 根据规则判断哪些JAR是业务模块
 */
@Slf4j
public class BusinessModuleFilter {

    /**
     * 根据包名规则判断JAR是否为业务模块
     *
     * @param jarPath JAR文件路径
     * @param packagePatterns 包名模式列表（如 ["com.mycompany.*"]）
     * @return 是否匹配
     */
    public boolean matchesByPackage(Path jarPath, List<String> packagePatterns) {
        if (packagePatterns == null || packagePatterns.isEmpty()) {
            return true; // 没有规则则全部匹配
        }

        try (JarFile jarFile = new JarFile(jarPath.toFile())) {
            Enumeration<JarEntry> entries = jarFile.entries();

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();

                if (name.endsWith(".class") && !entry.isDirectory()) {
                    String className = normalizeClassName(name);

                    for (String pattern : packagePatterns) {
                        if (matchesPackage(className, pattern)) {
                            log.debug("JAR {} matched package pattern {} with class {}",
                                    jarPath.getFileName(), pattern, className);
                            return true;
                        }
                    }
                }
            }
        } catch (IOException e) {
            log.warn("Failed to check package patterns for JAR: {}", jarPath, e);
        }

        return false;
    }

    /**
     * 根据JAR名称模式判断是否为业务模块
     *
     * @param jarName JAR文件名
     * @param namePatterns 名称模式列表（如 ["myproject-*"]）
     * @return 是否匹配
     */
    public boolean matchesByName(String jarName, List<String> namePatterns) {
        if (namePatterns == null || namePatterns.isEmpty()) {
            return true; // 没有规则则全部匹配
        }

        String baseName = removeVersionSuffix(jarName);

        for (String pattern : namePatterns) {
            // 匹配完整名称（用户选择了完整名称如 myproject-user-service-1.0.0.jar）
            if (matchesPattern(jarName, pattern)) {
                log.debug("JAR {} (full name) matched name pattern {}", jarName, pattern);
                return true;
            }
            // 匹配基础名称（用户选择了不带版本号的名称如 myproject-user-service）
            if (matchesPattern(baseName, pattern)) {
                log.debug("JAR {} (base name {}) matched name pattern {}", jarName, baseName, pattern);
                return true;
            }
        }

        return false;
    }

    /**
     * 规范化类名 - 从路径转换为标准类名格式
     */
    private String normalizeClassName(String classPath) {
        // BOOT-INF/classes/org/example/User.class -> org.example.User
        String name = classPath;

        // 处理Spring Boot Fat JAR结构
        if (name.startsWith("BOOT-INF/classes/")) {
            name = name.substring("BOOT-INF/classes/".length());
        } else if (name.startsWith("WEB-INF/classes/")) {
            name = name.substring("WEB-INF/classes/".length());
        }

        // 移除 .class 后缀
        if (name.endsWith(".class")) {
            name = name.substring(0, name.length() - 6);
        }

        // 路径分隔符转包名分隔符
        name = name.replace('/', '.').replace('\\', '.');

        return name;
    }

    /**
     * 匹配包名规则
     * com.mycompany.* 匹配 com.mycompany.service.UserService
     */
    private boolean matchesPackage(String className, String pattern) {
        // 处理通配符
        String prefix = pattern.replace(".*", "").replace("*", "");

        // 类名必须以指定前缀开头
        if (!className.startsWith(prefix)) {
            return false;
        }

        // 如果模式以 .* 结尾，匹配任意子包
        if (pattern.endsWith(".*")) {
            return true;
        }

        // 精确匹配包名
        return className.equals(prefix) ||
               className.startsWith(prefix + ".");
    }

    /**
     * 匹配名称模式（支持 * 通配符）
     * myproject-* 匹配 myproject-user-service
     */
    private boolean matchesPattern(String name, String pattern) {
        // 将通配符模式转换为正则表达式
        String regex = pattern
                .replace(".", "\\.")   // 转义点号
                .replace("*", ".*");   // * 转换为 .*

        // 添加边界
        if (!regex.startsWith(".*")) {
            regex = "^" + regex;
        }
        if (!regex.endsWith(".*")) {
            regex = regex + "$";
        }

        return name.matches(regex);
    }

    /**
     * 移除JAR名称中的版本号后缀
     * myproject-user-service-1.0.0.jar -> myproject-user-service
     * myproject-core-2.3.4-SNAPSHOT.jar -> myproject-core
     */
    private String removeVersionSuffix(String jarName) {
        // 移除 .jar 扩展名
        String name = jarName.replaceAll("\\.jar$", "");

        // 移除版本号后缀（匹配 -X.Y.Z 或 -X.Y.Z-SNAPSHOT 等格式）
        name = name.replaceAll("-\\d+\\.\\d+\\.\\d+.*$", "");

        return name;
    }
}

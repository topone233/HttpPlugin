package org.example.securityplatform.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

/**
 * API变更实体
 */
@Data
@Entity
@Table(name = "api_diff")
public class ApiDiff {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "diff_task_id", nullable = false)
    private Long diffTaskId;

    @Column(name = "api_url", nullable = false, length = 500)
    private String apiUrl;

    @Column(name = "http_method", nullable = false, length = 10)
    private String httpMethod;

    @Column(name = "controller_class", length = 255)
    private String controllerClass;

    @Column(name = "method_name", length = 255)
    private String methodName;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "parameters", columnDefinition = "TEXT")
    private String parameters;

    @Column(name = "change_type", nullable = false, length = 20)
    private String changeType; // NEW_API, MODIFIED_API, DELETED_API, AFFECTED_API

    @Column(name = "change_reason", columnDefinition = "TEXT")
    private String changeReason;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "call_chain", columnDefinition = "TEXT")
    private String callChain;

    @Column(name = "related_file_diff_ids")
    private String relatedFileDiffIds;  // 存储为逗号分隔的ID字符串

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "danger_functions", columnDefinition = "TEXT")
    private String dangerFunctions;
}

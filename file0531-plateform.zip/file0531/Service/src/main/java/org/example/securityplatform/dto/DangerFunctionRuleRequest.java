package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 危险函数规则请求 DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DangerFunctionRuleRequest {
    private String ruleName;
    private String functionType;
    private String classPattern;
    private String methodPattern;
    private String description;
    private String riskLevel;
    private String securityImpact;
    private String remediation;
    private String cweId;
    private String references;
    private Boolean enabled;
}

package org.example.securityplatform.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;

/**
 * 污点路径实体
 * 存储从污点源(Controller参数)到Sink的传播路径
 */
@Data
@Entity
@Table(name = "taint_path")
public class TaintPath {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sink_id", nullable = false)
    private Long sinkId;

    /**
     * 污点源类名（Controller类）
     */
    @Column(name = "source_class", length = 255)
    private String sourceClass;

    /**
     * 污点源方法名（Controller方法）
     */
    @Column(name = "source_method", length = 255)
    private String sourceMethod;

    /**
     * 污点参数名
     */
    @Column(name = "source_param", length = 100)
    private String sourceParam;

    /**
     * 参数类型
     */
    @Column(name = "source_param_type", length = 100)
    private String sourceParamType;

    /**
     * 调用链（JSON数组）
     * 格式：[{"className":"UserService","methodName":"findUser","lineNumber":25}]
     */
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "call_chain", columnDefinition = "TEXT")
    private String callChain;

    /**
     * 调用深度
     */
    @Column(name = "depth")
    private Integer depth = 0;

    /**
     * 是否可达
     */
    @Column(name = "is_reachable")
    private Boolean isReachable = true;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
}
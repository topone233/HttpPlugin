package org.example.securityplatform.analyzer.taint;

import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.entity.TaintSink;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Sink检测器接口
 * 支持多种漏洞类型的扩展
 */
public interface SinkDetector {

    /**
     * 获取漏洞类型
     *
     * @return 漏洞类型标识，如 SQL_INJECTION, COMMAND_INJECTION, SSRF
     */
    String getVulnerabilityType();

    /**
     * 检测Sink点（单JAR模式）
     *
     * @param jarPath   JAR包路径
     * @param artifactId 制品ID
     * @return 检测到的Sink点列表
     * @throws IOException IO异常
     */
    List<TaintSink> detect(String jarPath, Long artifactId) throws IOException;

    /**
     * 检测多个JAR中的Sink点（多JAR模式）
     * 默认实现遍历所有JAR并设置来源模块信息
     *
     * @param jars       JAR信息列表
     * @param artifactId 制品ID
     * @return 检测到的Sink点列表
     * @throws IOException IO异常
     */
    default List<TaintSink> detectAll(List<JarInfo> jars, Long artifactId) throws IOException {
        List<TaintSink> allSinks = new ArrayList<>();
        for (JarInfo jar : jars) {
            List<TaintSink> jarSinks = detect(jar.getJarPath(), artifactId);
            // 设置每个Sink的来源模块
            jarSinks.forEach(sink -> sink.setSourceModule(jar.getName()));
            allSinks.addAll(jarSinks);
        }
        return allSinks;
    }

    /**
     * 获取Sink类型描述
     *
     * @return Sink类型
     */
    default String getSinkType() {
        return "UNKNOWN";
    }
}
package org.example.securityplatform.dto;

import lombok.Data;

import java.util.List;

/**
 * Sink点响应
 */
@Data
public class TaintSinkResponse {
    /**
     * Sink ID
     */
    private Long id;

    /**
     * 漏洞类型
     */
    private String vulnerabilityType;

    /**
     * Sink类型
     */
    private String sinkType;

    /**
     * Sink类名
     */
    private String sinkClass;

    /**
     * Sink方法名
     */
    private String sinkMethod;

    /**
     * 可被注入的参数列表
     */
    private List<String> vulnerableParams;

    /**
     * 文件路径
     */
    private String filePath;

    /**
     * SQL片段
     */
    private String sqlSnippet;

    /**
     * 风险等级
     */
    private String riskLevel;

    /**
     * 行号
     */
    private Integer lineNumber;

    /**
     * 关联的污点路径列表
     */
    private List<TaintPathResponse> paths;
}
package org.example.securityplatform.api;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.jar.DependencyAnalysisConfig;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.DependencyPreviewResponse;
import org.example.securityplatform.dto.TaintAnalysisResultResponse;
import org.example.securityplatform.dto.TaintSinkResponse;
import org.example.securityplatform.service.TaintAnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

/**
 * 污点分析API控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/taint")
public class TaintAnalysisController {

    @Autowired
    private TaintAnalysisService taintAnalysisService;

    /**
     * 预览制品中的依赖信息
     * 用于前端下拉选择，自动列举依赖JAR和业务包名
     *
     * @param artifactId 制品ID
     * @return 依赖预览响应
     */
    @GetMapping("/preview-dependencies/{artifactId}")
    public Result<DependencyPreviewResponse> previewDependencies(@PathVariable Long artifactId) {
        try {
            log.info("收到依赖预览请求: artifactId={}", artifactId);
            DependencyPreviewResponse response = taintAnalysisService.previewDependencies(artifactId);
            return Result.success(response);
        } catch (IllegalArgumentException e) {
            log.warn("制品不存在: {}", artifactId);
            return Result.error("制品不存在: " + artifactId);
        } catch (Exception e) {
            log.error("预览依赖失败", e);
            return Result.error("预览依赖失败: " + e.getMessage());
        }
    }

    /**
     * 执行污点分析
     *
     * @param artifactId         制品ID
     * @param vulnerabilityType  漏洞类型（默认SQL_INJECTION）
     * @param analyzeDependencies 是否分析依赖模块（默认false）
     * @param includePackages    包含的包名模式列表（可选）
     * @param includeJarNames    包含的JAR名称模式列表（可选）
     * @return 分析结果
     */
    @PostMapping("/analyze/{artifactId}")
    public Result<TaintAnalysisResultResponse> analyze(
            @PathVariable Long artifactId,
            @RequestParam(defaultValue = "SQL_INJECTION") String vulnerabilityType,
            @RequestParam(required = false, defaultValue = "false") boolean analyzeDependencies,
            @RequestParam(required = false) List<String> includePackages,
            @RequestParam(required = false) List<String> includeJarNames) {
        try {
            log.info("收到污点分析请求: artifactId={}, vulnerabilityType={}, analyzeDependencies={}",
                    artifactId, vulnerabilityType, analyzeDependencies);

            DependencyAnalysisConfig config = analyzeDependencies
                    ? DependencyAnalysisConfig.withDependencies(includePackages, includeJarNames)
                    : DependencyAnalysisConfig.defaultConfig();

            TaintAnalysisResultResponse result = taintAnalysisService.analyze(artifactId, vulnerabilityType, config);
            return Result.success(result);
        } catch (IOException e) {
            log.error("污点分析失败", e);
            return Result.error("污点分析失败: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            log.warn("参数错误: {}", e.getMessage());
            return Result.error("参数错误: " + e.getMessage());
        }
    }

    /**
     * 获取污点分析结果
     *
     * @param artifactId     制品ID
     * @param vulnerabilityType 漏洞类型（默认SQL_INJECTION）
     * @return 分析结果
     */
    @GetMapping("/result/{artifactId}")
    public Result<TaintAnalysisResultResponse> getResult(
            @PathVariable Long artifactId,
            @RequestParam(defaultValue = "SQL_INJECTION") String vulnerabilityType) {
        TaintAnalysisResultResponse result = taintAnalysisService.getResult(artifactId, vulnerabilityType);
        return Result.success(result);
    }

    /**
     * 获取单个Sink的详情
     *
     * @param sinkId Sink ID
     * @return Sink详情（包含所有污点路径）
     */
    @GetMapping("/sink/{sinkId}")
    public Result<TaintSinkResponse> getSinkDetail(@PathVariable Long sinkId) {
        try {
            TaintSinkResponse sink = taintAnalysisService.getSinkDetail(sinkId);
            return Result.success(sink);
        } catch (IllegalArgumentException e) {
            log.warn("Sink不存在: {}", sinkId);
            return Result.error("Sink不存在: " + sinkId);
        }
    }
}
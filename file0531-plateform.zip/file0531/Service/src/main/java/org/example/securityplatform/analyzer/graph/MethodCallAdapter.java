package org.example.securityplatform.analyzer.graph;

import org.example.securityplatform.analyzer.diff.MethodCallModel;
import org.example.securityplatform.entity.MethodCallEdge;

/**
 * 方法调用数据适配器
 * 统一MethodCallModel（内存DTO）和MethodCallEdge（持久化Entity）之间的转换
 */
public class MethodCallAdapter {

    /**
     * MethodCallModel → MethodCallEdge
     */
    public MethodCallEdge toEntity(MethodCallModel model, Long artifactId) {
        MethodCallEdge edge = new MethodCallEdge();
        edge.setArtifactId(artifactId);
        edge.setCallerClass(model.getCallerClass());
        edge.setCallerMethod(model.getCallerMethod());
        edge.setCallerDescriptor(model.getCallerDescriptor());
        edge.setCalleeClass(model.getCalleeClass());
        edge.setCalleeMethod(model.getCalleeMethod());
        edge.setCalleeDescriptor(model.getCalleeDescriptor());
        edge.setCallLine(model.getCallLine());
        edge.setCallType(model.getCallType());
        return edge;
    }

    /**
     * MethodCallEdge → MethodCallModel
     */
    public MethodCallModel toModel(MethodCallEdge entity) {
        MethodCallModel model = new MethodCallModel();
        model.setCallerClass(entity.getCallerClass());
        model.setCallerMethod(entity.getCallerMethod());
        model.setCallerDescriptor(entity.getCallerDescriptor());
        model.setCalleeClass(entity.getCalleeClass());
        model.setCalleeMethod(entity.getCalleeMethod());
        model.setCalleeDescriptor(entity.getCalleeDescriptor());
        model.setCallLine(entity.getCallLine());
        model.setCallType(entity.getCallType());
        return model;
    }

    /**
     * 提取方法键（类名#方法名）
     */
    public String toMethodKey(String className, String methodName) {
        return className + "#" + methodName;
    }
}

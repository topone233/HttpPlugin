package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.RiskExclusionResponse;
import org.example.securityplatform.service.RiskExclusionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 风险排除控制器
 * 提供风险自动排除相关的API
 */
@Tag(name = "风险排除", description = "风险自动排除分析和审核")
@RestController
@RequestMapping("/api/risk-exclusion")
@RequiredArgsConstructor
public class RiskExclusionController {

    private final RiskExclusionService riskExclusionService;

    /**
     * 执行风险排除分析
     */
    @Operation(summary = "执行风险排除分析", description = "对制品执行风险自动排除分析")
    @PostMapping("/analyze/{artifactId}")
    public Result<Void> performRiskExclusion(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        riskExclusionService.performRiskExclusion(artifactId);
        return Result.success(null);
    }

    /**
     * 获取风险排除列表
     */
    @Operation(summary = "获取风险排除列表", description = "获取制品的所有风险排除记录")
    @GetMapping("/list/{artifactId}")
    public Result<List<RiskExclusionResponse>> getExclusions(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        List<RiskExclusionResponse> exclusions = riskExclusionService.getExclusions(artifactId);
        return Result.success(exclusions);
    }

    /**
     * 获取待审核的风险排除
     */
    @Operation(summary = "获取待审核项", description = "获取需要人工审核的风险排除项")
    @GetMapping("/pending-review/{artifactId}")
    public Result<List<RiskExclusionResponse>> getPendingReviewExclusions(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        List<RiskExclusionResponse> exclusions = riskExclusionService.getPendingReviewExclusions(artifactId);
        return Result.success(exclusions);
    }

    /**
     * 审核风险排除
     */
    @Operation(summary = "审核风险排除", description = "人工审核风险排除项，确认或拒绝")
    @PutMapping("/review/{exclusionId}")
    public Result<RiskExclusionResponse> reviewExclusion(
            @Parameter(description = "排除项ID") @PathVariable Long exclusionId,
            @Parameter(description = "审核状态: APPROVED, REJECTED") @RequestParam String status,
            @Parameter(description = "审核人") @RequestParam(required = false) String reviewer,
            @Parameter(description = "审核备注") @RequestParam(required = false) String notes) {
        RiskExclusionResponse response = riskExclusionService.reviewExclusion(exclusionId, status, reviewer, notes);
        return Result.success(response);
    }

    /**
     * 获取风险排除统计
     */
    @Operation(summary = "获取统计信息", description = "获取风险排除的统计数据")
    @GetMapping("/statistics/{artifactId}")
    public Result<Map<String, Object>> getExclusionStatistics(
            @Parameter(description = "制品ID") @PathVariable Long artifactId) {
        Map<String, Object> stats = riskExclusionService.getExclusionStatistics(artifactId);
        return Result.success(stats);
    }
}
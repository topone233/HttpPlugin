package org.example.securityplatform.repository;

import org.example.securityplatform.entity.FileDiff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 文件差异数据访问接口
 */
@Repository
public interface FileDiffRepository extends JpaRepository<FileDiff, Long> {
    List<FileDiff> findByDiffTaskId(Long diffTaskId);
    List<FileDiff> findByDiffTaskIdAndDiffType(Long diffTaskId, String diffType);
    long countByDiffTaskIdAndDiffType(Long diffTaskId, String diffType);
}

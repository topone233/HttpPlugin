package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 文件源代码差异（反编译后的Java源码对比）
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileSourceDiff {

    /** class文件路径 */
    private String filePath;

    /** 推断的.java源文件路径 */
    private String sourceFilePath;

    /** 差异类型: ADDED, MODIFIED, DELETED, UNCHANGED */
    private String diffType;

    /** 反编译后的基线源码（ADDED文件时为null） */
    private String baselineSource;

    /** 反编译后的目标源码（DELETED文件时为null） */
    private String targetSource;

    /** 反编译失败时的错误信息 */
    private String error;

    /** 字节码差异但反编译后源码相同（用于前端特殊标注） */
    private boolean bytecodeDiffButSourceSame;

    /** 字节码层面的差异类型（原始差异类型，在重新评估前） */
    private String originalDiffType;

    /** 来源JAR名称（多JAR模式） */
    private String sourceJar;

    /** JAR类型: MAIN 或 DEPENDENCY */
    private String jarType;
}

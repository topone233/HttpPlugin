package org.example.securityplatform.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.api.ApiExtractorStrategy;
import org.example.securityplatform.analyzer.api.ApiModel;
import org.example.securityplatform.analyzer.api.BytecodeApiExtractorStrategy;
import org.example.securityplatform.analyzer.api.SpringMvcApiExtractor;
import org.example.securityplatform.analyzer.api.JaxRsApiExtractor;
import org.example.securityplatform.analyzer.diff.*;
import org.example.securityplatform.analyzer.core.InterfaceMapper;
import org.example.securityplatform.analyzer.core.ReverseCallGraphBuilder;
import org.example.securityplatform.analyzer.jar.DependencyAnalysisConfig;
import org.example.securityplatform.analyzer.jar.DependencyScanner;
import org.example.securityplatform.analyzer.jar.FrameworkPackageFilter;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.analyzer.jar.MultiJarClasspathBuilder;
import org.example.securityplatform.analyzer.jar.PackageExtractor;
import org.example.securityplatform.dto.DependencyPreviewResponse;
import org.example.securityplatform.dto.FileSourceDiff;
import org.example.securityplatform.dto.QuickDiffListItem;
import org.example.securityplatform.dto.QuickDiffResponse;
import org.example.securityplatform.dto.ImpactGraphResponse;
import org.example.securityplatform.dto.ApiNode;
import org.example.securityplatform.dto.MethodChange;
import org.example.securityplatform.dto.AffectedNode;
import org.example.securityplatform.dto.CallEdge;
import org.example.securityplatform.dto.ImpactEdge;
import org.example.securityplatform.entity.ApiInfo;
import org.example.securityplatform.entity.MethodCallEdge;
import org.example.securityplatform.entity.QuickDiffRecord;
import org.example.securityplatform.exception.BusinessException;
import org.example.securityplatform.repository.QuickDiffRecordRepository;
import org.example.securityplatform.config.TempDirConfig;
import org.example.securityplatform.util.FileUtil;
import org.example.securityplatform.util.HashUtil;
import org.example.securityplatform.util.JarUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Collectors;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * 快速差异对比服务
 * 独立运行，不依赖数据库，直接分析上传的JAR文件
 */
@Slf4j
@Service
public class QuickDiffService {

    private final List<ApiExtractorStrategy> apiStrategies = new ArrayList<>();

    private final FrameworkPackageFilter frameworkPackageFilter = new FrameworkPackageFilter();
    private final PackageExtractor packageExtractor = new PackageExtractor();
    private final InterfaceMapper interfaceMapper = new InterfaceMapper();

    @Autowired
    private QuickDiffRecordRepository quickDiffRecordRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private TempDirConfig tempDirConfig;

    @Autowired
    private DependencyScanner dependencyScanner;

    @Autowired
    private SourceDiffService sourceDiffService;

    public QuickDiffService() {
        apiStrategies.add(new SpringMvcApiExtractor());
        apiStrategies.add(new JaxRsApiExtractor());
        apiStrategies.add(new BytecodeApiExtractorStrategy());
    }

    /**
     * 预览JAR文件中的依赖信息
     * 用于前端下拉选择，自动列举依赖JAR和业务包名
     *
     * @param file 上传的JAR文件
     * @return 依赖预览响应
     */
    public DependencyPreviewResponse previewDependencies(MultipartFile file) {
        log.info("开始预览依赖: {}", file.getOriginalFilename());

        String tempDir = null;
        String jarPath = null;

        try {
            // 创建临时目录并保存文件
            tempDir = createTempDir();
            jarPath = saveTempFile(tempDir, "preview", file);

            // 收集依赖JAR列表
            List<String> dependencyJars = new ArrayList<>();
            try (JarFile jarFile = new JarFile(jarPath)) {
                Enumeration<JarEntry> entries = jarFile.entries();

                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    String name = entry.getName();

                    // 扫描 BOOT-INF/lib 和 WEB-INF/lib
                    if ((name.startsWith("BOOT-INF/lib/") || name.startsWith("WEB-INF/lib/"))
                            && name.endsWith(".jar") && !entry.isDirectory()) {
                        // 提取JAR文件名
                        int lastSlash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
                        String jarName = lastSlash >= 0 ? name.substring(lastSlash + 1) : name;
                        dependencyJars.add(jarName);
                    }
                }
            }

            log.info("找到 {} 个依赖JAR", dependencyJars.size());

            // 收集业务包名
            Set<String> packages = new TreeSet<>();
            try (JarFile jarFile = new JarFile(jarPath)) {
                Enumeration<JarEntry> entries = jarFile.entries();

                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();
                    String name = entry.getName();

                    // 扫描 BOOT-INF/classes 和 根目录下的class文件
                    String classPath = null;
                    if (name.startsWith("BOOT-INF/classes/") && name.endsWith(".class") && !entry.isDirectory()) {
                        classPath = name.substring("BOOT-INF/classes/".length());
                    } else if (name.endsWith(".class") && !entry.isDirectory() && !name.contains("/")) {
                        // 根目录下的class文件
                        classPath = name;
                    }

                    if (classPath != null) {
                        // 排除框架包
                        if (isFrameworkPackage(classPath)) {
                            continue;
                        }

                        // 提取包名
                        String packageName = extractPackageName(classPath);
                        if (packageName != null && !packageName.isEmpty()) {
                            packages.add(packageName);
                        }
                    }
                }
            }

            log.info("找到 {} 个业务包", packages.size());

            // 自动选中业务包名（直接使用扫描结果）
            List<String> autoSelectPackages = new ArrayList<>(packages);

            // 检测多模块项目（优先pom.xml，其次layers.idx，最后包名扫描）
            boolean isMultiModule = false;
            List<String> detectedModules = null;
            List<String> autoSelectJars = null;
            String detectionMethod = "package_scan";  // 默认包名扫描

            try (JarFile jarFileForDetection = new JarFile(jarPath)) {
                // 1. 尝试从pom.xml解析modules标签（父项目）
                detectedModules = parseModulesFromPomXml(jarFileForDetection);

                if (detectedModules != null && !detectedModules.isEmpty()) {
                    // pom.xml检测成功（父项目）
                    isMultiModule = true;
                    detectionMethod = "pom_xml";
                    autoSelectJars = matchModulesToJars(detectedModules, dependencyJars);
                    log.info("使用pom.xml检测(父项目): 多模块=true, 模块数={}, 自动选中JAR数={}",
                            detectedModules.size(), autoSelectJars.size());
                } else {
                    // 2. 尝试从layers.idx解析application层JAR（Spring Boot分层打包）
                    List<String> layerJars = parseModulesFromLayersIdx(jarFileForDetection);

                    if (layerJars != null && !layerJars.isEmpty()) {
                        // layers.idx检测成功
                        isMultiModule = true;
                        detectionMethod = "layers_idx";
                        autoSelectJars = layerJars;  // 直接使用JAR名列表
                        log.info("使用layers.idx检测(分层打包): 多模块=true, application层JAR数={}",
                                autoSelectJars.size());
                    } else {
                        // 3. 使用包名扫描检测（默认可靠方法）
                        // 有业务包 → 视为多模块（依赖JAR中可能有业务模块）
                        isMultiModule = !packages.isEmpty();
                        detectionMethod = "package_scan";
                        autoSelectJars = Collections.emptyList();
                        log.info("使用包名扫描检测: 多模块={}, 业务包数={}, 自动选中包名={}",
                                isMultiModule, packages.size(), autoSelectPackages);
                    }
                }
            } catch (Exception e) {
                log.warn("多模块检测失败，使用包名扫描", e);
                isMultiModule = !packages.isEmpty();
                detectionMethod = "package_scan";
            }

            // 排序依赖JAR列表
            Collections.sort(dependencyJars);

            return new DependencyPreviewResponse(
                    dependencyJars,
                    new ArrayList<>(packages),
                    dependencyJars.size(),
                    isMultiModule,
                    detectedModules,
                    autoSelectJars,
                    detectionMethod,
                    autoSelectPackages  // 自动选中的包名
            );

        } catch (Exception e) {
            log.error("预览依赖失败", e);
            throw new BusinessException("预览依赖失败: " + e.getMessage());
        } finally {
            // 清理临时文件
            if (tempDir != null) {
                cleanupTempDir(tempDir);
            }
        }
    }

    /**
     * 从pom.xml解析模块列表
     * 扫描 META-INF/maven/<groupId>/<artifactId>/pom.xml
     *
     * @param jarFile JAR文件
     * @return 模块名列表（artifactId），如果未找到返回null
     */
    private List<String> parseModulesFromPomXml(JarFile jarFile) {
        try {
            Enumeration<JarEntry> entries = jarFile.entries();

            // 查找 META-INF/maven/*/pom.xml
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();

                if (name.startsWith("META-INF/maven/") && name.endsWith("pom.xml") && !entry.isDirectory()) {
                    log.info("找到pom.xml: {}", name);

                    try (InputStream is = jarFile.getInputStream(entry)) {
                        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                        DocumentBuilder builder = factory.newDocumentBuilder();
                        Document doc = builder.parse(is);

                        Element root = doc.getDocumentElement();
                        NodeList modulesNodes = root.getElementsByTagName("modules");

                        if (modulesNodes.getLength() > 0) {
                            Element modulesElement = (Element) modulesNodes.item(0);
                            NodeList moduleNodes = modulesElement.getElementsByTagName("module");

                            List<String> modules = new ArrayList<>();
                            for (int i = 0; i < moduleNodes.getLength(); i++) {
                                String moduleArtifactId = moduleNodes.item(i).getTextContent().trim();
                                if (!moduleArtifactId.isEmpty()) {
                                    modules.add(moduleArtifactId);
                                    log.info("解析到模块: {}", moduleArtifactId);
                                }
                            }

                            if (!modules.isEmpty()) {
                                log.info("从pom.xml解析到 {} 个子模块", modules.size());
                                return modules;
                            }
                        }

                        log.info("pom.xml中未找到<modules>标签");
                        return null;
                    }
                }
            }

            log.info("JAR中未找到META-INF/maven/*/pom.xml");
            return null;

        } catch (Exception e) {
            log.warn("解析pom.xml失败: {}", e.getMessage());
            return null;
        }
    }

    /**
     * 从layers.idx解析application层的业务JAR
     * Spring Boot分层JAR中，application层包含业务代码和业务模块JAR
     *
     * @param jarFile JAR文件
     * @return application层中的业务JAR名称列表
     */
    private List<String> parseModulesFromLayersIdx(JarFile jarFile) {
        try {
            JarEntry layersEntry = jarFile.getJarEntry("BOOT-INF/layers.idx");
            if (layersEntry == null) {
                log.info("未找到BOOT-INF/layers.idx文件");
                return null;
            }

            log.info("找到BOOT-INF/layers.idx文件");

            try (InputStream is = jarFile.getInputStream(layersEntry);
                 java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(is))) {

                List<String> applicationJars = new ArrayList<>();
                boolean inApplicationLayer = false;

                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();

                    // 检测层标记
                    if (line.startsWith("- \"")) {
                        String layerName = line.substring(3, line.length() - 2);
                        inApplicationLayer = "application".equals(layerName);
                        log.debug("检测到层: {}, inApplicationLayer={}", layerName, inApplicationLayer);
                    }
                    // 提取application层中的JAR文件
                    else if (inApplicationLayer && line.startsWith("- \"BOOT-INF/lib/") && line.endsWith(".jar\"")) {
                        // 提取JAR名称: BOOT-INF/lib/user-service-1.0.0.jar → user-service-1.0.0.jar
                        String jarPath = line.substring(3, line.length() - 1);  // 去掉引号
                        int lastSlash = jarPath.lastIndexOf('/');
                        String jarName = lastSlash >= 0 ? jarPath.substring(lastSlash + 1) : jarPath;
                        applicationJars.add(jarName);
                        log.info("从layers.idx application层提取JAR: {}", jarName);
                    }
                }

                if (!applicationJars.isEmpty()) {
                    log.info("从layers.idx解析到 {} 个application层JAR", applicationJars.size());
                    return applicationJars;
                }

                log.info("layers.idx中application层未找到业务JAR");
                return null;
            }

        } catch (Exception e) {
            log.warn("解析layers.idx失败: {}", e.getMessage());
            return null;
        }
    }

    /**
     * 匹配模块名到JAR文件名
     * 模块名如 "user-service" 匹配 JAR名 "user-service-1.0.0.jar"
     *
     * @param modules 模块名列表（artifactId）
     * @param jars JAR文件名列表（从BOOT-INF/lib扫描）
     * @return 匹配的JAR名列表
     */
    private List<String> matchModulesToJars(List<String> modules, List<String> jars) {
        List<String> matchedJars = new ArrayList<>();

        for (String module : modules) {
            // 尝试匹配：module-*.jar
            for (String jar : jars) {
                // 去掉.jar后缀
                String jarWithoutExt = jar.endsWith(".jar") ? jar.substring(0, jar.length() - 4) : jar;

                // 匹配模式：module 或 module-版本号
                if (jarWithoutExt.equals(module) || jarWithoutExt.startsWith(module + "-")) {
                    matchedJars.add(jar);
                    log.info("模块 {} 匹配到JAR: {}", module, jar);
                    break;  // 只匹配第一个
                }
            }
        }

        log.info("匹配结果: {} 个模块匹配到 {} 个JAR", modules.size(), matchedJars.size());
        return matchedJars;
    }

    /**
     * 判断是否为框架包（需要排除）
     */
    private boolean isFrameworkPackage(String classPath) {
        return frameworkPackageFilter.isFrameworkPackage(classPath);
    }

    /**
     * 从class文件路径提取包名
     * 例如: com/example/module/service/MyService.class -> com.example.module.service
     */
    private String extractPackageName(String classPath) {
        return packageExtractor.extractPackageName(classPath);
    }

    /**
     * 执行快速差异对比（向后兼容）
     */
    public QuickDiffResponse analyze(MultipartFile baselineFile, MultipartFile targetFile) {
        return analyze(baselineFile, targetFile, DependencyAnalysisConfig.defaultConfig());
    }

    /**
     * 执行快速差异对比（支持依赖分析）
     *
     * @param baselineFile 基线文件
     * @param targetFile   目标文件
     * @param depConfig    依赖分析配置
     * @return 对比结果
     */
    public QuickDiffResponse analyze(MultipartFile baselineFile, MultipartFile targetFile,
                                     DependencyAnalysisConfig depConfig) {
        log.info("开始快速差异对比: baseline={}, target={}, analyzeDependencies={}",
                baselineFile.getOriginalFilename(), targetFile.getOriginalFilename(),
                depConfig.isAnalyzeDependencies());
        long startTime = System.currentTimeMillis();

        String tempDir = null;
        List<JarInfo> baselineJars = null;
        List<JarInfo> targetJars = null;

        try {
            // 创建临时目录
            tempDir = createTempDir();
            String baselinePath = saveTempFile(tempDir, "baseline", baselineFile);
            String targetPath = saveTempFile(tempDir, "target", targetFile);

            // 扫描依赖JAR
            if (depConfig.isAnalyzeDependencies()) {
                baselineJars = dependencyScanner.scanDependencies(baselinePath, depConfig);
                targetJars = dependencyScanner.scanDependencies(targetPath, depConfig);
                log.info("依赖扫描完成: baseline有{}个JAR, target有{}个JAR",
                        baselineJars.size(), targetJars.size());
            }

            // 执行分析
            QuickDiffResponse response = doAnalyze(baselinePath, targetPath, depConfig, baselineJars, targetJars);

            long endTime = System.currentTimeMillis();
            response.setDuration(endTime - startTime);
            log.info("快速差异对比完成: 耗时={}ms", endTime - startTime);

            return response;

        } catch (Exception e) {
            log.error("快速差异对比失败", e);
            throw new BusinessException("差异对比失败: " + e.getMessage());
        } finally {
            // 清理依赖JAR临时文件
            if (baselineJars != null) {
                dependencyScanner.cleanupDependencies(baselineJars);
            }
            if (targetJars != null) {
                dependencyScanner.cleanupDependencies(targetJars);
            }
            // 清理临时文件
            if (tempDir != null) {
                cleanupTempDir(tempDir);
            }
        }
    }

    /**
     * 执行核心分析逻辑（向后兼容）
     */
    private QuickDiffResponse doAnalyze(String baselinePath, String targetPath) throws IOException {
        return doAnalyze(baselinePath, targetPath, DependencyAnalysisConfig.defaultConfig(), null, null);
    }

    /**
     * 执行核心分析逻辑（支持多JAR）
     */
    private QuickDiffResponse doAnalyze(String baselinePath, String targetPath,
                                         DependencyAnalysisConfig depConfig,
                                         List<JarInfo> baselineJars,
                                         List<JarInfo> targetJars) throws IOException {

        List<String> warnings = new ArrayList<>();

        // 检测多模块父项目场景
        if (!depConfig.isAnalyzeDependencies()) {
            try {
                boolean baselineParent = dependencyScanner.isMultiModuleParent(baselinePath);
                boolean targetParent = dependencyScanner.isMultiModuleParent(targetPath);

                if (baselineParent || targetParent) {
                    warnings.add("检测到主JAR包可能不包含业务代码。建议启用'分析依赖模块'选项以扫描子模块JAR。");
                    log.warn("检测到多模块父项目但未启用依赖分析");
                }
            } catch (Exception e) {
                log.warn("多模块检测失败", e);
            }
        }

        // Step 1: 文件差异检测
        log.info("Step 1: 文件差异检测");

        List<FileDiffModel> fileDiffs;
        FileDiffDetector.DiffStatistics fileStats;

        if (depConfig.isAnalyzeDependencies() && baselineJars != null && targetJars != null) {
            // 多JAR模式：使用类路径构建器
            log.info("使用多JAR模式进行差异检测");
            MultiJarClasspathBuilder baselineClasspath = new MultiJarClasspathBuilder(baselineJars);
            MultiJarClasspathBuilder targetClasspath = new MultiJarClasspathBuilder(targetJars);

            FileDiffDetector fileDiffDetector = new FileDiffDetector(baselineClasspath, targetClasspath);
            fileDiffs = fileDiffDetector.detect();
            fileStats = fileDiffDetector.getStatistics(fileDiffs);
        } else {
            // 单JAR模式（向后兼容）
            FileDiffDetector fileDiffDetector = new FileDiffDetector(baselinePath, targetPath);
            fileDiffs = fileDiffDetector.detect();
            fileStats = fileDiffDetector.getStatistics(fileDiffs);
        }

        // Step 2: 提取API信息（不依赖数据库）
        log.info("Step 2: 提取API信息");

        // 从所有JAR提取API（包括主JAR和依赖JAR）
        List<ApiInfo> baselineApis = new ArrayList<>();
        baselineApis.addAll(extractApisFromJar(baselinePath, "baseline-main"));

        if (baselineJars != null && !baselineJars.isEmpty()) {
            log.info("从 {} 个依赖JAR提取API", baselineJars.size());
            for (JarInfo jarInfo : baselineJars) {
                baselineApis.addAll(extractApisFromJar(jarInfo.getJarPath(), "baseline-dep-" + jarInfo.getName()));
            }
        }
        log.info("baseline API总数量: {}", baselineApis.size());

        List<ApiInfo> targetApis = new ArrayList<>();
        targetApis.addAll(extractApisFromJar(targetPath, "target-main"));

        if (targetJars != null && !targetJars.isEmpty()) {
            log.info("从 {} 个依赖JAR提取API", targetJars.size());
            for (JarInfo jarInfo : targetJars) {
                targetApis.addAll(extractApisFromJar(jarInfo.getJarPath(), "target-dep-" + jarInfo.getName()));
            }
        }
        log.info("target API总数量: {}", targetApis.size());

        // Step 3: 构建调用图
        log.info("========== Step 3: 构建调用图 ==========");
        List<MethodCallModel> callModels = new ArrayList<>();
        try {
            // 使用多JAR模式构建调用图（支持Spring Boot Fat JAR）
            if (targetJars != null && !targetJars.isEmpty()) {
                log.info("使用多JAR模式构建调用图: {} 个JAR", targetJars.size());
                CallGraphBuilder callGraphBuilder = new CallGraphBuilder(targetJars);
                callModels = callGraphBuilder.build();
            } else {
                log.info("使用单JAR模式构建调用图: {}", targetPath);
                CallGraphBuilder callGraphBuilder = new CallGraphBuilder(targetPath);
                callModels = callGraphBuilder.build();
            }

            log.info("调用图构建完成: {} 个调用关系", callModels.size());

            // 统计业务代码调用关系数量
            long businessCallCount = callModels.stream()
                    .filter(call -> call.getCallerClass().contains(".cxf.") || call.getCallerClass().contains(".example."))
                    .count();
            log.info("业务代码调用关系: {} 条（包含 .cxf. 或 .example. 的包）", businessCallCount);

            // 显示前10个业务调用关系样例
            int sampleCount = 0;
            for (MethodCallModel call : callModels) {
                // 优先显示业务代码的调用关系
                if (call.getCallerClass().contains(".cxf.") || call.getCallerClass().contains(".example.")) {
                    if (sampleCount++ < 10) {
                        log.info("  业务调用关系 #{}: {}#{} -> {}#{}",
                                sampleCount,
                                call.getCallerClass(),
                                call.getCallerMethod(),
                                call.getCalleeClass(),
                                call.getCalleeMethod());
                    }
                }
            }

            // 如果没有业务调用关系，显示所有调用关系样例
            if (sampleCount == 0) {
                log.warn("未找到业务代码调用关系，显示前10个调用关系：");
                sampleCount = 0;
                for (MethodCallModel call : callModels) {
                    if (sampleCount++ < 10) {
                        log.info("  调用关系 #{}: {}#{} -> {}#{}",
                                sampleCount,
                                call.getCallerClass(),
                                call.getCallerMethod(),
                                call.getCalleeClass(),
                                call.getCalleeMethod());
                    }
                }
            }
        } catch (Exception e) {
            log.error("调用图构建失败: {}", e.getMessage());
        }

        // 转换为MethodCallEdge
        List<MethodCallEdge> callEdges = callModels.stream().map(call -> {
            MethodCallEdge edge = new MethodCallEdge();
            edge.setCallerClass(call.getCallerClass());
            edge.setCallerMethod(call.getCallerMethod());
            edge.setCalleeClass(call.getCalleeClass());
            edge.setCalleeMethod(call.getCalleeMethod());
            edge.setCallType(call.getCallType());
            return edge;
        }).collect(Collectors.toList());

        // Step 4: 提取变更方法并分类
        log.info("Step 4: 提取变更方法并分类");
        MethodChangeClassification methodClassification = extractChangedMethodsClassified(fileDiffs);

        // Step 5: 先检测新增和删除的API（基于 baseline 和 target 对比）
        log.info("Step 5: 检测新增和删除的API");
        List<ApiChangeModel> newDeletedApis = detectNewAndDeletedApis(baselineApis, targetApis);

        // 分类新增和删除的 Controller 方法（使用统一类名格式）
        Set<String> newApiControllerMethods = new HashSet<>();
        Set<String> deletedApiControllerMethods = new HashSet<>();

        for (ApiChangeModel change : newDeletedApis) {
            if (change.getControllerClass() != null && change.getMethodName() != null) {
                // 根据API类型选择不同的API列表来normalize类名
                List<ApiInfo> apisToUse = "NEW_API".equals(change.getChangeType()) ? targetApis : baselineApis;
                String normalizedClass = normalizeClassName(change.getControllerClass(), apisToUse);
                String methodKey = normalizedClass + "#" + change.getMethodName();

                if ("NEW_API".equals(change.getChangeType())) {
                    newApiControllerMethods.add(methodKey);
                    log.info("新增Controller方法: {} (原始类名: {})", methodKey, change.getControllerClass());
                } else if ("DELETED_API".equals(change.getChangeType())) {
                    deletedApiControllerMethods.add(methodKey);
                    log.info("删除Controller方法: {} (原始类名: {})", methodKey, change.getControllerClass());
                }
            }
        }

        log.info("Controller方法分类统计: 新增={}, 删除={}", newApiControllerMethods.size(), deletedApiControllerMethods.size());

        // 提前初始化 apiChanges（后续步骤会添加）
        List<ApiChangeModel> apiChanges = new ArrayList<>(newDeletedApis);

        log.info("========== Step 5.5: 补充检测遗漏的API ==========");
        int missedDeletedApis = 0;
        int missedNewApis = 0;

        // 检测被删除的API方法
        for (String deletedMethod : methodClassification.getDeletedMethods()) {
            // 如果已经在deletedApiControllerMethods中，跳过
            if (deletedApiControllerMethods.contains(deletedMethod)) {
                continue;
            }

            // 判断是否可能是API方法
            if (isPotentialApiMethod(deletedMethod, baselineApis)) {
                deletedApiControllerMethods.add(deletedMethod);

                // 创建DELETED_API变更记录
                String[] parts = deletedMethod.split("#");
                String className = parts.length > 0 ? parts[0] : "Unknown";
                String methodName = parts.length > 1 ? parts[1] : "unknown";

                ApiChangeModel change = new ApiChangeModel();
                change.setApiUrl("/api/" + className.substring(className.lastIndexOf('.') + 1).toLowerCase() + "/" + methodName);
                change.setHttpMethod("GET"); // 默认
                change.setControllerClass(className);
                change.setMethodName(methodName);
                change.setChangeType("DELETED_API");
                change.setChangeReason("删除的API端点（通过方法签名识别）");
                apiChanges.add(change);

                missedDeletedApis++;
                log.info("补充检测到DELETED_API: {} (未被API提取器识别)", deletedMethod);
            }
        }

        // 检测新增的API方法
        for (String addedMethod : methodClassification.getAddedMethods()) {
            // 如果已经在newApiControllerMethods中，跳过
            if (newApiControllerMethods.contains(addedMethod)) {
                continue;
            }

            // 判断是否可能是API方法
            if (isPotentialApiMethod(addedMethod, targetApis)) {
                newApiControllerMethods.add(addedMethod);

                // 创建NEW_API变更记录
                String[] parts = addedMethod.split("#");
                String className = parts.length > 0 ? parts[0] : "Unknown";
                String methodName = parts.length > 1 ? parts[1] : "unknown";

                ApiChangeModel change = new ApiChangeModel();
                change.setApiUrl("/api/" + className.substring(className.lastIndexOf('.') + 1).toLowerCase() + "/" + methodName);
                change.setHttpMethod("GET"); // 默认
                change.setControllerClass(className);
                change.setMethodName(methodName);
                change.setChangeType("NEW_API");
                change.setChangeReason("新增的API端点（通过方法签名识别）");
                apiChanges.add(change);

                missedNewApis++;
                log.info("补充检测到NEW_API: {} (未被API提取器识别)", addedMethod);
            }
        }

        log.info("补充检测统计: 遗漏的删除API={}, 遗漏的新增API={}", missedDeletedApis, missedNewApis);

        // Step 6: 检测 MODIFIED_API（Controller方法本身被修改）
        log.info("Step 6: 检测 MODIFIED_API");
        Set<String> modifiedApiControllerMethods = new HashSet<>();
        Set<String> modifiedApiMethodKeys = new HashSet<>();
        Set<String> existingModifiedApiKeys = apiChanges.stream()
                .map(change -> String.valueOf(change.getHttpMethod()) + " " + String.valueOf(change.getApiUrl()))
                .collect(Collectors.toSet());

        for (ApiInfo api : targetApis) {
            String normalizedClass = normalizeClassName(api.getControllerClass(), targetApis);
            String methodKey = normalizedClass + "#" + api.getMethodName();

            if (methodClassification.getModifiedMethods().contains(methodKey) && modifiedApiMethodKeys.add(methodKey)) {
                modifiedApiControllerMethods.add(methodKey);

                // 创建 MODIFIED_API 变更记录
                ApiChangeModel change = new ApiChangeModel();
                change.setApiUrl(api.getUrl());
                change.setHttpMethod(api.getHttpMethod());
                change.setControllerClass(api.getControllerClass());
                change.setMethodName(api.getMethodName());
                change.setParameters(api.getParameters());
                change.setFramework(api.getFramework());
                change.setChangeType("MODIFIED_API");
                change.setChangeReason("API端点方法存在变更");

                // 构建调用链（单节点）
                List<ApiChangeModel.CallChainNode> chain = new ArrayList<>();
                chain.add(new ApiChangeModel.CallChainNode(api.getControllerClass(), api.getMethodName(), 0));
                change.setCallChain(chain);

                String apiKey = String.valueOf(change.getHttpMethod()) + " " + String.valueOf(change.getApiUrl());
                if (existingModifiedApiKeys.add(apiKey)) {
                    apiChanges.add(change);
                    log.info("检测到MODIFIED_API: {} {} ({}.{}())",
                            change.getHttpMethod(), change.getApiUrl(),
                            change.getControllerClass(), change.getMethodName());
                } else {
                    log.info("跳过重复MODIFIED_API: {}", apiKey);
                }
            }
        }

        log.info("MODIFIED_API数量: {}", modifiedApiControllerMethods.size());

        log.info("========== Step 7: API影响追溯 ==========");
        log.info("初始状态: 已识别API {} 个, 调用边 {} 条, 变更方法 {} 个",
                apiChanges.size(), callEdges.size(), methodClassification.getAllChangedMethods().size());

        log.info("Controller方法集合: 新增 {} 个, 修改 {} 个, 删除 {} 个",
                newApiControllerMethods.size(), modifiedApiControllerMethods.size(), deletedApiControllerMethods.size());

        boolean hasApis = !targetApis.isEmpty();
        boolean hasCallEdges = !callEdges.isEmpty();
        boolean hasAnyMethodChanges = !methodClassification.getAllChangedMethods().isEmpty();

        if (hasCallEdges && hasAnyMethodChanges) {
            // 过滤掉 Controller 方法的变更（已经处理过了）
            // 注意：使用getAllChangedMethods()而不是只用getModifiedMethods()
            Set<String> nonControllerChangedMethods = methodClassification.getAllChangedMethods().stream()
                    .filter(m -> !newApiControllerMethods.contains(m))
                    .filter(m -> !modifiedApiControllerMethods.contains(m))
                    .filter(m -> !deletedApiControllerMethods.contains(m))
                    .collect(Collectors.toSet());

            log.info("方法过滤统计: allChangedMethods总数={}, 过滤后nonControllerChangedMethods={}",
                    methodClassification.getAllChangedMethods().size(), nonControllerChangedMethods.size());

            // 详细日志：显示被过滤的方法
            if (log.isDebugEnabled()) {
                Set<String> filteredByNew = methodClassification.getAllChangedMethods().stream()
                        .filter(newApiControllerMethods::contains)
                        .collect(Collectors.toSet());
                Set<String> filteredByModified = methodClassification.getAllChangedMethods().stream()
                        .filter(modifiedApiControllerMethods::contains)
                        .collect(Collectors.toSet());
                Set<String> filteredByDeleted = methodClassification.getAllChangedMethods().stream()
                        .filter(deletedApiControllerMethods::contains)
                        .collect(Collectors.toSet());

                log.debug("被新增API过滤的方法: {}", filteredByNew);
                log.debug("被修改API过滤的方法: {}", filteredByModified);
                log.debug("被删除API过滤的方法: {}", filteredByDeleted);
            }

            if (!nonControllerChangedMethods.isEmpty()) {
                if (hasApis) {
                    // 方案A：标准流程（API信息可用）
                    log.info("使用标准API影响追溯流程");

                    ApiImpactAnalyzer analyzer = new ApiImpactAnalyzer(callEdges, targetApis, nonControllerChangedMethods);
                    List<ApiChangeModel> affectedChanges = analyzer.analyze();
                    log.info("API影响追溯完成，受影响API数量: {}", affectedChanges.size());

                    // 去重：移除已经检测过的 API
                    Set<String> existingApiKeys = apiChanges.stream()
                            .map(c -> c.getHttpMethod() + " " + c.getApiUrl())
                            .collect(Collectors.toSet());
                    for (ApiChangeModel change : affectedChanges) {
                        String key = change.getHttpMethod() + " " + change.getApiUrl();
                        if (!existingApiKeys.contains(key)) {
                            apiChanges.add(change);
                            existingApiKeys.add(key);
                            log.info("添加AFFECTED_API: {} {}", change.getHttpMethod(), change.getApiUrl());
                        } else {
                            log.info("跳过重复API: {}", key);
                        }
                    }
                } else {
                // 方案B：备用流程（API信息不可用，使用调用图反向追溯）
                log.warn(  "API提取失败（targetApis为空），使用调用图反向追溯作为备用方案");
                log.warn("注意：API提取器未能识别任何API，可能原因：");
                log.warn("  1. JAX-RS注解未被识别");
                log.warn("  2. API类不在扫描路径中");
                log.warn("  3. 需要检查API提取策略配置");

                // 构建反向调用图
                Map<String, List<String>> reverseCallGraph = buildReverseCallGraph(callEdges);
                log.info("反向调用图构建完成，包含 {} 个方法的调用关系", reverseCallGraph.size());

                // 统计业务代码的方法数量
                long businessMethodCount = reverseCallGraph.keySet().stream()
                        .filter(key -> key.contains(".cxf.") || key.contains(".example."))
                        .count();
                log.info("反向调用图中业务方法数量: {} 个", businessMethodCount);

                // 显示业务方法样例
                if (businessMethodCount > 0) {
                    int sampleCount = 0;
                    for (String method : reverseCallGraph.keySet()) {
                        if (method.contains(".cxf.") || method.contains(".example.")) {
                            if (sampleCount++ < 3) {
                                List<String> callers = reverseCallGraph.get(method);
                                log.info("  业务方法样例: {} 有 {} 个调用者",
                                        method.substring(method.lastIndexOf('.') + 1),
                                        callers.size());
                            }
                        }
                    }
                } else {
                    log.warn("反向调用图中没有任何业务方法！请检查调用图构建");
                }

                // 使用已经过滤过的非Controller变更方法
                    log.info("开始从 {} 个非Controller变更方法反向追溯", nonControllerChangedMethods.size());

                // 调试日志：显示变更方法样例
                if (log.isDebugEnabled()) {
                    int sampleCount = 0;
                    for (String method : nonControllerChangedMethods) {
                        if (sampleCount++ < 5) {
                            log.debug("变更方法样例: {}", method);
                        }
                    }
                }

                // 反向追溯，找到所有受影响的方法链路
                Set<String> visited = new HashSet<>();
                Map<String, List<String>> impactChains = new HashMap<>(); // method -> impact chain

                for (String changedMethod : nonControllerChangedMethods) {
                    List<String> chain = new ArrayList<>();
                    traceImpactChain(changedMethod, reverseCallGraph, visited, chain, 0);
                    if (!chain.isEmpty()) {
                        impactChains.put(changedMethod, chain);
                        log.info("变更方法 {} 的影响链路: {}", changedMethod, chain);
                    }
                }

                // 将影响链路转换为ApiChangeModel
                int affectedCount = 0;
                for (Map.Entry<String, List<String>> entry : impactChains.entrySet()) {
                    String modifiedMethod = entry.getKey();
                    List<String> chain = entry.getValue();

                    // 从调用链中提取信息
                    if (chain.isEmpty()) {
                        continue;
                    }

                    // 构建调用链节点
                    List<ApiChangeModel.CallChainNode> callChain = new ArrayList<>();
                    for (String method : chain) {
                        String[] parts = method.split("#");
                        if (parts.length == 2) {
                            callChain.add(new ApiChangeModel.CallChainNode(parts[0], parts[1], callChain.size()));
                        }
                    }

                    // 从调用链的顶层（最后一个节点）提取Controller信息
                    String topCaller = chain.get(chain.size() - 1);
                    String[] topParts = topCaller.split("#");
                    String topClass = topParts.length > 0 ? topParts[0] : "Unknown";
                    String topMethod = topParts.length > 1 ? topParts[1] : "unknown";

                    // 判断顶层方法是否真的是API Controller
                    boolean isRealApi = newApiControllerMethods.contains(topCaller) ||
                                        deletedApiControllerMethods.contains(topCaller) ||
                                        modifiedApiControllerMethods.contains(topCaller) ||
                                        isPotentialApiMethod(topCaller, Collections.emptyList());

                    if (!isRealApi) {
                        // 顶层方法不是Controller，跳过（不应标记为API变更）
                        log.info("跳过非API方法: {} (调用链长度={}, 但顶层不是Controller)", topCaller, chain.size());
                        continue;
                    }

                    // 确定变更类型：区分新增、修改、受影响
                    String changeType;
                    String changeReason;

                    if (newApiControllerMethods.contains(topCaller)) {
                        // 顶层调用者是新增的Controller方法
                        changeType = "NEW_API";
                        changeReason = "新增的API端点（通过调用图追溯发现）";
                        log.info("备用流程检测到NEW_API: {}", topCaller);
                    } else if (deletedApiControllerMethods.contains(topCaller)) {
                        // 顶层调用者是删除的Controller方法
                        changeType = "DELETED_API";
                        changeReason = "删除的API端点（通过调用图追溯发现）";
                        log.info("备用流程检测到DELETED_API: {}", topCaller);
                    } else if (modifiedApiControllerMethods.contains(topCaller)) {
                        // 顶层调用者是修改的Controller方法
                        changeType = "MODIFIED_API";
                        changeReason = "API端点方法存在变更";
                        log.info("备用流程检测到MODIFIED_API: {}", topCaller);
                    } else {
                        // 顶层调用者通过调用链被影响
                        changeType = "AFFECTED_API";
                        changeReason = "下游方法 " + modifiedMethod + " 存在变更，通过调用链路反向追溯发现影响";
                        log.info("备用流程检测到AFFECTED_API: {} (下游变更: {})", topCaller, modifiedMethod);
                    }

                    // 创建API变更记录
                    ApiChangeModel change = new ApiChangeModel();
                    change.setApiUrl("/api/" + topClass.substring(topClass.lastIndexOf('.') + 1).toLowerCase() + "/" + topMethod);
                    change.setHttpMethod("GET"); // 默认GET
                    change.setControllerClass(topClass);
                    change.setMethodName(topMethod);
                    change.setChangeType(changeType);
                    change.setChangeReason(changeReason);
                    change.setCallChain(callChain);

                    apiChanges.add(change);
                    log.info("创建影响API: {} {} ({}.{}())", change.getHttpMethod(), change.getApiUrl(),
                            change.getControllerClass(), change.getMethodName());
                    affectedCount++;
                }

                log.info("调用图反向追溯完成，发现 {} 条影响链路", affectedCount);
                }
            }
        } else {
            log.warn("调用边或变更方法为空，跳过API影响追溯. callEdges.isEmpty={}, methodClassification.getModifiedMethods().isEmpty={}",
                    callEdges.isEmpty(), methodClassification.getModifiedMethods().isEmpty());
        }

        int rawApiChangeCount = apiChanges.size();
        apiChanges = ApiChangeDeduplicator.deduplicate(apiChanges);
        log.info("Final apiChanges size: raw={}, deduplicated={}", rawApiChangeCount, apiChanges.size());

        // 构建响应
        QuickDiffResponse response = buildResponse(fileDiffs, fileStats, apiChanges, depConfig, baselineJars, targetJars, warnings);

        // 反编译变更文件生成源码差异
        try {
            List<FileSourceDiff> sourceDiffs = sourceDiffService.decompileChangedFiles(
                    fileDiffs, baselinePath, targetPath, baselineJars, targetJars);
            response.setSourceDiffs(sourceDiffs);
            log.info("源码反编译完成，共 {} 个文件差异", sourceDiffs.size());
        } catch (Exception e) {
            log.warn("源码反编译失败（非致命）: {}", e.getMessage());
        }

        return response;
    }

    /**
     * 构建响应（向后兼容）
     */
    private QuickDiffResponse buildResponse(List<FileDiffModel> fileDiffs,
                                             FileDiffDetector.DiffStatistics fileStats,
                                             List<ApiChangeModel> apiChanges) {
        return buildResponse(fileDiffs, fileStats, apiChanges, null, null, null, new ArrayList<>());
    }

    /**
     * 构建响应（支持依赖摘要）
     */
    private QuickDiffResponse buildResponse(List<FileDiffModel> fileDiffs,
                                             FileDiffDetector.DiffStatistics fileStats,
                                             List<ApiChangeModel> apiChanges,
                                             DependencyAnalysisConfig depConfig,
                                             List<JarInfo> baselineJars,
                                             List<JarInfo> targetJars,
                                             List<String> warnings) {
        List<ApiChangeModel> deduplicatedApiChanges = ApiChangeDeduplicator.deduplicate(apiChanges);
        // 构建文件差异列表
        List<QuickDiffResponse.FileDiffItem> fileDiffItems = fileDiffs.stream()
                .map(this::toFileDiffItem)
                .collect(Collectors.toList());

        // 构建API变更列表
        List<QuickDiffResponse.ApiDiffItem> apiDiffItems = deduplicatedApiChanges.stream()
                .map(this::toApiDiffItem)
                .collect(Collectors.toList());

        log.info("构建响应: apiChanges大小={}, apiDiffItems大小={}", apiChanges.size(), apiDiffItems.size());
        for (ApiChangeModel change : deduplicatedApiChanges) {
            log.info("API变更: {} {} - 类型={}",
                    change.getHttpMethod(), change.getApiUrl(),
                    change.getChangeType());
        }

        // 计算API统计
        QuickDiffResponse.ApiDiffSummary apiSummary = calculateApiSummary(deduplicatedApiChanges);
        log.info("API统计: 新增={}, 修改={}, 受影响={}, 删除={}",
                apiSummary.getNewApis(), apiSummary.getModifiedApis(),
                apiSummary.getAffectedApis(), apiSummary.getDeletedApis());

        // 构建依赖分析摘要
        QuickDiffResponse.DependencySummary dependencySummary = buildDependencySummary(
                depConfig, baselineJars, targetJars);

        // 构建影响图谱数据
        ImpactGraphResponse impactGraph = buildImpactGraph(fileDiffs, deduplicatedApiChanges);

        // 计算行数统计 - 分离字节码和业务文件
        int bytecodeTotalAdditions = 0;
        int bytecodeTotalDeletions = 0;
        int bytecodeBaselineTotalLines = 0;
        int bytecodeTargetTotalLines = 0;

        int businessTotalAdditions = 0;
        int businessTotalDeletions = 0;
        int businessBaselineTotalLines = 0;
        int businessTargetTotalLines = 0;

        Map<String, Integer> additionsByType = new HashMap<>();
        Map<String, Integer> deletionsByType = new HashMap<>();

        for (FileDiffModel diff : fileDiffs) {
            String filePath = diff.getFilePath();
            String extension = getFileExtension(filePath);

            if ("class".equals(extension)) {
                // 字节码文件统计
                bytecodeTotalAdditions += diff.getAddedLines();
                bytecodeTotalDeletions += diff.getDeletedLines();
                bytecodeBaselineTotalLines += diff.getBaselineLines();
                bytecodeTargetTotalLines += diff.getTargetLines();
            } else {
                // 业务文件统计
                businessTotalAdditions += diff.getAddedLines();
                businessTotalDeletions += diff.getDeletedLines();
                businessBaselineTotalLines += diff.getBaselineLines();
                businessTargetTotalLines += diff.getTargetLines();

                // 按类型统计
                if (!extension.isEmpty()) {
                    additionsByType.merge(extension, diff.getAddedLines(), Integer::sum);
                    deletionsByType.merge(extension, diff.getDeletedLines(), Integer::sum);
                }
            }
        }

        // 构建业务代码摘要
        QuickDiffResponse.BusinessCodeSummary businessCodeSummary = QuickDiffResponse.BusinessCodeSummary.builder()
                .totalAdditions(businessTotalAdditions)
                .totalDeletions(businessTotalDeletions)
                .baselineTotalLines(businessBaselineTotalLines)
                .targetTotalLines(businessTargetTotalLines)
                .additionsByType(additionsByType)
                .deletionsByType(deletionsByType)
                .build();

        // Calculate totals (bytecode + business)
        int totalAdditions = bytecodeTotalAdditions + businessTotalAdditions;
        int totalDeletions = bytecodeTotalDeletions + businessTotalDeletions;
        int baselineTotalLines = bytecodeBaselineTotalLines + businessBaselineTotalLines;
        int targetTotalLines = bytecodeTargetTotalLines + businessTargetTotalLines;

        return QuickDiffResponse.builder()
                .fileSummary(QuickDiffResponse.FileSummary.builder()
                        .addedFiles(fileStats.getAddedFiles())
                        .modifiedFiles(fileStats.getModifiedFiles())
                        .deletedFiles(fileStats.getDeletedFiles())
                        .totalMethodsAdded(fileStats.getTotalMethodsAdded())
                        .totalMethodsDeleted(fileStats.getTotalMethodsDeleted())
                        .totalMethodsModified(fileStats.getTotalMethodsModified())
                        .bytecodeTotalAdditions(bytecodeTotalAdditions)
                        .bytecodeTotalDeletions(bytecodeTotalDeletions)
                        .bytecodeBaselineTotalLines(bytecodeBaselineTotalLines)
                        .bytecodeTargetTotalLines(bytecodeTargetTotalLines)
                        .businessCodeSummary(businessCodeSummary)
                        .totalAdditions(totalAdditions)
                        .totalDeletions(totalDeletions)
                        .baselineTotalLines(baselineTotalLines)
                        .targetTotalLines(targetTotalLines)
                        .build())
                .apiSummary(apiSummary)
                .fileDiffs(fileDiffItems)
                .apiDiffs(apiDiffItems)
                .dependencySummary(dependencySummary)
                .warnings(warnings)
                .impactGraph(impactGraph) // 新增影响图谱
                .build();
    }

    /**
     * 构建影响图谱数据
     */
    private ImpactGraphResponse buildImpactGraph(
            List<FileDiffModel> fileDiffs,
            List<ApiChangeModel> apiChanges) {

        log.info("========== 构建影响图谱 ==========");
        log.info("输入: fileDiffs {} 个, apiChanges {} 个", fileDiffs.size(), apiChanges.size());

        List<MethodChange> changes = new ArrayList<>();
        List<AffectedNode> affected = new ArrayList<>();
        List<ApiNode> apis = new ArrayList<>();
        List<CallEdge> callEdges = new ArrayList<>();
        List<ImpactEdge> impactEdges = new ArrayList<>();

        // 1. 构建API节点
        long apiNodeId = 1L;
        for (ApiChangeModel api : apiChanges) {
            log.info("构建API节点: {} {} - 类型={}", api.getHttpMethod(), api.getApiUrl(), api.getChangeType());
            apis.add(ApiNode.builder()
                    .id(apiNodeId++)
                    .apiUrl(api.getApiUrl())
                    .httpMethod(api.getHttpMethod())
                    .controllerClass(api.getControllerClass())
                    .methodName(api.getMethodName())
                    .changeType(api.getChangeType())
                    .build());
        }

        // 2. 构建变更节点（基于文件差异中的修改方法）
        long changeNodeId = apiNodeId + 1;
        for (FileDiffModel fileDiff : fileDiffs) {
            if (fileDiff.getDiffType().equals("MODIFIED") && fileDiff.getBytecodeDiff() != null) {
                List<MethodChangeModel> methodChanges = fileDiff.getBytecodeDiff().getMethodChanges();

                if (methodChanges != null && !methodChanges.isEmpty()) {
                    String className = extractClassName(fileDiff.getFilePath());

                    for (MethodChangeModel mc : methodChanges) {
                        if (mc.getChangeType().equals("MODIFIED")) {
                            changes.add(MethodChange.builder()
                                    .id(changeNodeId++)
                                    .className(className)
                                    .methodName(mc.getMethodName())
                                    .methodDesc(mc.getDescriptor())
                                    .changeType("MODIFIED")
                                    .impactDepth(1)
                                    .affectedApis(1)
                                    .build());
                        }
                    }
                }
            }
        }

        // 3. 构建调用边（基于API变更的调用链）
        log.info("构建调用边...");
        long edgeId = 1L;
        Map<String, Long> nodeMap = new HashMap<>(); // className.methodName -> nodeId

        int totalCallEdges = 0;

        for (ApiChangeModel api : apiChanges) {
            if (api.getCallChain() != null && !api.getCallChain().isEmpty()) {
                List<ApiChangeModel.CallChainNode> chain = api.getCallChain();

                log.info("  API {} {} 的调用链长度: {}",
                        api.getHttpMethod(), api.getApiUrl(), chain.size());

                // 创建节点映射
                for (int i = 0; i < chain.size(); i++) {
                    String key = chain.get(i).getClassName() + "." + chain.get(i).getMethodName();
                    if (!nodeMap.containsKey(key)) {
                        nodeMap.put(key, changeNodeId++);
                        affected.add(AffectedNode.builder()
                                .id(nodeMap.get(key))
                                .className(chain.get(i).getClassName())
                                .methodName(chain.get(i).getMethodName())
                                .depth(chain.get(i).getDepth())
                                .build());
                    }
                }

                // 创建调用边
                if (chain.size() > 1) {
                    for (int i = 0; i < chain.size() - 1; i++) {
                        String sourceKey = chain.get(i).getClassName() + "." + chain.get(i).getMethodName();
                        String targetKey = chain.get(i + 1).getClassName() + "." + chain.get(i + 1).getMethodName();

                        callEdges.add(CallEdge.builder()
                                .id(edgeId++)
                                .sourceId(nodeMap.get(sourceKey))
                                .targetId(nodeMap.get(targetKey))
                                .build());
                        totalCallEdges++;
                    }
                    log.info("    ✓ 创建了 {} 条调用边", chain.size() - 1);
                } else {
                    log.info("    ✗ 调用链只有1个节点，无法创建调用边");
                }
            }
        }

        log.info("调用边构建完成: 总共 {} 条", totalCallEdges);

        // 4. 构建影响边（连接变更节点到API节点）
        for (MethodChange change : changes) {
            // 简化实现：为每个变更节点关联到所有受影响的API
            for (ApiNode api : apis) {
                if (api.getChangeType().equals("AFFECTED_API")) {
                    impactEdges.add(ImpactEdge.builder()
                            .id(edgeId++)
                            .sourceId(change.getId())
                            .targetId(api.getId())
                            .build());
                }
            }
        }

        log.info("========== 影响图谱构建完成 ==========");
        log.info("统计: 变更节点 {} 个, 受影响节点 {} 个, API节点 {} 个, 调用边 {} 条, 影响边 {} 条",
                changes.size(), affected.size(), apis.size(), callEdges.size(), impactEdges.size());

        return ImpactGraphResponse.builder()
                .changes(changes)
                .affected(affected)
                .apis(apis)
                .callEdges(callEdges)
                .impactEdges(impactEdges)
                .build();
    }

    /**
     * 从文件路径提取类名
     */
    private String extractClassName(String filePath) {
        if (filePath == null) return "Unknown";

        // 移除 .class 后缀
        String className = filePath;
        if (className.endsWith(".class")) {
            className = className.substring(0, className.length() - 6);
        }

        // 处理 Spring Boot Fat JAR 路径：BOOT-INF/classes/org/example/... -> org.example...
        if (className.startsWith("BOOT-INF/classes/")) {
            className = className.substring("BOOT-INF/classes/".length());
        } else if (className.startsWith("BOOT-INF\\classes\\")) {
            className = className.substring("BOOT-INF\\classes\\".length());
        }

        // 转换为标准类名格式
        className = className.replace('/', '.').replace('\\', '.');

        // 提取简单类名（最后一个点号之后的部分）
        int lastDot = className.lastIndexOf('.');
        if (lastDot >= 0 && lastDot < className.length() - 1) {
            return className.substring(lastDot + 1);
        }

        return className;
    }

    /**
     * 构建反向调用图（增强版：支持接口到实现类的映射）
     * @param callEdges 调用边列表
     * @return 反向调用图 Map<calleeMethod, List<callerMethod>>
     */
    private Map<String, List<String>> buildReverseCallGraph(List<MethodCallEdge> callEdges) {
        // 1. 收集所有类名
        Set<String> classNames = new HashSet<>();
        for (MethodCallEdge edge : callEdges) {
            classNames.add(edge.getCallerClass());
            classNames.add(edge.getCalleeClass());
        }

        // 2. 构建接口映射
        Map<String, Set<String>> interfaceToImpl = interfaceMapper.buildInterfaceToImplMap(classNames);

        // 3. 构建基础反向调用图
        Map<String, List<String>> reverseGraph = new HashMap<>();
        for (MethodCallEdge edge : callEdges) {
            String callerKey = edge.getCallerClass() + "#" + edge.getCallerMethod();
            String calleeKey = edge.getCalleeClass() + "#" + edge.getCalleeMethod();
            reverseGraph.computeIfAbsent(calleeKey, k -> new ArrayList<>()).add(callerKey);

            // 4. 如果被调用者是接口，为实现类也添加索引
            Set<String> impls = interfaceToImpl.get(edge.getCalleeClass());
            if (impls != null) {
                for (String impl : impls) {
                    String implCalleeKey = impl + "#" + edge.getCalleeMethod();
                    reverseGraph.computeIfAbsent(implCalleeKey, k -> new ArrayList<>()).add(callerKey);
                }
            }
        }

        log.info("反向调用图构建完成，包含 {} 个方法的调用关系", reverseGraph.size());

        // 打印业务方法样例
        int businessCount = 0;
        for (Map.Entry<String, List<String>> entry : reverseGraph.entrySet()) {
            if (entry.getKey().contains(".cxf.") || entry.getKey().contains(".example.")) {
                if (businessCount++ < 5) {
                    log.info("  业务方法样例: {} 有 {} 个调用者", entry.getKey(), entry.getValue().size());
                }
            }
        }
        log.info("反向调用图中业务方法数量: {}", businessCount);

        return reverseGraph;
    }

    /**
     * 构建接口到实现类的映射
     * 规则1: 同包映射 - com.example.service.UserServiceImpl -> com.example.service.UserService
     * 规则2: 父包映射 - com.example.service.impl.UserServiceImpl -> com.example.service.UserService
     */
    private Map<String, Set<String>> buildInterfaceImplMap(List<MethodCallEdge> callEdges) {
        Set<String> classNames = new HashSet<>();
        for (MethodCallEdge edge : callEdges) {
            classNames.add(edge.getCallerClass());
            classNames.add(edge.getCalleeClass());
        }
        return interfaceMapper.buildInterfaceToImplMap(classNames);
    }

    /**
     * 递归追溯影响链路
     * @param method 当前方法
     * @param reverseGraph 反向调用图
     * @param visited 已访问方法集合
     * @param chain 影响链路（从修改方法到顶层调用者）
     * @param depth 当前深度
     */
    private void traceImpactChain(String method, Map<String, List<String>> reverseGraph,
                                  Set<String> visited, List<String> chain, int depth) {
        if (depth > 20) { // 防止无限递归
            log.warn("影响链路追溯深度超过20，停止追溯");
            return;
        }

        if (visited.contains(method)) {
            return; // 避免循环
        }

        visited.add(method);
        chain.add(method);

        // 查找调用当前方法的所有方法
        List<String> callers = reverseGraph.get(method);
        if (callers != null && !callers.isEmpty()) {
            // 选择第一个调用者继续追溯（实际应用中可能需要追溯所有调用者）
            String nextCaller = callers.get(0);
            traceImpactChain(nextCaller, reverseGraph, visited, chain, depth + 1);
        }
    }

    /**
     * 构建依赖分析摘要
     */
    private QuickDiffResponse.DependencySummary buildDependencySummary(
            DependencyAnalysisConfig depConfig,
            List<JarInfo> baselineJars,
            List<JarInfo> targetJars) {

        if (depConfig == null || !depConfig.isAnalyzeDependencies()) {
            return QuickDiffResponse.DependencySummary.builder()
                    .enabled(false)
                    .build();
        }

        // 提取依赖JAR名称（排除主JAR）
        List<String> analyzedDeps = new ArrayList<>();
        if (targetJars != null) {
            for (JarInfo jar : targetJars) {
                if (jar.getType() == JarInfo.JarType.DEPENDENCY) {
                    analyzedDeps.add(jar.getName());
                }
            }
        }

        return QuickDiffResponse.DependencySummary.builder()
                .enabled(true)
                .baselineDependencyCount(baselineJars != null ?
                        (int) baselineJars.stream().filter(j -> j.getType() == JarInfo.JarType.DEPENDENCY).count() : 0)
                .targetDependencyCount(targetJars != null ?
                        (int) targetJars.stream().filter(j -> j.getType() == JarInfo.JarType.DEPENDENCY).count() : 0)
                .analyzedDependencies(analyzedDeps)
                .build();
    }
    /**
     * 从JAR文件提取API信息（公共方法，供DiffAnalysisService复用）
     *
     * @param jarPath JAR文件路径
     * @param label 标签（用于日志）
     * @return API信息列表
     */
    public List<ApiInfo> extractApisFromJar(String jarPath, String label) throws IOException {
        List<ApiInfo> apiInfos = new ArrayList<>();

        log.info("开始从JAR提取API: jarPath={}, label={}", jarPath, label);

        // 创建临时解压目录
        String tempExtractDir = createTempDir() + "/" + label;
        FileUtil.createDirectoryIfNotExists(tempExtractDir);

        try {
            JarUtil.extractJar(jarPath, tempExtractDir);
            log.info("JAR解压完成: {}", tempExtractDir);

            // 获取所有class文件
            List<Path> classFiles = FileUtil.listFilesByExtension(tempExtractDir, "class");
            log.info("找到 {} 个class文件", classFiles.size());

            // 处理 Spring Boot Fat JAR 结构：检查 BOOT-INF/classes 目录
            String bootInfClassesDir = tempExtractDir + "/BOOT-INF/classes";
            File bootInfDir = new File(bootInfClassesDir);
            if (bootInfDir.exists() && bootInfDir.isDirectory()) {
                log.info("检测到 Spring Boot Fat JAR 结构，扫描 BOOT-INF/classes 目录");
                List<Path> bootInfClassFiles = FileUtil.listFilesByExtension(bootInfClassesDir, "class");
                classFiles.addAll(bootInfClassFiles);
                log.info("从 BOOT-INF/classes 找到 {} 个 class 文件", bootInfClassFiles.size());
            }

            classFiles = classFiles.stream()
                    .distinct()
                    .collect(Collectors.toList());
            log.info("总共扫描 {} 个class文件", classFiles.size());
            log.info("API提取策略数量: {}", apiStrategies.size());

            // 记录每个策略的支持情况
            int[] strategySupportCounts = new int[apiStrategies.size()];
            int[] strategyApiCounts = new int[apiStrategies.size()];

            for (Path classFile : classFiles) {
                String fileName = classFile.getFileName().toString();

                for (int i = 0; i < apiStrategies.size(); i++) {
                    ApiExtractorStrategy strategy = apiStrategies.get(i);
                    String strategyName = strategy.getClass().getSimpleName();
                    boolean supports = strategy.supports(classFile.toString());

                    if (supports) {
                        strategySupportCounts[i]++;
                        List<ApiModel> apis = strategy.extract(classFile.toString());

                        if (!apis.isEmpty()) {
                            strategyApiCounts[i] += apis.size();
                            log.info("策略 {} 从 {} 提取到 {} 个API", strategyName, fileName, apis.size());

                            for (ApiModel api : apis) {
                                log.info("  - API: {} {} ({}.{}())", api.getHttpMethod(), api.getUrl(),
                                        api.getControllerClass(), api.getMethodName());

                                ApiInfo info = new ApiInfo();
                                info.setUrl(api.getUrl());
                                info.setHttpMethod(api.getHttpMethod());
                                info.setControllerClass(api.getControllerClass());
                                info.setMethodName(api.getMethodName());
                                info.setParameters(api.getParameters());
                                info.setFramework(api.getFramework());
                                apiInfos.add(info);
                            }
                        }
                    }
                }
            }

            // 输出策略统计
            log.info("API提取策略统计:");
            for (int i = 0; i < apiStrategies.size(); i++) {
                log.info("  - {}: 支持的class文件={}, 提取的API数量={}",
                        apiStrategies.get(i).getClass().getSimpleName(),
                        strategySupportCounts[i], strategyApiCounts[i]);
            }

            log.info("从{}提取到 {} 个API", label, apiInfos.size());

        } catch (Exception e) {
            log.error("提取API失败: label=" + label, e);
        } finally {
            // 清理解压目录
            FileUtil.deleteDirectory(tempExtractDir);
        }

        int rawApiInfoCount = apiInfos.size();
        apiInfos = deduplicateExtractedApis(apiInfos);
        log.info("Deduplicated extracted APIs: label={}, raw={}, deduplicated={}",
                label, rawApiInfoCount, apiInfos.size());

        return apiInfos;
    }

    private List<ApiInfo> deduplicateExtractedApis(List<ApiInfo> apiInfos) {
        Map<String, ApiInfo> uniqueApis = new LinkedHashMap<>();
        int unkeyedIndex = 0;

        for (ApiInfo apiInfo : apiInfos) {
            String key = getApiInfoDeduplicationKey(apiInfo);
            if (key == null) {
                key = "__unkeyed__:" + unkeyedIndex++;
            }
            uniqueApis.putIfAbsent(key, apiInfo);
        }

        return new ArrayList<>(uniqueApis.values());
    }

    private String getApiInfoDeduplicationKey(ApiInfo apiInfo) {
        if (apiInfo == null) {
            return null;
        }
        if (hasText(apiInfo.getHttpMethod()) && hasText(apiInfo.getUrl())) {
            return "route:" + apiInfo.getHttpMethod().trim().toUpperCase()
                    + " " + apiInfo.getUrl().trim();
        }
        if (hasText(apiInfo.getControllerClass()) && hasText(apiInfo.getMethodName())) {
            return "method:" + apiInfo.getControllerClass().trim()
                    + "#" + apiInfo.getMethodName().trim();
        }
        return null;
    }

    private boolean hasText(String value) {
        return value != null && !value.trim().isEmpty();
    }

    /**
     * 提取变更的方法（公共方法，供DiffAnalysisService复用）
     *
     * @param fileDiffs 文件差异列表
     * @return 变更方法集合
     */
    /**
     * 提取变更方法并分类（新增、删除、修改）
     * 根据 MethodChangeModel 的 changeType 字段进行分类
     *
     * @param fileDiffs 文件差异列表
     * @return 方法变更分类结果
     */
    public MethodChangeClassification extractChangedMethodsClassified(List<FileDiffModel> fileDiffs) {
        MethodChangeClassification classification = new MethodChangeClassification();

        for (FileDiffModel fileDiff : fileDiffs) {
            if (fileDiff.getBytecodeDiff() != null && fileDiff.getBytecodeDiff().getMethodChanges() != null) {
                String className = fileDiff.getFilePath();
                if (className.endsWith(".class")) {
                    className = className.substring(0, className.length() - 6);
                }

                // 处理 Spring Boot Fat JAR 路径：BOOT-INF/classes/org/example/... -> org.example...
                if (className.startsWith("BOOT-INF/classes/")) {
                    className = className.substring("BOOT-INF/classes/".length());
                } else if (className.startsWith("BOOT-INF\\classes\\")) {
                    className = className.substring("BOOT-INF\\classes\\".length());
                }

                // 转换为标准类名格式（完整类名）
                className = className.replace('/', '.').replace('\\', '.');

                for (MethodChangeModel methodChange : fileDiff.getBytecodeDiff().getMethodChanges()) {
                    // 过滤构造方法和静态初始化块
                    if (methodChange.isConstructor()) {
                        log.debug("跳过构造方法/静态初始化块: {}#{}", className, methodChange.getMethodName());
                        continue;
                    }

                    String methodKey = className + "#" + methodChange.getMethodName();
                    String changeType = methodChange.getChangeType();

                    if ("ADDED".equals(changeType)) {
                        classification.getAddedMethods().add(methodKey);
                        log.debug("新增方法: {}", methodKey);
                    } else if ("DELETED".equals(changeType)) {
                        classification.getDeletedMethods().add(methodKey);
                        log.debug("删除方法: {}", methodKey);
                    } else if ("MODIFIED".equals(changeType)) {
                        classification.getModifiedMethods().add(methodKey);
                        log.debug("修改方法: {}", methodKey);
                    }
                }
            }
        }

        log.info("方法变更分类统计: 新增={}, 删除={}, 修改={}",
                classification.getAddedMethods().size(),
                classification.getDeletedMethods().size(),
                classification.getModifiedMethods().size());

        return classification;
    }

    /**
     * 提取变更方法（旧方法，保持向后兼容）
     *
     * @param fileDiffs 文件差异列表
     * @return 变更方法集合（不区分类型）
     * @deprecated 使用 extractChangedMethodsClassified 替代
     */
    @Deprecated
    public Set<String> extractChangedMethods(List<FileDiffModel> fileDiffs) {
        MethodChangeClassification classification = extractChangedMethodsClassified(fileDiffs);
        return classification.getAllChangedMethods();
    }

    /**
     * 判断方法是否可能是API方法（用于补充检测未被API提取器识别的API）
     *
     * @param methodKey 方法键（格式：className#methodName）
     * @param apis 已识别的API列表
     * @return true if 可能是API方法
     */
    private boolean isPotentialApiMethod(String methodKey, List<ApiInfo> apis) {
        if (methodKey == null || methodKey.isEmpty()) {
            return false;
        }

        String[] parts = methodKey.split("#");
        if (parts.length < 2) {
            return false;
        }

        String className = parts[0];
        String methodName = parts[1];

        // 判断1：同一个类中是否有其他方法被识别为API
        boolean hasApiInSameClass = apis.stream()
                .anyMatch(api -> className.equals(api.getControllerClass()));
        if (hasApiInSameClass) {
            log.debug("方法 {} 所属的类中有其他API方法，判定为潜在API", methodKey);
            return true;
        }

        // 判断2：类名包含API相关关键词
        String simpleClassName = className.contains(".")
                ? className.substring(className.lastIndexOf('.') + 1)
                : className;

        if (simpleClassName.contains("Api") ||
            simpleClassName.contains("Controller") ||
            simpleClassName.contains("Resource") ||
            simpleClassName.endsWith("Api") ||
            simpleClassName.endsWith("Controller") ||
            simpleClassName.endsWith("Resource")) {
            log.debug("方法 {} 的类名 {} 包含API关键词，判定为潜在API", methodKey, simpleClassName);
            return true;
        }

        // 判断3：方法名符合常见API方法命名模式（可选，可能误判率高）
        // 暂不启用，避免误判

        return false;
    }

    /**
     * 统一类名格式，确保使用完整类名（包含包名）
     * 处理 SpringMvcApiExtractor 返回的简单类名问题
     *
     * @param className 类名（可能是简单类名或完整类名）
     * @param targetApis 目标API列表，用于查找完整类名
     * @return 统一后的完整类名
     */
    private String normalizeClassName(String className, List<ApiInfo> targetApis) {
        if (className == null || className.isEmpty()) {
            return className;
        }

        // 如果类名不包含包名（没有点号），从 targetApis 中查找完整类名
        if (!className.contains(".")) {
            for (ApiInfo api : targetApis) {
                if (api.getControllerClass() != null) {
                    String fullClassName = api.getControllerClass();
                    String simpleClassName = fullClassName.substring(fullClassName.lastIndexOf('.') + 1);
                    if (simpleClassName.equals(className)) {
                        log.info("类名格式统一: {} -> {}", className, fullClassName);
                        return fullClassName;
                    }
                }
            }
            log.warn("无法找到简单类名 {} 对应的完整类名", className);
        }

        return className;
    }

    /**
     * 方法变更分类结果，用于区分新增、删除、修改的方法
     */
    public static class MethodChangeClassification {
        private Set<String> addedMethods = new HashSet<>();
        private Set<String> deletedMethods = new HashSet<>();
        private Set<String> modifiedMethods = new HashSet<>();

        public Set<String> getAddedMethods() {
            return addedMethods;
        }

        public Set<String> getDeletedMethods() {
            return deletedMethods;
        }

        public Set<String> getModifiedMethods() {
            return modifiedMethods;
        }

        public Set<String> getAllChangedMethods() {
            Set<String> all = new HashSet<>();
            all.addAll(addedMethods);
            all.addAll(deletedMethods);
            all.addAll(modifiedMethods);
            return all;
        }

        public boolean isEmpty() {
            return addedMethods.isEmpty() && deletedMethods.isEmpty() && modifiedMethods.isEmpty();
        }
    }

    /**
     * 检测新增和删除的API（公共方法，供DiffAnalysisService复用）
     *
     * @param baselineApis 基线API列表
     * @param targetApis 目标API列表
     * @return API变更列表
     */
    public List<ApiChangeModel> detectNewAndDeletedApis(List<ApiInfo> baselineApis, List<ApiInfo> targetApis) {
        List<ApiChangeModel> changes = new ArrayList<>();

        // 使用 Map 去重，以 key 为唯一标识
        Map<String, ApiInfo> baselineApiMap = baselineApis.stream()
                .collect(Collectors.toMap(
                        api -> api.getHttpMethod() + " " + api.getUrl(),
                        api -> api,
                        (existing, replacement) -> existing, // 保留第一个
                        LinkedHashMap::new
                ));

        Map<String, ApiInfo> targetApiMap = targetApis.stream()
                .collect(Collectors.toMap(
                        api -> api.getHttpMethod() + " " + api.getUrl(),
                        api -> api,
                        (existing, replacement) -> existing, // 保留第一个
                        LinkedHashMap::new
                ));

        Set<String> baselineApiKeys = baselineApiMap.keySet();
        Set<String> targetApiKeys = targetApiMap.keySet();

        // 新增的API
        for (Map.Entry<String, ApiInfo> entry : targetApiMap.entrySet()) {
            if (!baselineApiKeys.contains(entry.getKey())) {
                ApiInfo api = entry.getValue();
                ApiChangeModel change = new ApiChangeModel();
                change.setApiUrl(api.getUrl());
                change.setHttpMethod(api.getHttpMethod());
                change.setControllerClass(api.getControllerClass());
                change.setMethodName(api.getMethodName());
                change.setChangeType("NEW_API");
                change.setChangeReason("新增的API端点");
                changes.add(change);
            }
        }

        // 删除的API
        for (Map.Entry<String, ApiInfo> entry : baselineApiMap.entrySet()) {
            if (!targetApiKeys.contains(entry.getKey())) {
                ApiInfo api = entry.getValue();
                ApiChangeModel change = new ApiChangeModel();
                change.setApiUrl(api.getUrl());
                change.setHttpMethod(api.getHttpMethod());
                change.setControllerClass(api.getControllerClass());
                change.setMethodName(api.getMethodName());
                change.setChangeType("DELETED_API");
                change.setChangeReason("删除的API端点");
                changes.add(change);
            }
        }

        return changes;
    }

    
    private QuickDiffResponse.FileDiffItem toFileDiffItem(FileDiffModel model) {
        // 映射方法变更详情
        List<QuickDiffResponse.FileDiffItem.MethodChange> methodChanges = null;
        if (model.getBytecodeDiff() != null && model.getBytecodeDiff().getMethodChanges() != null) {
            methodChanges = model.getBytecodeDiff().getMethodChanges().stream()
                    .filter(mc -> !mc.isConstructor()) // 过滤掉构造方法
                    .map(mc -> QuickDiffResponse.FileDiffItem.MethodChange.builder()
                            .methodName(mc.getMethodName())
                            .changeType(mc.getChangeType())
                            .build())
                    .collect(Collectors.toList());
        }

        return QuickDiffResponse.FileDiffItem.builder()
                .filePath(model.getFilePath())
                .sourceFilePath(model.getSourceFilePath())
                .diffType(model.getDiffType())
                .sourceJar(model.getSourceJar())           // 新增：来源JAR
                .jarType(model.getJarType())               // 新增：JAR类型
                .baselineLines(model.getBaselineLines())
                .targetLines(model.getTargetLines())
                .addedLines(model.getAddedLines())
                .deletedLines(model.getDeletedLines())
                .methodsAdded(model.getMethodsAdded())
                .methodsDeleted(model.getMethodsDeleted())
                .methodsModified(model.getMethodsModified())
                .methodChanges(methodChanges)
                .build();
    }

    private QuickDiffResponse.ApiDiffItem toApiDiffItem(ApiChangeModel model) {
        List<QuickDiffResponse.ApiDiffItem.CallChainNode> callChain = null;
        if (model.getCallChain() != null) {
            callChain = model.getCallChain().stream()
                    .map(node -> QuickDiffResponse.ApiDiffItem.CallChainNode.builder()
                            .className(node.getClassName())
                            .methodName(node.getMethodName())
                            .depth(node.getDepth())
                            .build())
                    .collect(Collectors.toList());
        }

        return QuickDiffResponse.ApiDiffItem.builder()
                .apiUrl(model.getApiUrl())
                .httpMethod(model.getHttpMethod())
                .controllerClass(model.getControllerClass())
                .methodName(model.getMethodName())
                .changeType(model.getChangeType())
                .changeReason(model.getChangeReason())
                .callChain(callChain)
                .build();
    }

    private QuickDiffResponse.ApiDiffSummary calculateApiSummary(List<ApiChangeModel> apiChanges) {
        int newApis = 0, modifiedApis = 0, affectedApis = 0, deletedApis = 0;

        for (ApiChangeModel change : apiChanges) {
            switch (change.getChangeType()) {
                case "NEW_API": newApis++; break;
                case "MODIFIED_API": modifiedApis++; break;
                case "AFFECTED_API": affectedApis++; break;
                case "DELETED_API": deletedApis++; break;
            }
        }

        return QuickDiffResponse.ApiDiffSummary.builder()
                .newApis(newApis)
                .modifiedApis(modifiedApis)
                .affectedApis(affectedApis)
                .deletedApis(deletedApis)
                .build();
    }

    // ==================== 辅助方法 ====================

    private String createTempDir() throws IOException {
        // 使用项目目录下的临时目录，避免使用系统临时目录
        Path tempPath = tempDirConfig.createUniqueTempDir("quick_diff", "diff");
        return tempPath.toString();
    }

    private String saveTempFile(String tempDir, String prefix, MultipartFile file) throws IOException {
        String fileName = prefix + "_" + file.getOriginalFilename();
        String filePath = tempDir + File.separator + fileName;
        Files.copy(file.getInputStream(), Paths.get(filePath));
        log.info("保存临时文件: {}", filePath);
        return filePath;
    }

    private void cleanupTempDir(String tempDir) {
        try {
            FileUtil.deleteDirectory(tempDir);
            log.info("清理临时目录: {}", tempDir);
        } catch (Exception e) {
            log.warn("清理临时目录失败: {}", tempDir, e);
        }
    }

    // ==================== 持久化相关方法 ====================

    /**
     * 分析并保存结果
     */
    public QuickDiffResponse analyzeAndSave(MultipartFile baselineFile, MultipartFile targetFile, String description) {
        return analyzeAndSave(baselineFile, targetFile, description, DependencyAnalysisConfig.defaultConfig());
    }

    /**
     * 分析并保存结果（支持依赖分析）
     */
    public QuickDiffResponse analyzeAndSave(MultipartFile baselineFile, MultipartFile targetFile,
                                           String description, DependencyAnalysisConfig depConfig) {
        log.info("开始快速差异对比并保存: baseline={}, target={}, analyzeDependencies={}",
                baselineFile.getOriginalFilename(), targetFile.getOriginalFilename(),
                depConfig.isAnalyzeDependencies());

        // 执行分析
        QuickDiffResponse response = analyze(baselineFile, targetFile, depConfig);

        // 保存到数据库
        try {
            QuickDiffRecord record = new QuickDiffRecord();
            record.setBaselineFileName(baselineFile.getOriginalFilename());
            record.setTargetFileName(targetFile.getOriginalFilename());
            record.setBaselineMd5(calculateMd5(baselineFile));
            record.setTargetMd5(calculateMd5(targetFile));
            record.setFileSummaryJson(serializeToJson(response.getFileSummary()));
            record.setApiSummaryJson(serializeToJson(response.getApiSummary()));
            record.setFileDiffsJson(serializeToJson(response.getFileDiffs()));
            record.setApiDiffsJson(serializeToJson(response.getApiDiffs()));
            record.setSourceDiffsJson(serializeToJson(response.getSourceDiffs()));
            record.setDependencySummaryJson(serializeToJson(response.getDependencySummary()));
            record.setWarningsJson(serializeToJson(response.getWarnings()));
            record.setImpactGraphJson(serializeToJson(response.getImpactGraph()));
            record.setDurationMs(response.getDuration());
            record.setDescription(description);

            record = quickDiffRecordRepository.save(record);
            log.info("快速差异对比结果已保存，ID={}", record.getId());

            return response;
        } catch (Exception e) {
            log.error("保存快速差异对比结果失败", e);
            throw new BusinessException("保存结果失败: " + e.getMessage());
        }
    }

    /**
     * 根据ID查询详情
     */
    public QuickDiffResponse findById(Long id) {
        QuickDiffRecord record = quickDiffRecordRepository.findById(id)
                .orElseThrow(() -> new BusinessException("记录不存在: " + id));

        return convertToResponse(record);
    }

    /**
     * 查询所有历史记录（按创建时间倒序）
     */
    public List<QuickDiffListItem> findAllOrderByCreateTimeDesc() {
        List<QuickDiffRecord> records = quickDiffRecordRepository.findAllByOrderByCreatedAtDesc();
        return records.stream()
                .map(this::convertToListItem)
                .collect(Collectors.toList());
    }

    /**
     * 删除记录
     */
    public void deleteById(Long id) {
        if (!quickDiffRecordRepository.existsById(id)) {
            throw new BusinessException("记录不存在: " + id);
        }
        quickDiffRecordRepository.deleteById(id);
        log.info("已删除快速差异对比记录，ID={}", id);
    }

    // ==================== 辅助方法 ====================

    /**
     * 计算文件MD5
     */
    private String calculateMd5(MultipartFile file) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(file.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            log.warn("计算MD5失败", e);
            return null;
        }
    }

    /**
     * 序列化为JSON
     */
    private String serializeToJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            log.error("JSON序列化失败", e);
            throw new RuntimeException("JSON序列化失败", e);
        }
    }

    /**
     * 从JSON反序列化
     */
    private <T> T deserializeFromJson(String json, TypeReference<T> typeReference) {
        try {
            return objectMapper.readValue(json, typeReference);
        } catch (Exception e) {
            log.error("JSON反序列化失败", e);
            throw new RuntimeException("JSON反序列化失败", e);
        }
    }

    /**
     * 实体转换为响应对象
     */
    private QuickDiffResponse convertToResponse(QuickDiffRecord record) {
        try {
            QuickDiffResponse.FileSummary fileSummary = deserializeFromJson(
                    record.getFileSummaryJson(),
                    new TypeReference<QuickDiffResponse.FileSummary>() {}
            );

            QuickDiffResponse.ApiDiffSummary apiSummary = deserializeFromJson(
                    record.getApiSummaryJson(),
                    new TypeReference<QuickDiffResponse.ApiDiffSummary>() {}
            );

            List<QuickDiffResponse.FileDiffItem> fileDiffs = deserializeFromJson(
                    record.getFileDiffsJson(),
                    new TypeReference<List<QuickDiffResponse.FileDiffItem>>() {}
            );

            List<QuickDiffResponse.ApiDiffItem> apiDiffs = deserializeFromJson(
                    record.getApiDiffsJson(),
                    new TypeReference<List<QuickDiffResponse.ApiDiffItem>>() {}
            );

            List<FileSourceDiff> sourceDiffs = null;
            if (record.getSourceDiffsJson() != null) {
                sourceDiffs = deserializeFromJson(
                        record.getSourceDiffsJson(),
                        new TypeReference<List<FileSourceDiff>>() {}
                );
            }

            QuickDiffResponse.DependencySummary dependencySummary = null;
            if (record.getDependencySummaryJson() != null) {
                dependencySummary = deserializeFromJson(
                        record.getDependencySummaryJson(),
                        new TypeReference<QuickDiffResponse.DependencySummary>() {}
                );
            }

            List<String> warnings = null;
            if (record.getWarningsJson() != null) {
                warnings = deserializeFromJson(
                        record.getWarningsJson(),
                        new TypeReference<List<String>>() {}
                );
            }

            ImpactGraphResponse impactGraph = null;
            if (record.getImpactGraphJson() != null) {
                impactGraph = deserializeFromJson(
                        record.getImpactGraphJson(),
                        new TypeReference<ImpactGraphResponse>() {}
                );
            }

            return QuickDiffResponse.builder()
                    .fileSummary(fileSummary)
                    .apiSummary(apiSummary)
                    .fileDiffs(fileDiffs)
                    .apiDiffs(apiDiffs)
                    .sourceDiffs(sourceDiffs)
                    .dependencySummary(dependencySummary)
                    .warnings(warnings)
                    .impactGraph(impactGraph)
                    .duration(record.getDurationMs())
                    .build();
        } catch (Exception e) {
            log.error("转换响应失败", e);
            throw new BusinessException("数据解析失败: " + e.getMessage());
        }
    }

    /**
     * 实体转换为列表项
     */
    private QuickDiffListItem convertToListItem(QuickDiffRecord record) {
        try {
            QuickDiffResponse.FileSummary fileSummary = deserializeFromJson(
                    record.getFileSummaryJson(),
                    new TypeReference<QuickDiffResponse.FileSummary>() {}
            );

            QuickDiffResponse.ApiDiffSummary apiSummary = deserializeFromJson(
                    record.getApiSummaryJson(),
                    new TypeReference<QuickDiffResponse.ApiDiffSummary>() {}
            );

            int totalFilesChanged = fileSummary.getAddedFiles() + fileSummary.getModifiedFiles() + fileSummary.getDeletedFiles();
            int totalMethodChanges = fileSummary.getTotalMethodsAdded() + fileSummary.getTotalMethodsDeleted() + fileSummary.getTotalMethodsModified();
            int totalApiChanges = apiSummary.getNewApis() + apiSummary.getModifiedApis() + apiSummary.getAffectedApis() + apiSummary.getDeletedApis();

            return QuickDiffListItem.builder()
                    .id(record.getId())
                    .baselineFileName(record.getBaselineFileName())
                    .targetFileName(record.getTargetFileName())
                    .durationMs(record.getDurationMs())
                    .description(record.getDescription())
                    .createdAt(record.getCreatedAt())
                    .totalFilesChanged(totalFilesChanged)
                    .totalMethodChanges(totalMethodChanges)
                    .totalApiChanges(totalApiChanges)
                    .build();
        } catch (Exception e) {
            log.error("转换列表项失败", e);
            return QuickDiffListItem.builder()
                    .id(record.getId())
                    .baselineFileName(record.getBaselineFileName())
                    .targetFileName(record.getTargetFileName())
                    .durationMs(record.getDurationMs())
                    .description(record.getDescription())
                    .createdAt(record.getCreatedAt())
                    .totalFilesChanged(0)
                    .totalMethodChanges(0)
                    .totalApiChanges(0)
                    .build();
        }
    }

    /**
     * 获取文件扩展名（不含点）
     * 例如: "config.xml" -> "xml"
     */
    private String getFileExtension(String filePath) {
        if (filePath == null || filePath.isEmpty()) {
            return "";
        }
        int lastDot = filePath.lastIndexOf('.');
        if (lastDot == -1 || lastDot == filePath.length() - 1) {
            return "";
        }
        return filePath.substring(lastDot + 1).toLowerCase();
    }
}

package org.example.securityplatform.api;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.CallPathRequest;
import org.example.securityplatform.dto.CallPathResponse;
import org.example.securityplatform.dto.MethodSuggestion;
import org.example.securityplatform.service.CallPathService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

/**
 * 调用路径分析API控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/call-path")
public class CallPathController {

    @Autowired
    private CallPathService callPathService;

    /**
     * 查询调用路径
     * POST /api/call-path/query
     *
     * @param request 查询请求
     * @return 调用路径响应
     */
    @PostMapping("/query")
    public Result<CallPathResponse> queryPath(@RequestBody @Valid CallPathRequest request) {
        try {
            log.info("收到调用路径查询请求: {}#{} -> {}#{}",
                    request.getStartClass(), request.getStartMethod(),
                    request.getEndClass(), request.getEndMethod());

            CallPathResponse response = callPathService.findPaths(request);
            return Result.success(response);
        } catch (IllegalArgumentException e) {
            log.warn("参数错误: {}", e.getMessage());
            return Result.error("参数错误: " + e.getMessage());
        } catch (Exception e) {
            log.error("查询调用路径失败", e);
            return Result.error("查询失败: " + e.getMessage());
        }
    }

    /**
     * 搜索方法（自动补全）
     * GET /api/call-path/search-methods?artifactId=1&keyword=UserService&limit=20
     *
     * @param artifactId 制品ID
     * @param keyword    关键字
     * @param limit      返回数量限制（默认20）
     * @return 方法建议列表
     */
    @GetMapping("/search-methods")
    public Result<List<MethodSuggestion>> searchMethods(
            @RequestParam Long artifactId,
            @RequestParam String keyword,
            @RequestParam(defaultValue = "20") Integer limit) {
        try {
            log.debug("收到方法搜索请求: artifactId={}, keyword={}, limit={}", artifactId, keyword, limit);

            List<MethodSuggestion> suggestions = callPathService.searchMethods(artifactId, keyword, limit);
            return Result.success(suggestions);
        } catch (IllegalArgumentException e) {
            log.warn("参数错误: {}", e.getMessage());
            return Result.error("参数错误: " + e.getMessage());
        } catch (Exception e) {
            log.error("搜索方法失败", e);
            return Result.error("搜索失败: " + e.getMessage());
        }
    }
}
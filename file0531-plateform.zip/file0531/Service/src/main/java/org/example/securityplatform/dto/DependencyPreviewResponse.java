package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 依赖预览响应 - 返回JAR包中的依赖JAR列表和业务包名列表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DependencyPreviewResponse {

    /**
     * 依赖JAR名称列表（从BOOT-INF/lib和WEB-INF/lib扫描）
     */
    private List<String> dependencyJars;

    /**
     * 业务包名列表（从class文件路径提取，排除框架包）
     */
    private List<String> packages;

    /**
     * 总依赖数量
     */
    private Integer totalDependencies;

    /**
     * 是否为多模块项目（父JAR无业务代码）
     */
    private Boolean isMultiModule;

    /**
     * 从pom.xml解析出的模块名列表
     */
    private List<String> detectedModules;

    /**
     * 自动匹配的子模块JAR名（基于detectedModules匹配BOOT-INF/lib）
     */
    private List<String> autoSelectJars;

    /**
     * 检测方式："pom_xml"（从pom.xml解析） 或 "layers_idx"（分层打包） 或 "package_scan"（包名扫描） 或 "heuristic"（启发式）
     */
    private String detectionMethod;

    /**
     * 自动选中的业务包名（从BOOT-INF/classes扫描，排除框架包）
     * 前端可自动填充到includePackages字段
     */
    private List<String> autoSelectPackages;
}
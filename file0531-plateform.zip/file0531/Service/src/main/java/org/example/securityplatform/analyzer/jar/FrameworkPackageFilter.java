package org.example.securityplatform.analyzer.jar;

import org.example.securityplatform.analyzer.core.AnalysisConfig;

/**
 * 框架包过滤器
 * 统一判断类路径是否属于框架包
 */
public class FrameworkPackageFilter {

    private final AnalysisConfig config;

    public FrameworkPackageFilter() {
        this.config = AnalysisConfig.defaultConfig();
    }

    public FrameworkPackageFilter(AnalysisConfig config) {
        this.config = config;
    }

    /**
     * 判断类路径是否属于框架包
     *
     * @param classPath 类路径（如 org/springframework/core/xxx）
     * @return true 如果是框架包
     */
    public boolean isFrameworkPackage(String classPath) {
        if (classPath == null || classPath.isEmpty()) {
            return false;
        }

        for (String prefix : config.getFrameworkPackages()) {
            if (classPath.startsWith(prefix)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断类路径是否属于业务包（非框架包）
     */
    public boolean isBusinessPackage(String classPath) {
        return !isFrameworkPackage(classPath);
    }
}

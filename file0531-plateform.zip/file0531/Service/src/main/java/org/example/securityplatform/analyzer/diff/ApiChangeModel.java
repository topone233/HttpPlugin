package org.example.securityplatform.analyzer.diff;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * API变更模型
 */
@Data
public class ApiChangeModel {
    private String apiUrl;
    private String httpMethod;
    private String controllerClass;
    private String methodName;
    private String parameters;
    private String framework;

    // 变更类型
    private String changeType; // NEW_API, MODIFIED_API, DELETED_API, AFFECTED_API

    // 变更原因
    private String changeReason;

    // 调用链（从API到变更点）
    private List<CallChainNode> callChain = new ArrayList<>();

    // 关联的文件差异
    private List<String> relatedFiles = new ArrayList<>();

    // 关联的危险函数
    private List<DangerFunctionRef> dangerFunctions = new ArrayList<>();

    @Data
    public static class CallChainNode {
        private String className;
        private String methodName;
        private int depth;

        public CallChainNode(String className, String methodName, int depth) {
            this.className = className;
            this.methodName = methodName;
            this.depth = depth;
        }
    }

    @Data
    public static class DangerFunctionRef {
        private String functionName;
        private String functionType;
    }

    /**
     * 生成API唯一标识
     */
    public String getApiKey() {
        return httpMethod + " " + apiUrl;
    }
}
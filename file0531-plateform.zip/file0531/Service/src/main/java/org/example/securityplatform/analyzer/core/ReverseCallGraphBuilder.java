package org.example.securityplatform.analyzer.core;

import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.function.Function;

/**
 * 反向调用图构建器
 * 将正向调用边转换为反向索引（被调用者 → 调用者），支持接口映射
 *
 * @param <T> 调用边类型（MethodCallModel 或 MethodCallEdge）
 */
@Slf4j
public class ReverseCallGraphBuilder<T> {

    private final InterfaceMapper interfaceMapper;

    public ReverseCallGraphBuilder() {
        this.interfaceMapper = new InterfaceMapper();
    }

    public ReverseCallGraphBuilder(InterfaceMapper interfaceMapper) {
        this.interfaceMapper = interfaceMapper;
    }

    /**
     * 构建反向调用图（基础版本）
     *
     * @param callEdges          调用边列表
     * @param calleeKeyExtractor 从调用边提取被调用者键（如 "类名#方法名"）
     * @return 反向调用图 Map<被调用者键, List<调用边>>
     */
    public Map<String, List<T>> buildReverseGraph(
            List<T> callEdges,
            Function<T, String> calleeKeyExtractor) {

        Map<String, List<T>> reverseGraph = new HashMap<>();

        for (T edge : callEdges) {
            String calleeKey = calleeKeyExtractor.apply(edge);
            reverseGraph.computeIfAbsent(calleeKey, k -> new ArrayList<>()).add(edge);
        }

        log.info("反向调用图构建完成: {} 条调用边, {} 个被调用者", callEdges.size(), reverseGraph.size());

        return reverseGraph;
    }

    /**
     * 构建反向调用图（支持接口映射）
     * 当被调用者是接口时，同时为实现类创建索引，使查询实现类方法时也能找到调用者
     *
     * @param callEdges           调用边列表
     * @param calleeKeyExtractor  从调用边提取被调用者键
     * @param calleeClassExtractor 从调用边提取被调用者类名
     * @param allClassNames       所有类名集合
     * @return 反向调用图（含接口映射）
     */
    public Map<String, List<T>> buildReverseGraphWithInterfaceMapping(
            List<T> callEdges,
            Function<T, String> calleeKeyExtractor,
            Function<T, String> calleeClassExtractor,
            Set<String> allClassNames) {

        // 先构建基础反向图
        Map<String, List<T>> reverseGraph = buildReverseGraph(callEdges, calleeKeyExtractor);

        // 构建接口映射
        Map<String, Set<String>> interfaceToImpl = interfaceMapper.buildInterfaceToImplMap(allClassNames);

        if (interfaceToImpl.isEmpty()) {
            return reverseGraph;
        }

        // 为接口方法添加实现类调用关系
        int mappingCount = 0;
        for (T edge : callEdges) {
            String calleeClass = calleeClassExtractor.apply(edge);
            Set<String> impls = interfaceToImpl.get(calleeClass);

            if (impls != null) {
                String calleeKey = calleeKeyExtractor.apply(edge);
                String methodName = calleeKey.substring(calleeClass.length());

                for (String impl : impls) {
                    String implCalleeKey = impl + methodName;
                    // 复制调用关系到实现类方法
                    reverseGraph.computeIfAbsent(implCalleeKey, k -> new ArrayList<>()).add(edge);
                    mappingCount++;
                }
            }
        }

        log.info("接口映射完成: 新增 {} 条映射关系", mappingCount);

        return reverseGraph;
    }

    /**
     * 构建反向调用图（简化版，只存储调用者键字符串）
     *
     * @param callEdges          调用边列表
     * @param callerKeyExtractor 从调用边提取调用者键
     * @param calleeKeyExtractor 从调用边提取被调用者键
     * @return 反向调用图 Map<被调用者键, List<调用者键>>
     */
    public Map<String, List<String>> buildReverseGraphSimple(
            List<T> callEdges,
            Function<T, String> callerKeyExtractor,
            Function<T, String> calleeKeyExtractor) {

        Map<String, List<String>> reverseGraph = new HashMap<>();

        for (T edge : callEdges) {
            String callerKey = callerKeyExtractor.apply(edge);
            String calleeKey = calleeKeyExtractor.apply(edge);
            reverseGraph.computeIfAbsent(calleeKey, k -> new ArrayList<>()).add(callerKey);
        }

        return reverseGraph;
    }

    /**
     * 构建正向调用图
     *
     * @param callEdges          调用边列表
     * @param callerKeyExtractor 从调用边提取调用者键
     * @return 正向调用图 Map<调用者键, List<调用边>>
     */
    public Map<String, List<T>> buildForwardGraph(
            List<T> callEdges,
            Function<T, String> callerKeyExtractor) {

        Map<String, List<T>> forwardGraph = new HashMap<>();

        for (T edge : callEdges) {
            String callerKey = callerKeyExtractor.apply(edge);
            forwardGraph.computeIfAbsent(callerKey, k -> new ArrayList<>()).add(edge);
        }

        return forwardGraph;
    }
}

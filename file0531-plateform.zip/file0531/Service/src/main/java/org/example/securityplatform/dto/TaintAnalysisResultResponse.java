package org.example.securityplatform.dto;

import lombok.Data;

import java.util.List;

/**
 * 污点分析结果响应
 */
@Data
public class TaintAnalysisResultResponse {
    /**
     * 制品ID
     */
    private Long artifactId;

    /**
     * 漏洞类型
     */
    private String vulnerabilityType;

    /**
     * Sink点总数
     */
    private Integer totalSinks;

    /**
     * 已追踪路径数
     */
    private Integer tracedPaths;

    /**
     * 可达路径数
     */
    private Integer reachablePaths;

    /**
     * Sink点列表
     */
    private List<TaintSinkResponse> sinks;
}
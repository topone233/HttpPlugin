package org.example.securityplatform.analyzer.taint;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.mybatis.MyBatisMapperModel;
import org.example.securityplatform.analyzer.mybatis.MyBatisMapperParser;
import org.example.securityplatform.entity.TaintSink;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * SQL注入Sink检测器
 * 检测MyBatis Mapper中的${}占位符注入风险
 */
@Slf4j
@Component
public class SqlInjectionSinkDetector implements SinkDetector {

    private final MyBatisMapperParser mapperParser = new MyBatisMapperParser();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String getVulnerabilityType() {
        return "SQL_INJECTION";
    }

    @Override
    public String getSinkType() {
        return "MYBATIS_MAPPER";
    }

    @Override
    public List<TaintSink> detect(String jarPath, Long artifactId) throws IOException {
        List<TaintSink> sinks = new ArrayList<>();

        log.info("开始检测SQL注入Sink点: {}", jarPath);

        // 解析MyBatis Mapper XML文件
        List<MyBatisMapperModel> mappers = mapperParser.parse(jarPath);

        // 遍历Mapper，检测${}占位符
        for (MyBatisMapperModel mapper : mappers) {
            for (MyBatisMapperModel.SqlStatement stmt : mapper.getStatements()) {
                if (!stmt.getDollarParams().isEmpty()) {
                    TaintSink sink = createSink(mapper, stmt, artifactId);
                    sinks.add(sink);
                }
            }
        }

        log.info("检测到 {} 个SQL注入Sink点", sinks.size());
        return sinks;
    }

    /**
     * 创建Sink实体
     */
    private TaintSink createSink(MyBatisMapperModel mapper, MyBatisMapperModel.SqlStatement stmt, Long artifactId) {
        TaintSink sink = new TaintSink();
        sink.setArtifactId(artifactId);
        sink.setVulnerabilityType(getVulnerabilityType());
        sink.setSinkType(getSinkType());

        // 从namespace提取类名（去除包名前缀）
        String namespace = mapper.getNamespace();
        sink.setSinkClass(namespace);
        sink.setSinkMethod(stmt.getId());

        // 存储可被注入的参数列表
        try {
            sink.setVulnerableParams(objectMapper.writeValueAsString(stmt.getDollarParams()));
        } catch (JsonProcessingException e) {
            log.warn("序列化参数列表失败", e);
            sink.setVulnerableParams("[]");
        }

        sink.setFilePath(mapper.getFilePath());
        sink.setSqlSnippet(truncateSql(stmt.getSql()));
        sink.setRiskLevel("HIGH"); // ${}占位符默认高危
        sink.setLineNumber(stmt.getLineNumber());

        return sink;
    }

    /**
     * 截断SQL片段，避免存储过长
     */
    private String truncateSql(String sql) {
        if (sql == null) {
            return null;
        }
        // 限制在500字符
        return sql.length() > 500 ? sql.substring(0, 500) + "..." : sql;
    }
}
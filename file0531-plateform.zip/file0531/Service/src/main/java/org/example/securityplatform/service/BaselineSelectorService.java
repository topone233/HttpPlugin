package org.example.securityplatform.service;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.dto.BaselineRecommendationResponse;
import org.example.securityplatform.entity.Artifact;
import org.example.securityplatform.entity.Task;
import org.example.securityplatform.repository.ArtifactRepository;
import org.example.securityplatform.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 基线版本推荐服务 - 推荐上次测试的制品作为基线
 */
@Slf4j
@Service
public class BaselineSelectorService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private ArtifactRepository artifactRepository;

    /**
     * 获取项目的基线推荐
     *
     * @param projectId 项目ID
     * @return 基线推荐响应
     */
    public BaselineRecommendationResponse getBaselineRecommendation(Long projectId) {
        log.info("获取项目基线推荐: projectId={}", projectId);

        BaselineRecommendationResponse response = new BaselineRecommendationResponse();
        response.setProjectId(projectId);

        // 获取项目的所有任务
        List<Task> tasks = taskRepository.findByProjectId(projectId);

        if (tasks.isEmpty()) {
            log.info("项目没有历史任务: projectId={}", projectId);
            response.setRecommended(null);
            response.setHistory(new ArrayList<>());
            return response;
        }

        // 按测试时间排序，最新的在前
        List<Task> sortedTasks = tasks.stream()
                .sorted(Comparator.comparing(Task::getTestTime, Comparator.nullsLast(Comparator.reverseOrder())))
                .collect(Collectors.toList());

        // 转换为历史制品列表
        List<BaselineRecommendationResponse.BaselineArtifact> historyList = new ArrayList<>();
        BaselineRecommendationResponse.BaselineArtifact recommended = null;

        for (Task task : sortedTasks) {
            // 获取任务的制品
            List<Artifact> artifacts = artifactRepository.findByTaskId(task.getId());
            if (!artifacts.isEmpty()) {
                // 取第一个制品（通常一个任务只有一个制品）
                Artifact artifact = artifacts.get(0);

                BaselineRecommendationResponse.BaselineArtifact baselineArtifact =
                        new BaselineRecommendationResponse.BaselineArtifact();
                baselineArtifact.setArtifactId(artifact.getId());
                baselineArtifact.setArtifactName(artifact.getArtifactName());
                baselineArtifact.setTaskId(task.getId());
                baselineArtifact.setTaskName(task.getTaskName());
                baselineArtifact.setTestTime(task.getTestTime());
                baselineArtifact.setTaskStatus(task.getStatus());

                historyList.add(baselineArtifact);

                // 推荐逻辑：优先选择 COMPLETED 状态，如果没有则选择最新的任务
                if (recommended == null) {
                    if ("COMPLETED".equals(task.getStatus())) {
                        // 优先推荐已完成的任务
                        recommended = baselineArtifact;
                    } else if (historyList.size() == 1) {
                        // 如果没有已完成的任务，推荐最新的任务（第一个）
                        // 但继续查找是否有已完成的任务
                    }
                }
            }
        }

        // 如果没有 COMPLETED 状态的任务，选择最新的作为推荐
        if (recommended == null && !historyList.isEmpty()) {
            recommended = historyList.get(0);
        }

        response.setHistory(historyList);
        response.setRecommended(recommended);

        log.info("基线推荐完成: historySize={}, recommended={}",
                historyList.size(), recommended != null ? recommended.getArtifactName() : "无");

        return response;
    }

    /**
     * 获取项目的历史制品列表
     *
     * @param projectId 项目ID
     * @return 历史制品列表
     */
    public List<BaselineRecommendationResponse.BaselineArtifact> getHistoryBaselines(Long projectId) {
        BaselineRecommendationResponse response = getBaselineRecommendation(projectId);
        return response.getHistory();
    }

    /**
     * 检查制品是否属于项目
     *
     * @param artifactId 制品ID
     * @param projectId  项目ID
     * @return 是否属于该项目
     */
    public boolean isArtifactBelongsToProject(Long artifactId, Long projectId) {
        Artifact artifact = artifactRepository.findById(artifactId).orElse(null);
        if (artifact == null) {
            return false;
        }

        Task task = taskRepository.findById(artifact.getTaskId()).orElse(null);
        if (task == null) {
            return false;
        }

        return projectId.equals(task.getProjectId());
    }
}
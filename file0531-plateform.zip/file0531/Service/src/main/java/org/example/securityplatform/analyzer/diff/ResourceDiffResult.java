package org.example.securityplatform.analyzer.diff;

import lombok.Data;

/**
 * 资源文件差异结果（用于XML/配置文件/SQL等业务代码文件）
 */
@Data
public class ResourceDiffResult {
    /**
     * 文件路径
     */
    private String filePath;

    /**
     * 基线版本行数
     */
    private int baselineLines;

    /**
     * 目标版本行数
     */
    private int targetLines;

    /**
     * 新增行数
     */
    private int addedLines;

    /**
     * 删除行数
     */
    private int deletedLines;

    /**
     * 检查是否存在实际差异
     */
    public boolean hasChanges() {
        return addedLines > 0 || deletedLines > 0;
    }
}
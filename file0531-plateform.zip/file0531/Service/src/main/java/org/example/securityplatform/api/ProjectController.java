package org.example.securityplatform.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.example.securityplatform.common.Result;
import org.example.securityplatform.dto.CreateProjectRequest;
import org.example.securityplatform.dto.ProjectResponse;
import org.example.securityplatform.service.ProjectService;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 项目管理API控制器
 */
@Tag(name = "项目管理", description = "项目的创建、查询、删除等操作")
@RestController
@RequestMapping("/api/projects")
@RequiredArgsConstructor
public class ProjectController {

    private final ProjectService projectService;

    /**
     * 创建项目
     */
    @Operation(summary = "创建项目", description = "创建一个新的安全测试项目")
    @PostMapping
    public Result<ProjectResponse> createProject(@Validated @RequestBody CreateProjectRequest request) {
        return Result.success(projectService.createProject(request));
    }

    /**
     * 根据ID查询项目
     */
    @Operation(summary = "根据ID查询项目", description = "根据项目ID获取项目详情")
    @GetMapping("/{id}")
    public Result<ProjectResponse> getProjectById(
            @Parameter(description = "项目ID") @PathVariable Long id) {
        return Result.success(projectService.getProjectById(id));
    }

    /**
     * 根据项目名称查询项目
     */
    @Operation(summary = "根据名称查询项目", description = "根据项目名称获取项目详情")
    @GetMapping("/name/{projectName}")
    public Result<ProjectResponse> getProjectByName(
            @Parameter(description = "项目名称") @PathVariable String projectName) {
        return Result.success(projectService.getProjectByName(projectName));
    }

    /**
     * 查询所有项目
     */
    @Operation(summary = "查询所有项目", description = "获取所有项目列表")
    @GetMapping
    public Result<List<ProjectResponse>> getAllProjects() {
        return Result.success(projectService.getAllProjects());
    }

    /**
     * 删除项目
     */
    @Operation(summary = "删除项目", description = "根据ID删除项目")
    @DeleteMapping("/{id}")
    public Result<Void> deleteProject(
            @Parameter(description = "项目ID") @PathVariable Long id) {
        projectService.deleteProject(id);
        return Result.success(null);
    }
}
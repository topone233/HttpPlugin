package org.example.securityplatform.analyzer.danger;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.entity.DangerFunctionRule;
import org.example.securityplatform.repository.DangerFunctionRuleRepository;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 基于规则库的危险函数扫描器
 * 从数据库读取规则进行扫描，替代硬编码的扫描规则
 */
@Slf4j
public class RuleBasedDangerFunctionScanner {

    private final String jarPath;
    private final List<DangerFunctionRule> rules;

    public RuleBasedDangerFunctionScanner(String jarPath, List<DangerFunctionRule> rules) {
        this.jarPath = jarPath;
        this.rules = rules;
    }

    /**
     * 扫描危险函数
     */
    public List<DangerFunctionModel> scan() throws IOException {
        List<DangerFunctionModel> results = new ArrayList<>();

        if (rules == null || rules.isEmpty()) {
            log.warn("没有加载到任何危险函数规则，跳过扫描");
            return results;
        }

        log.info("使用 {} 条规则进行危险函数扫描", rules.size());

        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> entries = jarFile.entries();

            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (entry.getName().endsWith(".class") && !entry.isDirectory()) {
                    try (InputStream is = jarFile.getInputStream(entry)) {
                        ClassReader classReader = new ClassReader(is);
                        RuleBasedVisitor visitor = new RuleBasedVisitor(entry.getName(), rules);
                        classReader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
                        results.addAll(visitor.getDangers());
                    } catch (IOException e) {
                        log.warn("解析class文件失败: {}", entry.getName(), e);
                    }
                }
            }
        }

        return results;
    }

    /**
     * 规则匹配的 ASM Visitor
     */
    private static class RuleBasedVisitor extends ClassVisitor {
        private final String filePath;
        private final List<DangerFunctionRule> rules;
        private String className;
        private String currentMethod;
        private int lineNumber;
        private final List<DangerFunctionModel> dangers = new ArrayList<>();

        public RuleBasedVisitor(String filePath, List<DangerFunctionRule> rules) {
            super(Opcodes.ASM9);
            this.filePath = filePath;
            this.rules = rules;
        }

        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            this.className = name;
            super.visit(version, access, name, signature, superName, interfaces);
        }

        @Override
        public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            this.currentMethod = name;
            return new MethodVisitor(Opcodes.ASM9) {
                @Override
                public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
                    // 检查每条规则
                    for (DangerFunctionRule rule : rules) {
                        if (matchesRule(owner, name, rule)) {
                            addDanger(rule);
                            break; // 匹配到一条规则后跳出
                        }
                    }
                }

                @Override
                public void visitLineNumber(int line, org.objectweb.asm.Label start) {
                    lineNumber = line;
                }
            };
        }

        /**
         * 检查方法调用是否匹配规则
         */
        private boolean matchesRule(String owner, String methodName, DangerFunctionRule rule) {
            return matchesPattern(owner, rule.getClassPattern()) &&
                   matchesPattern(methodName, rule.getMethodPattern());
        }

        /**
         * 模式匹配（支持通配符 *）
         */
        private boolean matchesPattern(String value, String pattern) {
            if (pattern == null || pattern.isEmpty() || "*".equals(pattern)) {
                return true;
            }
            if (value == null) {
                return false;
            }

            // 支持前缀通配符 *xxx
            if (pattern.startsWith("*") && !pattern.endsWith("*")) {
                return value.contains(pattern.substring(1));
            }
            // 支持后缀通配符 xxx*
            if (pattern.endsWith("*") && !pattern.startsWith("*")) {
                return value.startsWith(pattern.substring(0, pattern.length() - 1));
            }
            // 支持前后通配符 *xxx*
            if (pattern.startsWith("*") && pattern.endsWith("*")) {
                return value.contains(pattern.substring(1, pattern.length() - 1));
            }
            // 精确匹配
            return value.equals(pattern);
        }

        /**
         * 添加危险函数记录
         */
        private void addDanger(DangerFunctionRule rule) {
            DangerFunctionModel danger = new DangerFunctionModel();
            danger.setFunctionName(rule.getRuleName());
            danger.setFunctionType(rule.getFunctionType());
            danger.setClassName(className.replace('/', '.'));
            danger.setMethodName(currentMethod);
            danger.setLineNumber(lineNumber > 0 ? lineNumber : null);
            danger.setFilePath(filePath);
            danger.setRiskLevel(rule.getRiskLevel());
            dangers.add(danger);
        }

        public List<DangerFunctionModel> getDangers() {
            return dangers;
        }
    }
}

package org.example.securityplatform.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 差异分析进度实体
 */
@Data
@Entity
@Table(name = "diff_analysis_progress")
public class DiffAnalysisProgress {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "diff_task_id", nullable = false)
    private Long diffTaskId;

    @Column(name = "current_step", nullable = false, length = 50)
    private String currentStep;

    @Column(name = "step_status", nullable = false, length = 20)
    private String stepStatus = "PENDING"; // PENDING, IN_PROGRESS, COMPLETED, FAILED

    @Column(name = "progress_percentage")
    private Integer progressPercentage = 0;

    @Column(name = "message", columnDefinition = "TEXT")
    private String message;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}

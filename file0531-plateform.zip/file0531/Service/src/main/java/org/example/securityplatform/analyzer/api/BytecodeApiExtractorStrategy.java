package org.example.securityplatform.analyzer.api;

import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * 字节码API提取策略
 * 支持从编译后的.class文件中提取API信息
 */
@Slf4j
public class BytecodeApiExtractorStrategy implements ApiExtractorStrategy {

    private final BytecodeApiExtractor extractor = new BytecodeApiExtractor();

    @Override
    public boolean supports(String filePath) {
        return filePath != null && filePath.endsWith(".class");
    }

    @Override
    public List<ApiModel> extract(String filePath) {
        log.debug("从字节码文件提取API: {}", filePath);
        return extractor.extractFromClassFile(filePath);
    }
}

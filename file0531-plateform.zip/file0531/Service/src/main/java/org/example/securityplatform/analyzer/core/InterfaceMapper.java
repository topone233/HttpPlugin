package org.example.securityplatform.analyzer.core;

import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 接口-实现类映射器
 * 负责识别 XxxImpl → Xxx 的接口关系
 * <p>
 * 支持两种映射规则：
 * 1. 同包映射：com.example.service.UserServiceImpl → com.example.service.UserService
 * 2. 父包映射：com.example.service.impl.UserServiceImpl → com.example.service.UserService
 */
@Slf4j
public class InterfaceMapper {

    /** 缓存：接口到实现类的映射 */
    private Map<String, Set<String>> cachedInterfaceToImpl;

    /** 缓存：实现类到接口的反向映射 */
    private Map<String, String> cachedImplToInterface;

    /** 是否启用缓存 */
    private final boolean enableCache;

    public InterfaceMapper() {
        this.enableCache = true;
    }

    public InterfaceMapper(boolean enableCache) {
        this.enableCache = enableCache;
    }

    /**
     * 构建接口到实现类的映射
     *
     * @param classNames 所有类名集合
     * @return Map<接口名, Set<实现类名>>
     */
    public Map<String, Set<String>> buildInterfaceToImplMap(Set<String> classNames) {
        if (enableCache && cachedInterfaceToImpl != null) {
            return cachedInterfaceToImpl;
        }

        Map<String, Set<String>> interfaceToImpl = new HashMap<>();

        for (String className : classNames) {
            if (className.endsWith("Impl")) {
                List<String> possibleInterfaces = inferPossibleInterfaces(className);

                for (String interfaceName : possibleInterfaces) {
                    if (classNames.contains(interfaceName)) {
                        interfaceToImpl.computeIfAbsent(interfaceName, k -> new HashSet<>()).add(className);
                        log.debug("接口映射: {} -> {}", interfaceName, className);
                    }
                }
            }
        }

        log.info("接口映射统计: 找到 {} 个接口有实现类", interfaceToImpl.size());
        if (!interfaceToImpl.isEmpty()) {
            int sampleCount = 0;
            for (Map.Entry<String, Set<String>> entry : interfaceToImpl.entrySet()) {
                if (sampleCount++ < 3) {
                    log.info("  接口映射样例: {} -> {}", entry.getKey(), entry.getValue());
                }
            }
        }

        if (enableCache) {
            cachedInterfaceToImpl = interfaceToImpl;
            // 同时构建反向映射
            buildImplToInterfaceMap(interfaceToImpl);
        }

        return interfaceToImpl;
    }

    /**
     * 查找实现类对应的所有接口
     * 支持一个实现类实现多个接口的场景
     *
     * @param implClassName 实现类名
     * @return 接口名集合，如果找不到返回null
     */
    public Set<String> findInterfaces(String implClassName) {
        if (enableCache && cachedImplToInterface != null) {
            // 从缓存中查找，返回单个接口包装为Set
            String interfaceName = cachedImplToInterface.get(implClassName);
            if (interfaceName != null) {
                return Collections.singleton(interfaceName);
            }
        }

        // 如果缓存不可用，尝试推断
        // TODO: 未来可以支持一个类实现多个接口的场景
        List<String> possibleInterfaces = inferPossibleInterfaces(implClassName);
        Set<String> result = new HashSet<>();
        for (String interfaceName : possibleInterfaces) {
            // 注意：这里需要classNames集合来验证接口是否存在
            // 由于方法签名没有classNames参数，我们返回所有推断结果
            result.add(interfaceName);
        }

        return result.isEmpty() ? null : result;
    }

    /**
     * 查找实现类对应的接口
     *
     * @param implClassName 实现类名
     * @param classNames    所有类名集合
     * @return 接口名，如果找不到返回null
     */
    public String findInterfaceForImpl(String implClassName, Set<String> classNames) {
        if (enableCache && cachedImplToInterface != null) {
            return cachedImplToInterface.get(implClassName);
        }

        List<String> possibleInterfaces = inferPossibleInterfaces(implClassName);

        for (String interfaceName : possibleInterfaces) {
            if (classNames.contains(interfaceName)) {
                return interfaceName;
            }
        }

        return null;
    }

    /**
     * 查找方法键对应的接口方法键
     * 例如：UserServiceImpl#getUserById → UserService#getUserById
     *
     * @param methodKey   方法键（格式：类名#方法名）
     * @param classNames  所有类名集合
     * @return 接口方法键列表（可能有多个匹配）
     */
    public List<String> findInterfaceMethodKeys(String methodKey, Set<String> classNames) {
        List<String> result = new ArrayList<>();

        int hashIndex = methodKey.indexOf('#');
        if (hashIndex <= 0) {
            return result;
        }

        String className = methodKey.substring(0, hashIndex);
        String methodName = methodKey.substring(hashIndex);

        if (!className.endsWith("Impl")) {
            return result;
        }

        List<String> possibleInterfaces = inferPossibleInterfaces(className);

        for (String interfaceName : possibleInterfaces) {
            if (classNames.contains(interfaceName)) {
                result.add(interfaceName + methodName);
                log.debug("接口方法映射: {} -> {}", methodKey, interfaceName + methodName);
            } else {
                log.debug("接口方法映射尝试: {} -> {} (不存在)", methodKey, interfaceName + methodName);
            }
        }

        return result;
    }

    /**
     * 推断可能的接口名
     * <p>
     * 规则优先级：
     * 1. 父包下去掉.impl子包（com.example.service.impl.XxxImpl → com.example.service.Xxx）
     * 2. 同包下去掉Impl后缀（com.example.service.XxxImpl → com.example.service.Xxx）
     *
     * @param implClassName 实现类名
     * @return 可能的接口名列表
     */
    private List<String> inferPossibleInterfaces(String implClassName) {
        List<String> possibleInterfaces = new ArrayList<>();

        // 去掉 Impl 后缀
        String baseName = implClassName.substring(0, implClassName.length() - 4);

        // 规则1: 去掉 .impl 子包
        int implIndex = baseName.lastIndexOf(".impl.");
        if (implIndex > 0) {
            String interfaceName = baseName.substring(0, implIndex) + baseName.substring(implIndex + 5);
            possibleInterfaces.add(interfaceName);
        }

        // 规则2: 同包下去掉 Impl
        possibleInterfaces.add(baseName);

        return possibleInterfaces;
    }

    /**
     * 构建实现类到接口的反向映射
     */
    private void buildImplToInterfaceMap(Map<String, Set<String>> interfaceToImpl) {
        Map<String, String> implToInterface = new ConcurrentHashMap<>();

        for (Map.Entry<String, Set<String>> entry : interfaceToImpl.entrySet()) {
            String interfaceName = entry.getKey();
            for (String implName : entry.getValue()) {
                implToInterface.put(implName, interfaceName);
            }
        }

        cachedImplToInterface = implToInterface;
    }

    /**
     * 清除缓存（用于重新分析时）
     */
    public void clearCache() {
        cachedInterfaceToImpl = null;
        cachedImplToInterface = null;
    }
}

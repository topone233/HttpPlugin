package org.example.securityplatform.analyzer.jar;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * JAR信息模型 - 记录JAR包的基本信息
 */
@Data
@AllArgsConstructor
public class JarInfo {
    /**
     * JAR文件路径
     */
    private String jarPath;

    /**
     * JAR类型
     */
    private JarType type;

    /**
     * JAR名称或来源（如 "MAIN" 或 "BOOT-INF/lib/my-module.jar"）
     */
    private String name;

    /**
     * JAR类型枚举
     */
    public enum JarType {
        /**
         * 主JAR包（用户上传的JAR）
         */
        MAIN,

        /**
         * 依赖JAR包（从lib目录提取的）
         */
        DEPENDENCY
    }

    /**
     * 判断是否为主JAR
     */
    public boolean isMain() {
        return type == JarType.MAIN;
    }

    /**
     * 获取简短名称（用于显示）
     */
    public String getShortName() {
        if (isMain()) {
            return "主JAR包";
        }
        // 从路径中提取文件名
        int lastSep = Math.max(jarPath.lastIndexOf('/'), jarPath.lastIndexOf('\\'));
        return lastSep >= 0 ? jarPath.substring(lastSep + 1) : jarPath;
    }
}

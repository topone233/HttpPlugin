package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 调用边DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CallEdge {
    private Long id;
    private Long sourceId; // 调用者ID
    private Long targetId; // 被调用者ID
    private Integer callLine; // 调用行号
}
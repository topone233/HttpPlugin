package org.example.securityplatform.dto;

import lombok.Data;

import java.util.List;

/**
 * 文件差异摘要
 */
@Data
public class FileDiffSummary {
    private Long id;
    private String filePath;
    private String sourceFilePath;
    private String diffType; // ADDED, MODIFIED, DELETED

    private Integer baselineLines;
    private Integer targetLines;
    private Integer addedLines;
    private Integer deletedLines;

    // 变更行范围
    private List<LineRange> changedLineRanges;

    // 方法变更统计
    private Integer methodsAdded;
    private Integer methodsDeleted;
    private Integer methodsModified;

    @Data
    public static class LineRange {
        private int start;
        private int end;
    }
}

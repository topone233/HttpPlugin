package org.example.securityplatform.analyzer.diff;

import lombok.Data;

/**
 * 方法调用模型
 */
@Data
public class MethodCallModel {
    private String callerClass;
    private String callerMethod;
    private String callerDescriptor;
    private String calleeClass;
    private String calleeMethod;
    private String calleeDescriptor;
    private Integer callLine;
    private String callType; // VIRTUAL, STATIC, SPECIAL, INTERFACE

    /**
     * 调用者所在JAR（多模块模式下使用）
     */
    private String callerJar;

    /**
     * 被调用者所在JAR（多模块模式下使用，可能为空）
     */
    private String calleeJar;

    /**
     * 生成调用者唯一标识
     */
    public String getCallerKey() {
        return callerClass + "#" + callerMethod;
    }

    /**
     * 生成被调用者唯一标识
     */
    public String getCalleeKey() {
        return calleeClass + "#" + calleeMethod;
    }
}

package org.example.securityplatform.analyzer.diff;

import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.analyzer.jar.JarInfo;
import org.example.securityplatform.analyzer.jar.MultiJarClasspathBuilder;
import org.example.securityplatform.util.HashUtil;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 文件差异检测器 - 对比两个JAR包的文件差异
 * 支持多JAR类路径分析
 */
@Slf4j
public class FileDiffDetector {

    private final String baselineJarPath;
    private final String targetJarPath;
    private final BytecodeDiffAnalyzer bytecodeDiffAnalyzer = new BytecodeDiffAnalyzer();
    private final ResourceFileDiffAnalyzer resourceDiffAnalyzer = new ResourceFileDiffAnalyzer();

    // 多JAR支持
    private MultiJarClasspathBuilder baselineClasspath;
    private MultiJarClasspathBuilder targetClasspath;

    public FileDiffDetector(String baselineJarPath, String targetJarPath) {
        this.baselineJarPath = baselineJarPath;
        this.targetJarPath = targetJarPath;
    }

    /**
     * 使用多JAR类路径构建器进行差异检测
     */
    public FileDiffDetector(MultiJarClasspathBuilder baselineClasspath,
                           MultiJarClasspathBuilder targetClasspath) {
        this.baselineClasspath = baselineClasspath;
        this.targetClasspath = targetClasspath;
        // 从类路径中获取主JAR路径（用于向后兼容）
        this.baselineJarPath = null;
        this.targetJarPath = null;
    }

    /**
     * 检测文件差异
     *
     * @return 文件差异列表
     */
    public List<FileDiffModel> detect() throws IOException {
        // 如果使用了多JAR类路径构建器，使用新的检测逻辑
        if (baselineClasspath != null && targetClasspath != null) {
            return detectWithClasspath();
        }

        // 向后兼容：使用传统的单JAR检测逻辑
        return detectSingleJar();
    }

    /**
     * 使用多JAR类路径进行差异检测
     */
    private List<FileDiffModel> detectWithClasspath() throws IOException {
        log.info("开始多JAR文件差异检测");

        List<FileDiffModel> diffs = new ArrayList<>();

        // 1. 处理字节码文件 (.class)
        Set<String> allClassPaths = new HashSet<>();
        allClassPaths.addAll(baselineClasspath.getAllClassPaths());
        allClassPaths.addAll(targetClasspath.getAllClassPaths());

        log.info("总共 {} 个唯一字节码文件路径需要对比", allClassPaths.size());

        int bytecodeCount = 0;
        for (String path : allClassPaths) {
            FileDiffModel diff = analyzeBytecodeDiff(path);
            if (diff != null && diff.hasChanges()) {
                diffs.add(diff);
                bytecodeCount++;
            }
        }

        // 2. 处理资源文件 (.xml, .properties, .yml, .sql, .java 等)
        Set<String> allResourcePaths = new HashSet<>();
        allResourcePaths.addAll(baselineClasspath.getAllResourcePaths());
        allResourcePaths.addAll(targetClasspath.getAllResourcePaths());

        log.info("总共 {} 个唯一资源文件路径需要对比", allResourcePaths.size());

        int resourceCount = 0;
        for (String path : allResourcePaths) {
            FileDiffModel diff = analyzeResourceDiff(path);
            if (diff != null && diff.hasChanges()) {
                diffs.add(diff);
                resourceCount++;
            }
        }

        log.info("多JAR文件差异检测完成: 字节码文件 {} 个变更, 资源文件 {} 个变更, 共 {} 个文件变更",
                bytecodeCount, resourceCount, diffs.size());
        return diffs;
    }

    /**
     * 分析字节码文件差异（使用多JAR类路径）
     */
    private FileDiffModel analyzeBytecodeDiff(String path) throws IOException {
        FileDiffModel diff = new FileDiffModel();
        diff.setFilePath(path);
        diff.setSourceFilePath(FileDiffModel.inferSourcePath(path));
        diff.setFileType("BYTECODE");

        MultiJarClasspathBuilder.ClassLocation baselineLoc = baselineClasspath.getClassLocation(path);
        MultiJarClasspathBuilder.ClassLocation targetLoc = targetClasspath.getClassLocation(path);

        boolean inBaseline = baselineLoc != null;
        boolean inTarget = targetLoc != null;

        if (!inBaseline && inTarget) {
            // 新增文件
            diff.setDiffType("ADDED");
            diff.setSourceJar(targetLoc.getJar().getName());
            diff.setJarType(targetLoc.getJar().getType().name());

            try (InputStream is = targetClasspath.getClassInputStream(path)) {
                diff.setTargetMd5(HashUtil.calculateMd5(is));
            }

            // 字节码分析：统计新增文件的指令数
            try (InputStream is = targetClasspath.getClassInputStream(path)) {
                BytecodeDiffResult bytecodeDiff = bytecodeDiffAnalyzer.analyze(
                    null, is, path
                );
                diff.setBytecodeDiff(bytecodeDiff);
                diff.setBaselineLines(0);
                diff.setTargetLines(bytecodeDiff.getTargetInstructions());
                diff.setAddedLines(bytecodeDiff.getTargetInstructions());
                diff.setDeletedLines(0);
                diff.setMethodsAdded(bytecodeDiff.getMethodsAdded());
                diff.setMethodsDeleted(0);
                diff.setMethodsModified(0);
            } catch (Exception e) {
                log.warn("字节码分析失败（新增文件）: {}", path, e);
                diff.setBaselineLines(0);
                diff.setTargetLines(0);
                diff.setAddedLines(0);
                diff.setDeletedLines(0);
                diff.setMethodsAdded(0);
            }

            return diff;

        } else if (inBaseline && !inTarget) {
            // 删除文件
            diff.setDiffType("DELETED");
            diff.setSourceJar(baselineLoc.getJar().getName());
            diff.setJarType(baselineLoc.getJar().getType().name());

            try (InputStream is = baselineClasspath.getClassInputStream(path)) {
                diff.setBaselineMd5(HashUtil.calculateMd5(is));
            }

            // 字节码分析：统计删除文件的指令数
            try (InputStream is = baselineClasspath.getClassInputStream(path)) {
                BytecodeDiffResult bytecodeDiff = bytecodeDiffAnalyzer.analyze(
                    is, null, path
                );
                diff.setBytecodeDiff(bytecodeDiff);
                diff.setBaselineLines(bytecodeDiff.getBaselineInstructions());
                diff.setTargetLines(0);
                diff.setAddedLines(0);
                diff.setDeletedLines(bytecodeDiff.getBaselineInstructions());
                diff.setMethodsAdded(0);
                diff.setMethodsDeleted(bytecodeDiff.getMethodsDeleted());
                diff.setMethodsModified(0);
            } catch (Exception e) {
                log.warn("字节码分析失败（删除文件）: {}", path, e);
                diff.setBaselineLines(0);
                diff.setTargetLines(0);
                diff.setAddedLines(0);
                diff.setDeletedLines(0);
                diff.setMethodsDeleted(0);
            }

            return diff;

        } else if (inBaseline && inTarget) {
            // 两边都有，检查是否修改
            diff.setSourceJar(baselineLoc.getJar().getName());  // 使用baseline的来源
            diff.setJarType(baselineLoc.getJar().getType().name());

            String baselineMd5;
            String targetMd5;
            byte[] baselineBytes;
            byte[] targetBytes;

            try (InputStream baselineIs = baselineClasspath.getClassInputStream(path);
                 InputStream targetIs = targetClasspath.getClassInputStream(path)) {

                // Read bytes once and reuse for both MD5 and bytecode analysis
                baselineBytes = baselineIs.readAllBytes();
                targetBytes = targetIs.readAllBytes();

                baselineMd5 = HashUtil.calculateMd5(new ByteArrayInputStream(baselineBytes));
                targetMd5 = HashUtil.calculateMd5(new ByteArrayInputStream(targetBytes));

                diff.setBaselineMd5(baselineMd5);
                diff.setTargetMd5(targetMd5);
            }

            if (baselineMd5.equals(targetMd5)) {
                // 未修改
                diff.setDiffType("UNCHANGED");
                return null;
            }

            // 修改的文件
            diff.setDiffType("MODIFIED");

            // 检查来源JAR是否变化
            if (!baselineLoc.getJar().getName().equals(targetLoc.getJar().getName())) {
                log.info("Class {} moved from {} to {}", path,
                        baselineLoc.getJar().getName(), targetLoc.getJar().getName());
                diff.setSourceJar(baselineLoc.getJar().getName() + " -> " + targetLoc.getJar().getName());
            }

            // 字节码差异分析 - reuse the bytes
            try {
                BytecodeDiffResult bytecodeDiff = bytecodeDiffAnalyzer.analyze(
                    new ByteArrayInputStream(baselineBytes),
                    new ByteArrayInputStream(targetBytes),
                    path
                );
                diff.setBytecodeDiff(bytecodeDiff);
                diff.setBaselineLines(bytecodeDiff.getBaselineInstructions());
                diff.setTargetLines(bytecodeDiff.getTargetInstructions());
                diff.setAddedLines(bytecodeDiff.getAddedInstructions());
                diff.setDeletedLines(bytecodeDiff.getDeletedInstructions());
                diff.setMethodsAdded(bytecodeDiff.getMethodsAdded());
                diff.setMethodsDeleted(bytecodeDiff.getMethodsDeleted());
                diff.setMethodsModified(bytecodeDiff.getMethodsModified());

            } catch (Exception e) {
                log.warn("字节码差异分析失败，跳过: {}", path, e);
                diff.setBaselineLines(0);
                diff.setTargetLines(0);
                diff.setAddedLines(0);
                diff.setDeletedLines(0);
                diff.setMethodsAdded(0);
                diff.setMethodsDeleted(0);
                diff.setMethodsModified(0);
            }

            return diff;
        }

        return null;
    }

    /**
     * 分析资源文件差异（使用多JAR类路径）
     */
    private FileDiffModel analyzeResourceDiff(String path) throws IOException {
        FileDiffModel diff = new FileDiffModel();
        diff.setFilePath(path);
        diff.setFileType("RESOURCE");

        MultiJarClasspathBuilder.ResourceLocation baselineLoc = baselineClasspath.getResourceLocation(path);
        MultiJarClasspathBuilder.ResourceLocation targetLoc = targetClasspath.getResourceLocation(path);

        boolean inBaseline = baselineLoc != null;
        boolean inTarget = targetLoc != null;

        if (!inBaseline && inTarget) {
            // 新增资源文件
            diff.setDiffType("ADDED");
            diff.setSourceJar(targetLoc.getJar().getName());
            diff.setJarType(targetLoc.getJar().getType().name());

            try (InputStream is = targetClasspath.getResourceInputStream(path)) {
                diff.setTargetMd5(HashUtil.calculateMd5(is));
            }

            // 资源文件分析
            try (InputStream is = targetClasspath.getResourceInputStream(path)) {
                ResourceDiffResult resourceDiff = resourceDiffAnalyzer.analyze(
                    null, is, path
                );
                diff.setResourceDiff(resourceDiff);
                diff.setBaselineLines(0);
                diff.setTargetLines(resourceDiff.getTargetLines());
                diff.setAddedLines(resourceDiff.getTargetLines());
                diff.setDeletedLines(0);
            } catch (Exception e) {
                log.warn("资源文件分析失败（新增文件）: {}", path, e);
                diff.setBaselineLines(0);
                diff.setTargetLines(0);
                diff.setAddedLines(0);
                diff.setDeletedLines(0);
            }

            return diff;

        } else if (inBaseline && !inTarget) {
            // 删除资源文件
            diff.setDiffType("DELETED");
            diff.setSourceJar(baselineLoc.getJar().getName());
            diff.setJarType(baselineLoc.getJar().getType().name());

            try (InputStream is = baselineClasspath.getResourceInputStream(path)) {
                diff.setBaselineMd5(HashUtil.calculateMd5(is));
            }

            // 资源文件分析
            try (InputStream is = baselineClasspath.getResourceInputStream(path)) {
                ResourceDiffResult resourceDiff = resourceDiffAnalyzer.analyze(
                    is, null, path
                );
                diff.setResourceDiff(resourceDiff);
                diff.setBaselineLines(resourceDiff.getBaselineLines());
                diff.setTargetLines(0);
                diff.setAddedLines(0);
                diff.setDeletedLines(resourceDiff.getBaselineLines());
            } catch (Exception e) {
                log.warn("资源文件分析失败（删除文件）: {}", path, e);
                diff.setBaselineLines(0);
                diff.setTargetLines(0);
                diff.setAddedLines(0);
                diff.setDeletedLines(0);
            }

            return diff;

        } else if (inBaseline && inTarget) {
            // 两边都有，检查是否修改
            diff.setSourceJar(baselineLoc.getJar().getName());
            diff.setJarType(baselineLoc.getJar().getType().name());

            String baselineMd5;
            String targetMd5;

            try (InputStream baselineIs = baselineClasspath.getResourceInputStream(path);
                 InputStream targetIs = targetClasspath.getResourceInputStream(path)) {

                baselineMd5 = HashUtil.calculateMd5(baselineIs);
                targetMd5 = HashUtil.calculateMd5(targetIs);

                diff.setBaselineMd5(baselineMd5);
                diff.setTargetMd5(targetMd5);
            }

            if (baselineMd5.equals(targetMd5)) {
                // 未修改
                diff.setDiffType("UNCHANGED");
                return null;
            }

            // 修改的资源文件
            diff.setDiffType("MODIFIED");

            // 检查来源JAR是否变化
            if (!baselineLoc.getJar().getName().equals(targetLoc.getJar().getName())) {
                log.info("Resource {} moved from {} to {}", path,
                        baselineLoc.getJar().getName(), targetLoc.getJar().getName());
                diff.setSourceJar(baselineLoc.getJar().getName() + " -> " + targetLoc.getJar().getName());
            }

            // 资源文件差异分析
            try (InputStream baselineIs = baselineClasspath.getResourceInputStream(path);
                 InputStream targetIs = targetClasspath.getResourceInputStream(path)) {
                ResourceDiffResult resourceDiff = resourceDiffAnalyzer.analyze(
                    baselineIs, targetIs, path
                );
                diff.setResourceDiff(resourceDiff);
                diff.setBaselineLines(resourceDiff.getBaselineLines());
                diff.setTargetLines(resourceDiff.getTargetLines());
                diff.setAddedLines(resourceDiff.getAddedLines());
                diff.setDeletedLines(resourceDiff.getDeletedLines());
            } catch (Exception e) {
                log.warn("资源文件差异分析失败，跳过: {}", path, e);
                diff.setBaselineLines(0);
                diff.setTargetLines(0);
                diff.setAddedLines(0);
                diff.setDeletedLines(0);
            }

            return diff;
        }

        return null;
    }

    /**
     * 传统的单JAR差异检测（向后兼容）
     */
    private List<FileDiffModel> detectSingleJar() throws IOException {
        log.info("开始文件差异检测: baseline={}, target={}", baselineJarPath, targetJarPath);

        List<FileDiffModel> diffs = new ArrayList<>();

        // 获取两个JAR包的class文件列表
        Map<String, JarEntry> baselineEntries = getClassEntries(baselineJarPath);
        Map<String, JarEntry> targetEntries = getClassEntries(targetJarPath);
        Map<String, JarEntry> baselineResourceEntries = getResourceEntries(baselineJarPath);
        Map<String, JarEntry> targetResourceEntries = getResourceEntries(targetJarPath);

        log.info("基线JAR包含 {} 个class文件, 目标JAR包含 {} 个class文件",
                baselineEntries.size(), targetEntries.size());
        log.info("基线JAR包含 {} 个资源文件, 目标JAR包含 {} 个资源文件",
                baselineResourceEntries.size(), targetResourceEntries.size());

        Set<String> allPaths = new HashSet<>();
        allPaths.addAll(baselineEntries.keySet());
        allPaths.addAll(targetEntries.keySet());

        log.info("总共需要对比 {} 个文件", allPaths.size());

        int addedCount = 0, deletedCount = 0, modifiedCount = 0, unchangedCount = 0;

        // 对比每个文件
        for (String path : allPaths) {
            FileDiffModel diff = analyzeFileDiff(path, baselineEntries, targetEntries);
            if (diff != null) {
                if (diff.hasChanges()) {
                    diffs.add(diff);
                    switch (diff.getDiffType()) {
                        case "ADDED": addedCount++; break;
                        case "DELETED": deletedCount++; break;
                        case "MODIFIED": modifiedCount++; break;
                    }
                } else {
                    unchangedCount++;
                }
            } else {
                // diff为null说明文件未变更（analyzeFileDiff返回null）
                unchangedCount++;
            }
        }

        Set<String> allResourcePaths = new HashSet<>();
        allResourcePaths.addAll(baselineResourceEntries.keySet());
        allResourcePaths.addAll(targetResourceEntries.keySet());

        for (String path : allResourcePaths) {
            FileDiffModel diff = analyzeResourceFileDiff(path, baselineResourceEntries, targetResourceEntries);
            if (diff != null) {
                if (diff.hasChanges()) {
                    diffs.add(diff);
                    switch (diff.getDiffType()) {
                        case "ADDED": addedCount++; break;
                        case "DELETED": deletedCount++; break;
                        case "MODIFIED": modifiedCount++; break;
                    }
                } else {
                    unchangedCount++;
                }
            } else {
                unchangedCount++;
            }
        }

        log.info("文件差异检测完成: 新增={}, 删除={}, 修改={}, 未变更={}",
                addedCount, deletedCount, modifiedCount, unchangedCount);
        return diffs;
    }

    /**
     * 获取JAR包中的所有class文件
     */
    private Map<String, JarEntry> getClassEntries(String jarPath) throws IOException {
        Map<String, JarEntry> entries = new HashMap<>();
        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> enumeration = jarFile.entries();
            while (enumeration.hasMoreElements()) {
                JarEntry entry = enumeration.nextElement();
                if (entry.getName().endsWith(".class") && !entry.isDirectory()) {
                    entries.put(entry.getName(), entry);
                }
            }
        }
        return entries;
    }

    /**
     * 获取JAR包中需要统计的资源文件
     */
    private Map<String, JarEntry> getResourceEntries(String jarPath) throws IOException {
        Map<String, JarEntry> entries = new HashMap<>();
        try (JarFile jarFile = new JarFile(jarPath)) {
            Enumeration<JarEntry> enumeration = jarFile.entries();
            while (enumeration.hasMoreElements()) {
                JarEntry entry = enumeration.nextElement();
                if (isResourceEntry(entry)) {
                    entries.put(entry.getName(), entry);
                }
            }
        }
        return entries;
    }

    private boolean isResourceEntry(JarEntry entry) {
        if (entry.isDirectory()) {
            return false;
        }
        String name = entry.getName().toLowerCase(Locale.ROOT);
        return name.endsWith(".xml") ||
                name.endsWith(".properties") ||
                name.endsWith(".yml") ||
                name.endsWith(".yaml") ||
                name.endsWith(".sql") ||
                name.endsWith(".java");
    }

    /**
     * 分析单个文件的差异
     */
    private FileDiffModel analyzeFileDiff(String path,
                                           Map<String, JarEntry> baselineEntries,
                                           Map<String, JarEntry> targetEntries) throws IOException {
        FileDiffModel diff = new FileDiffModel();
        diff.setFilePath(path);
        diff.setSourceFilePath(FileDiffModel.inferSourcePath(path));

        boolean inBaseline = baselineEntries.containsKey(path);
        boolean inTarget = targetEntries.containsKey(path);

        if (!inBaseline && inTarget) {
            // 新增文件
            log.debug("检测到新增文件: {}", path);
            diff.setDiffType("ADDED");
            diff.setBaselineLines(0);
            diff.setBaselineMd5(null);

            try (JarFile targetJar = new JarFile(targetJarPath)) {
                JarEntry entry = targetEntries.get(path);
                try (InputStream is = targetJar.getInputStream(entry)) {
                    diff.setTargetMd5(HashUtil.calculateMd5(is));
                }

                // 字节码分析：统计新增文件的指令数
                try (InputStream is = targetJar.getInputStream(entry)) {
                    BytecodeDiffResult bytecodeDiff = analyzeBytecode(
                        null, is, path
                    );
                    diff.setBytecodeDiff(bytecodeDiff);
                    diff.setTargetLines(bytecodeDiff.getTargetInstructions());
                    diff.setAddedLines(bytecodeDiff.getTargetInstructions());
                    diff.setDeletedLines(0);
                    diff.setMethodsAdded(bytecodeDiff.getMethodsAdded());
                    diff.setMethodsDeleted(0);
                    diff.setMethodsModified(0);
                } catch (Exception e) {
                    log.warn("字节码分析失败（新增文件）: {}", path, e);
                    diff.setTargetLines(0);
                    diff.setAddedLines(0);
                    diff.setDeletedLines(0);
                    diff.setMethodsAdded(0);
                }
            } catch (Exception e) {
                log.warn("分析新增的文件失败: {}", path, e);
            }
            return diff;

        } else if (inBaseline && !inTarget) {
            // 删除文件
            diff.setDiffType("DELETED");
            diff.setTargetLines(0);
            diff.setTargetMd5(null);

            try (JarFile baselineJar = new JarFile(baselineJarPath)) {
                JarEntry entry = baselineEntries.get(path);
                try (InputStream is = baselineJar.getInputStream(entry)) {
                    diff.setBaselineMd5(HashUtil.calculateMd5(is));
                }

                // 字节码分析：统计删除文件的指令数
                try (InputStream is = baselineJar.getInputStream(entry)) {
                    BytecodeDiffResult bytecodeDiff = analyzeBytecode(
                        is, null, path
                    );
                    diff.setBytecodeDiff(bytecodeDiff);
                    diff.setBaselineLines(bytecodeDiff.getBaselineInstructions());
                    diff.setAddedLines(0);
                    diff.setDeletedLines(bytecodeDiff.getBaselineInstructions());
                    diff.setMethodsAdded(0);
                    diff.setMethodsDeleted(bytecodeDiff.getMethodsDeleted());
                    diff.setMethodsModified(0);
                } catch (Exception e) {
                    log.warn("字节码分析失败（删除文件）: {}", path, e);
                    diff.setBaselineLines(0);
                    diff.setAddedLines(0);
                    diff.setDeletedLines(0);
                    diff.setMethodsDeleted(0);
                }
            } catch (Exception e) {
                log.warn("分析删除的文件失败: {}", path, e);
            }
            return diff;

        } else if (inBaseline && inTarget) {
            // 两边都有，检查是否修改
            try (JarFile baselineJar = new JarFile(baselineJarPath);
                 JarFile targetJar = new JarFile(targetJarPath)) {

                JarEntry baselineEntry = baselineEntries.get(path);
                JarEntry targetEntry = targetEntries.get(path);

                try (InputStream baselineIs = baselineJar.getInputStream(baselineEntry);
                     InputStream targetIs = targetJar.getInputStream(targetEntry)) {

                    // Read bytes once and reuse for both MD5 and bytecode analysis
                    byte[] baselineBytes = baselineIs.readAllBytes();
                    byte[] targetBytes = targetIs.readAllBytes();

                    String baselineMd5 = HashUtil.calculateMd5(new ByteArrayInputStream(baselineBytes));
                    String targetMd5 = HashUtil.calculateMd5(new ByteArrayInputStream(targetBytes));

                    diff.setBaselineMd5(baselineMd5);
                    diff.setTargetMd5(targetMd5);

                    if (baselineMd5.equals(targetMd5)) {
                        // 未修改
                        diff.setDiffType("UNCHANGED");
                        log.debug("文件未变更: {}, MD5={}", path, baselineMd5);
                        return null;
                    }

                    // 修改的文件
                    log.info("检测到修改文件: {}, baselineMD5={}, targetMD5={}", path, baselineMd5, targetMd5);
                    diff.setDiffType("MODIFIED");

                    // Use the same bytes for bytecode analysis
                    try {
                        BytecodeDiffResult bytecodeDiff = analyzeBytecode(
                            new ByteArrayInputStream(baselineBytes),
                            new ByteArrayInputStream(targetBytes),
                            path
                        );
                        diff.setBytecodeDiff(bytecodeDiff);
                        diff.setBaselineLines(bytecodeDiff.getBaselineInstructions());
                        diff.setTargetLines(bytecodeDiff.getTargetInstructions());
                        diff.setAddedLines(bytecodeDiff.getAddedInstructions());
                        diff.setDeletedLines(bytecodeDiff.getDeletedInstructions());
                        diff.setMethodsAdded(bytecodeDiff.getMethodsAdded());
                        diff.setMethodsDeleted(bytecodeDiff.getMethodsDeleted());
                        diff.setMethodsModified(bytecodeDiff.getMethodsModified());
                    } catch (Exception e) {
                        log.warn("字节码差异分析失败，跳过: {}", path, e);
                        // 设置默认值
                        diff.setBaselineLines(0);
                        diff.setTargetLines(0);
                        diff.setAddedLines(0);
                        diff.setDeletedLines(0);
                        diff.setMethodsAdded(0);
                        diff.setMethodsDeleted(0);
                        diff.setMethodsModified(0);
                    }
                }
            }
            return diff;
        }

        return null;
    }

    /**
     * 分析单个资源文件的差异
     */
    private FileDiffModel analyzeResourceFileDiff(String path,
                                                   Map<String, JarEntry> baselineEntries,
                                                   Map<String, JarEntry> targetEntries) throws IOException {
        FileDiffModel diff = new FileDiffModel();
        diff.setFilePath(path);
        diff.setSourceFilePath(path);
        diff.setFileType("RESOURCE");
        diff.setJarType(JarInfo.JarType.MAIN.name());

        boolean inBaseline = baselineEntries.containsKey(path);
        boolean inTarget = targetEntries.containsKey(path);

        if (!inBaseline && inTarget) {
            diff.setDiffType("ADDED");
            diff.setSourceJar(getJarFileName(targetJarPath));
            diff.setBaselineLines(0);
            diff.setBaselineMd5(null);

            try (JarFile targetJar = new JarFile(targetJarPath)) {
                JarEntry entry = targetEntries.get(path);
                try (InputStream is = targetJar.getInputStream(entry)) {
                    diff.setTargetMd5(HashUtil.calculateMd5(is));
                }
                try (InputStream is = targetJar.getInputStream(entry)) {
                    ResourceDiffResult resourceDiff = resourceDiffAnalyzer.analyze(null, is, path);
                    diff.setResourceDiff(resourceDiff);
                    diff.setTargetLines(resourceDiff.getTargetLines());
                    diff.setAddedLines(resourceDiff.getAddedLines());
                    diff.setDeletedLines(resourceDiff.getDeletedLines());
                }
            }
            return diff;
        } else if (inBaseline && !inTarget) {
            diff.setDiffType("DELETED");
            diff.setSourceJar(getJarFileName(baselineJarPath));
            diff.setTargetLines(0);
            diff.setTargetMd5(null);

            try (JarFile baselineJar = new JarFile(baselineJarPath)) {
                JarEntry entry = baselineEntries.get(path);
                try (InputStream is = baselineJar.getInputStream(entry)) {
                    diff.setBaselineMd5(HashUtil.calculateMd5(is));
                }
                try (InputStream is = baselineJar.getInputStream(entry)) {
                    ResourceDiffResult resourceDiff = resourceDiffAnalyzer.analyze(is, null, path);
                    diff.setResourceDiff(resourceDiff);
                    diff.setBaselineLines(resourceDiff.getBaselineLines());
                    diff.setAddedLines(resourceDiff.getAddedLines());
                    diff.setDeletedLines(resourceDiff.getDeletedLines());
                }
            }
            return diff;
        } else if (inBaseline && inTarget) {
            diff.setSourceJar(getJarFileName(baselineJarPath));

            byte[] baselineBytes;
            byte[] targetBytes;
            try (JarFile baselineJar = new JarFile(baselineJarPath);
                 JarFile targetJar = new JarFile(targetJarPath)) {
                try (InputStream baselineIs = baselineJar.getInputStream(baselineEntries.get(path));
                     InputStream targetIs = targetJar.getInputStream(targetEntries.get(path))) {
                    baselineBytes = baselineIs.readAllBytes();
                    targetBytes = targetIs.readAllBytes();
                }
            }

            String baselineMd5 = HashUtil.calculateMd5(new ByteArrayInputStream(baselineBytes));
            String targetMd5 = HashUtil.calculateMd5(new ByteArrayInputStream(targetBytes));
            diff.setBaselineMd5(baselineMd5);
            diff.setTargetMd5(targetMd5);

            if (baselineMd5.equals(targetMd5)) {
                diff.setDiffType("UNCHANGED");
                return null;
            }

            diff.setDiffType("MODIFIED");
            ResourceDiffResult resourceDiff = resourceDiffAnalyzer.analyze(
                    new ByteArrayInputStream(baselineBytes),
                    new ByteArrayInputStream(targetBytes),
                    path
            );
            diff.setResourceDiff(resourceDiff);
            diff.setBaselineLines(resourceDiff.getBaselineLines());
            diff.setTargetLines(resourceDiff.getTargetLines());
            diff.setAddedLines(resourceDiff.getAddedLines());
            diff.setDeletedLines(resourceDiff.getDeletedLines());
            return diff;
        }

        return null;
    }

    private String getJarFileName(String jarPath) {
        if (jarPath == null || jarPath.isEmpty()) {
            return null;
        }
        return new File(jarPath).getName();
    }

    /**
     * 分析字节码差异
     */
    private BytecodeDiffResult analyzeBytecode(InputStream baselineStream,
                                                 InputStream targetStream,
                                                 String filePath) throws IOException {
        return bytecodeDiffAnalyzer.analyze(baselineStream, targetStream, filePath);
    }

    /**
     * 获取差异统计
     */
    public DiffStatistics getStatistics(List<FileDiffModel> diffs) {
        DiffStatistics stats = new DiffStatistics();
        for (FileDiffModel diff : diffs) {
            switch (diff.getDiffType()) {
                case "ADDED":
                    stats.addedFiles++;
                    break;
                case "DELETED":
                    stats.deletedFiles++;
                    break;
                case "MODIFIED":
                    stats.modifiedFiles++;
                    break;
            }
            stats.totalMethodsAdded += diff.getMethodsAdded();
            stats.totalMethodsDeleted += diff.getMethodsDeleted();
            stats.totalMethodsModified += diff.getMethodsModified();
        }
        return stats;
    }

    /**
     * 差异统计
     */
    @lombok.Data
    public static class DiffStatistics {
        private int addedFiles = 0;
        private int modifiedFiles = 0;
        private int deletedFiles = 0;
        private int totalMethodsAdded = 0;
        private int totalMethodsDeleted = 0;
        private int totalMethodsModified = 0;
    }
}

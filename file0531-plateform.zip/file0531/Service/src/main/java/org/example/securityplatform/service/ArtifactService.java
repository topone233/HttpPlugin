package org.example.securityplatform.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.securityplatform.common.ArtifactStatus;
import org.example.securityplatform.common.ValidationConstants;
import org.example.securityplatform.config.FileUploadConfig;
import org.example.securityplatform.config.TempDirConfig;
import org.example.securityplatform.dto.ArtifactResponse;
import org.example.securityplatform.entity.Artifact;
import org.example.securityplatform.entity.Task;
import org.example.securityplatform.entity.TaintSink;
import org.example.securityplatform.exception.BusinessException;
import org.example.securityplatform.repository.*;
import org.example.securityplatform.util.FileUtil;
import org.example.securityplatform.util.HashUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * 制品服务类
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ArtifactService {

    private final ArtifactRepository artifactRepository;
    private final TaskRepository taskRepository;
    private final FileUploadConfig fileUploadConfig;
    private final TempDirConfig tempDirConfig;

    // 分析数据Repository（用于删除分析数据）
    private final ApiInfoRepository apiInfoRepository;
    private final DangerFunctionRepository dangerFunctionRepository;
    private final ComponentInfoRepository componentInfoRepository;
    private final ConfigInfoRepository configInfoRepository;
    private final ExternalUrlRepository externalUrlRepository;
    private final TaintSinkRepository taintSinkRepository;
    private final TaintPathRepository taintPathRepository;
    private final AnalysisProgressRepository analysisProgressRepository;
    private final MethodCallEdgeRepository methodCallEdgeRepository;
    private final TestChecklistRepository testChecklistRepository;
    private final TestExecutionRepository testExecutionRepository;
    private final TestReportRepository testReportRepository;
    private final RiskExclusionRepository riskExclusionRepository;
    private final DiffAnalysisTaskRepository diffAnalysisTaskRepository;

    /**
     * 上传制品
     *
     * @param taskId      任务 ID (差异分析时可为null)
     * @param file        上传的文件
     * @param artifactType 制品类型
     * @return 制品响应
     */
    @Transactional
    public ArtifactResponse uploadArtifact(Long taskId, MultipartFile file, String artifactType) {
        // 如果提供了taskId，验证任务是否存在
        if (taskId != null) {
            Task task = taskRepository.findById(taskId)
                    .orElseThrow(() -> new BusinessException("任务不存在"));
        }

        // 检查文件是否为空
        if (file == null || file.isEmpty()) {
            throw new BusinessException("文件不能为空");
        }

        // 校验文件大小
        if (file.getSize() > ValidationConstants.MAX_FILE_SIZE) {
            throw new BusinessException("文件大小超过限制 (500MB)");
        }

        // 校验制品类型
        if (!isValidArtifactType(artifactType)) {
            throw new BusinessException("不支持的制品类型：" + artifactType);
        }

        // 校验文件扩展名
        String originalFilename = file.getOriginalFilename();
        String extension = FileUtil.getExtension(originalFilename);
        if (!isValidExtension(extension)) {
            throw new BusinessException("不支持的文件格式：" + extension);
        }

        // 校验制品类型与扩展名是否匹配
        if (!isTypeExtensionMatch(artifactType, extension)) {
            throw new BusinessException("制品类型与文件扩展名不匹配");
        }

        try {
            // 生成唯一的文件名
            String uniqueFileName = UUID.randomUUID().toString() + "." + extension;

            // 创建目录（如果有taskId则使用taskId目录，否则使用diff-analysis目录）
            String dirPath;
            if (taskId != null) {
                dirPath = fileUploadConfig.getBasePath() + File.separator + taskId;
            } else {
                dirPath = fileUploadConfig.getBasePath() + File.separator + "diff-analysis";
            }
            FileUtil.createDirectoryIfNotExists(dirPath);

            // 保存文件
            String filePath = dirPath + File.separator + uniqueFileName;
            Path path = Paths.get(filePath);
            Files.write(path, file.getBytes());

            // 计算 MD5
            String md5 = HashUtil.calculateMD5(filePath);

            // 查找相同MD5的制品，仅复用物理文件（节约存储空间）
            List<Artifact> sameMd5Artifacts = artifactRepository.findByMd5(md5);
            String finalFilePath = filePath;

            if (!sameMd5Artifacts.isEmpty()) {
                // 复用已存在的物理文件
                Artifact existing = sameMd5Artifacts.get(0);
                Files.deleteIfExists(path); // 删除刚上传的临时文件
                finalFilePath = existing.getFilePath();
                log.info("复用制品物理文件：md5={}, filePath={}, artifactId={}", md5, finalFilePath, existing.getId());
            }

            // 保存制品信息（每个任务关联自己的制品记录）
            // 注意：状态始终为 UPLOADED，因为分析结果数据需要按 artifactId 存储
            // 即使MD5相同，缓存机制会加速后续分析过程
            Artifact artifact = new Artifact();
            artifact.setTaskId(taskId);
            artifact.setArtifactName(originalFilename);
            artifact.setArtifactType(artifactType);
            artifact.setFilePath(finalFilePath);
            artifact.setFileSize(file.getSize());
            artifact.setMd5(md5);
            artifact.setStatus(ArtifactStatus.UPLOADED);

            Artifact savedArtifact = artifactRepository.save(artifact);
            log.info("制品上传成功：id={}, name={}, taskId={}", artifact.getId(), originalFilename, taskId);
            return toResponse(savedArtifact);

        } catch (IOException e) {
            log.error("文件上传失败：taskId={}, fileName={}", taskId, originalFilename, e);
            throw new BusinessException("文件上传失败：" + e.getMessage());
        }
    }

    /**
     * 校验制品类型
     */
    private boolean isValidArtifactType(String artifactType) {
        return Arrays.stream(ValidationConstants.ALLOWED_ARTIFACT_TYPES)
                .anyMatch(type -> type.equalsIgnoreCase(artifactType));
    }

    /**
     * 校验文件扩展名
     */
    private boolean isValidExtension(String extension) {
        return Arrays.stream(ValidationConstants.ALLOWED_EXTENSIONS)
                .anyMatch(ext -> ext.equalsIgnoreCase(extension));
    }

    /**
     * 校验制品类型与扩展名是否匹配
     */
    private boolean isTypeExtensionMatch(String artifactType, String extension) {
        for (String[] mapping : ValidationConstants.TYPE_EXTENSION_MAP) {
            if (mapping[0].equalsIgnoreCase(artifactType) && mapping[1].equalsIgnoreCase(extension)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 下载制品文件
     *
     * @param id 制品 ID
     * @return 文件响应
     */
    public ResponseEntity<Resource> downloadArtifact(Long id) {
        Artifact artifact = artifactRepository.findById(id)
                .orElseThrow(() -> new BusinessException("制品不存在"));

        if (artifact.getFilePath() == null) {
            throw new BusinessException("制品文件不存在");
        }

        Path filePath = Paths.get(artifact.getFilePath());
        if (!Files.exists(filePath)) {
            throw new BusinessException("制品文件已丢失");
        }

        try {
            Resource resource = new FileSystemResource(filePath);
            String contentType = getContentType(artifact.getArtifactType());

            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"" + artifact.getArtifactName() + "\"")
                    .header(HttpHeaders.CONTENT_LENGTH, String.valueOf(artifact.getFileSize()))
                    .body(resource);

        } catch (Exception e) {
            log.error("文件下载失败：artifactId={}", id, e);
            throw new BusinessException("文件下载失败：" + e.getMessage());
        }
    }

    /**
     * 获取内容类型
     */
    private String getContentType(String artifactType) {
        switch (artifactType.toUpperCase()) {
            case "JAR":
                return "application/java-archive";
            case "WAR":
                return "application/x-war";
            case "ZIP":
                return "application/zip";
            default:
                return "application/octet-stream";
        }
    }

    /**
     * 根据 ID 查询制品
     *
     * @param id 制品 ID
     * @return 制品响应
     */
    public ArtifactResponse getArtifactById(Long id) {
        Artifact artifact = artifactRepository.findById(id)
                .orElseThrow(() -> new BusinessException("制品不存在"));
        return toResponse(artifact);
    }

    /**
     * 根据任务 ID 查询制品列表
     *
     * @param taskId 任务 ID
     * @return 制品响应列表
     */
    public List<ArtifactResponse> getArtifactsByTaskId(Long taskId) {
        List<Artifact> artifacts = artifactRepository.findByTaskId(taskId);
        return artifacts.stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * 根据状态查询制品列表
     *
     * @param status 制品状态
     * @return 制品响应列表
     */
    public List<ArtifactResponse> getArtifactsByStatus(String status) {
        List<Artifact> artifacts = artifactRepository.findByStatus(status);
        return artifacts.stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * 查询所有制品
     *
     * @return 制品响应列表
     */
    public List<ArtifactResponse> getAllArtifacts() {
        List<Artifact> artifacts = artifactRepository.findAll();
        return artifacts.stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * 更新制品状态
     *
     * @param id     制品 ID
     * @param status 新状态
     * @return 制品响应
     */
    @Transactional
    public ArtifactResponse updateArtifactStatus(Long id, String status) {
        Artifact artifact = artifactRepository.findById(id)
                .orElseThrow(() -> new BusinessException("制品不存在"));
        artifact.setStatus(status);
        Artifact savedArtifact = artifactRepository.save(artifact);
        return toResponse(savedArtifact);
    }

    /**
     * 删除制品（级联删除所有关联数据）
     *
     * @param id 制品 ID
     */
    @Transactional
    public void deleteArtifact(Long id) {
        Artifact artifact = artifactRepository.findById(id)
                .orElseThrow(() -> new BusinessException("制品不存在"));

        String md5 = artifact.getMd5();
        String filePath = artifact.getFilePath();
        Long artifactId = artifact.getId();

        log.info("开始删除制品：id={}, name={}, md5={}", artifactId, artifact.getArtifactName(), md5);

        // === 步骤1：删除所有关联的分析数据 ===
        try {
            // 1.1 删除有依赖关系的数据（先删除TaintPath，后删除TaintSink）
            List<TaintSink> sinks = taintSinkRepository.findByArtifactId(artifactId);
            if (!sinks.isEmpty()) {
                List<Long> sinkIds = sinks.stream().map(TaintSink::getId).collect(Collectors.toList());
                taintPathRepository.deleteBySinkIdIn(sinkIds);
                log.debug("删除TaintPath：count={}", sinkIds.size());
            }

            // 1.2 删除主分析数据
            taintSinkRepository.deleteByArtifactId(artifactId);
            analysisProgressRepository.deleteByArtifactId(artifactId);
            methodCallEdgeRepository.deleteByArtifactId(artifactId);

            // 1.3 删除测试相关数据
            testChecklistRepository.deleteByArtifactId(artifactId);
            testExecutionRepository.deleteByArtifactId(artifactId);
            testReportRepository.deleteByArtifactId(artifactId);

            // 1.4 删除风险排除记录
            riskExclusionRepository.deleteByArtifactId(artifactId);

            // 1.5 删除基础分析数据
            apiInfoRepository.deleteByArtifactId(artifactId);
            dangerFunctionRepository.deleteByArtifactId(artifactId);
            componentInfoRepository.deleteByArtifactId(artifactId);
            configInfoRepository.deleteByArtifactId(artifactId);
            externalUrlRepository.deleteByArtifactId(artifactId);

            log.debug("分析数据删除完成：artifactId={}", artifactId);

        } catch (Exception e) {
            log.error("删除分析数据失败：artifactId={}", artifactId, e);
            throw new BusinessException("删除分析数据失败：" + e.getMessage());
        }

        // === 步骤2：删除差异分析关联 ===
        try {
            diffAnalysisTaskRepository.deleteByBaselineArtifactId(artifactId);
            diffAnalysisTaskRepository.deleteByTargetArtifactId(artifactId);
            log.debug("差异分析任务删除完成：artifactId={}", artifactId);
        } catch (Exception e) {
            log.warn("删除差异分析任务失败：artifactId={}", artifactId, e);
            // 不抛出异常，继续流程
        }

        // === 步骤3：删除数据库记录 ===
        artifactRepository.delete(artifact);
        log.debug("数据库记录删除完成：artifactId={}", artifactId);

        // === 步骤4：物理文件清理（检查共享） ===
        if (filePath != null) {
            try {
                // 再次查询MD5引用（artifact记录已删除）
                List<Artifact> remainingArtifacts = artifactRepository.findByMd5(md5);

                if (remainingArtifacts.isEmpty()) {
                    // 没有其他artifact使用该文件，删除物理文件
                    Path path = Paths.get(filePath);
                    if (Files.exists(path)) {
                        Files.delete(path);
                        log.info("物理文件删除：filePath={}", filePath);
                    } else {
                        log.warn("物理文件已不存在：filePath={}", filePath);
                    }
                } else {
                    log.info("物理文件保留：filePath={}，仍有{}个其他制品共享",
                             filePath, remainingArtifacts.size());
                }
            } catch (IOException e) {
                log.error("物理文件删除失败：filePath={}", filePath, e);
                // 不抛出异常，文件删除失败不影响整体流程
            }
        }

        // === 步骤5：临时目录清理 ===
        cleanupTempDirectories(artifactId);

        log.info("制品删除完成：id={}, name={}", artifactId, artifact.getArtifactName());
    }

    /**
     * 清理artifact相关的临时目录
     */
    private void cleanupTempDirectories(Long artifactId) {
        // 清理temp/extract/{artifactId}
        String extractDir = tempDirConfig.getExtractDir(artifactId);
        cleanupTempDir(extractDir, "extract");

        // 清理temp/extract/{artifactId}_xxx（依赖扫描子目录）
        cleanupDependencyExtractDirs(artifactId);

        // 清理temp/dep_scan中可能包含artifactId的目录
        cleanupDependencyScanDirs(artifactId);
    }

    /**
     * 清理单个临时目录
     */
    private void cleanupTempDir(String dirPath, String dirType) {
        try {
            Path path = Paths.get(dirPath);
            if (Files.exists(path)) {
                deleteDirectoryRecursive(path.toFile());
                log.debug("临时目录清理：type={}, path={}", dirType, dirPath);
            }
        } catch (Exception e) {
            log.warn("临时目录清理失败：type={}, path={}", dirType, dirPath, e);
        }
    }

    /**
     * 递归删除目录
     */
    private void deleteDirectoryRecursive(File directory) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    deleteDirectoryRecursive(file);
                }
            }
        }
        directory.delete();
    }

    /**
     * 清理依赖扫描相关的临时目录
     */
    private void cleanupDependencyScanDirs(Long artifactId) {
        try {
            String depScanBase = tempDirConfig.getTempBaseDir() + "/dep_scan";
            File baseDir = new File(depScanBase);

            if (baseDir.exists() && baseDir.isDirectory()) {
                File[] subDirs = baseDir.listFiles(File::isDirectory);
                if (subDirs != null) {
                    for (File subDir : subDirs) {
                        // 检查目录名是否包含artifactId
                        if (subDir.getName().contains(String.valueOf(artifactId))) {
                            deleteDirectoryRecursive(subDir);
                            log.debug("清理依赖扫描临时目录：{}", subDir.getAbsolutePath());
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.warn("清理依赖扫描目录失败：artifactId={}", artifactId, e);
        }
    }

    /**
     * 清理解压临时子目录（包含artifactId的）
     */
    private void cleanupDependencyExtractDirs(Long artifactId) {
        try {
            String extractBase = tempDirConfig.getTempBaseDir() + "/extract";
            File baseDir = new File(extractBase);

            if (baseDir.exists() && baseDir.isDirectory()) {
                File[] subDirs = baseDir.listFiles(File::isDirectory);
                if (subDirs != null) {
                    for (File subDir : subDirs) {
                        // 删除所有以artifactId开头的目录（如123_xxx）
                        if (subDir.getName().startsWith(String.valueOf(artifactId))) {
                            deleteDirectoryRecursive(subDir);
                            log.debug("清理解压临时子目录：{}", subDir.getAbsolutePath());
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.warn("清理解压子目录失败：artifactId={}", artifactId, e);
        }
    }

    /**
     * 清理文件丢失的制品记录
     *
     * @return 清理的记录数量
     */
    @Transactional
    public int cleanupMissingFiles() {
        List<Artifact> allArtifacts = artifactRepository.findAll();
        int count = 0;

        for (Artifact artifact : allArtifacts) {
            if (artifact.getFilePath() != null) {
                Path path = Paths.get(artifact.getFilePath().replace("./", "").replace("\\", "/"));
                if (!Files.exists(path)) {
                    log.warn("清理文件丢失的制品：id={}, name={}, path={}", artifact.getId(), artifact.getArtifactName(), artifact.getFilePath());
                    artifactRepository.delete(artifact);
                    count++;
                }
            }
        }

        log.info("清理完成，共删除 {} 条制品记录", count);
        return count;
    }

    private ArtifactResponse toResponse(Artifact artifact) {
        ArtifactResponse response = new ArtifactResponse();
        BeanUtils.copyProperties(artifact, response);
        return response;
    }
}
package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 优先测试项DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PriorityItem {
    private Long id;
    private Integer priority; // 1-5
    private String changeType; // ADDED | MODIFIED | DELETED
    private String method;
    private Integer affectedApis;
    private String changeId;
}
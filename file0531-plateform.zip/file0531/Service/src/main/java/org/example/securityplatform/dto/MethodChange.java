package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 方法变更DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MethodChange {
    private Long id;
    private String className;
    private String methodName;
    private String methodDesc;
    private String changeType; // ADDED | MODIFIED | DELETED
    private String riskLevel; // HIGH | MEDIUM | LOW
    private Integer impactDepth;
    private Integer affectedApis;
}
package org.example.securityplatform.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;

/**
 * 污点Sink点实体
 * 存储检测到的漏洞注入点（如MyBatis Mapper中的${}占位符）
 */
@Data
@Entity
@Table(name = "taint_sink")
public class TaintSink {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "artifact_id", nullable = false)
    private Long artifactId;

    /**
     * 漏洞类型：SQL_INJECTION, COMMAND_INJECTION, SSRF
     */
    @Column(name = "vulnerability_type", nullable = false, length = 50)
    private String vulnerabilityType;

    /**
     * Sink类型：MYBATIS_MAPPER, RUNTIME_EXEC, HTTP_CLIENT
     */
    @Column(name = "sink_type", length = 50)
    private String sinkType;

    /**
     * Sink类名（如Mapper接口类）
     */
    @Column(name = "sink_class", length = 255)
    private String sinkClass;

    /**
     * Sink方法名
     */
    @Column(name = "sink_method", length = 255)
    private String sinkMethod;

    /**
     * 可被注入的参数列表（JSON数组）
     */
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "vulnerable_params", columnDefinition = "TEXT")
    private String vulnerableParams;

    /**
     * 文件路径（如Mapper XML文件路径）
     */
    @Column(name = "file_path", length = 500)
    private String filePath;

    /**
     * SQL片段（用于前端展示）
     */
    @Column(name = "sql_snippet", columnDefinition = "TEXT")
    private String sqlSnippet;

    /**
     * 风险等级：HIGH, MEDIUM, LOW
     */
    @Column(name = "risk_level", length = 20)
    private String riskLevel = "HIGH";

    /**
     * 行号
     */
    @Column(name = "line_number")
    private Integer lineNumber;

    /**
     * 来源模块（JAR名称）
     * 用于多模块分析时标识Sink所在的模块
     */
    @Column(name = "source_module", length = 255)
    private String sourceModule;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
}
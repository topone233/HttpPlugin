package org.example.securityplatform.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * 快速差异对比响应
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuickDiffResponse {

    /**
     * 文件差异摘要
     */
    private FileSummary fileSummary;

    /**
     * API变更摘要
     */
    private ApiDiffSummary apiSummary;

    /**
     * 文件差异列表
     */
    private List<FileDiffItem> fileDiffs;

    /**
     * API变更列表
     */
    private List<ApiDiffItem> apiDiffs;

    /**
     * 分析耗时（毫秒）
     */
    private Long duration;

    /**
     * 依赖分析摘要（多JAR分析时使用）
     */
    private DependencySummary dependencySummary;

    /**
     * 分析警告或建议
     */
    private List<String> warnings;

    /**
     * 源代码差异列表（反编译后的Java源码）
     */
    private List<FileSourceDiff> sourceDiffs;

    /**
     * 影响图谱数据（变更影响链路可视化）
     */
    private ImpactGraphResponse impactGraph;

    /**
     * 依赖分析摘要
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DependencySummary {
        /**
         * 是否启用了依赖分析
         */
        private boolean enabled;
        /**
         * 分析的依赖JAR数量（baseline）
         */
        private int baselineDependencyCount;
        /**
         * 分析的依赖JAR数量（target）
         */
        private int targetDependencyCount;
        /**
         * 分析的依赖JAR名称列表
         */
        private List<String> analyzedDependencies;
    }

    /**
     * 文件差异摘要
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FileSummary {
        private int addedFiles;
        private int modifiedFiles;
        private int deletedFiles;
        private int totalMethodsAdded;
        private int totalMethodsDeleted;
        private int totalMethodsModified;

        /**
         * Java代码文件统计（字节码统计）
         * 统计 .class 文件差异（基于反编译后的字节码指令计数）
         */
        private int bytecodeTotalAdditions;        // Java代码新增行数
        private int bytecodeTotalDeletions;        // Java代码删除行数
        private int bytecodeBaselineTotalLines;    // Java代码基线总行数
        private int bytecodeTargetTotalLines;      // Java代码目标总行数

        /**
         * 配置文件统计摘要
         *
         * 注：字段名为 businessCodeSummary 是历史命名，
         * 实际含义是 ResourceFileSummary（配置文件摘要）
         * 统计范围：xml/properties/yml/yaml/sql/java 等资源文件
         */
        private BusinessCodeSummary businessCodeSummary;

        /**
         * 总体统计（Java代码 + 配置文件合计）
         */
        private int totalAdditions;                // 代码变更总量（新增）
        private int totalDeletions;                // 代码变更总量（删除）
        private int baselineTotalLines;            // 代码总行数（基线）
        private int targetTotalLines;              // 代码总行数（目标）
    }

    /**
     * 配置文件统计摘要
     *
     * 注：类名为 BusinessCodeSummary 是历史命名，
     * 实际含义是 ResourceFileSummary（配置文件摘要）
     * 统计范围：xml/properties/yml/yaml/sql/java 等资源文件
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BusinessCodeSummary {
        private int totalAdditions;           // 配置文件新增行数
        private int totalDeletions;           // 配置文件删除行数
        private int baselineTotalLines;       // 配置文件基线总行数
        private int targetTotalLines;         // 配置文件目标总行数

        /**
         * 按文件类型细分统计
         * 例如：{"xml": 50, "yml": 20, "properties": 30}
         */
        private Map<String, Integer> additionsByType;
        private Map<String, Integer> deletionsByType;
    }

    /**
     * API变更摘要
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ApiDiffSummary {
        private int newApis;
        private int modifiedApis;
        private int affectedApis;
        private int deletedApis;
    }

    /**
     * 文件差异项
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FileDiffItem {
        private String filePath;
        private String sourceFilePath;
        private String diffType;
        // 多JAR支持：记录来源JAR
        private String sourceJar;      // 来源JAR名称
        private String jarType;        // MAIN 或 DEPENDENCY
        private Integer baselineLines;
        private Integer targetLines;
        private Integer addedLines;
        private Integer deletedLines;
        private Integer methodsAdded;
        private Integer methodsDeleted;
        private Integer methodsModified;
        // 方法变更详情
        private List<MethodChange> methodChanges;

        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class MethodChange {
            private String methodName;
            private String changeType; // ADDED, DELETED, MODIFIED
        }
    }

    /**
     * API变更项
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ApiDiffItem {
        private String apiUrl;
        private String httpMethod;
        private String controllerClass;
        private String methodName;
        private String changeType;
        private String changeReason;
        private List<CallChainNode> callChain;

        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class CallChainNode {
            private String className;
            private String methodName;
            private int depth;
        }
    }
}

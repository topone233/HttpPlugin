package org.example.securityplatform.analyzer.diff;

import lombok.Data;
import org.objectweb.asm.Opcodes;

/**
 * 方法变更模型
 */
@Data
public class MethodChangeModel {
    private String methodName;
    private String descriptor;
    private int access;
    private String changeType; // ADDED, DELETED, MODIFIED
    private int baselineInstructions;
    private int targetInstructions;

    /**
     * 是否为构造方法
     */
    public boolean isConstructor() {
        return "<init>".equals(methodName) || "<clinit>".equals(methodName);
    }

    /**
     * 是否为public方法
     */
    public boolean isPublic() {
        return (access & Opcodes.ACC_PUBLIC) != 0;
    }

    /**
     * 获取方法签名
     */
    public String getSignature() {
        return methodName + descriptor;
    }
}
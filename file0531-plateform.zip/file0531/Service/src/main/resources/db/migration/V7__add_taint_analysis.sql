-- 污点分析 - Sink点表
-- 存储检测到的漏洞注入点（如MyBatis Mapper中的${}占位符）
CREATE TABLE IF NOT EXISTS taint_sink (
    id BIGSERIAL PRIMARY KEY,
    artifact_id BIGINT NOT NULL,
    vulnerability_type VARCHAR(50) NOT NULL,  -- SQL_INJECTION, COMMAND_INJECTION, SSRF
    sink_type VARCHAR(50),                      -- MYBATIS_MAPPER, RUNTIME_EXEC, HTTP_CLIENT
    sink_class VARCHAR(255),                    -- Mapper接口类名
    sink_method VARCHAR(255),                   -- Mapper方法名
    vulnerable_params JSONB,                    -- 可被注入的参数列表 ["param1", "param2"]
    file_path VARCHAR(500),                     -- XML文件路径
    sql_snippet TEXT,                           -- SQL片段（用于展示）
    risk_level VARCHAR(20) DEFAULT 'HIGH',      -- 风险等级
    line_number INTEGER,                        -- 行号
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sink_artifact FOREIGN KEY (artifact_id) REFERENCES artifact(id) ON DELETE CASCADE
);

-- 污点分析 - 污点路径表
-- 存储从污点源(Controller参数)到Sink的传播路径
CREATE TABLE IF NOT EXISTS taint_path (
    id BIGSERIAL PRIMARY KEY,
    sink_id BIGINT NOT NULL,
    source_class VARCHAR(255),                  -- Controller类名
    source_method VARCHAR(255),                 -- Controller方法名
    source_param VARCHAR(100),                  -- 污点参数名
    source_param_type VARCHAR(100),             -- 参数类型
    call_chain JSONB,                           -- 调用链 [{className, methodName, lineNumber}]
    depth INTEGER DEFAULT 0,                    -- 调用深度
    is_reachable BOOLEAN DEFAULT true,          -- 是否可达
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_path_sink FOREIGN KEY (sink_id) REFERENCES taint_sink(id) ON DELETE CASCADE
);

-- 创建索引
CREATE INDEX idx_sink_artifact ON taint_sink(artifact_id);
CREATE INDEX idx_sink_vuln_type ON taint_sink(vulnerability_type);
CREATE INDEX idx_sink_type ON taint_sink(sink_type);
CREATE INDEX idx_sink_risk ON taint_sink(risk_level);

CREATE INDEX idx_path_sink ON taint_path(sink_id);
CREATE INDEX idx_path_source ON taint_path(source_class, source_method);
CREATE INDEX idx_path_reachable ON taint_path(is_reachable);
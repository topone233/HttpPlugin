ALTER TABLE quick_diff_record
    ADD COLUMN IF NOT EXISTS dependency_summary_json TEXT;

ALTER TABLE quick_diff_record
    ADD COLUMN IF NOT EXISTS warnings_json TEXT;

ALTER TABLE quick_diff_record
    ADD COLUMN IF NOT EXISTS impact_graph_json TEXT;

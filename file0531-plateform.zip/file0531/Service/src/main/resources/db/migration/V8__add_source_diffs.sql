-- 创建快速差异对比记录表
CREATE TABLE IF NOT EXISTS quick_diff_record (
    id BIGSERIAL PRIMARY KEY,
    baseline_file_name VARCHAR(255) NOT NULL,
    target_file_name VARCHAR(255) NOT NULL,
    baseline_md5 VARCHAR(64),
    target_md5 VARCHAR(64),
    file_summary_json TEXT,
    api_summary_json TEXT,
    file_diffs_json TEXT,
    api_diffs_json TEXT,
    source_diffs_json TEXT,
    duration_ms BIGINT,
    description VARCHAR(500),
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- 创建索引
CREATE INDEX idx_created_at ON quick_diff_record(created_at);

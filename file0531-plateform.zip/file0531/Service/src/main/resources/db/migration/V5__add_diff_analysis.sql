-- 差异分析任务表
CREATE TABLE IF NOT EXISTS diff_analysis_task (
    id BIGSERIAL PRIMARY KEY,
    project_id BIGINT NOT NULL,
    baseline_artifact_id BIGINT NOT NULL,
    target_artifact_id BIGINT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    error_message TEXT,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    CONSTRAINT fk_diff_task_project FOREIGN KEY (project_id) REFERENCES project(id) ON DELETE CASCADE,
    CONSTRAINT fk_diff_task_baseline FOREIGN KEY (baseline_artifact_id) REFERENCES artifact(id) ON DELETE CASCADE,
    CONSTRAINT fk_diff_task_target FOREIGN KEY (target_artifact_id) REFERENCES artifact(id) ON DELETE CASCADE
);

-- 文件差异表
CREATE TABLE IF NOT EXISTS file_diff (
    id BIGSERIAL PRIMARY KEY,
    diff_task_id BIGINT NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    source_file_path VARCHAR(500),
    diff_type VARCHAR(20) NOT NULL,
    baseline_lines INTEGER DEFAULT 0,
    target_lines INTEGER DEFAULT 0,
    added_lines INTEGER DEFAULT 0,
    deleted_lines INTEGER DEFAULT 0,
    changed_line_ranges JSONB,
    methods_added INTEGER DEFAULT 0,
    methods_deleted INTEGER DEFAULT 0,
    methods_modified INTEGER DEFAULT 0,
    CONSTRAINT fk_file_diff_task FOREIGN KEY (diff_task_id) REFERENCES diff_analysis_task(id) ON DELETE CASCADE
);

-- API变更表
CREATE TABLE IF NOT EXISTS api_diff (
    id BIGSERIAL PRIMARY KEY,
    diff_task_id BIGINT NOT NULL,
    api_url VARCHAR(500) NOT NULL,
    http_method VARCHAR(10) NOT NULL,
    controller_class VARCHAR(255),
    method_name VARCHAR(255),
    parameters JSONB,
    change_type VARCHAR(20) NOT NULL,
    change_reason TEXT,
    call_chain JSONB,
    related_file_diff_ids JSONB,
    danger_functions JSONB,
    risk_level VARCHAR(10) DEFAULT 'MEDIUM',
    CONSTRAINT fk_api_diff_task FOREIGN KEY (diff_task_id) REFERENCES diff_analysis_task(id) ON DELETE CASCADE
);

-- 方法调用关系表（用于存储调用图）
CREATE TABLE IF NOT EXISTS method_call_edge (
    id BIGSERIAL PRIMARY KEY,
    artifact_id BIGINT NOT NULL,
    caller_class VARCHAR(255) NOT NULL,
    caller_method VARCHAR(255) NOT NULL,
    caller_descriptor VARCHAR(500),
    callee_class VARCHAR(255) NOT NULL,
    callee_method VARCHAR(255) NOT NULL,
    callee_descriptor VARCHAR(500),
    call_line INTEGER,
    call_type VARCHAR(20),
    CONSTRAINT fk_call_edge_artifact FOREIGN KEY (artifact_id) REFERENCES artifact(id) ON DELETE CASCADE
);

-- 差异分析进度表
CREATE TABLE IF NOT EXISTS diff_analysis_progress (
    id BIGSERIAL PRIMARY KEY,
    diff_task_id BIGINT NOT NULL,
    current_step VARCHAR(50) NOT NULL,
    step_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    progress_percentage INTEGER DEFAULT 0,
    message TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_diff_progress_task FOREIGN KEY (diff_task_id) REFERENCES diff_analysis_task(id) ON DELETE CASCADE
);

-- 创建索引
CREATE INDEX idx_diff_task_project ON diff_analysis_task(project_id);
CREATE INDEX idx_diff_task_status ON diff_analysis_task(status);
CREATE INDEX idx_diff_task_baseline ON diff_analysis_task(baseline_artifact_id);
CREATE INDEX idx_diff_task_target ON diff_analysis_task(target_artifact_id);

CREATE INDEX idx_file_diff_task ON file_diff(diff_task_id);
CREATE INDEX idx_file_diff_type ON file_diff(diff_type);

CREATE INDEX idx_api_diff_task ON api_diff(diff_task_id);
CREATE INDEX idx_api_diff_type ON api_diff(change_type);
CREATE INDEX idx_api_diff_risk ON api_diff(risk_level);

CREATE INDEX idx_call_edge_artifact ON method_call_edge(artifact_id);
CREATE INDEX idx_call_edge_caller ON method_call_edge(caller_class, caller_method);
CREATE INDEX idx_call_edge_callee ON method_call_edge(callee_class, callee_method);

CREATE INDEX idx_diff_progress_task ON diff_analysis_progress(diff_task_id);

<template>
  <div class="call-path-graph">
    <div ref="graphContainer" class="graph-container"></div>
    <div v-if="loading" class="loading-overlay">
      <el-icon class="is-loading"><Loading /></el-icon>
      <span>加载中...</span>
    </div>
    <div v-if="!loading && (!paths || paths.length === 0)" class="empty-state">
      <el-empty description="无调用路径" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, onUnmounted } from 'vue'
import { Graph } from '@antv/g6'
import { Loading } from '@element-plus/icons-vue'

const props = defineProps({
  startData: {
    type: Object,
    default: () => ({})
  },
  endData: {
    type: Object,
    default: () => ({})
  },
  paths: {
    type: Array,
    default: () => []
  },
  loading: {
    type: Boolean,
    default: false
  }
})

const graphContainer = ref(null)
let graph = null

onMounted(() => {
  initGraph()
})

onUnmounted(() => {
  if (graph) {
    graph.destroy()
  }
})

watch(() => props.paths, () => {
  if (graph && props.paths && props.paths.length > 0) {
    updateGraph()
  }
}, { deep: true })

function initGraph() {
  if (!graphContainer.value) return

  const width = graphContainer.value.offsetWidth
  const height = graphContainer.value.offsetHeight || 400

  graph = new Graph({
    container: graphContainer.value,
    width,
    height,
    autoFit: 'view',
    padding: 20,
    behaviors: ['drag-canvas', 'zoom-canvas', 'drag-element'],
    layout: {
      type: 'dagre',
      rankdir: 'TB',
      nodesep: 60,
      ranksep: 80
    },
    node: {
      style: {
        size: (d) => {
          const label = d.data?.label || ''
          const lines = label.split('\n').length
          return [Math.max(100, label.length * 8), 20 + lines * 16]
        },
        fill: (d) => {
          const type = d.data?.nodeType
          if (type === 'start') return '#C8E6C9'  // 绿色起点
          if (type === 'end') return '#FFCDD2'    // 红色终点
          return '#E3F2FD'                        // 蓝色中间节点
        },
        stroke: (d) => {
          const type = d.data?.nodeType
          if (type === 'start') return '#4CAF50'
          if (type === 'end') return '#E53935'
          return '#2196F3'
        },
        lineWidth: 2,
        radius: 4,
        labelText: (d) => d.data?.label || '',
        labelFill: '#333',
        labelFontSize: 12,
        labelPlacement: 'center'
      }
    },
    edge: {
      style: {
        stroke: '#5B8FF9',
        lineWidth: 2,
        endArrow: true
      }
    }
  })

  if (props.paths && props.paths.length > 0) {
    updateGraph()
  }
}

function updateGraph() {
  if (!graph) return

  const data = transformToGraphData(props.paths, props.startData, props.endData)
  graph.setData(data)
  graph.render()
}

function transformToGraphData(paths, startData, endData) {
  const nodes = []
  const edges = []
  const nodeMap = new Map()

  paths.forEach((path, pathIndex) => {
    // 1. Start节点
    const startId = `start-${startData.startClass}-${startData.startMethod}-${pathIndex}`
    if (!nodeMap.has(startId)) {
      nodeMap.set(startId, true)
      nodes.push({
        id: startId,
        data: {
          label: formatNodeLabel(startData.startClass, startData.startMethod),
          nodeType: 'start'
        }
      })
    }

    // 2. End节点（所有路径共享）
    const endId = `end-${endData.endClass}-${endData.endMethod}`
    if (!nodeMap.has(endId)) {
      nodeMap.set(endId, true)
      nodes.push({
        id: endId,
        data: {
          label: formatNodeLabel(endData.endClass, endData.endMethod),
          nodeType: 'end'
        }
      })
    }

    // 3. 中间节点和边
    let prevId = startId
    if (path.nodes && path.nodes.length > 1) {
      path.nodes.slice(1).forEach((node, nodeIndex) => {
        const nodeId = `node-${node.className}-${node.methodName}-${pathIndex}-${nodeIndex}`
        if (!nodeMap.has(nodeId)) {
          nodeMap.set(nodeId, true)
          nodes.push({
            id: nodeId,
            data: {
              label: formatNodeLabel(node.className, node.methodName),
              nodeType: 'intermediate'
            }
          })
        }

        edges.push({
          id: `edge-${prevId}-${nodeId}`,
          source: prevId,
          target: nodeId
        })
        prevId = nodeId
      })
    }

    // 最后一条边连接到end
    edges.push({
      id: `edge-${prevId}-${endId}`,
      source: prevId,
      target: endId
    })
  })

  return { nodes, edges }
}

function formatNodeLabel(className, methodName) {
  const shortClass = className.split('.').pop()
  return `${shortClass}\n${methodName}()`
}
</script>

<style scoped>
.call-path-graph {
  width: 100%;
  height: 100%;
  position: relative;
  background: #fafafa;
  border-radius: 4px;
}

.graph-container {
  width: 100%;
  height: 400px;
}

.loading-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.8);
  z-index: 10;
}

.loading-overlay .el-icon {
  font-size: 32px;
  margin-bottom: 10px;
}

.empty-state {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
</style>
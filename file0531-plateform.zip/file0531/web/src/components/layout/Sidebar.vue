<template>
  <div class="sidebar-container">
    <el-menu
      :default-active="activeMenu"
      :collapse="isCollapsed"
      :collapse-transition="false"
      router
      background-color="#304156"
      text-color="#bfcbd9"
      active-text-color="#409eff"
    >
      <el-menu-item index="/dashboard">
        <el-icon><DataBoard /></el-icon>
        <template #title>仪表盘</template>
      </el-menu-item>

      <el-menu-item index="/projects">
        <el-icon><Folder /></el-icon>
        <template #title>项目管理</template>
      </el-menu-item>

      <el-sub-menu index="diff">
        <template #title>
          <el-icon><Sort /></el-icon>
          <span>差异对比</span>
        </template>
        <el-menu-item index="/quick-diff">
          <el-icon><Promotion /></el-icon>
          <template #title>快速对比</template>
        </el-menu-item>
        <el-menu-item index="/quick-diff/history">
          <el-icon><Clock /></el-icon>
          <template #title>快速对比历史</template>
        </el-menu-item>
        <el-menu-item index="/diff-analysis">
          <el-icon><Histogram /></el-icon>
          <template #title>差异分析</template>
        </el-menu-item>
      </el-sub-menu>

      <el-menu-item index="/reports">
        <el-icon><Document /></el-icon>
        <template #title>测试报告</template>
      </el-menu-item>

      <el-menu-item index="/taint-analysis">
        <el-icon><Aim /></el-icon>
        <template #title>污点分析</template>
      </el-menu-item>

      <el-menu-item index="/call-path-analysis">
        <el-icon><Share /></el-icon>
        <template #title>调用链路分析</template>
      </el-menu-item>

      <el-sub-menu index="rules">
        <template #title>
          <el-icon><Setting /></el-icon>
          <span>规则配置</span>
        </template>
        <el-menu-item index="/rule-management/test-cases">
          <el-icon><Document /></el-icon>
          <template #title>测试用例库</template>
        </el-menu-item>
        <el-menu-item index="/rule-management/config-items">
          <el-icon><Checked /></el-icon>
          <template #title>配置检查项</template>
        </el-menu-item>
        <el-menu-item index="/rule-management/danger-function-rules">
          <el-icon><Warning /></el-icon>
          <template #title>危险函数规则</template>
        </el-menu-item>
      </el-sub-menu>
    </el-menu>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import {
  Clock, Setting, Checked, Warning, Aim, Share,
  DataBoard, Folder, Sort, Promotion, Histogram, Document
} from '@element-plus/icons-vue'

const props = defineProps({
  isCollapsed: {
    type: Boolean,
    default: false
  }
})

const route = useRoute()

const activeMenu = computed(() => {
  const path = route.path
  if (path.startsWith('/projects')) return '/projects'
  if (path.startsWith('/quick-diff')) return '/quick-diff'
  if (path.startsWith('/diff-analysis')) return '/diff-analysis'
  if (path.startsWith('/reports')) return '/reports'
  if (path.startsWith('/taint-analysis')) return '/taint-analysis'
  if (path.startsWith('/rule-management')) return '/rule-management'
  return path
})
</script>

<style lang="scss" scoped>
.sidebar-container {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.el-menu {
  border-right: none;
  flex: 1;
}
</style>

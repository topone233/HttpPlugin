/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TestReportResponse = {
    id?: number;
    artifactId?: number;
    reportName?: string;
    reportType?: string;
    reportStatus?: string;
    generatedBy?: string;
    generatedAt?: string;
    totalTestCases?: number;
    executedCount?: number;
    passCount?: number;
    failCount?: number;
    skipCount?: number;
    errorCount?: number;
    criticalCount?: number;
    highCount?: number;
    mediumCount?: number;
    lowCount?: number;
    startTime?: string;
    endTime?: string;
    totalDurationMs?: number;
    summary?: string;
    vulnerabilitySummary?: Record<string, Record<string, any>>;
    componentSummary?: Record<string, Record<string, any>>;
    recommendations?: string;
    reportFilePath?: string;
    reportFormat?: string;
    fileSizeBytes?: number;
    createdAt?: string;
};


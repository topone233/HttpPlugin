/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TestEnvironmentResponse } from './TestEnvironmentResponse';
export type ResultTestEnvironmentResponse = {
    code?: number;
    message?: string;
    data?: TestEnvironmentResponse;
};


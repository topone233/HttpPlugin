/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TaskResponse = {
    id?: number;
    projectId?: number;
    taskName?: string;
    testVersion?: string;
    testTime?: string;
    status?: string;
    createdBy?: string;
    createdAt?: string;
    updatedAt?: string;
};


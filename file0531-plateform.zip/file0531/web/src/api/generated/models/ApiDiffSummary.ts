/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CallChainNode } from './CallChainNode';
import type { DangerFunctionInfo } from './DangerFunctionInfo';
export type ApiDiffSummary = {
    id?: number;
    apiUrl?: string;
    httpMethod?: string;
    controllerClass?: string;
    methodName?: string;
    changeType?: string;
    changeReason?: string;
    riskLevel?: string;
    parameters?: Array<Record<string, Record<string, any>>>;
    callChain?: Array<CallChainNode>;
    relatedFileDiffIds?: Array<number>;
    dangerFunctions?: Array<DangerFunctionInfo>;
};


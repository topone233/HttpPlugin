/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TestEnvironmentResponse } from './TestEnvironmentResponse';
export type ResultListTestEnvironmentResponse = {
    code?: number;
    message?: string;
    data?: Array<TestEnvironmentResponse>;
};


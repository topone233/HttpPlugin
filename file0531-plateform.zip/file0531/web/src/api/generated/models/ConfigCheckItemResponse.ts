/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ConfigCheckItemResponse = {
    id?: number;
    itemName?: string;
    category?: string;
    configKeyPattern?: string;
    checkRule?: string;
    expectedValue?: string;
    unsafeValues?: string;
    riskLevel?: string;
    description?: string;
    remediation?: string;
    standardReference?: string;
    enabled?: boolean;
    createdAt?: string;
    updatedAt?: string;
};


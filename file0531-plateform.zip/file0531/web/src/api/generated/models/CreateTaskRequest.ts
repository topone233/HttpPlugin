/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateTaskRequest = {
    projectId: number;
    taskName?: string;
    testVersion?: string;
    testTime?: string;
    createdBy?: string;
};


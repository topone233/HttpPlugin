/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ResultVoid = {
    code?: number;
    message?: string;
    data?: Record<string, any>;
};


/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type RiskExclusionResponse = {
    id?: number;
    artifactId?: number;
    dangerFunctionId?: number;
    ruleId?: number;
    functionName?: string;
    functionType?: string;
    className?: string;
    filePath?: string;
    lineNumber?: number;
    originalRiskLevel?: string;
    exclusionReason?: string;
    confidenceLevel?: string;
    status?: string;
    reviewer?: string;
    reviewNotes?: string;
    reviewedAt?: string;
    createdAt?: string;
};


/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ApiSummary = {
    url?: string;
    httpMethod?: string;
    controllerClass?: string;
    methodName?: string;
    framework?: string;
};


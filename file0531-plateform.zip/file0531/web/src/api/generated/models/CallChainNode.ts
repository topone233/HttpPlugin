/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CallChainNode = {
    className?: string;
    methodName?: string;
    depth?: number;
};


/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { BaselineRecommendationResponse } from './BaselineRecommendationResponse';
export type ResultBaselineRecommendationResponse = {
    code?: number;
    message?: string;
    data?: BaselineRecommendationResponse;
};


/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type BaselineArtifact = {
    artifactId?: number;
    artifactName?: string;
    taskId?: number;
    taskName?: string;
    testTime?: string;
    taskStatus?: string;
};


/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ConfigCheckItemResponse } from './ConfigCheckItemResponse';
export type ResultListConfigCheckItemResponse = {
    code?: number;
    message?: string;
    data?: Array<ConfigCheckItemResponse>;
};


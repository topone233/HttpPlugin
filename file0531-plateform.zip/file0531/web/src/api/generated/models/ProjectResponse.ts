/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ProjectResponse = {
    id?: number;
    projectName?: string;
    productName?: string;
    description?: string;
    createdBy?: string;
    createdAt?: string;
    updatedAt?: string;
};


/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TestReportResponse } from './TestReportResponse';
export type ResultListTestReportResponse = {
    code?: number;
    message?: string;
    data?: Array<TestReportResponse>;
};


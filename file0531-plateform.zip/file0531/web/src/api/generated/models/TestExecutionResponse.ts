/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TestExecutionResponse = {
    id?: number;
    artifactId?: number;
    checklistId?: number;
    testCaseId?: number;
    executionName?: string;
    vulnerabilityType?: string;
    executionStatus?: string;
    executionType?: string;
    executor?: string;
    startTime?: string;
    endTime?: string;
    durationMs?: number;
    testResult?: string;
    severity?: string;
    reproducible?: boolean;
    environmentInfo?: string;
    testData?: string;
    actualResult?: string;
    expectedResult?: string;
    evidenceFiles?: string;
    logOutput?: string;
    errorMessage?: string;
    notes?: string;
    createdAt?: string;
    updatedAt?: string;
};


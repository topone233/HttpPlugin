/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AnalysisProgressResponse = {
    id?: number;
    artifactId?: number;
    status?: string;
    currentStep?: string;
    totalSteps?: number;
    completedSteps?: number;
    progressPercentage?: number;
    message?: string;
    startedAt?: string;
    completedAt?: string;
};


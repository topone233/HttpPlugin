/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ResultListMapStringObject = {
    code?: number;
    message?: string;
    data?: Array<Record<string, Record<string, any>>>;
};


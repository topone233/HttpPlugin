/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateProjectRequest = {
    projectName?: string;
    productName?: string;
    description?: string;
    createdBy?: string;
};


/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TestChecklistResponse } from './TestChecklistResponse';
export type StrategyMatchResponse = {
    artifactId?: number;
    totalTestCases?: number;
    todoCount?: number;
    passCount?: number;
    naCount?: number;
    vulnerabilityTypeCounts?: Record<string, number>;
    riskLevelCounts?: Record<string, number>;
    testChecklist?: Array<TestChecklistResponse>;
    exclusionCount?: number;
    pendingReviewCount?: number;
};


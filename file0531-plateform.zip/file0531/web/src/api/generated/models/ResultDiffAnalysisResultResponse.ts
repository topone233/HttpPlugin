/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DiffAnalysisResultResponse } from './DiffAnalysisResultResponse';
export type ResultDiffAnalysisResultResponse = {
    code?: number;
    message?: string;
    data?: DiffAnalysisResultResponse;
};


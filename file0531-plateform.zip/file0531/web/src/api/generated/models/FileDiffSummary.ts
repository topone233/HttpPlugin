/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { LineRange } from './LineRange';
export type FileDiffSummary = {
    id?: number;
    filePath?: string;
    sourceFilePath?: string;
    diffType?: string;
    baselineLines?: number;
    targetLines?: number;
    addedLines?: number;
    deletedLines?: number;
    changedLineRanges?: Array<LineRange>;
    methodsAdded?: number;
    methodsDeleted?: number;
    methodsModified?: number;
};


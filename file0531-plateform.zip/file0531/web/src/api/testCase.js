import api from './index'

export default {
  // 获取所有测试用例
  getList() {
    return api.get('/strategy/test-cases')
  },

  // 获取测试用例详情
  getById(id) {
    return api.get(`/strategy/test-cases/${id}`)
  },

  // 创建测试用例
  create(data) {
    return api.post('/strategy/test-cases', data)
  },

  // 更新测试用例
  update(id, data) {
    return api.put(`/strategy/test-cases/${id}`, data)
  },

  // 删除测试用例
  delete(id) {
    return api.delete(`/strategy/test-cases/${id}`)
  },

  // 按漏洞类型获取测试用例
  getByType(type) {
    return api.get(`/strategy/test-cases/by-type/${type}`)
  },

  // 获取所有漏洞类型
  getTypes() {
    return api.get('/strategy/vulnerability-types')
  }
}

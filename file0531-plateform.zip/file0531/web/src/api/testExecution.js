import api from './index'

export default {
  // Get test executions by artifact ID
  getList(artifactId) {
    return api.get(`/test-execution/artifact/${artifactId}`)
  },

  // Get execution by ID
  getById(id) {
    return api.get(`/test-execution/${id}`)
  },

  // Create test execution (artifactId in request body)
  create(data) {
    return api.post(`/test-execution`, data)
  },

  // Start test execution
  start(id) {
    return api.put(`/test-execution/${id}/start`)
  },

  // Complete test execution
  complete(id, result) {
    return api.put(`/test-execution/${id}/complete`, result)
  },

  // Cancel test execution
  cancel(id, reason) {
    const params = reason ? `?reason=${encodeURIComponent(reason)}` : ''
    return api.put(`/test-execution/${id}/cancel${params}`)
  },

  // Batch create test executions
  batchCreate(artifactId) {
    return api.post(`/test-execution/batch/${artifactId}`)
  },

  // Get execution statistics
  getStatistics(artifactId) {
    return api.get(`/test-execution/statistics/${artifactId}`)
  },

  // Get executions by checklist ID
  getByChecklist(checklistId) {
    return api.get(`/test-execution/checklist/${checklistId}`)
  }
}

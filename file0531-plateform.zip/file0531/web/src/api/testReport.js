import api from './index'

export default {
  // Get report list
  getList(params) {
    return api.get('/test-report', { params })
  },

  // Get report by ID
  getById(id) {
    return api.get(`/test-report/${id}`)
  },

  // Generate report
  generate(artifactId, reportType, generatedBy) {
    const params = new URLSearchParams()
    if (reportType) params.append('reportType', reportType)
    if (generatedBy) params.append('generatedBy', generatedBy)
    return api.post(`/test-report/generate/${artifactId}?${params.toString()}`)
  },

  // Export report
  export(id, format = 'pdf') {
    return api.get(`/test-report/${id}/export`, {
      params: { format },
      responseType: 'blob'
    })
  },

  // Delete report
  delete(id) {
    return api.delete(`/test-report/${id}`)
  },

  // Get report by artifact
  getByArtifact(artifactId) {
    return api.get(`/test-report/artifact/${artifactId}`)
  },

  // Get latest report
  getLatest(artifactId) {
    return api.get(`/test-report/latest/${artifactId}`)
  }
}

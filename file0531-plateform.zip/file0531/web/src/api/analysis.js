import api from './index'

export default {
  // Get analysis progress
  getProgress(artifactId) {
    return api.get(`/analysis/progress/${artifactId}`)
  },

  // Get analysis result
  getResult(artifactId) {
    return api.get(`/analysis/result/${artifactId}`)
  }
}

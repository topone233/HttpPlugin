import request from './index'

/**
 * 污点分析API
 */
export default {
  /**
   * 预览制品中的依赖信息
   * @param {number} artifactId 制品ID
   * @returns {Promise} 包含依赖JAR列表和业务包名列表
   */
  previewDependencies(artifactId) {
    return request.get(`/taint/preview-dependencies/${artifactId}`, {
      timeout: 60000 // 1分钟超时
    })
  },

  /**
   * 执行污点分析
   * @param {number} artifactId 制品ID
   * @param {object} options 选项
   * @param {string} options.vulnerabilityType 漏洞类型
   * @param {boolean} options.analyzeDependencies 是否分析依赖模块
   * @param {string[]} options.includePackages 包含的包名列表
   * @param {string[]} options.includeJarNames 包含的JAR名称列表
   */
  analyze(artifactId, options = {}) {
    const params = new URLSearchParams()
    params.append('vulnerabilityType', options.vulnerabilityType || 'SQL_INJECTION')

    if (options.analyzeDependencies) {
      params.append('analyzeDependencies', 'true')
      if (options.includePackages && options.includePackages.length > 0) {
        options.includePackages.forEach(pkg => params.append('includePackages', pkg))
      }
      if (options.includeJarNames && options.includeJarNames.length > 0) {
        options.includeJarNames.forEach(name => params.append('includeJarNames', name))
      }
    }

    return request.post(`/taint/analyze/${artifactId}`, null, {
      params,
      timeout: 300000 // 5分钟超时
    })
  },

  /**
   * 获取污点分析结果
   * @param {number} artifactId 制品ID
   * @param {string} vulnerabilityType 漏洞类型
   */
  getResult(artifactId, vulnerabilityType = 'SQL_INJECTION') {
    return request.get(`/taint/result/${artifactId}`, {
      params: { vulnerabilityType }
    })
  },

  /**
   * 获取Sink详情
   * @param {number} sinkId Sink ID
   */
  getSinkDetail(sinkId) {
    return request.get(`/taint/sink/${sinkId}`)
  }
}
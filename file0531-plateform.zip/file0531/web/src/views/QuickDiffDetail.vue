<template>
  <div class="quick-diff-detail">
    <el-card shadow="never" v-loading="loading">
      <template #header>
        <div class="card-header">
          <span>对比详情</span>
          <el-button @click="goBack">返回列表</el-button>
        </div>
      </template>

      <div v-if="error" class="error-container">
        <el-result icon="error" title="加载失败" :sub-title="error">
          <el-button type="primary" @click="loadDetail">重试</el-button>
        </el-result>
      </div>

      <div v-else-if="result">
        <!-- 文件变更统计 -->
        <div class="summary-section">
          <h3>文件变更统计</h3>
          <el-row :gutter="20">
            <el-col :span="6">
              <el-statistic title="新增文件" :value="result.fileSummary?.addedFiles || 0">
                <template #suffix>
                  <el-icon color="#67C23A"><DocumentAdd /></el-icon>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="修改文件" :value="result.fileSummary?.modifiedFiles || 0">
                <template #suffix>
                  <el-icon color="#E6A23C"><Edit /></el-icon>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="删除文件" :value="result.fileSummary?.deletedFiles || 0">
                <template #suffix>
                  <el-icon color="#F56C6C"><Delete /></el-icon>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="方法变更" :value="totalMethodChanges">
                <template #suffix>
                  <el-icon color="#409EFF"><Operation /></el-icon>
                </template>
              </el-statistic>
            </el-col>
          </el-row>

          <!-- 第二行：行数统计 -->
          <el-row :gutter="20" style="margin-top: 15px;">
            <el-col :span="6">
              <el-statistic title="新增代码总量" :value="result.fileSummary?.totalAdditions || 0">
                <template #suffix>
                  <span style="font-size: 14px; color: #67C23A;">行</span>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="删除代码总量" :value="result.fileSummary?.totalDeletions || 0">
                <template #suffix>
                  <span style="font-size: 14px; color: #F56C6C;">行</span>
                </template>
              </el-statistic>
            </el-col>
            <el-col :span="6">
              <el-statistic title="净变化" :value="netLineChanges">
                <template #suffix>
                  <el-icon :color="netLineChanges >= 0 ? '#67C23A' : '#F56C6C'">
                    <Top v-if="netLineChanges >= 0" />
                    <Bottom v-else />
                  </el-icon>
                </template>
              </el-statistic>
            </el-col>
          </el-row>
        </div>

        <el-divider />

        <!-- API变更统计 -->
        <div class="summary-section">
          <h3>API变更统计</h3>
          <el-row :gutter="20">
            <el-col :span="6">
              <div class="stat-box">
                <div class="label">新增API</div>
                <div class="value">{{ result.apiSummary?.newApis || 0 }}</div>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="stat-box">
                <div class="label">修改API</div>
                <div class="value">{{ result.apiSummary?.modifiedApis || 0 }}</div>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="stat-box">
                <div class="label">受影响API</div>
                <div class="value">{{ result.apiSummary?.affectedApis || 0 }}</div>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="stat-box">
                <div class="label">删除API</div>
                <div class="value">{{ result.apiSummary?.deletedApis || 0 }}</div>
              </div>
            </el-col>
          </el-row>
        </div>

        <el-divider v-if="result.apiDiffs?.length" />

        <!-- API变更详情 -->
        <div class="detail-section" v-if="result.apiDiffs?.length">
          <h3>API变更详情</h3>
          <el-tabs v-model="activeTab">
            <el-tab-pane label="全部" name="all" />
            <el-tab-pane label="新增" name="NEW_API" />
            <el-tab-pane label="修改" name="MODIFIED_API" />
            <el-tab-pane label="受影响" name="AFFECTED_API" />
            <el-tab-pane label="删除" name="DELETED_API" />
          </el-tabs>

          <el-table :data="filteredApiDiffs" style="width: 100%">
            <el-table-column prop="httpMethod" label="方法" width="80">
              <template #default="{ row }">
                <el-tag :type="getMethodTagType(row.httpMethod)" size="small">
                  {{ row.httpMethod }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="apiUrl" label="API路径" min-width="200" show-overflow-tooltip />
            <el-table-column prop="changeType" label="变更类型" width="100">
              <template #default="{ row }">
                <el-tag :type="getChangeTypeTag(row.changeType)" size="small">
                  {{ getChangeTypeLabel(row.changeType) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="changeReason" label="原因" min-width="200" show-overflow-tooltip />
            <el-table-column label="操作" width="80">
              <template #default="{ row }">
                <el-button type="primary" link @click="showApiDetail(row)">详情</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>

        <el-divider v-if="result.fileDiffs?.length" />

        <!-- 文件差异详情 -->
        <div class="detail-section" v-if="result.fileDiffs?.length">
          <h3>文件差异详情</h3>
          <el-table :data="result.fileDiffs" style="width: 100%">
            <el-table-column prop="filePath" label="文件路径" min-width="250" show-overflow-tooltip />
            <el-table-column prop="diffType" label="类型" width="100">
              <template #default="{ row }">
                <el-tag :type="getDiffTypeTag(row.diffType)" size="small">
                  {{ row.diffType }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="行数变化" width="150">
              <template #default="{ row }">
                <span v-if="row.addedLines > 0" class="added">+{{ row.addedLines }}</span>
                <span v-if="row.deletedLines > 0" class="deleted">-{{ row.deletedLines }}</span>
                <span v-if="(!row.addedLines || row.addedLines === 0) && (!row.deletedLines || row.deletedLines === 0)">-</span>
              </template>
            </el-table-column>
            <el-table-column label="方法变更" min-width="200">
              <template #default="{ row }">
                <template v-if="row.methodChanges && row.methodChanges.length > 0">
                  <div class="method-changes">
                    <template v-for="(mc, index) in row.methodChanges.slice(0, 3)" :key="index">
                      <el-tag
                        :type="mc.changeType === 'ADDED' ? 'success' : mc.changeType === 'DELETED' ? 'danger' : 'warning'"
                        size="small"
                        class="method-tag"
                      >
                        {{ mc.changeType === 'ADDED' ? '+' : mc.changeType === 'DELETED' ? '-' : '~' }}{{ mc.methodName }}
                      </el-tag>
                    </template>
                    <el-popover
                      v-if="row.methodChanges.length > 3"
                      placement="left"
                      :width="400"
                      trigger="click"
                    >
                      <template #reference>
                        <el-tag type="info" size="small" class="method-tag clickable">
                          +{{ row.methodChanges.length - 3 }} 更多
                        </el-tag>
                      </template>
                      <div class="method-popover">
                        <div class="method-popover-header">
                          <span>共 {{ row.methodChanges.length }} 个方法变更</span>
                        </div>
                        <div class="method-popover-list">
                          <div
                            v-for="(mc, index) in row.methodChanges"
                            :key="index"
                            class="method-item"
                          >
                            <el-tag
                              :type="mc.changeType === 'ADDED' ? 'success' : mc.changeType === 'DELETED' ? 'danger' : 'warning'"
                              size="small"
                            >
                              {{ mc.changeType === 'ADDED' ? '+' : mc.changeType === 'DELETED' ? '-' : '~' }}
                              {{ mc.changeType === 'ADDED' ? '新增' : mc.changeType === 'DELETED' ? '删除' : '修改' }}
                            </el-tag>
                            <span class="method-name">{{ mc.methodName }}</span>
                          </div>
                        </div>
                      </div>
                    </el-popover>
                  </div>
                </template>
                <template v-else>
                  <span v-if="row.methodsAdded > 0" class="added">+{{ row.methodsAdded }}</span>
                  <span v-if="row.methodsModified > 0" class="modified">~{{ row.methodsModified }}</span>
                  <span v-if="row.methodsDeleted > 0" class="deleted">-{{ row.methodsDeleted }}</span>
                  <span v-if="row.methodsAdded === 0 && row.methodsModified === 0 && row.methodsDeleted === 0">-</span>
                </template>
              </template>
            </el-table-column>
          </el-table>
        </div>

        <!-- 源代码差异对比 -->
        <template v-if="result.sourceDiffs?.length">
          <el-divider />
          <div class="detail-section">
            <h3>源代码差异对比
              <el-tag type="info" size="small" style="margin-left: 10px;">
                {{ result.sourceDiffs.length }} 个文件
              </el-tag>
            </h3>
            <div class="source-diff-layout">
              <div class="source-diff-file-list" :class="{ collapsed: fileListCollapsed }">
                <!-- 文件列表内容 -->
                <div v-if="!fileListCollapsed" class="file-list-content">
                  <div class="file-list-header">
                    <el-radio-group v-model="sourceDiffFilter" size="small">
                      <el-radio-button label="ALL">全部</el-radio-button>
                      <el-radio-button label="ADDED">新增</el-radio-button>
                      <el-radio-button label="MODIFIED">修改</el-radio-button>
                      <el-radio-button label="DELETED">删除</el-radio-button>
                    </el-radio-group>
                  </div>
                  <div class="file-list-items">
                    <div v-for="sd in filteredSourceDiffs" :key="sd.filePath"
                         :class="['file-list-item', { active: selectedSourceDiff?.filePath === sd.filePath }]"
                         @click="selectedSourceDiff = sd">
                      <el-tag :type="getDiffTypeTag(sd.diffType)" size="small" class="file-diff-type">
                        {{ getDiffTypeLabel(sd.diffType) }}
                      </el-tag>
                      <!-- 字节码差异但源码相同的特殊标记 -->
                      <el-tag v-if="sd.bytecodeDiffButSourceSame" type="warning" size="small" class="bytecode-tag">
                        字节码差异
                      </el-tag>
                      <span class="file-list-path" :title="sd.sourceFilePath || sd.filePath">
                        {{ getShortPath(sd.sourceFilePath || sd.filePath) }}
                      </span>
                    </div>
                    <el-empty v-if="!filteredSourceDiffs.length" description="无匹配文件" :image-size="60" />
                  </div>
                </div>

                <!-- 折叠按钮：吸附在右边缘 -->
                <div class="file-list-toggle"
                     @click="fileListCollapsed = !fileListCollapsed"
                     role="button"
                     tabindex="0"
                     :aria-label="fileListCollapsed ? '展开文件列表' : '折叠文件列表'"
                     :aria-expanded="!fileListCollapsed"
                     @keydown.enter="fileListCollapsed = !fileListCollapsed"
                     @keydown.space="fileListCollapsed = !fileListCollapsed">
                  <el-icon>
                    <Fold v-if="!fileListCollapsed" />
                    <Expand v-else />
                  </el-icon>
                </div>
              </div>
              <div class="source-diff-viewer">
                <FileDiffViewer
                  v-if="selectedSourceDiff"
                  :baseline-source="selectedSourceDiff.baselineSource"
                  :target-source="selectedSourceDiff.targetSource"
                  :file-path="selectedSourceDiff.sourceFilePath || selectedSourceDiff.filePath"
                  :diff-type="selectedSourceDiff.diffType"
                  :error="selectedSourceDiff.error"
                  :bytecode-diff-but-source-same="selectedSourceDiff.bytecodeDiffButSourceSame"
                  :original-diff-type="selectedSourceDiff.originalDiffType"
                />
                <el-empty v-else description="请选择左侧文件查看源码差异" />
              </div>
            </div>
          </div>
        </template>

        <!-- 影响链路图谱 -->
        <el-card shadow="never" v-if="result?.impactGraph" class="impact-graph-card">
          <template #header>
            <span>影响链路图谱</span>
            <el-tag type="info" size="small" style="margin-left: 10px;">
              变更: {{ result.impactGraph.changes?.length || 0 }} |
              API: {{ result.impactGraph.apis?.length || 0 }} |
              受影响: {{ result.impactGraph.affected?.length || 0 }}
            </el-tag>
          </template>
          <ChangeImpactGraph
            :graph-data="result.impactGraph"
            @node-click="handleGraphNodeClick"
          />
        </el-card>
      </div>
    </el-card>

    <!-- API详情弹窗 -->
    <el-dialog v-model="apiDetailVisible" title="API变更详情" width="600px">
      <el-descriptions :column="1" border v-if="selectedApi">
        <el-descriptions-item label="API路径">{{ selectedApi.apiUrl }}</el-descriptions-item>
        <el-descriptions-item label="HTTP方法">{{ selectedApi.httpMethod }}</el-descriptions-item>
        <el-descriptions-item label="控制器">{{ selectedApi.controllerClass }}</el-descriptions-item>
        <el-descriptions-item label="方法名">{{ selectedApi.methodName }}</el-descriptions-item>
        <el-descriptions-item label="变更类型">{{ getChangeTypeLabel(selectedApi.changeType) }}</el-descriptions-item>
        <el-descriptions-item label="变更原因">{{ selectedApi.changeReason }}</el-descriptions-item>
        <el-descriptions-item label="调用链" v-if="selectedApi.callChain?.length">
          <div class="call-chain">
            <template v-for="(node, index) in selectedApi.callChain" :key="index">
              <span class="node">{{ node.className }}.{{ node.methodName }}</span>
              <span v-if="index < selectedApi.callChain.length - 1" class="arrow">→</span>
            </template>
          </div>
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { DocumentAdd, Edit, Delete, Operation, Fold, Expand, Top, Bottom } from '@element-plus/icons-vue'
import { useRoute, useRouter } from 'vue-router'
import diffAnalysisApi from '@/api/diffAnalysis'
import FileDiffViewer from '@/components/diff/FileDiffViewer.vue'
import ChangeImpactGraph from '@/components/diff/ChangeImpactGraph.vue'

const router = useRouter()
const route = useRoute()

const loading = ref(true)
const error = ref('')
const result = ref(null)
const activeTab = ref('all')
const apiDetailVisible = ref(false)
const selectedApi = ref(null)

// 源码差异
const sourceDiffFilter = ref('ALL')
const selectedSourceDiff = ref(null)
const fileListCollapsed = ref(false)  // 文件列表折叠状态

const filteredSourceDiffs = computed(() => {
  if (!result.value?.sourceDiffs) return []
  if (sourceDiffFilter.value === 'ALL') {
    // 显示所有文件，包括UNCHANGED的（字节码差异但源码相同）
    return result.value.sourceDiffs
  }
  // 过滤时，字节码差异但源码相同的文件（bytecodeDiffButSourceSame=true）也应该显示
  return result.value.sourceDiffs.filter(sd => {
    if (sd.diffType === sourceDiffFilter.value) return true
    // 如果是MODIFIED过滤，也包含字节码差异但源码相同的文件
    if (sourceDiffFilter.value === 'MODIFIED' && sd.bytecodeDiffButSourceSame) return true
    return false
  })
})

// 计算属性
const totalMethodChanges = computed(() => {
  const s = result.value?.fileSummary || {}
  return (s.totalMethodsAdded || 0) + (s.totalMethodsModified || 0) + (s.totalMethodsDeleted || 0)
})

const netLineChanges = computed(() => {
  const additions = result.value?.fileSummary?.totalAdditions || 0
  const deletions = result.value?.fileSummary?.totalDeletions || 0
  return additions - deletions
})

const filteredApiDiffs = computed(() => {
  if (!result.value?.apiDiffs) return []
  if (activeTab.value === 'all') return result.value.apiDiffs
  return result.value.apiDiffs.filter(api => api.changeType === activeTab.value)
})

// 方法
const loadDetail = async () => {
  const id = route.params.id
  loading.value = true
  error.value = ''

  try {
    const res = await diffAnalysisApi.getQuickDiffDetail(id)
    result.value = res.data || res
  } catch (e) {
    console.error('加载详情失败', e)
    error.value = e.message || '加载失败'
  } finally {
    loading.value = false
  }
}

const goBack = () => {
  router.push('/quick-diff/history')
}

const showApiDetail = (api) => {
  selectedApi.value = api
  apiDetailVisible.value = true
}

// 标签类型
const getMethodTagType = (method) => {
  const types = { GET: 'success', POST: 'primary', PUT: 'warning', DELETE: 'danger' }
  return types[method] || 'info'
}

const getChangeTypeTag = (type) => {
  const types = { NEW_API: 'success', MODIFIED_API: 'warning', AFFECTED_API: 'info', DELETED_API: 'danger' }
  return types[type] || ''
}

const getChangeTypeLabel = (type) => {
  const labels = { NEW_API: '新增', MODIFIED_API: '修改', AFFECTED_API: '受影响', DELETED_API: '删除' }
  return labels[type] || type
}


const getDiffTypeTag = (type) => {
  const types = { ADDED: 'success', MODIFIED: 'warning', DELETED: 'danger', UNCHANGED: 'info' }
  return types[type] || ''
}

const getDiffTypeLabel = (type) => {
  const labels = { ADDED: '新增', MODIFIED: '修改', DELETED: '删除', UNCHANGED: '未变更' }
  return labels[type] || type
}

const getShortPath = (path) => {
  if (!path) return ''
  const parts = path.split('/')
  if (parts.length <= 3) return path
  return '.../' + parts.slice(-3).join('/')
}

const handleGraphNodeClick = (node) => {
  console.log('点击图谱节点:', node)
  if (node.nodeType === 'api' && node.apiUrl) {
    const api = result.value.apiDiffs?.find(a => a.apiUrl === node.apiUrl)
    if (api) {
      selectedApi.value = api
      apiDetailVisible.value = true
    }
  }
}

onMounted(() => {
  loadDetail()
})
</script>

<style scoped>
.quick-diff-detail {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.error-container {
  padding: 60px 20px;
  text-align: center;
}

.summary-section {
  padding: 10px 0;
}

.summary-section h3 {
  margin-bottom: 15px;
  color: #303133;
}

.stat-box {
  text-align: center;
  padding: 20px;
  border-radius: 8px;
  background: #f5f7fa;
}

.stat-box .label {
  font-size: 14px;
  color: #666;
}

.stat-box .value {
  font-size: 28px;
  font-weight: bold;
  margin-top: 5px;
}

.detail-section h3 {
  margin-bottom: 15px;
  color: #303133;
}

.added {
  color: #67C23A;
  margin-right: 10px;
}

.modified {
  color: #E6A23C;
  margin-right: 10px;
}

.deleted {
  color: #F56C6C;
}

.call-chain {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 5px;
}

.call-chain .node {
  padding: 2px 8px;
  background: #f0f2f5;
  border-radius: 4px;
  font-size: 12px;
}

.call-chain .arrow {
  color: #409EFF;
}

.method-changes {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.method-tag {
  font-size: 11px;
}

.method-tag.clickable {
  cursor: pointer;
}

.method-tag.clickable:hover {
  opacity: 0.8;
}

.method-popover {
  max-height: 400px;
  overflow-y: auto;
}

.method-popover-header {
  font-weight: bold;
  margin-bottom: 10px;
  padding-bottom: 8px;
  border-bottom: 1px solid #ebeef5;
}

.method-popover-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.method-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px 0;
}

.method-name {
  font-family: monospace;
  font-size: 13px;
  word-break: break-all;
}

.source-diff-layout {
  display: flex;
  gap: 16px;
  min-height: 600px;                    /* 改为最小高度 */
  max-height: calc(100vh - 60px);      /* 最大高度 = 视口高度 - Header高度 */
  position: sticky;                     /* sticky定位 */
  top: 60px;                            /* 吸附在Header下方 */
  z-index: 10;                          /* 确保覆盖下方内容 */
  background: white;                    /* 避免下方内容透出 */
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1); /* 吸附时添加阴影 */
  margin-bottom: 20px;                  /* 与下方内容保持间距 */
}

.source-diff-file-list {
  display: flex;
  background: #fafafa;
  border: 1px solid #e4e7ed;
  border-radius: 4px;
  overflow: hidden;
  transition: width 0.3s ease;  /* 平滑动画 */
}

.source-diff-file-list.collapsed {
  width: 20px;  /* 折叠后只保留按钮宽度 */
}

.source-diff-file-list:not(.collapsed) {
  width: 300px;
}

.file-list-content {
  flex: 1;
  overflow-y: auto;
  border-right: 1px solid #e4e7ed;
}

.file-list-header {
  padding: 10px;
  border-bottom: 1px solid #e4e7ed;
  background: #fafafa;
}

.file-list-items {
  flex: 1;
  overflow-y: auto;
}

.file-list-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  cursor: pointer;
  border-bottom: 1px solid #f0f2f5;
  transition: background 0.2s;
}

.file-list-item:hover {
  background: #f5f7fa;
}

.file-list-item.active {
  background: #ecf5ff;
}

.file-diff-type {
  flex-shrink: 0;
}

.bytecode-tag {
  flex-shrink: 0;
  font-size: 11px;
  margin-left: 4px;
}

.file-list-path {
  font-family: 'SFMono-Regular', Consolas, monospace;
  font-size: 12px;
  color: #606266;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.file-list-toggle {
  width: 20px;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #ecf5ff;
  cursor: pointer;
  color: #409eff;
  user-select: none;
  border-left: 2px solid #409eff;
  transition: background 0.2s;
}

.file-list-toggle:hover {
  background: #d9ecff;
}

.file-list-toggle:focus {
  outline: 2px solid #409eff;
  outline-offset: -2px;
}

.source-diff-viewer {
  flex: 1;
  overflow: hidden;
  border: 1px solid #e4e7ed;
  border-radius: 4px;
}

.impact-graph-card {
  margin-top: 20px;
}

.impact-graph-card :deep(.el-card__header) {
  display: flex;
  align-items: center;
}
</style>

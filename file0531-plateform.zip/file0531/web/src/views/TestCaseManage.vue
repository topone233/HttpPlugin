<template>
  <div class="test-case-manage">
    <el-card shadow="never">
      <template #header>
        <div class="card-header">
          <span>测试用例库管理</span>
          <el-button type="primary" @click="showCreateDialog">
            <el-icon><Plus /></el-icon>
            新建用例
          </el-button>
        </div>
      </template>

      <el-table :data="testCases" v-loading="loading" style="width: 100%">
        <el-table-column prop="caseName" label="用例名称" min-width="180" />
        <el-table-column prop="vulnerabilityType" label="漏洞类型" width="140">
          <template #default="{ row }">
            <el-tag size="small">{{ row.vulnerabilityType }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="riskLevel" label="风险等级" width="100">
          <template #default="{ row }">
            <el-tag :type="getRiskTagType(row.riskLevel)" size="small">
              {{ row.riskLevel }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="detectionMethod" label="检测方法" width="100" />
        <el-table-column prop="enabled" label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="row.enabled ? 'success' : 'info'" size="small">
              {{ row.enabled ? '启用' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="createdAt" label="创建时间" width="160">
          <template #default="{ row }">
            {{ formatDate(row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link @click="showEditDialog(row)">编辑</el-button>
            <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Create/Edit Dialog -->
    <el-dialog v-model="dialogVisible" :title="isEdit ? '编辑测试用例' : '新建测试用例'" width="700px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="用例名称" prop="caseName">
              <el-input v-model="form.caseName" placeholder="请输入用例名称" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="漏洞类型" prop="vulnerabilityType">
              <el-select v-model="form.vulnerabilityType" placeholder="请选择漏洞类型" style="width: 100%">
                <el-option label="SQL注入" value="SQL_INJECTION" />
                <el-option label="XSS" value="XSS" />
                <el-option label="命令执行" value="COMMAND_INJECTION" />
                <el-option label="路径遍历" value="PATH_TRAVERSAL" />
                <el-option label="反序列化" value="DESERIALIZATION" />
                <el-option label="SSRF" value="SSRF" />
                <el-option label="XXE" value="XXE" />
                <el-option label="认证绕过" value="AUTH_BYPASS" />
                <el-option label="信息泄露" value="INFO_DISCLOSURE" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="风险等级" prop="riskLevel">
              <el-select v-model="form.riskLevel" placeholder="请选择风险等级" style="width: 100%">
                <el-option label="高" value="HIGH" />
                <el-option label="中" value="MEDIUM" />
                <el-option label="低" value="LOW" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="检测方法" prop="detectionMethod">
              <el-select v-model="form.detectionMethod" placeholder="请选择检测方法" style="width: 100%">
                <el-option label="自动" value="AUTO" />
                <el-option label="半自动" value="SEMI_AUTO" />
                <el-option label="手工" value="MANUAL" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="适用组件">
          <el-input v-model="form.applicableComponents" type="textarea" :rows="2"
            placeholder="适用组件列表，JSON数组格式，如: [&quot;mybatis&quot;, &quot;jdbc&quot;]" />
        </el-form-item>
        <el-form-item label="适用危险函数">
          <el-input v-model="form.applicableDangerFunctions" type="textarea" :rows="2"
            placeholder="适用危险函数列表，JSON数组格式，如: [&quot;Runtime.exec&quot;, &quot;ProcessBuilder&quot;]" />
        </el-form-item>
        <el-form-item label="测试步骤">
          <el-input v-model="form.testSteps" type="textarea" :rows="3" placeholder="请输入测试步骤" />
        </el-form-item>
        <el-form-item label="Payload模板">
          <el-input v-model="form.payloadTemplate" type="textarea" :rows="2" placeholder="请输入Payload模板" />
        </el-form-item>
        <el-form-item label="预期结果">
          <el-input v-model="form.expectedResult" type="textarea" :rows="2" placeholder="请输入预期结果" />
        </el-form-item>
        <el-form-item label="参考资料">
          <el-input v-model="form.references" type="textarea" :rows="2" placeholder="请输入参考资料" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm" :loading="submitting">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import testCaseApi from '@/api/testCase'

const loading = ref(false)
const testCases = ref([])

const dialogVisible = ref(false)
const isEdit = ref(false)
const submitting = ref(false)
const formRef = ref(null)

const form = reactive({
  id: null,
  caseName: '',
  vulnerabilityType: '',
  riskLevel: 'HIGH',
  detectionMethod: 'MANUAL',
  applicableComponents: '',
  applicableDangerFunctions: '',
  testSteps: '',
  payloadTemplate: '',
  expectedResult: '',
  references: ''
})

const rules = {
  caseName: [{ required: true, message: '请输入用例名称', trigger: 'blur' }],
  vulnerabilityType: [{ required: true, message: '请选择漏洞类型', trigger: 'change' }],
  riskLevel: [{ required: true, message: '请选择风险等级', trigger: 'change' }]
}

const loadTestCases = async () => {
  loading.value = true
  try {
    testCases.value = await testCaseApi.getList()
  } catch (e) {
    console.error('Failed to load test cases:', e)
  } finally {
    loading.value = false
  }
}

const showCreateDialog = () => {
  isEdit.value = false
  Object.assign(form, {
    id: null,
    caseName: '',
    vulnerabilityType: '',
    riskLevel: 'HIGH',
    detectionMethod: 'MANUAL',
    applicableComponents: '',
    applicableDangerFunctions: '',
    testSteps: '',
    payloadTemplate: '',
    expectedResult: '',
    references: ''
  })
  dialogVisible.value = true
}

const showEditDialog = (row) => {
  isEdit.value = true
  Object.assign(form, {
    id: row.id,
    caseName: row.caseName,
    vulnerabilityType: row.vulnerabilityType,
    riskLevel: row.riskLevel,
    detectionMethod: row.detectionMethod,
    applicableComponents: row.applicableComponents || '',
    applicableDangerFunctions: row.applicableDangerFunctions || '',
    testSteps: row.testSteps || '',
    payloadTemplate: row.payloadTemplate || '',
    expectedResult: row.expectedResult || '',
    references: row.references || ''
  })
  dialogVisible.value = true
}

const submitForm = async () => {
  await formRef.value.validate()
  submitting.value = true
  try {
    if (isEdit.value) {
      await testCaseApi.update(form.id, form)
      ElMessage.success('更新成功')
    } else {
      await testCaseApi.create(form)
      ElMessage.success('创建成功')
    }
    dialogVisible.value = false
    loadTestCases()
  } catch (e) {
    console.error('Failed to submit:', e)
  } finally {
    submitting.value = false
  }
}

const handleDelete = async (row) => {
  await ElMessageBox.confirm(`确定删除测试用例 "${row.caseName}" 吗？`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
  try {
    await testCaseApi.delete(row.id)
    ElMessage.success('删除成功')
    loadTestCases()
  } catch (e) {
    console.error('Failed to delete:', e)
  }
}

const getRiskTagType = (level) => {
  const types = { HIGH: 'danger', MEDIUM: 'warning', LOW: 'info' }
  return types[level] || 'info'
}

const formatDate = (dateStr) => {
  if (!dateStr) return '-'
  return new Date(dateStr).toLocaleString('zh-CN')
}

onMounted(() => {
  loadTestCases()
})
</script>

<style lang="scss" scoped>
.test-case-manage {
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}
</style>

<template>
  <div class="project-list">
    <el-card shadow="never">
      <template #header>
        <div class="card-header">
          <span>项目列表</span>
          <el-button type="primary" @click="showCreateDialog">
            <el-icon><Plus /></el-icon>
            新建项目
          </el-button>
        </div>
      </template>

      <el-form :inline="true" :model="searchForm" class="search-form">
        <el-form-item label="项目名称">
          <el-input v-model="searchForm.name" placeholder="请输入项目名称" clearable />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="loadProjects">查询</el-button>
          <el-button @click="resetSearch">重置</el-button>
        </el-form-item>
      </el-form>

      <el-table :data="filteredProjects" v-loading="loading" style="width: 100%">
        <el-table-column prop="projectName" label="项目名称" min-width="150" />
        <el-table-column prop="productName" label="产品名称" min-width="150" />
        <el-table-column prop="description" label="描述" show-overflow-tooltip />
        <el-table-column prop="createdBy" label="创建人" width="120" />
        <el-table-column prop="createdAt" label="创建时间" width="180">
          <template #default="{ row }">
            {{ formatDate(row.createdAt) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link @click="goToDetail(row.id)">详情</el-button>
            <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        style="margin-top: 20px; justify-content: flex-end"
      />
    </el-card>

    <!-- Create Dialog -->
    <el-dialog v-model="dialogVisible" title="新建项目" width="500px">
      <el-form :model="projectForm" :rules="rules" ref="formRef" label-width="80px">
        <el-form-item label="项目名称" prop="projectName">
          <el-input v-model="projectForm.projectName" placeholder="请输入项目名称" />
        </el-form-item>
        <el-form-item label="产品名称" prop="productName">
          <el-input v-model="projectForm.productName" placeholder="请输入产品名称" />
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input
            v-model="projectForm.description"
            type="textarea"
            :rows="3"
            placeholder="请输入项目描述"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit" :loading="submitting">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Service, type ProjectResponse, type CreateProjectRequest } from '@/api/client'
import StatusTag from '@/components/common/StatusTag.vue'
import { formatDate } from '@/utils/format'

const router = useRouter()

const loading = ref(false)
const projects = ref<ProjectResponse[]>([])
const currentPage = ref(1)
const pageSize = ref(10)

const searchForm = reactive({
  name: ''
})

const dialogVisible = ref(false)
const submitting = ref(false)
const formRef = ref()

const projectForm = reactive<CreateProjectRequest>({
  projectName: '',
  productName: '',
  description: '',
  createdBy: ''
})

const rules = {
  projectName: [{ required: true, message: '请输入项目名称', trigger: 'blur' }]
}

// 前端过滤（后端暂不支持搜索）
const filteredProjects = computed(() => {
  let result = projects.value
  if (searchForm.name) {
    result = result.filter(p =>
      p.projectName?.toLowerCase().includes(searchForm.name.toLowerCase())
    )
  }
  return result
})

const total = computed(() => filteredProjects.value.length)

const loadProjects = async () => {
  loading.value = true
  try {
    projects.value = await Service.getAllProjects()
  } catch (e) {
    console.error('Failed to load projects:', e)
    ElMessage.error('加载项目列表失败')
  } finally {
    loading.value = false
  }
}

const resetSearch = () => {
  searchForm.name = ''
  currentPage.value = 1
}

const goToDetail = (id: number) => {
  router.push(`/projects/${id}`)
}

const showCreateDialog = () => {
  projectForm.projectName = ''
  projectForm.productName = ''
  projectForm.description = ''
  projectForm.createdBy = ''
  dialogVisible.value = true
}

const handleSubmit = async () => {
  await formRef.value?.validate()
  submitting.value = true
  try {
    await Service.createProject({
      projectName: projectForm.projectName,
      productName: projectForm.productName || undefined,
      description: projectForm.description || undefined,
      createdBy: projectForm.createdBy || undefined
    })
    ElMessage.success('创建成功')
    dialogVisible.value = false
    loadProjects()
  } catch (e) {
    console.error('Failed to create:', e)
    ElMessage.error('创建失败')
  } finally {
    submitting.value = false
  }
}

const handleDelete = async (row: ProjectResponse) => {
  await ElMessageBox.confirm(`确定删除项目 "${row.projectName}" 吗？`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
  try {
    await Service.deleteProject(row.id!)
    ElMessage.success('删除成功')
    loadProjects()
  } catch (e) {
    console.error('Failed to delete:', e)
    ElMessage.error('删除失败')
  }
}

onMounted(() => {
  loadProjects()
})
</script>

<style lang="scss" scoped>
.project-list {
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .search-form {
    margin-bottom: 20px;
  }
}
</style>

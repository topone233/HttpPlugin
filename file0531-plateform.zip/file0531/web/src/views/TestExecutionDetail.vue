<template>
  <div class="execution-detail">
    <!-- 执行基本信息卡片 -->
    <el-card shadow="never">
      <template #header>
        <div class="card-header">
          <span>执行详情</span>
          <div>
            <el-button @click="goBack">返回</el-button>
            <el-button
              type="primary"
              @click="submitResult"
              v-if="execution.executionStatus === 'RUNNING'"
              :loading="submitting"
            >
              提交结果
            </el-button>
          </div>
        </div>
      </template>

      <el-descriptions :column="2" border>
        <el-descriptions-item label="执行名称">{{ execution.executionName }}</el-descriptions-item>
        <el-descriptions-item label="漏洞类型">
          <el-tag size="small">{{ execution.vulnerabilityType || '-' }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="执行状态">
          <StatusTag type="execution" :status="execution.executionStatus || 'PENDING'" />
        </el-descriptions-item>
        <el-descriptions-item label="测试结果">
          <el-tag v-if="execution.testResult" :type="getResultTagType(execution.testResult)">
            {{ execution.testResult }}
          </el-tag>
          <span v-else>-</span>
        </el-descriptions-item>
        <el-descriptions-item label="开始时间">{{ formatDate(execution.startTime) }}</el-descriptions-item>
        <el-descriptions-item label="结束时间">{{ formatDate(execution.endTime) }}</el-descriptions-item>
        <el-descriptions-item label="执行耗时">{{ formatDuration(execution.durationMs) }}</el-descriptions-item>
        <el-descriptions-item label="执行人">{{ execution.executor || '-' }}</el-descriptions-item>
      </el-descriptions>
    </el-card>

    <!-- 测试结果提交表单（仅RUNNING状态显示） -->
    <el-card shadow="never" style="margin-top: 20px" v-if="execution.executionStatus === 'RUNNING'">
      <template #header>提交测试结果</template>
      <el-form :model="resultForm" :rules="resultRules" ref="resultFormRef" label-width="100px">
        <el-form-item label="测试结果" prop="testResult">
          <el-select v-model="resultForm.testResult" placeholder="请选择测试结果">
            <el-option label="通过" value="PASS" />
            <el-option label="失败" value="FAIL" />
            <el-option label="跳过" value="SKIP" />
            <el-option label="错误" value="ERROR" />
          </el-select>
        </el-form-item>

        <el-form-item label="严重程度" prop="severity">
          <el-select v-model="resultForm.severity" placeholder="请选择严重程度">
            <el-option label="高" value="HIGH" />
            <el-option label="中" value="MEDIUM" />
            <el-option label="低" value="LOW" />
          </el-select>
        </el-form-item>

        <el-form-item label="可复现">
          <el-switch v-model="resultForm.reproducible" />
        </el-form-item>

        <el-form-item label="实际结果">
          <el-input v-model="resultForm.actualResult" type="textarea" :rows="3"
            placeholder="请输入实际测试结果" />
        </el-form-item>

        <el-form-item label="证据文件">
          <EvidenceUpload
            v-model="resultForm.evidenceFiles"
            :execution-id="executionId"
          />
        </el-form-item>

        <el-form-item label="日志输出">
          <el-input v-model="resultForm.logOutput" type="textarea" :rows="5"
            placeholder="请输入测试日志" />
        </el-form-item>

        <el-form-item label="错误信息">
          <el-input v-model="resultForm.errorMessage" type="textarea" :rows="3"
            placeholder="如有错误请填写" />
        </el-form-item>

        <el-form-item label="备注">
          <el-input v-model="resultForm.notes" type="textarea" :rows="2" />
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 执行详情记录展示（COMPLETED状态显示） -->
    <el-card shadow="never" style="margin-top: 20px" v-if="execution.executionStatus === 'COMPLETED'">
      <template #header>执行详情记录</template>
      <el-descriptions :column="1" border>
        <el-descriptions-item label="测试数据">{{ execution.testData || '-' }}</el-descriptions-item>
        <el-descriptions-item label="预期结果">{{ execution.expectedResult || '-' }}</el-descriptions-item>
        <el-descriptions-item label="实际结果">{{ execution.actualResult || '-' }}</el-descriptions-item>
        <el-descriptions-item label="日志输出">
          <el-input type="textarea" :rows="10" :model-value="execution.logOutput" readonly />
        </el-descriptions-item>
        <el-descriptions-item label="错误信息">
          <el-input v-if="execution.errorMessage" type="textarea" :rows="5"
            :model-value="execution.errorMessage" readonly />
          <span v-else>-</span>
        </el-descriptions-item>
        <el-descriptions-item label="证据文件">
          <el-input v-if="execution.evidenceFiles" type="textarea" :rows="3"
            :model-value="execution.evidenceFiles" readonly />
          <span v-else>-</span>
        </el-descriptions-item>
      </el-descriptions>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import testExecutionApi from '@/api/testExecution'
import StatusTag from '@/components/common/StatusTag.vue'
import EvidenceUpload from '@/components/business/EvidenceUpload.vue'
import { formatDate, formatDuration } from '@/utils/format'

const route = useRoute()
const router = useRouter()

const executionId = route.params.id
const execution = ref({})
const submitting = ref(false)
const resultFormRef = ref(null)

const resultForm = reactive({
  testResult: '',
  severity: '',
  reproducible: false,
  actualResult: '',
  evidenceFiles: '',
  logOutput: '',
  errorMessage: '',
  notes: ''
})

const resultRules = {
  testResult: [{ required: true, message: '请选择测试结果', trigger: 'change' }],
  severity: [{ required: true, message: '请选择严重程度', trigger: 'change' }]
}

const goBack = () => {
  router.back()
}

const loadExecution = async () => {
  try {
    execution.value = await testExecutionApi.getById(executionId)
  } catch (e) {
    console.error('Failed to load execution:', e)
    ElMessage.error('加载执行详情失败')
  }
}

const submitResult = async () => {
  await resultFormRef.value.validate()
  submitting.value = true
  try {
    await testExecutionApi.complete(executionId, resultForm)
    ElMessage.success('测试结果已提交')
    router.back()
  } catch (e) {
    console.error('Submit failed:', e)
    ElMessage.error('提交失败')
  } finally {
    submitting.value = false
  }
}

const getResultTagType = (result) => {
  const types = {
    PASS: 'success',
    FAIL: 'danger',
    SKIP: 'warning',
    ERROR: 'danger'
  }
  return types[result] || 'info'
}

onMounted(() => {
  loadExecution()
})
</script>

<style lang="scss" scoped>
.execution-detail {
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}
</style>
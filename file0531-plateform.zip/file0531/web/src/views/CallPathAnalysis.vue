<template>
  <div class="call-path-analysis">
    <!-- 头部：Artifact选择 -->
    <el-card shadow="never">
      <div class="header">
        <h2>调用链路分析</h2>
        <el-select
          v-model="artifactId"
          filterable
          placeholder="选择制品"
          style="width: 300px;"
          clearable
          :loading="loading"
          @change="onArtifactChange"
        >
          <el-option
            v-for="item in artifacts"
            :key="item.id"
            :label="`${item.id} - ${item.artifactName}`"
            :value="String(item.id)"
          />
        </el-select>
      </div>
    </el-card>

    <!-- 查询表单 -->
    <el-card shadow="never" style="margin-top: 20px;" v-if="artifactId">
      <el-form :model="queryForm" label-width="120px">
        <!-- 起点输入 -->
        <el-form-item label="起点方法" required>
          <el-autocomplete
            v-model="queryForm.startMethod"
            :fetch-suggestions="searchStartMethods"
            placeholder="输入类名或方法名搜索"
            style="width: 100%;"
            @select="onStartMethodSelect"
            :disabled="!artifactId"
          >
            <template #default="{ item }">
              <div class="method-suggestion">
                <span class="method-name">{{ item.displayName }}</span>
                <span class="method-class">{{ item.className }}</span>
              </div>
            </template>
          </el-autocomplete>
        </el-form-item>

        <!-- 终点输入 -->
        <el-form-item label="终点方法" required>
          <el-autocomplete
            v-model="queryForm.endMethod"
            :fetch-suggestions="searchEndMethods"
            placeholder="输入类名或方法名搜索"
            style="width: 100%;"
            @select="onEndMethodSelect"
            :disabled="!artifactId"
          >
            <template #default="{ item }">
              <div class="method-suggestion">
                <span class="method-name">{{ item.displayName }}</span>
                <span class="method-class">{{ item.className }}</span>
              </div>
            </template>
          </el-autocomplete>
        </el-form-item>

        <!-- 高级选项 -->
        <el-collapse>
          <el-collapse-item title="高级选项" name="advanced">
            <el-form-item label="查找所有路径">
              <el-switch v-model="queryForm.findAllPaths" />
              <span class="form-tip">开启后将查找所有可能的调用路径</span>
            </el-form-item>

            <el-form-item
              label="最大路径数"
              v-if="queryForm.findAllPaths"
            >
              <el-input-number
                v-model="queryForm.maxPaths"
                :min="1"
                :max="100"
              />
              <span class="form-tip">限制返回的路径数量，避免结果过多</span>
            </el-form-item>

            <el-form-item label="最大深度">
              <el-input-number
                v-model="queryForm.maxDepth"
                :min="1"
                :max="50"
              />
              <span class="form-tip">调用链的最大深度</span>
            </el-form-item>
          </el-collapse-item>
        </el-collapse>

        <!-- 查询按钮 -->
        <el-form-item>
          <el-button
            type="primary"
            @click="queryPath"
            :loading="querying"
            :disabled="!queryForm.startClass || !queryForm.endClass"
          >
            {{ querying ? '查询中...' : '查询路径' }}
          </el-button>
          <el-button @click="resetForm">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <!-- 结果区域 -->
    <el-card shadow="never" style="margin-top: 20px;" v-if="result">
      <template #header>
        <div class="card-header">
          <span>查询结果</span>
          <div>
            <el-tag type="success">找到 {{ result.totalPaths }} 条路径</el-tag>
            <el-tag
              v-if="result.truncated"
              type="warning"
              style="margin-left: 10px;"
            >
              结果已截断，请增加最大路径数
            </el-tag>
          </div>
        </div>
      </template>

      <!-- 路径可视化 -->
      <div v-if="result.paths && result.paths.length > 0">
        <CallPathGraph
          :start-data="{
            startClass: result.startClass,
            startMethod: result.startMethod
          }"
          :end-data="{
            endClass: result.endClass,
            endMethod: result.endMethod
          }"
          :paths="result.paths"
          :loading="querying"
        />
      </div>

      <!-- 无结果 -->
      <el-empty
        v-else
        description="未找到调用路径"
        :image-size="150"
      >
        <template #description>
          <p>未找到从 <b>{{ result.startClass }}#{{ result.startMethod }}</b> 到 <b>{{ result.endClass }}#{{ result.endMethod }}</b> 的调用路径</p>
          <p style="color: #909399; font-size: 13px;">
            可能原因：<br>
            1. 两个方法之间不存在调用关系<br>
            2. 调用深度超过了最大深度限制<br>
            3. 方法名称输入错误
          </p>
        </template>
      </el-empty>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import callPathApi from '@/api/callPath'
import artifactApi from '@/api/artifact'
import CallPathGraph from '@/components/callpath/CallPathGraph.vue'

const artifactId = ref('')
const artifacts = ref([])
const loading = ref(false)
const querying = ref(false)
const result = ref(null)

const queryForm = ref({
  startMethod: '',
  startClass: '',
  startMethodName: '',
  endMethod: '',
  endClass: '',
  endMethodName: '',
  findAllPaths: false,
  maxPaths: 10,
  maxDepth: 20
})

// 加载制品列表
async function loadArtifacts() {
  loading.value = true
  try {
    const res = await artifactApi.getAll()
    artifacts.value = res || []
  } catch (error) {
    console.error('加载制品列表失败', error)
  } finally {
    loading.value = false
  }
}

// 搜索起点方法（自动补全）
async function searchStartMethods(keyword, cb) {
  if (!keyword || !artifactId.value) {
    cb([])
    return
  }

  try {
    console.log('搜索起点方法:', keyword, 'artifactId:', artifactId.value)
    const res = await callPathApi.searchMethods(
      parseInt(artifactId.value),
      keyword,
      20
    )
    console.log('搜索结果:', res)
    // axios拦截器已经提取了result.data，所以res就是List<MethodSuggestion>
    // Element Plus Autocomplete 要求每个item必须有value字段
    const suggestions = (Array.isArray(res) ? res : []).map(item => ({
      ...item,
      value: item.displayName // 添加value字段用于显示
    }))
    cb(suggestions)
  } catch (error) {
    console.error('搜索方法失败', error)
    cb([])
  }
}

// 搜索终点方法（自动补全）
async function searchEndMethods(keyword, cb) {
  if (!keyword || !artifactId.value) {
    cb([])
    return
  }

  try {
    console.log('搜索终点方法:', keyword, 'artifactId:', artifactId.value)
    const res = await callPathApi.searchMethods(
      parseInt(artifactId.value),
      keyword,
      20
    )
    console.log('搜索结果:', res)
    // axios拦截器已经提取了result.data，所以res就是List<MethodSuggestion>
    // Element Plus Autocomplete 要求每个item必须有value字段
    const suggestions = (Array.isArray(res) ? res : []).map(item => ({
      ...item,
      value: item.displayName // 添加value字段用于显示
    }))
    cb(suggestions)
  } catch (error) {
    console.error('搜索方法失败', error)
    cb([])
  }
}

// 选择起点方法
function onStartMethodSelect(item) {
  queryForm.value.startClass = item.className
  queryForm.value.startMethodName = item.methodName
}

// 选择终点方法
function onEndMethodSelect(item) {
  queryForm.value.endClass = item.className
  queryForm.value.endMethodName = item.methodName
}

// Artifact改变时重置表单
function onArtifactChange() {
  resetForm()
}

// 查询路径
async function queryPath() {
  if (!queryForm.value.startClass || !queryForm.value.endClass) {
    ElMessage.warning('请选择起点和终点方法')
    return
  }

  querying.value = true
  result.value = null

  try {
    const params = {
      artifactId: parseInt(artifactId.value),
      startClass: queryForm.value.startClass,
      startMethod: queryForm.value.startMethodName,
      endClass: queryForm.value.endClass,
      endMethod: queryForm.value.endMethodName,
      findAllPaths: queryForm.value.findAllPaths,
      maxPaths: queryForm.value.maxPaths,
      maxDepth: queryForm.value.maxDepth
    }

    const res = await callPathApi.queryPath(params)
    result.value = res.data || res

    if (result.value.totalPaths > 0) {
      ElMessage.success(`找到 ${result.value.totalPaths} 条调用路径`)
    } else {
      ElMessage.info('未找到调用路径')
    }
  } catch (error) {
    console.error('查询调用路径失败', error)
    ElMessage.error(error.response?.data?.message || '查询失败')
  } finally {
    querying.value = false
  }
}

// 重置表单
function resetForm() {
  queryForm.value = {
    startMethod: '',
    startClass: '',
    startMethodName: '',
    endMethod: '',
    endClass: '',
    endMethodName: '',
    findAllPaths: false,
    maxPaths: 10,
    maxDepth: 20
  }
  result.value = null
}

onMounted(() => {
  loadArtifacts()
})
</script>

<style scoped>
.call-path-analysis {
  padding: 20px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header h2 {
  margin: 0;
  font-size: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.method-suggestion {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.method-name {
  font-weight: 500;
}

.method-class {
  color: #909399;
  font-size: 12px;
  font-family: monospace;
}

.form-tip {
  color: #909399;
  font-size: 12px;
  margin-left: 10px;
}
</style>
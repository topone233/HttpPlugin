<template>
  <div class="diff-analysis">
    <!-- 步骤1: 选择制品 -->
    <el-card shadow="never" v-if="currentStep === 1">
      <template #header>
        <div class="card-header">
          <span>创建差异分析任务</span>
        </div>
      </template>

      <el-form :model="form" label-width="120px">
        <el-form-item label="项目">
          <el-select v-model="form.projectId" placeholder="请选择项目" @change="onProjectChange">
            <el-option
              v-for="project in projects"
              :key="project.id"
              :label="project.name"
              :value="project.id"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="基线版本">
          <el-radio-group v-model="baselineType" @change="onBaselineTypeChange">
            <el-radio value="recommended">推荐基线</el-radio>
            <el-radio value="history">历史制品</el-radio>
            <el-radio value="upload">手动上传</el-radio>
          </el-radio-group>
        </el-form-item>

        <!-- 推荐基线 -->
        <el-form-item label="推荐制品" v-if="baselineType === 'recommended'">
          <el-card shadow="never" class="baseline-card" v-if="recommendedBaseline">
            <div class="baseline-info">
              <span class="name">{{ recommendedBaseline.artifactName }}</span>
              <span class="time">测试时间: {{ formatDate(recommendedBaseline.testTime) }}</span>
              <span class="task">任务: {{ recommendedBaseline.taskName }}</span>
            </div>
            <el-button type="primary" size="small" @click="selectBaseline(recommendedBaseline)">
              选择
            </el-button>
          </el-card>
          <el-alert
            v-else
            title="暂无推荐基线"
            type="info"
            description="该项目没有历史制品，请使用历史制品或手动上传"
            :closable="false"
            show-icon
          />
        </el-form-item>

        <!-- 历史制品 -->
        <el-form-item label="历史制品" v-if="baselineType === 'history'">
          <el-select v-model="form.baselineArtifactId" placeholder="请选择历史制品">
            <el-option
              v-for="item in historyArtifacts"
              :key="item.artifactId"
              :label="item.artifactName"
              :value="item.artifactId"
            >
              <span>{{ item.artifactName }}</span>
              <span style="color: #999; margin-left: 10px;">{{ formatDate(item.testTime) }}</span>
            </el-option>
          </el-select>
          <el-alert
            v-if="historyArtifacts.length === 0"
            title="暂无历史制品"
            type="info"
            :closable="false"
            show-icon
            style="margin-top: 10px;"
          />
        </el-form-item>

        <!-- 手动上传基线 -->
        <el-form-item label="上传基线" v-if="baselineType === 'upload'">
          <el-upload
            :auto-upload="false"
            :on-change="onBaselineFileChange"
            :show-file-list="false"
            accept=".jar,.war"
          >
            <el-button type="primary">选择文件</el-button>
            <template #tip>
              <div class="el-upload__tip">支持 .jar, .war 文件</div>
            </template>
          </el-upload>
          <span v-if="baselineFile" class="file-name">{{ baselineFile.name }}</span>
        </el-form-item>

        <el-form-item label="目标版本">
          <el-upload
            :auto-upload="false"
            :on-change="onTargetFileChange"
            :show-file-list="false"
            accept=".jar,.war"
          >
            <el-button type="success">选择文件</el-button>
            <template #tip>
              <div class="el-upload__tip">上传新版本制品包</div>
            </template>
          </el-upload>
          <span v-if="targetFile" class="file-name">{{ targetFile.name }}</span>
        </el-form-item>
      </el-form>

      <div class="actions">
        <el-button type="primary" @click="startAnalysis" :loading="creating" :disabled="!canStart">
          开始分析
        </el-button>
      </div>
    </el-card>

    <!-- 步骤2: 分析进度 -->
    <el-card shadow="never" v-if="currentStep === 2">
      <template #header>
        <div class="card-header">
          <span>分析进度</span>
        </div>
      </template>

      <div class="progress-container">
        <el-progress
          :percentage="progress.progress"
          :status="progressStatus"
          :stroke-width="20"
        />
        <p class="step-text">{{ progress.currentStep }}</p>

        <el-steps :active="progressSteps" align-center>
          <el-step title="基线分析" />
          <el-step title="目标分析" />
          <el-step title="文件对比" />
          <el-step title="调用图构建" />
          <el-step title="API追溯" />
          <el-step title="完成" />
        </el-steps>
      </div>
    </el-card>

    <!-- 步骤3: 分析结果 -->
    <el-card shadow="never" v-if="currentStep === 3">
      <template #header>
        <div class="card-header">
          <span>差异分析结果</span>
          <el-button type="primary" @click="exportReport">导出报告</el-button>
        </div>
      </template>

      <!-- 概览统计 -->
      <div class="summary-cards">
        <el-row :gutter="20">
          <el-col :span="6">
            <el-statistic title="新增文件" :value="result.summary?.addedFiles || 0">
              <template #suffix>
                <el-icon color="#67C23A"><DocumentAdd /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="6">
            <el-statistic title="修改文件" :value="result.summary?.modifiedFiles || 0">
              <template #suffix>
                <el-icon color="#E6A23C"><Edit /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="6">
            <el-statistic title="删除文件" :value="result.summary?.deletedFiles || 0">
              <template #suffix>
                <el-icon color="#F56C6C"><Delete /></el-icon>
              </template>
            </el-statistic>
          </el-col>
          <el-col :span="6">
            <el-statistic title="变更API" :value="totalApiChanges">
              <template #suffix>
                <el-icon color="#409EFF"><Connection /></el-icon>
              </template>
            </el-statistic>
          </el-col>
        </el-row>
      </div>

      <el-divider />

      <!-- API变更统计 -->
      <div class="api-summary">
        <el-row :gutter="20">
          <el-col :span="6">
            <div class="stat-box high">
              <div class="label">高危API</div>
              <div class="value">{{ result.summary?.highRiskApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="stat-box medium">
              <div class="label">中危API</div>
              <div class="value">{{ result.summary?.mediumRiskApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="stat-box low">
              <div class="label">低危API</div>
              <div class="value">{{ result.summary?.lowRiskApis || 0 }}</div>
            </div>
          </el-col>
          <el-col :span="6">
            <div class="stat-box">
              <div class="label">新增API</div>
              <div class="value">{{ result.summary?.newApis || 0 }}</div>
            </div>
          </el-col>
        </el-row>
      </div>

      <el-divider />

      <!-- API变更列表 -->
      <el-tabs v-model="activeTab">
        <el-tab-pane label="变更影响图谱" name="graph">
          <ChangeImpactGraph
            v-if="taskId"
            :diff-task-id="taskId"
            @node-click="handleGraphNodeClick"
          />
        </el-tab-pane>
        <el-tab-pane label="智能推荐" name="recommendation">
          <RecommendationPanel
            v-if="taskId"
            :diff-task-id="taskId"
            @view-graph="handleViewGraph"
          />
        </el-tab-pane>
        <el-tab-pane label="全部API" name="all" />
        <el-tab-pane label="新增" name="NEW_API" />
        <el-tab-pane label="修改" name="MODIFIED_API" />
        <el-tab-pane label="受影响" name="AFFECTED_API" />
        <el-tab-pane label="删除" name="DELETED_API" />
      </el-tabs>

      <!-- API变更表格（非智能分析标签时显示） -->
      <el-table v-if="!['graph', 'recommendation'].includes(activeTab)" :data="filteredApiDiffs" style="width: 100%">
        <el-table-column prop="httpMethod" label="方法" width="80">
          <template #default="{ row }">
            <el-tag :type="getMethodTagType(row.httpMethod)" size="small">
              {{ row.httpMethod }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="apiUrl" label="API路径" min-width="200" show-overflow-tooltip />
        <el-table-column prop="changeType" label="变更类型" width="120">
          <template #default="{ row }">
            <el-tag :type="getChangeTypeTag(row.changeType)" size="small">
              {{ getChangeTypeLabel(row.changeType) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="changeReason" label="变更原因" min-width="200" show-overflow-tooltip />
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button type="primary" link @click="showApiDetail(row)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-divider />

      <!-- 文件差异列表 -->
      <h3>文件差异</h3>
      <el-table :data="result.fileDiffs" style="width: 100%">
        <el-table-column prop="filePath" label="文件路径" min-width="300" show-overflow-tooltip />
        <el-table-column prop="diffType" label="变更类型" width="100">
          <template #default="{ row }">
            <el-tag :type="getDiffTypeTag(row.diffType)" size="small">
              {{ row.diffType }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="行数变化" width="150">
          <template #default="{ row }">
            <span v-if="row.addedLines > 0" class="added">+{{ row.addedLines }}</span>
            <span v-if="row.deletedLines > 0" class="deleted">-{{ row.deletedLines }}</span>
          </template>
        </el-table-column>
        <el-table-column label="方法变化" width="180">
          <template #default="{ row }">
            <span v-if="row.methodsAdded > 0">新增: {{ row.methodsAdded }}</span>
            <span v-if="row.methodsModified > 0"> | 修改: {{ row.methodsModified }}</span>
            <span v-if="row.methodsDeleted > 0"> | 删除: {{ row.methodsDeleted }}</span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- API详情弹窗 -->
    <el-dialog v-model="apiDetailVisible" title="API变更详情" width="600px">
      <el-descriptions :column="1" border v-if="selectedApi">
        <el-descriptions-item label="API路径">{{ selectedApi.apiUrl }}</el-descriptions-item>
        <el-descriptions-item label="HTTP方法">{{ selectedApi.httpMethod }}</el-descriptions-item>
        <el-descriptions-item label="控制器">{{ selectedApi.controllerClass }}</el-descriptions-item>
        <el-descriptions-item label="方法名">{{ selectedApi.methodName }}</el-descriptions-item>
        <el-descriptions-item label="变更类型">{{ getChangeTypeLabel(selectedApi.changeType) }}</el-descriptions-item>
        <el-descriptions-item label="变更原因">{{ selectedApi.changeReason }}</el-descriptions-item>
        <el-descriptions-item label="调用链" v-if="selectedApi.callChain?.length">
          <div class="call-chain">
            <template v-for="(node, index) in selectedApi.callChain" :key="index">
              <span class="node">{{ node.className }}.{{ node.methodName }}</span>
              <span v-if="index < selectedApi.callChain.length - 1" class="arrow">→</span>
            </template>
          </div>
        </el-descriptions-item>
      </el-descriptions>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import { DocumentAdd, Edit, Delete, Connection } from '@element-plus/icons-vue'
import diffAnalysisApi from '@/api/diffAnalysis'
import projectApi from '@/api/project'
import artifactApi from '@/api/artifact'
import { formatDate } from '@/utils/format'
import ChangeImpactGraph from '@/components/diff/ChangeImpactGraph.vue'
import RecommendationPanel from '@/components/diff/RecommendationPanel.vue'

// 步骤控制
const currentStep = ref(1)
const creating = ref(false)

// 项目列表
const projects = ref([])
const form = reactive({
  projectId: null,
  baselineArtifactId: null,
  targetArtifactId: null
})

// 基线选择
const baselineType = ref('recommended')
const recommendedBaseline = ref(null)
const historyArtifacts = ref([])
const baselineFile = ref(null)
const targetFile = ref(null)

// 进度
const progress = reactive({
  progress: 0,
  status: '',
  currentStep: ''
})
let progressTimer = null

// 结果
const taskId = ref(null)
const result = ref({
  summary: {},
  fileDiffs: [],
  apiDiffs: []
})
const activeTab = ref('all')
const apiDetailVisible = ref(false)
const selectedApi = ref(null)

// 计算属性
const canStart = computed(() => {
  if (!form.projectId) return false
  if (!targetFile.value) return false
  if (baselineType.value === 'history' && !form.baselineArtifactId) return false
  if (baselineType.value === 'upload' && !baselineFile.value) return false
  if (baselineType.value === 'recommended' && !form.baselineArtifactId) return false
  return true
})

const progressStatus = computed(() => {
  if (progress.status === 'FAILED') return 'exception'
  if (progress.progress === 100) return 'success'
  return ''
})

const progressSteps = computed(() => {
  if (progress.progress >= 100) return 6
  if (progress.progress >= 85) return 5
  if (progress.progress >= 70) return 4
  if (progress.progress >= 50) return 3
  if (progress.progress >= 30) return 2
  if (progress.progress >= 10) return 1
  return 0
})

const totalApiChanges = computed(() => {
  const s = result.value.summary
  return (s?.newApis || 0) + (s?.modifiedApis || 0) + (s?.affectedApis || 0) + (s?.deletedApis || 0)
})

const filteredApiDiffs = computed(() => {
  if (activeTab.value === 'all') {
    return result.value.apiDiffs
  }
  return result.value.apiDiffs.filter(api => api.changeType === activeTab.value)
})

// 方法
const loadProjects = async () => {
  try {
    const res = await projectApi.getList()
    projects.value = res || []
  } catch (e) {
    console.error('加载项目失败', e)
    ElMessage.error('加载项目列表失败')
  }
}

const onProjectChange = async (projectId) => {
  if (baselineType.value === 'recommended' || baselineType.value === 'history') {
    await loadBaselineRecommendation(projectId)
  }
}

const onBaselineTypeChange = async () => {
  if (form.projectId) {
    await loadBaselineRecommendation(form.projectId)
  }
}

const loadBaselineRecommendation = async (projectId) => {
  try {
    const res = await diffAnalysisApi.getBaselineRecommendation(projectId)
    console.log('基线推荐API返回:', res)
    console.log('recommended:', res?.recommended)
    console.log('history:', res?.history)

    recommendedBaseline.value = res?.recommended
    historyArtifacts.value = res?.history || []

    console.log('historyArtifacts.value:', historyArtifacts.value)

    if (baselineType.value === 'recommended' && recommendedBaseline.value) {
      form.baselineArtifactId = recommendedBaseline.value.artifactId
    }
  } catch (e) {
    console.error('加载基线推荐失败', e)
    ElMessage.error('加载基线推荐失败')
  }
}

const selectBaseline = (item) => {
  form.baselineArtifactId = item.artifactId
}

const onBaselineFileChange = (file) => {
  baselineFile.value = file.raw
}

const onTargetFileChange = (file) => {
  targetFile.value = file.raw
}

const startAnalysis = async () => {
  creating.value = true
  try {
    let baselineArtifactId = form.baselineArtifactId
    let targetArtifactId = form.targetArtifactId

    // 如果是手动上传基线，先上传文件
    if (baselineType.value === 'upload' && baselineFile.value) {
      ElMessage.info('正在上传基线文件...')
      const uploadRes = await artifactApi.upload(null, baselineFile.value, 'JAR')
      baselineArtifactId = uploadRes.id
      ElMessage.success('基线文件上传成功')
    }

    // 上传目标文件
    if (targetFile.value) {
      ElMessage.info('正在上传目标文件...')
      const uploadRes = await artifactApi.upload(null, targetFile.value, 'JAR')
      targetArtifactId = uploadRes.id
      ElMessage.success('目标文件上传成功')
    }

    // 创建差异分析任务
    const res = await diffAnalysisApi.createDiffAnalysis({
      projectId: form.projectId,
      baselineArtifactId: baselineArtifactId,
      targetArtifactId: targetArtifactId
    })

    currentStep.value = 2
    startProgressPolling(res)
    ElMessage.success('差异分析任务已创建')
  } catch (e) {
    console.error('创建差异分析失败', e)
    ElMessage.error('创建失败: ' + (e.message || '未知错误'))
  } finally {
    creating.value = false
  }
}

const startProgressPolling = (taskId) => {
  progressTimer = setInterval(async () => {
    try {
      const res = await diffAnalysisApi.getProgress(taskId)
      console.log('进度查询结果:', res)
      progress.progress = res?.progress || 0
      progress.status = res?.status || ''
      progress.currentStep = res?.currentStep || ''

      if (progress.status === 'COMPLETED' || progress.status === 'FAILED') {
        stopProgressPolling()

        if (progress.status === 'COMPLETED') {
          console.log('分析完成，跳转到结果页面')
          currentStep.value = 3
          loadResult(taskId)
        }
      }
    } catch (e) {
      console.error('获取进度失败', e)
    }
  }, 2000)
}

const stopProgressPolling = () => {
  if (progressTimer) {
    clearInterval(progressTimer)
    progressTimer = null
  }
}

const loadResult = async (id) => {
  taskId.value = id
  try {
    const res = await diffAnalysisApi.getDiffResult(id)
    console.log('加载差异分析结果:', res)
    result.value = res || {}
    console.log('结果数据:', {
      summary: result.value.summary,
      fileDiffsCount: result.value.fileDiffs?.length,
      apiDiffsCount: result.value.apiDiffs?.length
    })
  } catch (e) {
    console.error('加载结果失败:', e)
    ElMessage.error('加载结果失败: ' + (e.message || '未知错误'))
  }
}

const exportReport = async () => {
  try {
    const res = await diffAnalysisApi.exportReport(result.value.diffTaskId)
    const blob = new Blob([res], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `diff_analysis_${result.value.diffTaskId}.xlsx`
    a.click()
    window.URL.revokeObjectURL(url)
  } catch (e) {
    ElMessage.error('导出失败')
  }
}

const showApiDetail = (api) => {
  selectedApi.value = api
  apiDetailVisible.value = true
}

// 智能分析相关方法
const handleGraphNodeClick = (node) => {
  // 点击图谱节点，可以跳转到对应的API详情
  if (node.nodeType === 'api' && result.value?.apiDiffs) {
    const api = result.value.apiDiffs.find(a => a.id === node.id)
    if (api) {
      showApiDetail(api)
    }
  }
}

const handleViewGraph = (changeId) => {
  // 从推荐面板跳转到图谱
  activeTab.value = 'graph'
  // TODO: 聚焦到特定变更节点
}

// 标签类型转换
const getMethodTagType = (method) => {
  const types = { GET: 'success', POST: 'primary', PUT: 'warning', DELETE: 'danger' }
  return types[method] || 'info'
}

const getChangeTypeTag = (type) => {
  const types = { NEW_API: 'success', MODIFIED_API: 'warning', AFFECTED_API: 'info', DELETED_API: 'danger' }
  return types[type] || ''
}

const getChangeTypeLabel = (type) => {
  const labels = { NEW_API: '新增', MODIFIED_API: '修改', AFFECTED_API: '受影响', DELETED_API: '删除' }
  return labels[type] || type
}

const getDiffTypeTag = (type) => {
  const types = { ADDED: 'success', MODIFIED: 'warning', DELETED: 'danger' }
  return types[type] || ''
}

onMounted(() => {
  loadProjects()
})

onUnmounted(() => {
  stopProgressPolling()
})
</script>

<style scoped>
.diff-analysis {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.baseline-card {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.baseline-info {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.baseline-info .name {
  font-weight: bold;
}

.baseline-info .time,
.baseline-info .task {
  color: #666;
  font-size: 12px;
}

.file-name {
  margin-left: 10px;
  color: #409EFF;
}

.actions {
  margin-top: 20px;
  text-align: center;
}

.progress-container {
  padding: 40px 20px;
  text-align: center;
}

.step-text {
  margin-top: 20px;
  color: #666;
}

.summary-cards {
  padding: 20px 0;
}

.api-summary {
  padding: 10px 0;
}

.stat-box {
  text-align: center;
  padding: 20px;
  border-radius: 8px;
  background: #f5f7fa;
}

.stat-box.high {
  background: #fef0f0;
}

.stat-box.medium {
  background: #fdf6ec;
}

.stat-box.low {
  background: #f0f9eb;
}

.stat-box .label {
  font-size: 14px;
  color: #666;
}

.stat-box .value {
  font-size: 28px;
  font-weight: bold;
  margin-top: 5px;
}

.added {
  color: #67C23A;
  margin-right: 10px;
}

.deleted {
  color: #F56C6C;
}

.call-chain {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 5px;
}

.call-chain .node {
  padding: 2px 8px;
  background: #f0f2f5;
  border-radius: 4px;
  font-size: 12px;
}

.call-chain .arrow {
  color: #409EFF;
}
</style>

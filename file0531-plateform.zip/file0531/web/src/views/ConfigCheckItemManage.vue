<template>
  <div class="config-check-manage">
    <el-card shadow="never">
      <template #header>
        <div class="card-header">
          <span>配置检查项管理</span>
          <el-button type="primary" @click="showCreateDialog">
            <el-icon><Plus /></el-icon>
            新建检查项
          </el-button>
        </div>
      </template>

      <el-table :data="items" v-loading="loading" style="width: 100%">
        <el-table-column prop="itemName" label="检查项名称" min-width="200" />
        <el-table-column prop="category" label="类别" width="120">
          <template #default="{ row }">
            <el-tag size="small">{{ row.category }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="configKeyPattern" label="配置键模式" min-width="150" />
        <el-table-column prop="riskLevel" label="风险等级" width="100">
          <template #default="{ row }">
            <el-tag :type="getRiskTagType(row.riskLevel)" size="small">
              {{ row.riskLevel }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="enabled" label="状态" width="80">
          <template #default="{ row }">
            <el-tag :type="row.enabled ? 'success' : 'info'" size="small">
              {{ row.enabled ? '启用' : '禁用' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button type="primary" link @click="showEditDialog(row)">编辑</el-button>
            <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Create/Edit Dialog -->
    <el-dialog v-model="dialogVisible" :title="isEdit ? '编辑配置检查项' : '新建配置检查项'" width="700px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="检查项名称" prop="itemName">
              <el-input v-model="form.itemName" placeholder="请输入检查项名称" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="类别" prop="category">
              <el-select v-model="form.category" placeholder="请选择类别" style="width: 100%">
                <el-option label="数据库" value="DATABASE" />
                <el-option label="安全配置" value="SECURITY" />
                <el-option label="日志" value="LOGGING" />
                <el-option label="会话" value="SESSION" />
                <el-option label="认证" value="AUTHENTICATION" />
                <el-option label="加密" value="ENCRYPTION" />
                <el-option label="网络" value="NETWORK" />
                <el-option label="其他" value="OTHER" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="风险等级" prop="riskLevel">
              <el-select v-model="form.riskLevel" placeholder="请选择风险等级" style="width: 100%">
                <el-option label="高" value="HIGH" />
                <el-option label="中" value="MEDIUM" />
                <el-option label="低" value="LOW" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="配置键模式" prop="configKeyPattern">
          <el-input v-model="form.configKeyPattern" placeholder="配置键匹配模式，如: spring.datasource.*" />
        </el-form-item>
        <el-form-item label="检查规则">
          <el-input v-model="form.checkRule" type="textarea" :rows="2" placeholder="检查规则描述" />
        </el-form-item>
        <el-form-item label="期望值">
          <el-input v-model="form.expectedValue" placeholder="期望的配置值（支持正则）" />
        </el-form-item>
        <el-form-item label="不安全值">
          <el-input v-model="form.unsafeValues" type="textarea" :rows="2"
            placeholder="不安全值列表，JSON数组格式，如: [&quot;true&quot;, &quot;enable&quot;]" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="form.description" type="textarea" :rows="2" placeholder="检查项描述" />
        </el-form-item>
        <el-form-item label="修复建议">
          <el-input v-model="form.remediation" type="textarea" :rows="2" placeholder="修复建议" />
        </el-form-item>
        <el-form-item label="标准参考">
          <el-input v-model="form.standardReference" placeholder="标准参考，如: OWASP, CIS" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm" :loading="submitting">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import configCheckItemApi from '@/api/configCheckItem'

const loading = ref(false)
const items = ref([])

const dialogVisible = ref(false)
const isEdit = ref(false)
const submitting = ref(false)
const formRef = ref(null)

const form = reactive({
  id: null,
  itemName: '',
  category: '',
  configKeyPattern: '',
  checkRule: '',
  expectedValue: '',
  unsafeValues: '',
  riskLevel: 'MEDIUM',
  description: '',
  remediation: '',
  standardReference: ''
})

const rules = {
  itemName: [{ required: true, message: '请输入检查项名称', trigger: 'blur' }],
  category: [{ required: true, message: '请选择类别', trigger: 'change' }],
  configKeyPattern: [{ required: true, message: '请输入配置键模式', trigger: 'blur' }],
  riskLevel: [{ required: true, message: '请选择风险等级', trigger: 'change' }]
}

const loadItems = async () => {
  loading.value = true
  try {
    items.value = await configCheckItemApi.getList()
  } catch (e) {
    console.error('Failed to load items:', e)
  } finally {
    loading.value = false
  }
}

const showCreateDialog = () => {
  isEdit.value = false
  Object.assign(form, {
    id: null,
    itemName: '',
    category: '',
    configKeyPattern: '',
    checkRule: '',
    expectedValue: '',
    unsafeValues: '',
    riskLevel: 'MEDIUM',
    description: '',
    remediation: '',
    standardReference: ''
  })
  dialogVisible.value = true
}

const showEditDialog = (row) => {
  isEdit.value = true
  Object.assign(form, {
    id: row.id,
    itemName: row.itemName,
    category: row.category,
    configKeyPattern: row.configKeyPattern,
    checkRule: row.checkRule || '',
    expectedValue: row.expectedValue || '',
    unsafeValues: row.unsafeValues || '',
    riskLevel: row.riskLevel,
    description: row.description || '',
    remediation: row.remediation || '',
    standardReference: row.standardReference || ''
  })
  dialogVisible.value = true
}

const submitForm = async () => {
  await formRef.value.validate()
  submitting.value = true
  try {
    if (isEdit.value) {
      await configCheckItemApi.update(form.id, form)
      ElMessage.success('更新成功')
    } else {
      await configCheckItemApi.create(form)
      ElMessage.success('创建成功')
    }
    dialogVisible.value = false
    loadItems()
  } catch (e) {
    console.error('Failed to submit:', e)
  } finally {
    submitting.value = false
  }
}

const handleDelete = async (row) => {
  await ElMessageBox.confirm(`确定删除检查项 "${row.itemName}" 吗？`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  })
  try {
    await configCheckItemApi.delete(row.id)
    ElMessage.success('删除成功')
    loadItems()
  } catch (e) {
    console.error('Failed to delete:', e)
  }
}

const getRiskTagType = (level) => {
  const types = { HIGH: 'danger', MEDIUM: 'warning', LOW: 'info' }
  return types[level] || 'info'
}

onMounted(() => {
  loadItems()
})
</script>

<style lang="scss" scoped>
.config-check-manage {
  .card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}
</style>

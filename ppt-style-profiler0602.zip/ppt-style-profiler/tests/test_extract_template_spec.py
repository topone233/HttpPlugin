#!/usr/bin/env python
"""Smoke test for ppt-style-profiler extraction.

This test builds a synthetic PPTX fixture with known coordinates, repeated
layouts, theme colors, sample text, and an image relationship. It then runs the
extractor and validator using only local dependencies.
"""

from __future__ import annotations

import base64
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


PML = "http://schemas.openxmlformats.org/presentationml/2006/main"
DML = "http://schemas.openxmlformats.org/drawingml/2006/main"
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"

SLIDE_W = 9144000
SLIDE_H = 5143500

PNG_1X1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII="
)


def text_shape(
    shape_id: int,
    name: str,
    text: str,
    x: int,
    y: int,
    cx: int,
    cy: int,
    ph_type: str | None = None,
    ph_idx: int | None = None,
    font_size: int = 2800,
    fill_scheme: str = "bg1",
) -> str:
    ph = ""
    if ph_type:
        idx = f' idx="{ph_idx}"' if ph_idx is not None else ""
        ph = f'<p:ph type="{ph_type}"{idx}/>'
    return f"""
<p:sp>
  <p:nvSpPr>
    <p:cNvPr id="{shape_id}" name="{name}"/>
    <p:cNvSpPr/>
    <p:nvPr>{ph}</p:nvPr>
  </p:nvSpPr>
  <p:spPr>
    <a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
    <a:solidFill><a:schemeClr val="{fill_scheme}"/></a:solidFill>
    <a:ln w="12700"><a:solidFill><a:schemeClr val="accent1"/></a:solidFill></a:ln>
  </p:spPr>
  <p:txBody>
    <a:bodyPr/>
    <a:lstStyle/>
    <a:p>
      <a:pPr algn="l"/>
      <a:r>
        <a:rPr lang="en-US" sz="{font_size}" b="1">
          <a:latin typeface="Aptos Display"/>
          <a:solidFill><a:schemeClr val="tx1"/></a:solidFill>
        </a:rPr>
        <a:t>{text}</a:t>
      </a:r>
    </a:p>
  </p:txBody>
</p:sp>
"""


def picture(shape_id: int, name: str, x: int, y: int, cx: int, cy: int, rel_id: str = "rId2") -> str:
    return f"""
<p:pic>
  <p:nvPicPr>
    <p:cNvPr id="{shape_id}" name="{name}"/>
    <p:cNvPicPr/>
    <p:nvPr><p:ph type="pic" idx="3"/></p:nvPr>
  </p:nvPicPr>
  <p:blipFill>
    <a:blip r:embed="{rel_id}"/>
    <a:stretch><a:fillRect/></a:stretch>
  </p:blipFill>
  <p:spPr>
    <a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>
    <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
  </p:spPr>
</p:pic>
"""


def slide_xml(children: str) -> str:
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:p="{PML}" xmlns:a="{DML}" xmlns:r="{REL}">
  <p:cSld>
    <p:spTree>
      <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
      <p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{SLIDE_W}" cy="{SLIDE_H}"/><a:chOff x="0" y="0"/><a:chExt cx="{SLIDE_W}" cy="{SLIDE_H}"/></a:xfrm></p:grpSpPr>
      {children}
    </p:spTree>
  </p:cSld>
  <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
</p:sld>
"""


def layout_xml(name: str, children: str) -> str:
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldLayout xmlns:p="{PML}" xmlns:a="{DML}" xmlns:r="{REL}" type="custom" preserve="1">
  <p:cSld name="{name}">
    <p:spTree>
      <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
      <p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{SLIDE_W}" cy="{SLIDE_H}"/><a:chOff x="0" y="0"/><a:chExt cx="{SLIDE_W}" cy="{SLIDE_H}"/></a:xfrm></p:grpSpPr>
      {children}
    </p:spTree>
  </p:cSld>
  <p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>
</p:sldLayout>
"""


def rels_xml(relationships: list[tuple[str, str, str]]) -> str:
    rels = "\n".join(
        f'<Relationship Id="{rel_id}" Type="{rel_type}" Target="{target}"/>'
        for rel_id, rel_type, target in relationships
    )
    return f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="{PKG_REL}">
{rels}
</Relationships>
"""


def create_synthetic_pptx(path: Path) -> None:
    cover_title = text_shape(2, "Title Placeholder", "Synthetic Template", 731520, 514350, 7680960, 900000, "title", 1, 4000)
    cover_subtitle = text_shape(3, "Subtitle Placeholder", "Reference style sample", 731520, 1600000, 6000000, 500000, "subTitle", 2, 2200)
    content_title = text_shape(2, "Title Placeholder", "Known Layout", 731520, 350000, 7680960, 500000, "title", 1, 3200)
    content_body = text_shape(3, "Body Placeholder", "Three deterministic bullets", 731520, 1200000, 4114800, 3000000, "body", 2, 2200)
    content_pic = picture(4, "Hero Image Placeholder", 5257800, 1200000, 3071520, 3000000)

    slide2 = (
        text_shape(2, "Title Placeholder", "First Repeated Slide", 731520, 350000, 7680960, 500000, "title", 1, 3200)
        + text_shape(3, "Body Placeholder", "Same geometry, different text", 731520, 1200000, 4114800, 3000000, "body", 2, 2200)
        + content_pic
    )
    slide3 = (
        text_shape(2, "Title Placeholder", "Second Repeated Slide", 731520, 350000, 7680960, 500000, "title", 1, 3200)
        + text_shape(3, "Body Placeholder", "Archetype should deduplicate", 731520, 1200000, 4114800, 3000000, "body", 2, 2200)
        + content_pic
    )

    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(
            "[Content_Types].xml",
            """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Default Extension="png" ContentType="image/png"/>
  <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
  <Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>
  <Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>
  <Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>
  <Override PartName="/ppt/slideLayouts/slideLayout2.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>
  <Override PartName="/ppt/slides/slide1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>
  <Override PartName="/ppt/slides/slide2.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>
  <Override PartName="/ppt/slides/slide3.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>
</Types>
""",
        )
        zf.writestr("_rels/.rels", rels_xml([("rId1", f"{REL}/officeDocument", "ppt/presentation.xml")]))
        zf.writestr(
            "ppt/presentation.xml",
            f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:p="{PML}" xmlns:a="{DML}" xmlns:r="{REL}">
  <p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>
  <p:sldIdLst>
    <p:sldId id="256" r:id="rId2"/>
    <p:sldId id="257" r:id="rId3"/>
    <p:sldId id="258" r:id="rId4"/>
  </p:sldIdLst>
  <p:sldSz cx="{SLIDE_W}" cy="{SLIDE_H}" type="screen16x9"/>
</p:presentation>
""",
        )
        zf.writestr(
            "ppt/_rels/presentation.xml.rels",
            rels_xml(
                [
                    ("rId1", f"{REL}/slideMaster", "slideMasters/slideMaster1.xml"),
                    ("rId2", f"{REL}/slide", "slides/slide1.xml"),
                    ("rId3", f"{REL}/slide", "slides/slide2.xml"),
                    ("rId4", f"{REL}/slide", "slides/slide3.xml"),
                    ("rId5", f"{REL}/theme", "theme/theme1.xml"),
                ]
            ),
        )
        zf.writestr(
            "ppt/theme/theme1.xml",
            f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<a:theme xmlns:a="{DML}" name="Synthetic Theme">
  <a:themeElements>
    <a:clrScheme name="Synthetic">
      <a:dk1><a:srgbClr val="111111"/></a:dk1>
      <a:lt1><a:srgbClr val="FFFFFF"/></a:lt1>
      <a:dk2><a:srgbClr val="17324D"/></a:dk2>
      <a:lt2><a:srgbClr val="F4F8FB"/></a:lt2>
      <a:accent1><a:srgbClr val="1F4E79"/></a:accent1>
      <a:accent2><a:srgbClr val="F2B705"/></a:accent2>
      <a:accent3><a:srgbClr val="2A9D8F"/></a:accent3>
      <a:accent4><a:srgbClr val="E76F51"/></a:accent4>
      <a:accent5><a:srgbClr val="7A4CB0"/></a:accent5>
      <a:accent6><a:srgbClr val="6C757D"/></a:accent6>
      <a:hlink><a:srgbClr val="0563C1"/></a:hlink>
      <a:folHlink><a:srgbClr val="954F72"/></a:folHlink>
    </a:clrScheme>
    <a:fontScheme name="Synthetic Fonts">
      <a:majorFont><a:latin typeface="Aptos Display"/><a:ea typeface="Microsoft YaHei"/></a:majorFont>
      <a:minorFont><a:latin typeface="Aptos"/><a:ea typeface="Microsoft YaHei"/></a:minorFont>
    </a:fontScheme>
    <a:fmtScheme name="Synthetic Format">
      <a:fillStyleLst><a:solidFill><a:schemeClr val="accent1"/></a:solidFill></a:fillStyleLst>
      <a:lnStyleLst><a:ln w="12700"><a:solidFill><a:schemeClr val="accent1"/></a:solidFill></a:ln></a:lnStyleLst>
      <a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>
      <a:bgFillStyleLst><a:solidFill><a:schemeClr val="bg1"/></a:solidFill></a:bgFillStyleLst>
    </a:fmtScheme>
  </a:themeElements>
</a:theme>
""",
        )
        zf.writestr("ppt/slideMasters/slideMaster1.xml", layout_xml("Master", text_shape(10, "Footer", "Confidential", 731520, 4700000, 3000000, 250000, "ftr", 10, 1000)))
        zf.writestr(
            "ppt/slideMasters/_rels/slideMaster1.xml.rels",
            rels_xml(
                [
                    ("rId1", f"{REL}/slideLayout", "../slideLayouts/slideLayout1.xml"),
                    ("rId2", f"{REL}/slideLayout", "../slideLayouts/slideLayout2.xml"),
                    ("rId3", f"{REL}/theme", "../theme/theme1.xml"),
                ]
            ),
        )
        zf.writestr("ppt/slideLayouts/slideLayout1.xml", layout_xml("Cover", cover_title + cover_subtitle))
        zf.writestr("ppt/slideLayouts/slideLayout2.xml", layout_xml("Content", content_title + content_body + content_pic))
        zf.writestr("ppt/slideLayouts/_rels/slideLayout1.xml.rels", rels_xml([("rId1", f"{REL}/slideMaster", "../slideMasters/slideMaster1.xml")]))
        zf.writestr("ppt/slideLayouts/_rels/slideLayout2.xml.rels", rels_xml([("rId1", f"{REL}/slideMaster", "../slideMasters/slideMaster1.xml")]))
        zf.writestr("ppt/slides/slide1.xml", slide_xml(cover_title + cover_subtitle))
        zf.writestr("ppt/slides/slide2.xml", slide_xml(slide2))
        zf.writestr("ppt/slides/slide3.xml", slide_xml(slide3))
        for slide_no, layout_target in [(1, "../slideLayouts/slideLayout1.xml"), (2, "../slideLayouts/slideLayout2.xml"), (3, "../slideLayouts/slideLayout2.xml")]:
            zf.writestr(
                f"ppt/slides/_rels/slide{slide_no}.xml.rels",
                rels_xml(
                    [
                        ("rId1", f"{REL}/slideLayout", layout_target),
                        ("rId2", f"{REL}/image", "../media/image1.png"),
                    ]
                ),
            )
        zf.writestr("ppt/media/image1.png", PNG_1X1)


def main() -> int:
    skill_root = Path(__file__).resolve().parents[1]
    extractor = skill_root / "scripts" / "extract_template_spec.py"
    validator = skill_root / "scripts" / "validate_template_spec.py"

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        pptx = tmp_path / "synthetic-template.pptx"
        out_dir = tmp_path / "profile"
        create_synthetic_pptx(pptx)

        env = os.environ.copy()
        env["PATH"] = ""
        subprocess.run(
            [sys.executable, str(extractor), str(pptx), "--out", str(out_dir)],
            cwd=skill_root,
            env=env,
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            [sys.executable, str(validator), str(out_dir / "template-spec.json")],
            cwd=skill_root,
            env=env,
            check=True,
            capture_output=True,
            text=True,
        )

        spec = json.loads((out_dir / "template-spec.json").read_text(encoding="utf-8"))
        assert spec["deck"]["width_emu"] == SLIDE_W
        assert spec["deck"]["height_emu"] == SLIDE_H
        assert spec["deck"]["slide_count"] == 3
        assert spec["theme"]["colors"]["accent1"] == "#1F4E79"
        assert len(spec["slides"]) == 3
        assert len(spec["archetypes"]) == 2
        assert spec["slides"][1]["archetype_id"] == spec["slides"][2]["archetype_id"]
        assert spec["rendering"]["status"] == "skipped"
        assert any(warning["code"] == "rendering_skipped" for warning in spec["warnings"])

        first_title = spec["slides"][0]["elements"][0]
        assert first_title["role"] == "title"
        assert first_title["bbox_emu"]["x"] == 731520.0
        assert first_title["bbox_norm"]["x"] == 0.08
        assert first_title["sample_text"] == "Synthetic Template"

        image_elements = [
            element
            for slide in spec["slides"]
            for element in slide["elements"]
            if element["type"] == "image"
        ]
        assert image_elements
        assert image_elements[0]["relationships"][0]["media_id"] == "media_1"

    print("ppt-style-profiler smoke test passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

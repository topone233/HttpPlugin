#!/usr/bin/env python
"""Extract a machine-readable PowerPoint template/style profile.

The extractor reads PPTX Open XML directly via zipfile + lxml. It intentionally
does not depend on python-pptx because template profiling needs access to
masters, layouts, relationships, and raw DrawingML details that high-level APIs
often hide.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import json
import posixpath
import shutil
import subprocess
import sys
import tempfile
import zipfile
from collections import OrderedDict
from pathlib import Path
from typing import Any

try:
    from lxml import etree
except ImportError as exc:  # pragma: no cover - import guard
    raise SystemExit("lxml is required for ppt-style-profiler extraction") from exc

try:
    from PIL import Image
except ImportError:  # pragma: no cover - optional metadata only
    Image = None  # type: ignore[assignment]


SCHEMA_VERSION = "1.0.0"
DEFAULT_SLIDE_WIDTH_EMU = 9144000
DEFAULT_SLIDE_HEIGHT_EMU = 6858000

NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "c": "http://schemas.openxmlformats.org/drawingml/2006/chart",
    "dgm": "http://schemas.openxmlformats.org/drawingml/2006/diagram",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
}

REL_NS = NS["rel"]
R_ID = f"{{{NS['r']}}}id"
R_EMBED = f"{{{NS['r']}}}embed"
R_LINK = f"{{{NS['r']}}}link"


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def local_name(node: etree._Element) -> str:
    return etree.QName(node).localname


def int_attr(node: etree._Element | None, name: str, default: int | None = None) -> int | None:
    if node is None:
        return default
    value = node.get(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def bool_attr(value: str | None) -> bool | None:
    if value is None:
        return None
    return value in {"1", "true", "True"}


def emu_to_pt(value: int | None) -> float | None:
    if value is None:
        return None
    return round(value / 12700, 3)


def safe_rel_path(path: str) -> str:
    return posixpath.normpath(path.replace("\\", "/")).lstrip("./")


def rels_path_for(part_path: str) -> str:
    part_path = safe_rel_path(part_path)
    directory, filename = posixpath.split(part_path)
    if directory:
        return f"{directory}/_rels/{filename}.rels"
    return f"_rels/{filename}.rels"


def resolve_relationship_target(part_path: str, target: str) -> str:
    target = target.replace("\\", "/")
    if target.startswith("/"):
        return safe_rel_path(target[1:])
    base_dir = posixpath.dirname(safe_rel_path(part_path))
    return safe_rel_path(posixpath.join(base_dir, target))


def first_match(root: etree._Element, paths: list[str]) -> etree._Element | None:
    for path in paths:
        found = root.find(path, NS)
        if found is not None:
            return found
    return None


def bbox_to_norm(bbox: dict[str, float] | None, width: int, height: int) -> dict[str, float] | None:
    if bbox is None:
        return None
    return {
        "x": round(float(bbox["x"]) / width, 6),
        "y": round(float(bbox["y"]) / height, 6),
        "width": round(float(bbox["width"]) / width, 6),
        "height": round(float(bbox["height"]) / height, 6),
    }


def normalize_bbox_dict(bbox: dict[str, float] | None) -> dict[str, float] | None:
    if bbox is None:
        return None
    return {
        "x": float(bbox["x"]),
        "y": float(bbox["y"]),
        "width": float(bbox["width"]),
        "height": float(bbox["height"]),
    }


def parse_color_choice(node: etree._Element | None, theme_colors: dict[str, str]) -> dict[str, Any] | None:
    if node is None:
        return None
    name = local_name(node)
    modifiers: dict[str, str] = {}
    for child in node:
        modifiers[local_name(child)] = dict(child.attrib).get("val", "")

    if name == "srgbClr":
        raw = node.get("val", "").upper()
        if len(raw) == 6:
            return {"type": "srgb", "value": f"#{raw}", "modifiers": modifiers}
    if name == "sysClr":
        raw = (node.get("lastClr") or node.get("val") or "").upper()
        if len(raw) == 6:
            return {"type": "system", "value": f"#{raw}", "modifiers": modifiers}
        return {"type": "system", "value": node.get("val"), "modifiers": modifiers}
    if name == "schemeClr":
        token = node.get("val")
        resolved = theme_colors.get(token or "")
        return {
            "type": "scheme",
            "value": token,
            "resolved": resolved,
            "modifiers": modifiers,
        }
    if name == "prstClr":
        return {"type": "preset", "value": node.get("val"), "modifiers": modifiers}
    return {"type": name, "value": node.get("val"), "modifiers": modifiers}


def extract_fill(parent: etree._Element | None, theme_colors: dict[str, str]) -> dict[str, Any] | None:
    if parent is None:
        return None
    no_fill = parent.find("a:noFill", NS)
    if no_fill is not None:
        return {"type": "none"}
    solid = parent.find("a:solidFill", NS)
    if solid is not None:
        color_node = next(iter(solid), None)
        return {"type": "solid", "color": parse_color_choice(color_node, theme_colors)}
    grad = parent.find("a:gradFill", NS)
    if grad is not None:
        stops = []
        for stop in grad.xpath(".//a:gs", namespaces=NS):
            color_node = next(iter(stop), None)
            stops.append(
                {
                    "position": stop.get("pos"),
                    "color": parse_color_choice(color_node, theme_colors),
                }
            )
        return {"type": "gradient", "stops": stops}
    pattern = parent.find("a:pattFill", NS)
    if pattern is not None:
        return {"type": "pattern", "preset": pattern.get("prst")}
    blip = parent.find("a:blipFill", NS)
    if blip is not None:
        return {"type": "image"}
    return None


def extract_line(sp_pr: etree._Element | None, theme_colors: dict[str, str]) -> dict[str, Any] | None:
    if sp_pr is None:
        return None
    line = sp_pr.find("a:ln", NS)
    if line is None:
        return None
    width_emu = int_attr(line, "w")
    return {
        "width_emu": width_emu,
        "width_pt": emu_to_pt(width_emu),
        "cap": line.get("cap"),
        "compound": line.get("cmpd"),
        "dash": (line.find("a:prstDash", NS).get("val") if line.find("a:prstDash", NS) is not None else None),
        "fill": extract_fill(line, theme_colors),
    }


def extract_effects(sp_pr: etree._Element | None) -> list[str]:
    if sp_pr is None:
        return []
    effects = []
    for node in sp_pr.xpath(".//a:outerShdw | .//a:innerShdw | .//a:glow | .//a:softEdge | .//a:reflection", namespaces=NS):
        effects.append(local_name(node))
    return sorted(set(effects))


def extract_xfrm(element: etree._Element) -> dict[str, Any] | None:
    xfrm = first_match(
        element,
        [
            "./p:spPr/a:xfrm",
            "./p:grpSpPr/a:xfrm",
            "./p:xfrm",
            "./p:cxnSpPr/a:xfrm",
        ],
    )
    if xfrm is None:
        return None

    off = xfrm.find("a:off", NS)
    ext = xfrm.find("a:ext", NS)
    ch_off = xfrm.find("a:chOff", NS)
    ch_ext = xfrm.find("a:chExt", NS)

    bbox = None
    if off is not None and ext is not None:
        bbox = {
            "x": float(int_attr(off, "x", 0) or 0),
            "y": float(int_attr(off, "y", 0) or 0),
            "width": float(int_attr(ext, "cx", 0) or 0),
            "height": float(int_attr(ext, "cy", 0) or 0),
        }

    child_box = None
    if ch_off is not None and ch_ext is not None:
        child_box = {
            "x": float(int_attr(ch_off, "x", 0) or 0),
            "y": float(int_attr(ch_off, "y", 0) or 0),
            "width": float(int_attr(ch_ext, "cx", 0) or 0),
            "height": float(int_attr(ch_ext, "cy", 0) or 0),
        }

    return {
        "bbox": bbox,
        "child_bbox": child_box,
        "rotation": int_attr(xfrm, "rot", 0),
        "flip_h": bool_attr(xfrm.get("flipH")),
        "flip_v": bool_attr(xfrm.get("flipV")),
    }


def apply_group_transform(
    bbox: dict[str, float] | None,
    group_xfrm: dict[str, Any] | None,
) -> dict[str, float] | None:
    if bbox is None or group_xfrm is None:
        return bbox
    outer = group_xfrm.get("bbox")
    inner = group_xfrm.get("child_bbox")
    if not outer or not inner or inner["width"] == 0 or inner["height"] == 0:
        return bbox
    sx = outer["width"] / inner["width"]
    sy = outer["height"] / inner["height"]
    return {
        "x": outer["x"] + (bbox["x"] - inner["x"]) * sx,
        "y": outer["y"] + (bbox["y"] - inner["y"]) * sy,
        "width": bbox["width"] * sx,
        "height": bbox["height"] * sy,
    }


def extract_text(element: etree._Element) -> dict[str, Any]:
    paragraphs = []
    for paragraph in element.xpath(".//p:txBody/a:p", namespaces=NS):
        text = "".join(paragraph.xpath(".//a:t/text()", namespaces=NS))
        if text:
            paragraphs.append(text)
    sample_text = "\n".join(paragraphs)
    return {
        "sample_text": sample_text,
        "reference_content": bool(sample_text),
        "text_stats": {
            "paragraph_count": len(paragraphs),
            "char_count": len(sample_text),
            "line_count": len(paragraphs),
        },
    }


def extract_text_style(element: etree._Element, theme_colors: dict[str, str]) -> dict[str, Any]:
    style: dict[str, Any] = {}
    text_body = element.find(".//p:txBody", NS)
    if text_body is None:
        return style

    body_pr = text_body.find("a:bodyPr", NS)
    if body_pr is not None:
        style["body"] = {
            "vertical": body_pr.get("vert"),
            "anchor": body_pr.get("anchor"),
            "wrap": body_pr.get("wrap"),
            "left_inset": int_attr(body_pr, "lIns"),
            "right_inset": int_attr(body_pr, "rIns"),
            "top_inset": int_attr(body_pr, "tIns"),
            "bottom_inset": int_attr(body_pr, "bIns"),
        }

    p_pr = text_body.find(".//a:pPr", NS)
    if p_pr is not None:
        style["paragraph"] = {
            "alignment": p_pr.get("algn"),
            "level": int_attr(p_pr, "lvl"),
        }

    run_props = text_body.xpath(".//a:rPr | .//a:defRPr | .//a:endParaRPr", namespaces=NS)
    chosen = None
    for props in run_props:
        if props.get("sz") or props.find("a:latin", NS) is not None or props.find("a:solidFill", NS) is not None:
            chosen = props
            break
    if chosen is None and run_props:
        chosen = run_props[0]

    if chosen is not None:
        latin = chosen.find("a:latin", NS)
        ea = chosen.find("a:ea", NS)
        font_size = int_attr(chosen, "sz")
        style["run"] = {
            "font_family": latin.get("typeface") if latin is not None else None,
            "east_asian_font_family": ea.get("typeface") if ea is not None else None,
            "font_size_pt": round(font_size / 100, 2) if font_size is not None else None,
            "bold": bool_attr(chosen.get("b")),
            "italic": bool_attr(chosen.get("i")),
            "underline": chosen.get("u"),
            "color": extract_fill(chosen, theme_colors),
        }

    return style


def extract_shape_style(element: etree._Element, theme_colors: dict[str, str]) -> dict[str, Any]:
    sp_pr = first_match(
        element,
        [
            "./p:spPr",
            "./p:grpSpPr",
            "./p:cxnSpPr",
        ],
    )
    style: dict[str, Any] = {
        "fill": extract_fill(sp_pr, theme_colors),
        "line": extract_line(sp_pr, theme_colors),
        "effects": extract_effects(sp_pr),
        "text": extract_text_style(element, theme_colors),
    }
    if sp_pr is not None:
        geom = sp_pr.find("a:prstGeom", NS)
        if geom is not None:
            style["geometry"] = geom.get("prst")
    return style


def extract_placeholder(element: etree._Element) -> dict[str, Any] | None:
    ph = element.find(".//p:nvPr/p:ph", NS)
    if ph is None:
        return None
    return {
        "type": ph.get("type") or "body",
        "idx": ph.get("idx"),
        "size": ph.get("sz"),
        "orientation": ph.get("orient"),
    }


def placeholder_keys(placeholder: dict[str, Any] | None) -> list[str]:
    if not placeholder:
        return []
    keys = []
    if placeholder.get("idx") is not None:
        keys.append(f"idx:{placeholder['idx']}")
    if placeholder.get("type"):
        keys.append(f"type:{placeholder['type']}")
    return keys


def infer_role(
    element_type: str,
    name: str | None,
    placeholder: dict[str, Any] | None,
    sample_text: str,
    bbox_norm: dict[str, float] | None,
) -> str:
    ph_type = (placeholder or {}).get("type")
    if ph_type in {"title", "ctrTitle"}:
        return "title"
    if ph_type == "subTitle":
        return "subtitle"
    if ph_type in {"body", "obj"}:
        return "body"
    if ph_type == "pic":
        return "image_placeholder"
    if ph_type == "sldNum":
        return "slide_number"
    if ph_type in {"dt", "date"}:
        return "date"
    if ph_type == "ftr":
        return "footer"

    lowered_name = (name or "").lower()
    lowered_text = sample_text.strip().lower()
    if element_type == "image" and "logo" in lowered_name:
        return "logo"
    if element_type == "image":
        return "image"
    if "logo" in lowered_name:
        return "logo"
    if "icon" in lowered_name:
        return "icon"
    if element_type == "chart":
        return "chart"
    if element_type == "table":
        return "table"
    if sample_text:
        if bbox_norm and bbox_norm["y"] > 0.86 and bbox_norm["height"] < 0.08:
            return "footer"
        if len(lowered_text) <= 4 and lowered_text.isdigit():
            return "slide_number"
        return "text"
    if element_type in {"shape", "connector"}:
        return "decoration"
    return element_type


def make_element_id(part_path: str, c_nv_id: str | None, z_order: int, element_type: str) -> str:
    part_base = Path(part_path).stem.replace(" ", "_")
    suffix = c_nv_id or str(z_order)
    return f"{part_base}_{element_type}_{suffix}"


class PptxTemplateExtractor:
    def __init__(self, pptx_path: Path, out_dir: Path, no_render: bool = False):
        self.pptx_path = pptx_path
        self.out_dir = out_dir
        self.no_render = no_render
        self.parser = etree.XMLParser(resolve_entities=False, recover=True)
        self.warnings: list[dict[str, Any]] = []
        self._xml_cache: dict[str, etree._Element] = {}
        self._rels_cache: dict[str, dict[str, dict[str, Any]]] = {}
        self._zip_names: set[str] = set()
        self.theme_colors: dict[str, str] = {}
        self.media_by_path: dict[str, dict[str, Any]] = {}

    def warn(self, code: str, message: str, part: str | None = None, **extra: Any) -> None:
        warning = {"code": code, "message": message}
        if part:
            warning["part"] = part
        warning.update(extra)
        self.warnings.append(warning)

    def extract(self) -> tuple[dict[str, Any], dict[str, Any]]:
        started_at = utc_now()
        self.out_dir.mkdir(parents=True, exist_ok=True)
        (self.out_dir / "evidence").mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(self.pptx_path, "r") as zf:
            self.zf = zf  # type: ignore[attr-defined]
            self._zip_names = set(zf.namelist())
            source_bytes = self.pptx_path.read_bytes()

            presentation = self.read_xml("ppt/presentation.xml")
            if presentation is None:
                raise RuntimeError("ppt/presentation.xml not found; input is not a valid PPTX")

            deck = self.extract_deck(presentation)
            self.theme_colors = self.extract_theme()["colors"]
            media = self.extract_media()
            self.media_by_path = {item["path"]: item for item in media}

            masters = self.extract_masters(deck)
            layouts = self.extract_layouts(deck, masters)
            slides = self.extract_slides(deck, layouts, masters)
            archetypes = self.build_archetypes(slides)
            rendering = self.render_evidence()

            source = {
                "path": str(self.pptx_path.resolve()),
                "name": self.pptx_path.name,
                "sha256": sha256_bytes(source_bytes),
                "extracted_at": started_at,
            }

            theme = self.extract_theme()
            spec = {
                "schema_version": SCHEMA_VERSION,
                "source": source,
                "deck": deck,
                "theme": theme,
                "masters": masters,
                "layouts": layouts,
                "slides": slides,
                "archetypes": archetypes,
                "media": media,
                "rendering": rendering,
                "warnings": self.warnings,
            }

        finished_at = utc_now()
        log = {
            "started_at": started_at,
            "finished_at": finished_at,
            "input": str(self.pptx_path),
            "output": str(self.out_dir),
            "counts": {
                "masters": len(spec["masters"]),
                "layouts": len(spec["layouts"]),
                "slides": len(spec["slides"]),
                "archetypes": len(spec["archetypes"]),
                "media": len(spec["media"]),
                "warnings": len(spec["warnings"]),
            },
            "warnings": self.warnings,
        }
        return spec, log

    def read_xml(self, part_path: str) -> etree._Element | None:
        part_path = safe_rel_path(part_path)
        if part_path in self._xml_cache:
            return self._xml_cache[part_path]
        if part_path not in self._zip_names:
            return None
        try:
            root = etree.fromstring(self.zf.read(part_path), parser=self.parser)  # type: ignore[attr-defined]
            self._xml_cache[part_path] = root
            return root
        except etree.XMLSyntaxError as exc:
            self.warn("xml_parse_error", f"Could not parse XML: {exc}", part_path)
            return None

    def read_rels(self, part_path: str) -> dict[str, dict[str, Any]]:
        part_path = safe_rel_path(part_path)
        if part_path in self._rels_cache:
            return self._rels_cache[part_path]
        rels_part = rels_path_for(part_path)
        rels: dict[str, dict[str, Any]] = {}
        if rels_part not in self._zip_names:
            self._rels_cache[part_path] = rels
            return rels

        root = self.read_xml(rels_part)
        if root is None:
            self._rels_cache[part_path] = rels
            return rels
        for rel in root.xpath(".//rel:Relationship", namespaces=NS):
            rel_id = rel.get("Id")
            if not rel_id:
                continue
            target = rel.get("Target") or ""
            target_mode = rel.get("TargetMode")
            resolved = target if target_mode == "External" else resolve_relationship_target(part_path, target)
            rels[rel_id] = {
                "id": rel_id,
                "type": rel.get("Type"),
                "target": target,
                "target_resolved": resolved,
                "target_mode": target_mode,
            }
        self._rels_cache[part_path] = rels
        return rels

    def extract_deck(self, presentation: etree._Element) -> dict[str, Any]:
        size = presentation.find(".//p:sldSz", NS)
        width = int_attr(size, "cx", DEFAULT_SLIDE_WIDTH_EMU) or DEFAULT_SLIDE_WIDTH_EMU
        height = int_attr(size, "cy", DEFAULT_SLIDE_HEIGHT_EMU) or DEFAULT_SLIDE_HEIGHT_EMU
        slide_ids = presentation.xpath(".//p:sldIdLst/p:sldId", namespaces=NS)
        visible_count = sum(1 for node in slide_ids if node.get("show") != "0")
        return {
            "slide_count": len(slide_ids),
            "visible_slide_count": visible_count,
            "width_emu": width,
            "height_emu": height,
            "aspect_ratio": round(width / height, 6),
            "coordinate_system": {
                "native_unit": "EMU",
                "normalized": "0..1 relative to slide width/height",
            },
        }

    def extract_theme(self) -> dict[str, Any]:
        theme_parts = sorted(name for name in self._zip_names if name.startswith("ppt/theme/") and name.endswith(".xml"))
        colors: dict[str, str] = {}
        fonts: dict[str, Any] = {}
        format_scheme: dict[str, Any] = {}

        for theme_part in theme_parts:
            root = self.read_xml(theme_part)
            if root is None:
                continue
            clr_scheme = root.find(".//a:clrScheme", NS)
            if clr_scheme is not None:
                for color_slot in clr_scheme:
                    slot_name = local_name(color_slot)
                    color_node = next(iter(color_slot), None)
                    parsed = parse_color_choice(color_node, colors)
                    if parsed:
                        raw = parsed.get("value") or parsed.get("resolved")
                        if isinstance(raw, str) and raw.startswith("#") and len(raw) == 7:
                            colors[slot_name] = raw.upper()

            font_scheme = root.find(".//a:fontScheme", NS)
            if font_scheme is not None:
                for bucket in ("majorFont", "minorFont"):
                    node = font_scheme.find(f"a:{bucket}", NS)
                    if node is None:
                        continue
                    latin = node.find("a:latin", NS)
                    ea = node.find("a:ea", NS)
                    fonts[bucket] = {
                        "latin": latin.get("typeface") if latin is not None else None,
                        "east_asian": ea.get("typeface") if ea is not None else None,
                    }

            fmt = root.find(".//a:fmtScheme", NS)
            if fmt is not None:
                format_scheme = {
                    "fill_style_count": len(fmt.xpath(".//a:fillStyleLst/*", namespaces=NS)),
                    "line_style_count": len(fmt.xpath(".//a:lnStyleLst/*", namespaces=NS)),
                    "effect_style_count": len(fmt.xpath(".//a:effectStyleLst/*", namespaces=NS)),
                    "background_fill_style_count": len(fmt.xpath(".//a:bgFillStyleLst/*", namespaces=NS)),
                }

        if not theme_parts:
            self.warn("theme_missing", "No ppt/theme/*.xml parts were found")

        return {
            "theme_parts": theme_parts,
            "colors": colors,
            "fonts": fonts,
            "format_scheme": format_scheme,
        }

    def extract_media(self) -> list[dict[str, Any]]:
        media = []
        for index, path in enumerate(sorted(name for name in self._zip_names if name.startswith("ppt/media/")), start=1):
            data = self.zf.read(path)  # type: ignore[attr-defined]
            item: dict[str, Any] = {
                "id": f"media_{index}",
                "path": path,
                "sha256": sha256_bytes(data),
                "bytes": len(data),
            }
            if Image is not None:
                try:
                    with Image.open(io.BytesIO(data)) as img:
                        item["image"] = {
                            "width_px": img.width,
                            "height_px": img.height,
                            "mode": img.mode,
                            "format": img.format,
                        }
                except Exception:
                    pass
            media.append(item)
        return media

    def collect_master_paths(self) -> list[str]:
        rels = self.read_rels("ppt/presentation.xml")
        paths = [
            rel["target_resolved"]
            for rel in rels.values()
            if (rel.get("type") or "").endswith("/slideMaster") and rel.get("target_mode") != "External"
        ]
        paths.extend(name for name in self._zip_names if name.startswith("ppt/slideMasters/") and name.endswith(".xml"))
        return sorted(OrderedDict((path, None) for path in paths).keys())

    def extract_masters(self, deck: dict[str, Any]) -> list[dict[str, Any]]:
        masters = []
        for index, path in enumerate(self.collect_master_paths(), start=1):
            elements = self.extract_part_elements(path, "master", deck)
            masters.append(
                {
                    "id": f"master_{index}",
                    "path": path,
                    "name": Path(path).stem,
                    "elements": elements,
                    "placeholder_slots": [self.element_to_slot(elem, i + 1) for i, elem in enumerate(elements) if elem.get("placeholder")],
                }
            )
        return masters

    def collect_layout_paths(self, masters: list[dict[str, Any]]) -> list[str]:
        paths = []
        for master in masters:
            for rel in self.read_rels(master["path"]).values():
                if (rel.get("type") or "").endswith("/slideLayout") and rel.get("target_mode") != "External":
                    paths.append(rel["target_resolved"])
        paths.extend(name for name in self._zip_names if name.startswith("ppt/slideLayouts/") and name.endswith(".xml"))
        return sorted(OrderedDict((path, None) for path in paths).keys())

    def extract_layouts(self, deck: dict[str, Any], masters: list[dict[str, Any]]) -> list[dict[str, Any]]:
        master_by_path = {master["path"]: master for master in masters}
        layouts = []
        for index, path in enumerate(self.collect_layout_paths(masters), start=1):
            rels = self.read_rels(path)
            master_path = None
            for rel in rels.values():
                if (rel.get("type") or "").endswith("/slideMaster"):
                    master_path = rel["target_resolved"]
                    break
            elements = self.extract_part_elements(path, "layout", deck)
            layouts.append(
                {
                    "id": f"layout_{index}",
                    "path": path,
                    "name": Path(path).stem,
                    "master": master_by_path.get(master_path, {}).get("id") if master_path else None,
                    "master_path": master_path,
                    "elements": elements,
                    "placeholder_slots": [self.element_to_slot(elem, i + 1) for i, elem in enumerate(elements) if elem.get("placeholder")],
                }
            )
        return layouts

    def extract_slides(
        self,
        deck: dict[str, Any],
        layouts: list[dict[str, Any]],
        masters: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        presentation = self.read_xml("ppt/presentation.xml")
        assert presentation is not None
        pres_rels = self.read_rels("ppt/presentation.xml")
        layouts_by_path = {layout["path"]: layout for layout in layouts}
        masters_by_id = {master["id"]: master for master in masters}

        slides = []
        for index, slide_id in enumerate(presentation.xpath(".//p:sldIdLst/p:sldId", namespaces=NS), start=1):
            rel_id = slide_id.get(R_ID)
            rel = pres_rels.get(rel_id or "")
            if rel is None:
                self.warn("slide_relationship_missing", f"Slide relationship {rel_id!r} not found", "ppt/presentation.xml")
                continue
            path = rel["target_resolved"]
            slide_rels = self.read_rels(path)
            layout_path = None
            for slide_rel in slide_rels.values():
                if (slide_rel.get("type") or "").endswith("/slideLayout"):
                    layout_path = slide_rel["target_resolved"]
                    break
            layout = layouts_by_path.get(layout_path or "")
            master = masters_by_id.get(layout.get("master")) if layout else None
            elements = self.extract_part_elements(path, "slide", deck, slide_rels)
            self.apply_placeholder_inheritance(elements, layout, master)
            signature = self.geometry_signature(elements)

            slides.append(
                {
                    "slide_index": index,
                    "slide_id": slide_id.get("id"),
                    "path": path,
                    "name": Path(path).stem,
                    "hidden": slide_id.get("show") == "0",
                    "layout": {
                        "id": layout.get("id"),
                        "path": layout.get("path"),
                        "master": layout.get("master"),
                    }
                    if layout
                    else None,
                    "elements": elements,
                    "geometry_signature": signature,
                    "archetype_id": "",
                }
            )
        return slides

    def extract_part_elements(
        self,
        part_path: str,
        container: str,
        deck: dict[str, Any],
        rels: dict[str, dict[str, Any]] | None = None,
    ) -> list[dict[str, Any]]:
        root = self.read_xml(part_path)
        if root is None:
            return []
        rels = rels if rels is not None else self.read_rels(part_path)
        sp_tree = root.find(".//p:cSld/p:spTree", NS)
        if sp_tree is None:
            return []
        elements: list[dict[str, Any]] = []
        for child in sp_tree:
            if local_name(child) in {"nvGrpSpPr", "grpSpPr"}:
                continue
            self.extract_element_recursive(
                child,
                part_path,
                container,
                deck,
                rels,
                elements,
                parent_group_xfrm=None,
            )
        return elements

    def extract_element_recursive(
        self,
        element: etree._Element,
        part_path: str,
        container: str,
        deck: dict[str, Any],
        rels: dict[str, dict[str, Any]],
        elements: list[dict[str, Any]],
        parent_group_xfrm: dict[str, Any] | None,
    ) -> None:
        tag = local_name(element)
        if tag not in {"sp", "pic", "graphicFrame", "cxnSp", "grpSp"}:
            return

        z_order = len(elements)
        extracted = self.extract_single_element(
            element,
            part_path,
            container,
            deck,
            rels,
            z_order,
            parent_group_xfrm,
        )
        elements.append(extracted)

        if tag == "grpSp":
            self.warn("group_shape_detected", "Grouped shapes require transform normalization", part_path)
            group_xfrm = extract_xfrm(element)
            if parent_group_xfrm and group_xfrm:
                group_xfrm["bbox"] = apply_group_transform(group_xfrm.get("bbox"), parent_group_xfrm)
            for child in element:
                if local_name(child) in {"nvGrpSpPr", "grpSpPr"}:
                    continue
                self.extract_element_recursive(
                    child,
                    part_path,
                    container,
                    deck,
                    rels,
                    elements,
                    parent_group_xfrm=group_xfrm,
                )

    def extract_single_element(
        self,
        element: etree._Element,
        part_path: str,
        container: str,
        deck: dict[str, Any],
        rels: dict[str, dict[str, Any]],
        z_order: int,
        parent_group_xfrm: dict[str, Any] | None,
    ) -> dict[str, Any]:
        tag = local_name(element)
        c_nv_pr = element.find(".//p:cNvPr", NS)
        c_nv_id = c_nv_pr.get("id") if c_nv_pr is not None else None
        name = c_nv_pr.get("name") if c_nv_pr is not None else None
        description = c_nv_pr.get("descr") if c_nv_pr is not None else None

        text_info = extract_text(element)
        placeholder = extract_placeholder(element)
        xfrm = extract_xfrm(element)
        bbox_emu = normalize_bbox_dict(apply_group_transform(xfrm.get("bbox") if xfrm else None, parent_group_xfrm))
        bbox_norm = bbox_to_norm(bbox_emu, deck["width_emu"], deck["height_emu"])
        element_type = self.element_type(element)
        role = infer_role(element_type, name, placeholder, text_info["sample_text"], bbox_norm)

        relationship_refs = self.extract_relationship_refs(element, rels)
        if element_type == "chart":
            self.warn("chart_detected", "Chart geometry is captured, but chart data/style is not fully profiled in v1", part_path)
        if element.xpath(".//dgm:*", namespaces=NS):
            self.warn("smartart_detected", "SmartArt/diagram internals are not fully profiled in v1", part_path)

        item: dict[str, Any] = {
            "id": make_element_id(part_path, c_nv_id, z_order, element_type),
            "type": element_type,
            "role": role,
            "name": name,
            "description": description,
            "placeholder": placeholder,
            "bbox_emu": bbox_emu,
            "bbox_norm": bbox_norm,
            "z_order": z_order,
            "sample_text": text_info["sample_text"],
            "reference_content": text_info["reference_content"],
            "text_stats": text_info["text_stats"],
            "style": extract_shape_style(element, self.theme_colors),
            "relationships": relationship_refs,
            "source": {
                "part": part_path,
                "container": container,
                "xml_path": f"{part_path}#L{element.sourceline or 0}:{tag}:{c_nv_id or z_order}",
                "tag": tag,
            },
        }
        if xfrm:
            item["transform"] = {
                "rotation": xfrm.get("rotation"),
                "flip_h": xfrm.get("flip_h"),
                "flip_v": xfrm.get("flip_v"),
            }
        return item

    def element_type(self, element: etree._Element) -> str:
        tag = local_name(element)
        if tag == "pic":
            return "image"
        if tag == "cxnSp":
            return "connector"
        if tag == "grpSp":
            return "group"
        if tag == "graphicFrame":
            if element.find(".//a:tbl", NS) is not None:
                return "table"
            if element.find(".//c:chart", NS) is not None:
                return "chart"
            return "graphic_frame"
        if tag == "sp":
            if element.find(".//p:txBody", NS) is not None:
                return "text_box"
            return "shape"
        return tag

    def extract_relationship_refs(
        self,
        element: etree._Element,
        rels: dict[str, dict[str, Any]],
    ) -> list[dict[str, Any]]:
        refs = []
        for blip in element.xpath(".//a:blip", namespaces=NS):
            rel_id = blip.get(R_EMBED) or blip.get(R_LINK)
            if not rel_id:
                continue
            rel = rels.get(rel_id)
            ref = {"relationship_id": rel_id, "kind": "image"}
            if rel:
                ref.update(
                    {
                        "relationship_type": rel.get("type"),
                        "target": rel.get("target_resolved"),
                        "target_mode": rel.get("target_mode"),
                    }
                )
                media_item = self.media_by_path.get(rel.get("target_resolved", ""))
                if media_item:
                    ref["media_id"] = media_item["id"]
            refs.append(ref)
        for chart in element.xpath(".//c:chart", namespaces=NS):
            rel_id = chart.get(R_ID)
            if not rel_id:
                continue
            rel = rels.get(rel_id)
            ref = {"relationship_id": rel_id, "kind": "chart"}
            if rel:
                ref.update({"relationship_type": rel.get("type"), "target": rel.get("target_resolved")})
            refs.append(ref)
        return refs

    def apply_placeholder_inheritance(
        self,
        elements: list[dict[str, Any]],
        layout: dict[str, Any] | None,
        master: dict[str, Any] | None,
    ) -> None:
        layout_map = self.placeholder_map(layout.get("elements", []) if layout else [])
        master_map = self.placeholder_map(master.get("elements", []) if master else [])
        for elem in elements:
            if elem.get("bbox_emu") is not None:
                continue
            inherited = None
            inherited_from = None
            for key in placeholder_keys(elem.get("placeholder")):
                if key in layout_map:
                    inherited = layout_map[key]
                    inherited_from = {"part": layout.get("path"), "element_id": inherited.get("id")}
                    break
                if key in master_map:
                    inherited = master_map[key]
                    inherited_from = {"part": master.get("path"), "element_id": inherited.get("id")}
                    break
            if inherited and inherited.get("bbox_emu") is not None:
                elem["bbox_emu"] = inherited["bbox_emu"]
                elem["bbox_norm"] = inherited["bbox_norm"]
                elem["source"]["inherited_bbox_from"] = inherited_from
                if elem.get("role") in {None, "text", "text_box", "body"} and inherited.get("role"):
                    elem["role"] = inherited["role"]

    def placeholder_map(self, elements: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        mapping: dict[str, dict[str, Any]] = {}
        for elem in elements:
            for key in placeholder_keys(elem.get("placeholder")):
                mapping.setdefault(key, elem)
        return mapping

    def element_to_slot(self, elem: dict[str, Any], index: int) -> dict[str, Any]:
        return {
            "slot_id": f"slot_{index}",
            "type": elem.get("type"),
            "role": elem.get("role"),
            "bbox_emu": elem.get("bbox_emu"),
            "bbox_norm": elem.get("bbox_norm"),
            "placeholder": elem.get("placeholder"),
            "style": elem.get("style", {}),
            "source_element_id": elem.get("id"),
        }

    def geometry_signature(self, elements: list[dict[str, Any]]) -> str:
        tokens = []
        for elem in elements:
            bbox = elem.get("bbox_norm")
            if bbox:
                box = [round(float(bbox[key]), 3) for key in ("x", "y", "width", "height")]
            else:
                box = None
            tokens.append(
                {
                    "type": elem.get("type"),
                    "role": elem.get("role"),
                    "bbox": box,
                }
            )
        payload = json.dumps(tokens, sort_keys=True, separators=(",", ":"))
        return sha256_bytes(payload.encode("utf-8"))[:16]

    def build_archetypes(self, slides: list[dict[str, Any]]) -> list[dict[str, Any]]:
        grouped: OrderedDict[str, list[dict[str, Any]]] = OrderedDict()
        for slide in slides:
            grouped.setdefault(slide["geometry_signature"], []).append(slide)

        archetypes = []
        for index, (signature, group) in enumerate(grouped.items(), start=1):
            archetype_id = f"archetype_{index}"
            for slide in group:
                slide["archetype_id"] = archetype_id
            first = group[0]
            slots = [self.element_to_slot(elem, i + 1) for i, elem in enumerate(first["elements"])]
            archetypes.append(
                {
                    "id": archetype_id,
                    "geometry_signature": signature,
                    "slide_indices": [slide["slide_index"] for slide in group],
                    "source_layout": first["layout"]["id"] if first.get("layout") else None,
                    "source_layout_path": first["layout"]["path"] if first.get("layout") else None,
                    "element_count": len(first["elements"]),
                    "element_slots": slots,
                    "role_distribution": self.role_distribution(first["elements"]),
                }
            )
        return archetypes

    def role_distribution(self, elements: list[dict[str, Any]]) -> dict[str, int]:
        distribution: dict[str, int] = {}
        for elem in elements:
            role = elem.get("role") or "unknown"
            distribution[role] = distribution.get(role, 0) + 1
        return distribution

    def render_evidence(self) -> dict[str, Any]:
        tools = {
            "soffice": shutil.which("soffice"),
            "pdftoppm": shutil.which("pdftoppm"),
        }
        if self.no_render:
            return {"status": "disabled", "tools": tools, "evidence": []}
        if not tools["soffice"] or not tools["pdftoppm"]:
            missing = [name for name, path in tools.items() if not path]
            self.warn(
                "rendering_skipped",
                f"Rendering skipped because required tool(s) are missing from PATH: {', '.join(missing)}",
            )
            return {"status": "skipped", "tools": tools, "evidence": []}

        evidence_dir = self.out_dir / "evidence"
        try:
            with tempfile.TemporaryDirectory() as tmp:
                tmp_path = Path(tmp)
                subprocess.run(
                    [
                        tools["soffice"],
                        "--headless",
                        "--convert-to",
                        "pdf",
                        "--outdir",
                        str(tmp_path),
                        str(self.pptx_path),
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
                pdfs = sorted(tmp_path.glob("*.pdf"))
                if not pdfs:
                    raise RuntimeError("LibreOffice did not produce a PDF")
                output_prefix = evidence_dir / "slide"
                subprocess.run(
                    [
                        tools["pdftoppm"],
                        "-png",
                        "-r",
                        "120",
                        str(pdfs[0]),
                        str(output_prefix),
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
            evidence = [
                path.relative_to(self.out_dir).as_posix()
                for path in sorted(evidence_dir.glob("slide-*.png"))
            ]
            return {"status": "rendered", "tools": tools, "evidence": evidence}
        except Exception as exc:
            self.warn("rendering_failed", f"Rendering failed: {exc}")
            return {"status": "failed", "tools": tools, "evidence": []}


def write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Extract a PPTX template/style profile.")
    parser.add_argument("pptx", help="Input .pptx file")
    parser.add_argument("--out", required=True, help="Output profile directory")
    parser.add_argument("--no-render", action="store_true", help="Disable optional LibreOffice/Poppler rendering")
    args = parser.parse_args(argv)

    pptx_path = Path(args.pptx)
    if not pptx_path.exists():
        print(f"Error: input file not found: {pptx_path}", file=sys.stderr)
        return 2
    if pptx_path.suffix.lower() != ".pptx":
        print(f"Error: input must be a .pptx file: {pptx_path}", file=sys.stderr)
        return 2

    extractor = PptxTemplateExtractor(pptx_path, Path(args.out), no_render=args.no_render)
    try:
        spec, log = extractor.extract()
    except zipfile.BadZipFile:
        print(f"Error: not a valid PPTX/ZIP file: {pptx_path}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"Error: extraction failed: {exc}", file=sys.stderr)
        return 1

    out_dir = Path(args.out)
    write_json(out_dir / "template-spec.json", spec)
    write_json(out_dir / "extraction-log.json", log)
    write_json(out_dir / "warnings.json", spec["warnings"])
    print(f"Wrote {out_dir / 'template-spec.json'}")
    print(f"Slides: {len(spec['slides'])}; archetypes: {len(spec['archetypes'])}; warnings: {len(spec['warnings'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

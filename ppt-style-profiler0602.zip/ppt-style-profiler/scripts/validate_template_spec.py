#!/usr/bin/env python
"""Validate a ppt-style-profiler template-spec.json file."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


REQUIRED_TOP_LEVEL = [
    "schema_version",
    "source",
    "deck",
    "theme",
    "masters",
    "layouts",
    "slides",
    "archetypes",
    "media",
    "rendering",
    "warnings",
]

REQUIRED_SOURCE = ["path", "name", "sha256", "extracted_at"]
REQUIRED_DECK = [
    "slide_count",
    "visible_slide_count",
    "width_emu",
    "height_emu",
    "aspect_ratio",
    "coordinate_system",
]
REQUIRED_ELEMENT = [
    "id",
    "type",
    "role",
    "bbox_emu",
    "bbox_norm",
    "z_order",
    "style",
    "source",
]
REQUIRED_BBOX = ["x", "y", "width", "height"]


def schema_path() -> Path:
    return Path(__file__).resolve().parents[1] / "references" / "template-spec.schema.json"


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def validate_with_jsonschema(spec: dict[str, Any], schema: dict[str, Any]) -> list[str] | None:
    try:
        import jsonschema  # type: ignore
    except ImportError:
        return None

    validator = jsonschema.Draft202012Validator(schema)
    errors = []
    for error in sorted(validator.iter_errors(spec), key=lambda item: list(item.path)):
        location = ".".join(str(part) for part in error.path) or "<root>"
        errors.append(f"{location}: {error.message}")
    return errors


def expect_keys(obj: Any, keys: list[str], path: str, errors: list[str]) -> None:
    if not isinstance(obj, dict):
        errors.append(f"{path}: expected object")
        return
    for key in keys:
        if key not in obj:
            errors.append(f"{path}: missing required key {key!r}")


def expect_list(obj: Any, path: str, errors: list[str]) -> None:
    if not isinstance(obj, list):
        errors.append(f"{path}: expected array")


def validate_bbox(bbox: Any, path: str, errors: list[str]) -> None:
    if bbox is None:
        return
    if not isinstance(bbox, dict):
        errors.append(f"{path}: expected object or null")
        return
    for key in REQUIRED_BBOX:
        value = bbox.get(key)
        if not isinstance(value, (int, float)):
            errors.append(f"{path}.{key}: expected number")


def validate_element(element: Any, path: str, errors: list[str]) -> None:
    expect_keys(element, REQUIRED_ELEMENT, path, errors)
    if not isinstance(element, dict):
        return
    if not isinstance(element.get("id"), str):
        errors.append(f"{path}.id: expected string")
    if not isinstance(element.get("type"), str):
        errors.append(f"{path}.type: expected string")
    if not isinstance(element.get("role"), str):
        errors.append(f"{path}.role: expected string")
    if not isinstance(element.get("z_order"), int):
        errors.append(f"{path}.z_order: expected integer")
    if not isinstance(element.get("style"), dict):
        errors.append(f"{path}.style: expected object")
    if not isinstance(element.get("source"), dict):
        errors.append(f"{path}.source: expected object")
    validate_bbox(element.get("bbox_emu"), f"{path}.bbox_emu", errors)
    validate_bbox(element.get("bbox_norm"), f"{path}.bbox_norm", errors)


def validate_fallback(spec: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    expect_keys(spec, REQUIRED_TOP_LEVEL, "<root>", errors)

    if spec.get("schema_version") != "1.0.0":
        errors.append("schema_version: expected '1.0.0'")

    source = spec.get("source")
    expect_keys(source, REQUIRED_SOURCE, "source", errors)
    if isinstance(source, dict):
        sha = source.get("sha256")
        if not isinstance(sha, str) or len(sha) != 64 or any(ch not in "0123456789abcdef" for ch in sha):
            errors.append("source.sha256: expected 64 lowercase hex characters")

    deck = spec.get("deck")
    expect_keys(deck, REQUIRED_DECK, "deck", errors)
    if isinstance(deck, dict):
        for key in ["slide_count", "visible_slide_count", "width_emu", "height_emu"]:
            if not isinstance(deck.get(key), int):
                errors.append(f"deck.{key}: expected integer")
        if not isinstance(deck.get("aspect_ratio"), (int, float)):
            errors.append("deck.aspect_ratio: expected number")

    theme = spec.get("theme")
    expect_keys(theme, ["theme_parts", "colors", "fonts"], "theme", errors)

    for collection_name in ["masters", "layouts", "slides", "archetypes", "media", "warnings"]:
        expect_list(spec.get(collection_name), collection_name, errors)

    for part_name in ["masters", "layouts"]:
        for index, part in enumerate(spec.get(part_name, []) or []):
            expect_keys(part, ["id", "path", "elements"], f"{part_name}[{index}]", errors)
            for element_index, element in enumerate(part.get("elements", []) if isinstance(part, dict) else []):
                validate_element(element, f"{part_name}[{index}].elements[{element_index}]", errors)

    for index, slide in enumerate(spec.get("slides", []) or []):
        expect_keys(
            slide,
            ["slide_index", "path", "hidden", "layout", "elements", "geometry_signature", "archetype_id"],
            f"slides[{index}]",
            errors,
        )
        if not isinstance(slide, dict):
            continue
        for element_index, element in enumerate(slide.get("elements", []) or []):
            validate_element(element, f"slides[{index}].elements[{element_index}]", errors)

    rendering = spec.get("rendering")
    expect_keys(rendering, ["status", "tools", "evidence"], "rendering", errors)
    if isinstance(rendering, dict):
        if rendering.get("status") not in {"rendered", "skipped", "failed", "disabled"}:
            errors.append("rendering.status: unexpected value")
        if not isinstance(rendering.get("tools"), dict):
            errors.append("rendering.tools: expected object")
        if not isinstance(rendering.get("evidence"), list):
            errors.append("rendering.evidence: expected array")

    return errors


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate template-spec.json.")
    parser.add_argument("spec", help="Path to template-spec.json")
    parser.add_argument("--schema", default=None, help="Optional JSON Schema path")
    args = parser.parse_args(argv)

    spec_path = Path(args.spec)
    if not spec_path.exists():
        print(f"Error: spec not found: {spec_path}", file=sys.stderr)
        return 2

    schema_file = Path(args.schema) if args.schema else schema_path()
    spec = load_json(spec_path)
    schema = load_json(schema_file)

    errors = validate_with_jsonschema(spec, schema)
    validator_name = "jsonschema"
    if errors is None:
        validator_name = "built-in structural validator"
        errors = validate_fallback(spec)

    if errors:
        print(f"Validation failed using {validator_name}:")
        for error in errors:
            print(f"- {error}")
        return 1

    print(f"Validation passed using {validator_name}: {spec_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

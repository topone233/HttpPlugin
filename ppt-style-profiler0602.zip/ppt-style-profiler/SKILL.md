---
name: ppt-style-profiler
description: Use this skill whenever the user wants to reverse-engineer, identify, extract, or profile a PowerPoint/PPTX template, visual style, layout system, theme, or reusable deck format. Trigger for requests such as "识别 PPT 模板/风格/版式", "提取 PPT style/template spec", "analyze this reference deck", "extract a machine-readable PPT template", or "use this PPT style for later HTML/PPT generation". This skill focuses on producing a machine-readable template/style spec from a reference .pptx; it does not generate the final HTML or PPTX deck in v1.
---

# ppt-style-profiler

Extract a machine-readable template/style specification from a reference
PowerPoint deck. Treat this skill as a compiler front-end: the input is a
`.pptx`; the output is a `template-spec.json` bundle that future HTML or PPTX
generators can consume.

## Use This For

- Identifying a PPT's template, visual style, theme, layout system, and reusable
  slide archetypes.
- Producing a coordinate-level template specification for style transfer.
- Preparing a reference deck for a future HTML presentation generator or native
  PPTX generator.

Do not use this skill as the final deck authoring workflow. After the spec is
created, use a separate generator skill or workflow to create HTML/PPTX output.

## Output Contract

The primary output is:

```text
<output-dir>/
  template-spec.json
  extraction-log.json
  warnings.json
  evidence/
```

`template-spec.json` preserves reference PPT sample text as reference content.
The sample text is useful for capacity and role inference, but it must not be
treated as semantic content to reuse in a new deck.

## Standard Workflow

1. Resolve the input `.pptx` path and choose an output directory. If the user did
   not specify one, use `<pptx-stem>-template-profile`.
2. Run the extractor from this skill directory:

   ```bash
   python scripts/extract_template_spec.py input.pptx --out output/template-profile
   ```

3. Validate the spec:

   ```bash
   python scripts/validate_template_spec.py output/template-profile/template-spec.json
   ```

4. Inspect `warnings.json` and `extraction-log.json`. Rendering is optional:
   the extractor attempts to use local LibreOffice and Poppler (`pdftoppm`) when
   available. If they are missing, the spec still emits with
   `rendering.status = "skipped"` and an explicit warning.
5. If evidence images were produced, visually inspect them against the
   archetypes in `template-spec.json`. Use the images to judge whether roles
   like title, footer, logo, hero image, card, and decoration were inferred
   correctly.

## What The Extractor Captures

- Deck-level size, aspect ratio, slide order, and source file hash.
- Theme colors, fonts, and basic DrawingML style tokens.
- Slide masters, slide layouts, and placeholder geometry.
- Per-slide element instances with:
  - `id`, `type`, `role`, `z_order`
  - `bbox_emu` and `bbox_norm`
  - `sample_text` and text statistics where present
  - font, fill, line, alignment, and effect summaries where extractable
  - source part paths and relationship references
- Media files with hashes and image dimensions when available.
- Deduplicated slide archetypes derived from geometry signatures while retaining
  the original raw slide instances.

## Important Interpretation Rules

- Prefer XML-derived coordinates and styles over visual guesses.
- Use rendered evidence images to refine interpretation, not to override
  machine-readable coordinates without a clear reason.
- Treat missing rendering as a confidence limitation, not a failure.
- Record unsupported or low-confidence areas explicitly. Common examples:
  SmartArt, charts with external workbook data, complex grouped transforms,
  theme color transforms, custom fonts unavailable on the machine, and manually
  edited slides that do not match their layout.

## Schema

The formal JSON Schema lives at:

```text
references/template-spec.schema.json
```

Run `scripts/validate_template_spec.py` before handing the spec to a downstream
HTML or PPTX generator.


importScripts('../shared/constants.js', '../shared/utils.js', '../shared/db.js');

// Capture toggle, mirrored from chrome.storage.session.capturing.
// Defaults to ON until storage is read; the popup writes the persisted value.
let capturing = true;
chrome.storage.session.get('capturing', r => { capturing = r.capturing !== false; });

// In-memory buffer for correlation: last 30s of requests per tab
const reqBuffer = new Map(); // tabId -> [{...}]
const pendingBehaviors = new Map(); // tabId -> [{behavior, enqueuedAt}]

// webRequest capture: pending requests + interceptor body cache
const wrPending = new Map(); // requestId -> { tabId, method, url, urlPath, startTime, reqHeaders, resourceType, pageUrl }
const BODY_CACHE_MAX = 200;

function getBuffer(map, tabId) {
  if (!map.has(tabId)) map.set(tabId, []);
  return map.get(tabId);
}

function pruneBuffer(buf, windowMs = 30000) {
  const cutoff = Date.now() - windowMs;
  while (buf.length && buf[0].ts < cutoff) buf.shift();
}

// Dynamic window: extend for export/download actions
function dynamicWindow(behaviorText) {
  const t = (behaviorText || '').toLowerCase();
  let w = CORR.BASE_WINDOW;
  if (/export|导出|download|下载/.test(t)) w += 1000;
  return Math.min(w + 2000, CORR.MAX_WINDOW); // +2000 for chain
}

function correlate(behavior, requests) {
  const win = dynamicWindow(behavior.elementText);
  const T = behavior.timestamp;

  // Stage 1: candidate filtering — include requests from 500ms BEFORE click too
  // (some requests start just before click event fires due to event loop)
  const candidates = requests.filter(r =>
    r.ts >= T - 1000 && r.ts <= T + win && isApiRequest(r.url)
  );

  console.log('[SW] correlate:', behavior.elementText, 'T=', T, 'win=', win,
    'totalBuf=', requests.length, 'candidates=', candidates.length,
    candidates.map(r => `${r.method} ${r.url} ts=${r.ts}`));

  if (!candidates.length) return [];

  const bTokens = tokenize(behavior.elementText || behavior.ariaLabel || behavior.title || '');
  const isMutation = ['POST', 'PUT', 'DELETE', 'PATCH'];
  const results = [];

  for (const req of candidates) {
    const rTokens = tokenizeUrl(req.url);

    const temporal = Math.max(0, 1 - Math.max(0, req.ts - T) / win);
    const semantic = jaccard(bTokens, rTokens);
    const param = strongMatch(behavior.rowData, req.reqBody);

    // Method boost: mutation methods are stronger action signals
    const methodBoost = isMutation.includes(req.method) ? 0.1 : 0;

    const confidence = CORR.W_PARAM * param + CORR.W_SEMANTIC * semantic + CORR.W_TEMPORAL * temporal + methodBoost;

    console.log('[SW]   candidate:', req.method, req.url,
      'temporal=', temporal.toFixed(3), 'semantic=', semantic.toFixed(3), 'param=', param,
      'confidence=', confidence.toFixed(3), 'threshold=', CORR.THRESHOLD);

    if (confidence < CORR.THRESHOLD) continue;

    // Classify type
    let reqType = 'unknown';
    if (param === 1.0) reqType = 'action';
    else if (isMutation.includes(req.method) && temporal >= 0.5) reqType = 'action';
    else if (['OPTIONS', 'HEAD'].includes(req.method)) reqType = 'precheck';
    else if (req.method === 'GET' && semantic < 0.1 && param === 0) reqType = 'refresh';
    else if (confidence >= 0.5) reqType = 'action';

    results.push({
      id: generateId(),
      behaviorId: behavior.id,
      behavior: { type: behavior.type, text: behavior.elementText, page: behavior.pageContext?.path },
      request: { method: req.method, urlPath: new URL(req.url).pathname, url: req.url },
      confidence: Math.round(confidence * 100) / 100,
      evidence: {
        temporal: Math.round(temporal * 100) / 100,
        semantic: Math.round(semantic * 100) / 100,
        param,
      },
      reqType,
      timestamp: req.ts,
    });
  }

  return results.sort((a, b) => b.confidence - a.confidence);
}

async function saveWebRequestRecord(details) {
  const { requestId, tabId, method, url, statusCode, resourceType, startTime, reqHeaders, pageUrl, duration } = details;
  const urlPath = (() => { try { return new URL(url).pathname; } catch { return url; } })();

  const record = {
    id: generateId(),
    timestamp: startTime || Date.now(),
    tabId,
    method: method || 'GET',
    url,
    urlPath,
    resourceType: resourceType || 'other',
    requestHeaders: reqHeaders || {},
    requestBody: null,
    responseStatus: statusCode || 0,
    responseBody: null,
    pageUrl: pageUrl || '',
    pageContext: null,
    duration: duration ?? -1,
  };
  await put('requests', record);
  await evictOldest('requests', DB.REQUESTS_CAP, DB.REQUESTS_EVICT);
  return record;
}

// webRequest listeners
chrome.webRequest.onBeforeSendHeaders.addListener(
  details => {
    if (!capturing) return;
    if (details.tabId < 0) return;
    // Prune stale entries (requests that never completed)
    const now = Date.now();
    for (const [id, p] of wrPending) {
      if (now - p.startTime > 60000) wrPending.delete(id);
    }
    const reqHeaders = {};
    if (details.requestHeaders) details.requestHeaders.forEach(h => { reqHeaders[h.name] = h.value; });
    wrPending.set(details.requestId, {
      requestId: details.requestId,
      tabId: details.tabId,
      method: details.method,
      url: details.url,
      startTime: details.timeStamp,
      reqHeaders,
      resourceType: details.type,
      pageUrl: details.initiator || '',
    });
  },
  { urls: ['<all_urls>'] },
  ['requestHeaders']
);

chrome.webRequest.onCompleted.addListener(
  details => {
    const pending = wrPending.get(details.requestId);
    if (!pending) return;
    wrPending.delete(details.requestId);
    pending.statusCode = details.statusCode;
    pending.duration = details.timeStamp - (pending.startTime || details.timeStamp);
    saveWebRequestRecord(pending);
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

chrome.webRequest.onErrorOccurred.addListener(
  details => {
    const pending = wrPending.get(details.requestId);
    if (!pending) return;
    wrPending.delete(details.requestId);
    pending.statusCode = 0;
    pending.duration = -1;
    saveWebRequestRecord(pending);
  },
  { urls: ['<all_urls>'] }
);

// Clean up wrPending entries when a tab is closed
chrome.tabs.onRemoved.addListener(tabId => {
  for (const [id, p] of wrPending) {
    if (p.tabId === tabId) wrPending.delete(id);
  }
});

async function saveBehavior(payload) {
  const record = {
    id: generateId(),
    timestamp: payload.timestamp || Date.now(),
    type: payload.type,
    elementText: payload.elementText,
    elementTag: payload.elementTag,
    dataAttrs: payload.dataAttrs || {},
    ariaLabel: payload.ariaLabel,
    title: payload.title,
    rowData: payload.rowData || {},
    pageContext: payload.pageContext || null,
    pageUrl: payload.pageUrl,
  };
  await put('behaviors', record);
  await evictOldest('behaviors', DB.BEHAVIORS_CAP, DB.BEHAVIORS_EVICT);
  return record;
}

function setBadge(capturing) {
  chrome.action.setBadgeText({ text: capturing ? 'ON' : 'OFF' });
  chrome.action.setBadgeBackgroundColor({ color: capturing ? '#4ec94e' : '#e04e4e' });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'session' && 'capturing' in changes) {
    capturing = changes.capturing.newValue !== false;
    setBadge(capturing);
  }
});

chrome.runtime.onInstalled.addListener(() => setBadge(true));
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.session.get('capturing', r => setBadge(r.capturing !== false));
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  if (msg.type === 'RAW_REQUEST') {
    if (!capturing) return;
    const payload = { ...msg.payload, tabId };
    if (!isApiRequest(payload.url)) return;

    // Backfill: find the webRequest-saved record that lacks responseBody and update it
    if (tabId && payload.respBody != null) {
      const ts = payload.ts || Date.now();
      findAndBackfill('requests', payload.url, ts, {
        reqBody: payload.reqBody,
        respBody: payload.respBody,
        reqHeaders: payload.reqHeaders,
        status: payload.status,
        pageContext: payload.pageContext,
      }).then(found => {
        if (found) console.log('[SW] backfill: updated', payload.method, payload.url, 'with responseBody');
      }).catch(err => console.error('[SW] backfill failed:', err));
    }

    // Also push to correlation buffer (for behavior-API correlation)
    const buf = getBuffer(reqBuffer, tabId);
    pruneBuffer(buf);
    buf.push({ ...payload, ts: payload.ts || Date.now() });

    // Re-correlate pending behaviors
    const pending = getBuffer(pendingBehaviors, tabId);
    const now = Date.now();
    while (pending.length && now - pending[0].enqueuedAt > CORR.MAX_WINDOW) pending.shift();

    if (pending.length) console.log('[SW] re-correlate: new request', payload.method, payload.url, 'against', pending.length, 'pending behaviors');
    (async () => {
      for (const { behavior } of pending) {
        const mappings = correlate(behavior, buf);
        if (mappings.length) console.log('[SW] re-correlate found', mappings.length, 'mappings for', behavior.elementText);
        for (const m of mappings) {
          await put('mappings', m);
        }
      }
    })().catch(err => console.error('[SW] re-correlate failed:', err));
    return;
  }

  if (msg.type === 'RAW_BEHAVIOR') {
    if (!capturing) return;
    const payload = { ...msg.payload, tabId };
    console.log('[SW] RAW_BEHAVIOR received:', payload.elementText, 'tabId:', tabId, 'rowData:', JSON.stringify(payload.rowData));
    saveBehavior(payload).then(async behavior => {
      const buf = getBuffer(reqBuffer, tabId);
      pruneBuffer(buf);
      console.log('[SW] correlating behavior', behavior.elementText, 'against', buf.length, 'buffered requests');
      const mappings = correlate(behavior, buf);
      console.log('[SW] correlation result:', mappings.length, 'mappings');
      for (const m of mappings) {
        await put('mappings', m);
      }
      // Also add to pending for re-correlation when later requests arrive
      getBuffer(pendingBehaviors, tabId).push({ behavior, enqueuedAt: Date.now() });
    }).catch(err => console.error('[SW] saveBehavior/correlate failed:', err));
    return;
  }

  if (msg.type === 'GET_STATS') {
    Promise.all([count('requests'), count('behaviors'), count('mappings')])
      .then(([r, b, m]) => sendResponse({ totalRequests: r, totalBehaviors: b, totalMappings: m }))
      .catch(err => {
        console.error('[SW] GET_STATS failed:', err);
        sendResponse({ totalRequests: 0, totalBehaviors: 0, totalMappings: 0 });
      });
    return true;
  }

  if (msg.type === 'GET_EXPORT') {
    Promise.all([getAll('requests'), getAll('behaviors'), getAll('mappings')])
      .then(([requests, behaviors, mappings]) => {
        const outputs = buildOutputs(requests, behaviors, mappings);
        console.log('[SW] GET_EXPORT: requests=%d behaviors=%d mappings=%d apiAssets=%d pageApiMap=%d behaviorApiMap=%d',
          requests.length, behaviors.length, mappings.length,
          outputs.apiAssets.length, outputs.pageApiMap.length, outputs.behaviorApiMap.length);
        sendResponse({ requests, behaviors, mappings, ...outputs });
      })
      .catch(err => {
        console.error('[SW] GET_EXPORT failed:', err);
        sendResponse({ error: err.message, apiAssets: [], pageApiMap: [], behaviorApiMap: [] });
      });
    return true;
  }

  if (msg.type === 'GET_HISTORY') {
    const { page = 0, pageSize = 50, sort = { field: 'timestamp', dir: 'desc' }, filter = {} } = msg;
    const sortDir = sort.dir === 'asc' ? 'next' : 'prev';
    const filterFn = (record) => {
      if (filter.method && record.method !== filter.method) return false;
      if (filter.statusClass) {
        const s = record.responseStatus || 0;
        const cls = s >= 200 && s < 300 ? '2xx' : s >= 300 && s < 400 ? '3xx' : s >= 400 && s < 500 ? '4xx' : s >= 500 ? '5xx' : '';
        if (cls !== filter.statusClass) return false;
      }
      if (filter.resourceType) {
        const types = filter.resourceType.split(',');
        const rt = (record.resourceType || '').toLowerCase();
        if (!types.some(t => rt === t.trim().toLowerCase())) return false;
      }
      if (filter.search) {
        const url = (record.url || '').toLowerCase();
        if (!url.includes(filter.search.toLowerCase())) return false;
      }
      return true;
    };
    getPaged('requests', { page, pageSize, sortDir, filterFn })
      .then(result => {
        const items = result.items.map(r => ({
          id: r.id, timestamp: r.timestamp, method: r.method,
          url: r.url, urlPath: r.urlPath,
          responseStatus: r.responseStatus, resourceType: r.resourceType,
          duration: r.duration ?? -1, pageUrl: r.pageUrl,
          pageContext: r.pageContext,
        }));
        sendResponse({ items, total: result.total, page: result.page, pageSize: result.pageSize });
      })
      .catch(err => {
        console.error('[SW] GET_HISTORY failed:', err);
        sendResponse({ items: [], total: 0, page, pageSize, error: err.message });
      });
    return true;
  }

  if (msg.type === 'GET_HISTORY_DETAIL') {
    const { id } = msg;
    getById('requests', id)
      .then(record => {
        if (!record) { sendResponse({ error: 'Not found' }); return; }
        sendResponse({
          id: record.id, method: record.method, url: record.url,
          requestHeaders: record.requestHeaders || null,
          requestBody: record.requestBody || null,
          responseStatus: record.responseStatus,
          responseBody: record.responseBody || null,
          resourceType: record.resourceType,
          duration: record.duration ?? -1,
          timestamp: record.timestamp,
        });
      })
      .catch(err => {
        console.error('[SW] GET_HISTORY_DETAIL failed:', err);
        sendResponse({ error: err.message });
      });
    return true;
  }

  if (msg.type === 'REPLAY_REQUEST') {
    const { method, url, headers, body } = msg;
    const start = Date.now();
    const fetchOpts = { method: method || 'GET', headers: headers || {}, credentials: 'include' };
    if (body && method !== 'GET' && method !== 'HEAD') fetchOpts.body = body;
    fetch(url, fetchOpts).then(async resp => {
      const duration = Date.now() - start;
      const respHeaders = {};
      resp.headers.forEach((v, k) => { respHeaders[k] = v; });
      let responseBody = '';
      try { responseBody = await resp.text(); } catch { responseBody = '(unreadable)'; }
      sendResponse({
        responseStatus: resp.status,
        responseHeaders: respHeaders,
        responseBody,
        duration,
      });
    }).catch(err => {
      sendResponse({ error: err.message, responseStatus: 0, duration: Date.now() - start });
    });
    return true;
  }

  if (msg.type === 'PING') {
    sendResponse({ pong: true });
    return true;
  }

  if (msg.type === 'CLEAR_DATA') {
    Promise.all([clear('requests'), clear('behaviors'), clear('mappings')])
      .then(() => sendResponse({ ok: true }))
      .catch(err => {
        console.error('[SW] CLEAR_DATA failed:', err);
        sendResponse({ error: err.message });
      });
    return true;
  }
});

function buildOutputs(requests, behaviors, mappings) {
  // Output 1: API asset list
  const apiMap = new Map();
  for (const r of requests) {
    const key = `${r.method}:${r.urlPath}`;
    if (!apiMap.has(key)) {
      let host = '';
      try { host = new URL(r.url).host; } catch { host = ''; }
      apiMap.set(key, { method: r.method, urlPath: r.urlPath, host, resourceType: r.resourceType || r.initiatorType || '-', callCount: 0,
        firstSeen: r.timestamp, lastSeen: r.timestamp,
        sampleRequestHeaders: r.requestHeaders, sampleRequestBody: r.requestBody,
        sampleResponseBody: r.responseBody, pages: new Set(), records: [] });
    }
    const e = apiMap.get(key);
    e.callCount++;
    e.lastSeen = Math.max(e.lastSeen, r.timestamp);
    if (r.pageContext?.path) e.pages.add(r.pageContext.path);
    e.records.push({ timestamp: r.timestamp, method: r.method, status: r.responseStatus, pageUrl: r.pageUrl,
      bodyPreview: typeof r.requestBody === 'string' ? r.requestBody.slice(0, 200) : '' });
  }
  const apiAssets = [...apiMap.values()].map(e => ({ ...e, pages: [...e.pages] }));

  // Output 2: page → API mapping
  const pageMap = new Map();
  for (const r of requests) {
    const path = r.pageContext?.path;
    if (!path) continue;
    if (!pageMap.has(path)) {
      pageMap.set(path, { page: path, pageTitle: r.pageContext?.title,
        breadcrumb: r.pageContext?.breadcrumb || [], apis: new Map() });
    }
    const key = `${r.method}:${r.urlPath}`;
    const p = pageMap.get(path);
    if (!p.apis.has(key)) p.apis.set(key, { method: r.method, urlPath: r.urlPath, callCount: 0 });
    p.apis.get(key).callCount++;
  }

  // Enrich with behavior action names from mappings
  for (const m of mappings) {
    const path = m.behavior?.page;
    if (!path || !pageMap.has(path)) continue;
    const p = pageMap.get(path);
    if (!p.actions) p.actions = [];
    if (m.confidence >= 0.5 && !p.actions.find(a => a.api === m.request.urlPath)) {
      p.actions.push({ name: m.behavior.text, api: m.request.urlPath, method: m.request.method });
    }
  }

  const pageApiMap = [...pageMap.values()].map(p => ({
    ...p, apis: [...p.apis.values()], actions: p.actions || [],
  }));

  // Output 3: behavior → API mapping (include unmapped behaviors too)
  const behaviorMap = new Map();
  // First: add all behaviors from DB
  for (const b of behaviors) {
    const key = `${b.elementText || ''}:${b.pageContext?.path || ''}`;
    if (!behaviorMap.has(key)) {
      behaviorMap.set(key, {
        behavior: { type: b.type, text: b.elementText, page: b.pageContext?.path },
        mappings: [], occurrences: 0, records: []
      });
    }
    const entry = behaviorMap.get(key);
    entry.occurrences++;
    entry.records.push({ timestamp: b.timestamp, type: b.type, elementText: b.elementText, pageUrl: b.pageUrl });
  }
  // Then: add mapped results
  for (const m of mappings) {
    const key = `${m.behavior?.text}:${m.behavior?.page}`;
    if (!behaviorMap.has(key)) {
      behaviorMap.set(key, { behavior: m.behavior, mappings: [], occurrences: 0 });
    }
    const b = behaviorMap.get(key);
    if (!b.mappings.find(x => x.urlPath === m.request.urlPath)) {
      b.mappings.push({ method: m.request.method, urlPath: m.request.urlPath,
        confidence: m.confidence, evidence: m.evidence });
    }
  }
  const behaviorApiMap = [...behaviorMap.values()];

  return { apiAssets, pageApiMap, behaviorApiMap };
}

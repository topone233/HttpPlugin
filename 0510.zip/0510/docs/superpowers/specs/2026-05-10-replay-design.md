# Dashboard 内嵌增强重放器设计

## 概述

在现有 Dashboard 侧边栏新增"请求重放"tab，提供增强内嵌重放器。安全测试人员可从请求历史/行为映射一键跳转重放，支持变量替换、发送历史、保存为测试用例。

## UI 结构

### 侧边栏新增 tab

- 名称：请求重放
- 图标：发送箭头 SVG
- 位置：第4个 tab（历史之后）

### 主区域布局：左右两栏

**左栏——请求编辑器：**
- Method 下拉：GET / POST / PUT / DELETE / PATCH
- URL 输入框
- Headers 编辑区：key-value 对列表，每行可增删
- Body 编辑区：textarea，带 JSON 格式化按钮
- 变量面板（可折叠）：
  - 变量定义列表：key = value
  - 点击变量名插入 `{{key}}` 到当前焦点输入框
  - 内置变量：`{{timestamp}}`、`{{random}}`
- [发送] 按钮

**右栏——响应查看器：**
- 状态码 + 耗时
- 响应 Headers（可折叠 raw 显示）
- 响应 Body：自动检测 JSON 并格式化，带文本搜索
- [保存为用例] 按钮

**底部面板——历史 + 用例：**
- 历史列表：最近 50 条发送记录（Method / URL / 状态码 / 时间），点击重新加载到编辑器
- 用例列表：已保存用例（名称 / Method / URL），点击加载，支持重命名/删除

### 入口集成

- 请求历史表格：每行加"重放"按钮（"查看详情"旁）
- 请求详情 Modal：底部加"重放此请求"按钮
- 行为映射表格：关联 API 列加"重放"小按钮
- 点击后切换到重放 tab，自动填充 method / url / headers / body

## 数据存储

### IndexedDB 新增 object store

DB VERSION 从 2 升到 3，onupgradeneeded 建新 store。

**replayHistory：**
- 字段：id, timestamp, method, url, headers, body, variables, responseStatus, responseHeaders, responseBody, duration
- 索引：timestamp
- 上限：500 条，溢出淘汰 50 条

**testCases：**
- 字段：id, name, timestamp, method, url, headers, body, variables
- 索引：timestamp, name
- 无上限

### shared/db.js 变更

DB 对象新增常量：
```
REPLAY_HISTORY_CAP: 500,
REPLAY_HISTORY_EVICT: 50,
```

新增 `put` / `getAll` / `getPaged` / `evictOldest` / `clear` 对两个新 store 的支持。DB VERSION 升 3，onupgradeneeded 创建 store + 索引。

## 请求发送机制

**优先方案：** Dashboard 页面直接 `fetch()` 发送请求。Chrome 扩展页面配合 `<all_urls>` host_permissions，大部分场景无 CORS 问题。

**降级方案：** 若 fetch 因 CORS 失败，自动降级走 Service Worker 中转。

### SW 新增消息类型

`REPLAY_REQUEST`：
- 入参：method, url, headers, body
- SW 内用 `fetch()` 发送（SW 上下文同样有扩展权限）
- 返回：responseStatus, responseHeaders, responseBody, duration, error

Dashboard 逻辑：
```
try {
  response = await fetch(url, { method, headers, body });
} catch (corsError) {
  response = await chrome.runtime.sendMessage({ type: 'REPLAY_REQUEST', ... });
}
```

## 变量系统

- 语法：`{{variableName}}`，可用于 URL、Headers 值、Body 任意位置
- 变量定义区：key=value 列表，持久化到 `chrome.storage.local`（跨 session 保留）
- 内置变量：`{{timestamp}}`（当前毫秒时间戳）、`{{random}}`（0-9999 随机整数）
- 发送前替换：遍历变量表，正则 `/\{\{(\w+)\}\}/g` 替换所有匹配
- 校验：未定义变量高亮红色，阻止发送并提示"变量 xxx 未定义"

## 用例管理

- 保存：点击[保存为用例]弹出命名输入框（默认值：Method + URL path）
- 列表操作：点击加载、重命名（双击名称编辑）、删除（带确认）
- 导出：重放 tab 内单独的"导出用例"按钮，导出 testCases 为 JSON 文件

## 文件变更清单

| 文件 | 变更 |
|------|------|
| `shared/constants.js` | 新增 MSG.REPLAY_REQUEST |
| `shared/db.js` | DB VERSION 升 3，新增 replayHistory + testCases store |
| `dashboard/dashboard.html` | 新增重放 tab 按钮 + tab-panel 区域 + 重放 modal |
| `dashboard/dashboard.css` | 重放器样式（左右分栏、编辑器、响应区、变量面板） |
| `dashboard/dashboard.js` | 重放器逻辑（编辑、发送、变量、历史、用例） |
| `background/service-worker.js` | 新增 REPLAY_REQUEST 消息处理 |

## 风险与约束

- CORS：已设计降级方案，双路径覆盖
- DB 迁移：VERSION 升 3 是增量迁移，不影响现有 store 数据
- Dashboard 体积：replay tab 懒加载，不增加其他 tab 的渲染开销
- 变量安全：变量值不做执行，只做字符串替换，无注入风险

# Dashboard 内嵌增强重放器 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add an enhanced request replay tab to the Dashboard, enabling security testers to replay captured API requests with variable substitution, send history, and saved test cases.

**Architecture:** New "请求重放" tab in Dashboard sidebar. Left/right split panel: request editor on left, response viewer on right. Bottom panel for history and saved cases. Requests sent via direct `fetch()` with SW `REPLAY_REQUEST` fallback for CORS issues. Two new IndexedDB stores (`replayHistory`, `testCases`) added in DB v3 migration. Variable system uses `{{var}}` syntax persisted to `chrome.storage.local`.

**Tech Stack:** Vanilla JS, IndexedDB, Chrome Extension APIs (fetch, storage.session, runtime.sendMessage)

---

## File Structure

| File | Responsibility |
|------|---------------|
| `shared/constants.js` | Add `MSG.REPLAY_REQUEST` constant |
| `shared/db.js` | DB v3 migration, new `replayHistory` + `testCases` stores |
| `dashboard/dashboard.html` | Replay tab button, replay panel HTML, replay modals |
| `dashboard/dashboard.css` | Replay layout styles (split panel, editor, response, variables, history/cases) |
| `dashboard/dashboard.js` | Replay logic (editor, send, variables, history, cases, integration with existing tabs) |
| `background/service-worker.js` | `REPLAY_REQUEST` message handler (CORS fallback) |

---

### Task 1: DB Migration — replayHistory + testCases stores

**Files:**
- Modify: `shared/constants.js`
- Modify: `shared/db.js`

- [ ] **Step 1: Add REPLAY_REQUEST to constants**

In `shared/constants.js`, add to the `MSG` object:

```js
const MSG = {
  RAW_REQUEST: 'RAW_REQUEST',
  RAW_BEHAVIOR: 'RAW_BEHAVIOR',
  GET_STATS: 'GET_STATS',
  GET_EXPORT: 'GET_EXPORT',
  CLEAR_DATA: 'CLEAR_DATA',
  SET_CAPTURE: 'SET_CAPTURE',
  GET_CAPTURE: 'GET_CAPTURE',
  GET_HISTORY: 'GET_HISTORY',
  GET_HISTORY_DETAIL: 'GET_HISTORY_DETAIL',
  REPLAY_REQUEST: 'REPLAY_REQUEST',
};
```

Also add to the `DB` object:

```js
const DB = {
  NAME: 'sec_cap',
  VERSION: 3,
  REQUESTS_CAP: 5000,
  REQUESTS_EVICT: 500,
  BEHAVIORS_CAP: 2000,
  BEHAVIORS_EVICT: 200,
  REPLAY_HISTORY_CAP: 500,
  REPLAY_HISTORY_EVICT: 50,
};
```

- [ ] **Step 2: Update db.js — bump version and add stores**

In `shared/db.js`, change `indexedDB.open('sec_cap', 2)` to `indexedDB.open('sec_cap', 3)`.

Add inside the `onupgradeneeded` handler, after the existing `mappings` store creation:

```js
      if (!db.objectStoreNames.contains('replayHistory')) {
        const s = db.createObjectStore('replayHistory', { keyPath: 'id' });
        s.createIndex('timestamp', 'timestamp');
      }
      if (!db.objectStoreNames.contains('testCases')) {
        const s = db.createObjectStore('testCases', { keyPath: 'id' });
        s.createIndex('timestamp', 'timestamp');
        s.createIndex('name', 'name');
      }
```

The existing generic functions `put`, `getAll`, `count`, `clear`, `getById`, `getPaged`, `evictOldest` all accept a `store` name parameter — they will work with the new stores without code changes.

- [ ] **Step 3: Commit**

```bash
git add shared/constants.js shared/db.js
git commit -m "feat: add replayHistory and testCases stores to IndexedDB v3"
```

---

### Task 2: SW REPLAY_REQUEST handler

**Files:**
- Modify: `background/service-worker.js`

- [ ] **Step 1: Add REPLAY_REQUEST message handler**

In `background/service-worker.js`, inside the `chrome.runtime.onMessage.addListener` callback, after the `GET_HISTORY_DETAIL` block and before the `PING` block, add:

```js
  if (msg.type === 'REPLAY_REQUEST') {
    const { method, url, headers, body } = msg;
    const start = Date.now();
    const fetchOpts = { method: method || 'GET', headers: headers || {} };
    if (body && method !== 'GET' && method !== 'HEAD') fetchOpts.body = body;
    fetch(url, fetchOpts).then(async resp => {
      const duration = Date.now() - start;
      const respHeaders = {};
      resp.headers.forEach((v, k) => { respHeaders[k] = v; });
      let responseBody = '';
      try { responseBody = await resp.text(); } catch { responseBody = '(unreadable)'; }
      sendResponse({
        responseStatus: resp.status,
        responseHeaders: respHeaders,
        responseBody,
        duration,
      });
    }).catch(err => {
      sendResponse({ error: err.message, responseStatus: 0, duration: Date.now() - start });
    });
    return true;
  }
```

- [ ] **Step 2: Commit**

```bash
git add background/service-worker.js
git commit -m "feat: add REPLAY_REQUEST handler in service worker for CORS fallback"
```

---

### Task 3: Dashboard HTML — replay tab and panel structure

**Files:**
- Modify: `dashboard/dashboard.html`

- [ ] **Step 1: Add replay tab button to sidebar nav**

In `dashboard/dashboard.html`, after the history nav-item button (the one with `data-tab="history"`), add:

```html
      <button class="nav-item" data-tab="replay">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>
        </svg>
        <span>请求重放</span>
        <span class="nav-badge" id="badgeReplay">0</span>
      </button>
```

- [ ] **Step 2: Add replay tab-panel in the content-area**

In `dashboard/dashboard.html`, after `tab-history` div (the one with `class="tab-panel active"`), add:

```html
      <div id="tab-replay" class="tab-panel">
        <div class="replay-layout">
          <div class="replay-left">
            <div class="replay-section">
              <div class="replay-request-line">
                <select id="replayMethod" class="replay-method-select">
                  <option value="GET">GET</option>
                  <option value="POST">POST</option>
                  <option value="PUT">PUT</option>
                  <option value="DELETE">DELETE</option>
                  <option value="PATCH">PATCH</option>
                </select>
                <input id="replayUrl" type="text" class="replay-url-input" placeholder="https://api.example.com/endpoint" />
              </div>
            </div>
            <div class="replay-section">
              <div class="replay-section-header">
                <span class="replay-section-title">Headers</span>
                <button id="replayAddHeader" class="btn btn-ghost btn-sm" title="添加 Header">+</button>
              </div>
              <div id="replayHeaders" class="replay-headers-list">
                <div class="replay-header-row">
                  <input type="text" class="replay-hdr-key" placeholder="Header name" />
                  <input type="text" class="replay-hdr-val" placeholder="Value" />
                  <button class="btn btn-ghost btn-sm replay-hdr-del" title="删除">&times;</button>
                </div>
              </div>
            </div>
            <div class="replay-section">
              <div class="replay-section-header">
                <span class="replay-section-title">Body</span>
                <button id="replayFormatBody" class="btn btn-ghost btn-sm" title="格式化 JSON">{ }</button>
              </div>
              <textarea id="replayBody" class="replay-body-input" placeholder='{"key": "value"}'></textarea>
            </div>
            <div class="replay-section replay-vars-section">
              <div class="replay-section-header" id="replayVarsToggle" style="cursor:pointer">
                <span class="replay-section-title">变量</span>
                <span class="replay-vars-hint" id="replayVarsHint">点击展开</span>
              </div>
              <div id="replayVarsPanel" class="replay-vars-panel" style="display:none">
                <div class="replay-vars-builtin">
                  <span class="replay-var-chip" data-var="timestamp">{{timestamp}}</span>
                  <span class="replay-var-chip" data-var="random">{{random}}</span>
                </div>
                <div id="replayVarsList" class="replay-vars-list"></div>
                <div class="replay-var-add-row">
                  <input id="replayVarKey" type="text" class="replay-var-input" placeholder="变量名" />
                  <input id="replayVarVal" type="text" class="replay-var-input" placeholder="值" />
                  <button id="replayAddVar" class="btn btn-ghost btn-sm" title="添加变量">+</button>
                </div>
              </div>
            </div>
            <div class="replay-actions">
              <button id="replaySend" class="btn btn-primary btn-send">发送</button>
              <button id="replaySaveCase" class="btn btn-ghost" title="保存为用例">保存用例</button>
            </div>
          </div>
          <div class="replay-right">
            <div class="replay-response-status" id="replayRespStatus">
              <span class="replay-status-text">等待发送请求...</span>
            </div>
            <div class="replay-section">
              <div class="replay-section-header collapsible" id="replayRespHeadersToggle">
                <span class="replay-section-title">响应 Headers</span>
                <span class="replay-collapse-icon">▾</span>
              </div>
              <pre id="replayRespHeaders" class="replay-resp-headers" style="display:none"></pre>
            </div>
            <div class="replay-section replay-resp-body-section">
              <div class="replay-section-header">
                <span class="replay-section-title">响应 Body</span>
                <input id="replayRespSearch" type="text" class="replay-resp-search" placeholder="搜索..." />
              </div>
              <pre id="replayRespBody" class="replay-resp-body"></pre>
            </div>
          </div>
        </div>
        <div class="replay-bottom">
          <div class="replay-bottom-tabs">
            <button class="replay-bottom-tab active" data-replay-tab="history">发送历史</button>
            <button class="replay-bottom-tab" data-replay-tab="cases">已保存用例</button>
            <button class="btn btn-ghost btn-sm" id="replayExportCases" title="导出用例">导出</button>
          </div>
          <div class="replay-bottom-content">
            <div id="replayHistoryPanel" class="replay-bottom-panel active">
              <table class="replay-bottom-table">
                <thead><tr><th>方法</th><th>URL</th><th>状态</th><th>耗时</th><th>时间</th></tr></thead>
                <tbody id="replayHistoryBody"></tbody>
              </table>
            </div>
            <div id="replayCasesPanel" class="replay-bottom-panel">
              <table class="replay-bottom-table">
                <thead><tr><th>名称</th><th>方法</th><th>URL</th><th>操作</th></tr></thead>
                <tbody id="replayCasesBody"></tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
```

- [ ] **Step 3: Add save-case naming modal**

After the `historyDetailModal` div, add:

```html
<!-- 保存用例命名模态框 -->
<div id="saveCaseModal" class="modal-overlay" style="display:none">
  <div class="modal-dialog" style="width:400px">
    <div class="modal-header">
      <span class="modal-title">保存为测试用例</span>
      <button class="modal-close" id="saveCaseModalClose">&times;</button>
    </div>
    <div class="modal-body">
      <label style="display:block;margin-bottom:8px;font-size:13px;color:#64748b">用例名称</label>
      <input id="saveCaseName" type="text" class="replay-url-input" style="width:100%;margin-bottom:16px" placeholder="输入用例名称" />
      <button id="saveCaseConfirm" class="btn btn-primary" style="width:100%">保存</button>
    </div>
  </div>
</div>
```

- [ ] **Step 4: Add "重放" buttons to existing UI elements**

In the history table template inside `dashboard.js`, in the `renderHistory` function, change the detail button cell to include a replay button. Find this line in `renderHistory()`:

```js
      <td><button class="btn-detail" data-hist-id="${escapeHtml(r.id)}">查看详情</button></td>
```

Replace with:

```js
      <td>
        <button class="btn-detail" data-hist-id="${escapeHtml(r.id)}">查看详情</button>
        <button class="btn-replay" data-hist-id="${escapeHtml(r.id)}">重放</button>
      </td>
```

In the `openHistoryDetailModal` function, before `document.getElementById('historyDetailModal').style.display = 'flex';`, add a replay button to the modal. Find this line:

```js
    document.getElementById('historyDetailModal').style.display = 'flex';
```

Before it, add:

```js
    document.getElementById('histDetailReplay').onclick = () => {
      closeHistoryDetailModal();
      loadIntoReplay(r.method, r.url, r.requestHeaders || {}, r.requestBody || '');
    };
```

In `dashboard.html`, inside the `historyDetailModal` modal-body, after the last `modal-section` (响应 Body), add:

```html
      <div style="margin-top:16px;text-align:right">
        <button id="histDetailReplay" class="btn btn-primary">重放此请求</button>
      </div>
```

- [ ] **Step 5: Commit**

```bash
git add dashboard/dashboard.html
git commit -m "feat: add replay tab HTML structure and integration buttons"
```

---

### Task 4: Dashboard CSS — replay styles

**Files:**
- Modify: `dashboard/dashboard.css`

- [ ] **Step 1: Add replay styles at the end of dashboard.css**

Append after the last CSS rule:

```css
/* ===== Replay Tab ===== */
.replay-layout {
  display: flex; flex: 1; overflow: hidden; gap: 1px; background: #e2e8f0;
}
.replay-left, .replay-right {
  background: #fff; display: flex; flex-direction: column; overflow-y: auto;
}
.replay-left { flex: 1; padding: 16px; min-width: 0; }
.replay-right { flex: 1; padding: 16px; min-width: 0; }
.replay-section { margin-bottom: 12px; }
.replay-section-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 6px;
}
.replay-section-title {
  font-size: 11px; font-weight: 600; color: #64748b;
  text-transform: uppercase; letter-spacing: 0.5px;
}
.replay-request-line { display: flex; gap: 8px; }
.replay-method-select {
  padding: 8px 10px; border: 1px solid #e2e8f0; border-radius: 8px;
  font-size: 13px; font-weight: 700; color: #7c3aed; background: #f5f3ff;
  outline: none; min-width: 90px; cursor: pointer;
}
.replay-method-select:focus { border-color: #7c3aed; }
.replay-url-input {
  flex: 1; padding: 8px 12px; border: 1px solid #e2e8f0; border-radius: 8px;
  font-size: 13px; color: #1e293b; background: #f8fafc; outline: none;
}
.replay-url-input:focus { border-color: #7c3aed; background: #fff; }
.replay-headers-list { display: flex; flex-direction: column; gap: 4px; }
.replay-header-row { display: flex; gap: 6px; align-items: center; }
.replay-hdr-key, .replay-hdr-val {
  padding: 6px 10px; border: 1px solid #e2e8f0; border-radius: 6px;
  font-size: 12px; color: #1e293b; background: #f8fafc; outline: none;
}
.replay-hdr-key { width: 35%; }
.replay-hdr-val { flex: 1; }
.replay-hdr-key:focus, .replay-hdr-val:focus { border-color: #7c3aed; background: #fff; }
.replay-body-input {
  width: 100%; min-height: 120px; padding: 10px; border: 1px solid #e2e8f0;
  border-radius: 8px; font-size: 12px; color: #1e293b; background: #f8fafc;
  outline: none; resize: vertical; font-family: 'SF Mono', 'Cascadia Code', monospace;
}
.replay-body-input:focus { border-color: #7c3aed; background: #fff; }
.btn-sm { padding: 3px 8px; font-size: 16px; line-height: 1; }

/* Variables */
.replay-vars-hint { font-size: 11px; color: #94a3b8; }
.replay-vars-panel { margin-top: 8px; }
.replay-vars-builtin { display: flex; gap: 6px; margin-bottom: 8px; }
.replay-var-chip {
  font-size: 11px; padding: 2px 8px; border-radius: 4px;
  background: #f5f3ff; color: #7c3aed; cursor: pointer;
  font-family: 'SF Mono', 'Cascadia Code', monospace;
  border: 1px solid #ede9fe;
}
.replay-var-chip:hover { background: #ede9fe; }
.replay-var-chip.undefined { background: #fef2f2; color: #dc2626; border-color: #fecaca; }
.replay-vars-list { display: flex; flex-direction: column; gap: 4px; margin-bottom: 8px; }
.replay-var-row {
  display: flex; align-items: center; gap: 6px; font-size: 12px;
}
.replay-var-row .var-name { color: #7c3aed; font-weight: 600; min-width: 80px; font-family: 'SF Mono', 'Cascadia Code', monospace; }
.replay-var-row .var-eq { color: #94a3b8; }
.replay-var-row .var-val { color: #334155; flex: 1; }
.replay-var-row .var-del {
  background: none; border: none; color: #94a3b8; cursor: pointer;
  font-size: 14px; padding: 0 4px;
}
.replay-var-row .var-del:hover { color: #dc2626; }
.replay-var-add-row { display: flex; gap: 6px; }
.replay-var-input {
  padding: 5px 8px; border: 1px solid #e2e8f0; border-radius: 6px;
  font-size: 12px; outline: none; background: #f8fafc;
}
.replay-var-input:focus { border-color: #7c3aed; background: #fff; }

/* Actions */
.replay-actions { display: flex; gap: 8px; margin-top: 8px; }
.btn-send { flex: 1; padding: 10px; font-size: 14px; font-weight: 600; }

/* Response */
.replay-response-status {
  padding: 10px 14px; border-radius: 8px; margin-bottom: 12px;
  background: #f8fafc; border: 1px solid #e2e8f0;
}
.replay-status-text { font-size: 13px; color: #64748b; }
.replay-status-text.ok { color: #059669; }
.replay-status-text.err { color: #dc2626; }
.replay-resp-headers {
  background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px;
  padding: 10px; font-size: 11px; color: #64748b;
  max-height: 150px; overflow: auto; white-space: pre-wrap; word-break: break-all;
  font-family: 'SF Mono', 'Cascadia Code', monospace;
}
.replay-resp-body-section { flex: 1; display: flex; flex-direction: column; }
.replay-resp-body {
  background: #1e293b; color: #e2e8f0; border-radius: 8px;
  padding: 14px; font-size: 12px; line-height: 1.6;
  flex: 1; overflow: auto; white-space: pre-wrap; word-break: break-all;
  font-family: 'SF Mono', 'Cascadia Code', monospace;
}
.replay-resp-search {
  padding: 4px 8px; border: 1px solid #e2e8f0; border-radius: 6px;
  font-size: 12px; width: 140px; outline: none; background: #f8fafc;
}
.replay-resp-search:focus { border-color: #7c3aed; background: #fff; }
.replay-collapse-icon { font-size: 12px; color: #94a3b8; }
.replay-section-header.collapsible { cursor: pointer; }
.replay-section-header.collapsible:hover .replay-section-title { color: #7c3aed; }

/* Bottom panel */
.replay-bottom {
  border-top: 1px solid #e2e8f0; background: #fff;
  max-height: 200px; display: flex; flex-direction: column;
}
.replay-bottom-tabs {
  display: flex; align-items: center; gap: 0;
  padding: 0 12px; border-bottom: 1px solid #f1f5f9;
}
.replay-bottom-tab {
  padding: 8px 14px; border: none; background: transparent;
  font-size: 12px; color: #64748b; font-weight: 500; cursor: pointer;
  border-bottom: 2px solid transparent;
}
.replay-bottom-tab.active { color: #7c3aed; border-bottom-color: #7c3aed; }
.replay-bottom-tab:hover { color: #7c3aed; }
.replay-bottom-content { flex: 1; overflow: auto; }
.replay-bottom-panel { display: none; }
.replay-bottom-panel.active { display: block; }
.replay-bottom-table { width: 100%; border-collapse: collapse; font-size: 12px; }
.replay-bottom-table th {
  background: #f8fafc; padding: 6px 12px; text-align: left;
  font-size: 10px; font-weight: 600; color: #94a3b8;
  text-transform: uppercase; letter-spacing: 0.5px;
  border-bottom: 1px solid #e2e8f0;
}
.replay-bottom-table td {
  padding: 6px 12px; border-bottom: 1px solid #f1f5f9;
  font-size: 12px; color: #334155; cursor: pointer;
}
.replay-bottom-table tr:hover td { background: #f5f3ff; }

/* Replay buttons in existing tables */
.btn-replay {
  background: #f0fdf4; color: #16a34a; border: none;
  padding: 4px 12px; border-radius: 6px; font-size: 12px;
  font-weight: 500; cursor: pointer; transition: all 0.15s;
  margin-left: 4px;
}
.btn-replay:hover { background: #dcfce7; }

/* Variable undefined highlight in inputs */
.replay-url-input.var-undefined, .replay-body-input.var-undefined,
.replay-hdr-val.var-undefined {
  border-color: #fca5a5; background: #fef2f2;
}
```

- [ ] **Step 2: Commit**

```bash
git add dashboard/dashboard.css
git commit -m "feat: add replay tab styles"
```

---

### Task 5: Dashboard JS — replay core logic (editor, send, variables)

**Files:**
- Modify: `dashboard/dashboard.js`

This is the largest task. All replay JS goes into `dashboard/dashboard.js`.

- [ ] **Step 1: Add replay state and utility functions**

At the top of `dashboard/dashboard.js`, after the existing variable declarations (`let data = ...`, `let minConf = 0.15`, `let filterText = ''`), add:

```js
// ===== Replay State =====
const replayState = {
  history: [],
  cases: [],
  variables: {},
  _lastFocusEl: null,
};

const BUILTIN_VARS = {
  timestamp: () => String(Date.now()),
  random: () => String(Math.floor(Math.random() * 10000)),
};

function loadVariables() {
  chrome.storage.local.get('replayVariables', r => {
    replayState.variables = r.replayVariables || {};
    renderVariables();
  });
}

function saveVariables() {
  chrome.storage.local.set({ replayVariables: replayState.variables });
}

function applyVariables(text) {
  return text.replace(/\{\{(\w+)\}\}/g, (match, key) => {
    if (BUILTIN_VARS[key]) return BUILTIN_VARS[key]();
    if (replayState.variables[key] != null) return replayState.variables[key];
    return match;
  });
}

function findUndefinedVars(text) {
  const matches = text.match(/\{\{(\w+)\}\}/g) || [];
  return matches.map(m => m.slice(2, -2)).filter(k => !BUILTIN_VARS[k] && replayState.variables[k] == null);
}

function getAllUndefinedVars() {
  const url = document.getElementById('replayUrl').value;
  const body = document.getElementById('replayBody').value;
  const headerVals = [...document.querySelectorAll('.replay-hdr-val')].map(el => el.value);
  const texts = [url, body, ...headerVals];
  const all = new Set();
  for (const t of texts) {
    for (const v of findUndefinedVars(t)) all.add(v);
  }
  return [...all];
}

function highlightUndefinedVars() {
  const undefined = getAllUndefinedVars();
  // Remove existing highlights
  document.getElementById('replayUrl').classList.remove('var-undefined');
  document.getElementById('replayBody').classList.remove('var-undefined');
  document.querySelectorAll('.replay-hdr-val').forEach(el => el.classList.remove('var-undefined'));
  if (!undefined.length) return;
  // Highlight inputs containing undefined vars
  if (findUndefinedVars(document.getElementById('replayUrl').value).length)
    document.getElementById('replayUrl').classList.add('var-undefined');
  if (findUndefinedVars(document.getElementById('replayBody').value).length)
    document.getElementById('replayBody').classList.add('var-undefined');
  document.querySelectorAll('.replay-hdr-val').forEach(el => {
    if (findUndefinedVars(el.value).length) el.classList.add('var-undefined');
  });
}
```

- [ ] **Step 2: Add variable panel render and interaction**

After the functions above, add:

```js
function renderVariables() {
  const list = document.getElementById('replayVarsList');
  list.innerHTML = Object.entries(replayState.variables).map(([k, v]) => `
    <div class="replay-var-row">
      <span class="var-name">${escapeHtml(k)}</span>
      <span class="var-eq">=</span>
      <span class="var-val">${escapeHtml(v)}</span>
      <button class="var-del" data-var-key="${escapeHtml(k)}" title="删除">&times;</button>
    </div>
  `).join('');
  // Delete handlers
  list.querySelectorAll('.var-del').forEach(btn => {
    btn.addEventListener('click', () => {
      delete replayState.variables[btn.dataset.varKey];
      saveVariables();
      renderVariables();
      highlightUndefinedVars();
    });
  });
}

function insertVarAtFocus(varName) {
  const text = `{{${varName}}}`;
  const el = replayState._lastFocusEl;
  if (el && (el.id === 'replayUrl' || el.id === 'replayBody' || el.classList.contains('replay-hdr-val'))) {
    const start = el.selectionStart;
    const end = el.selectionEnd;
    el.value = el.value.slice(0, start) + text + el.value.slice(end);
    el.selectionStart = el.selectionEnd = start + text.length;
    el.focus();
  }
  highlightUndefinedVars();
}

function setupVariableInteractions() {
  // Toggle panel
  document.getElementById('replayVarsToggle').addEventListener('click', () => {
    const panel = document.getElementById('replayVarsPanel');
    const hint = document.getElementById('replayVarsHint');
    const visible = panel.style.display !== 'none';
    panel.style.display = visible ? 'none' : 'block';
    hint.textContent = visible ? '点击展开' : '点击收起';
  });

  // Track last focused input
  const trackFocus = e => {
    if (e.target.id === 'replayUrl' || e.target.id === 'replayBody' || e.target.classList.contains('replay-hdr-val')) {
      replayState._lastFocusEl = e.target;
    }
  };
  document.addEventListener('focusin', trackFocus);

  // Add variable
  document.getElementById('replayAddVar').addEventListener('click', () => {
    const keyEl = document.getElementById('replayVarKey');
    const valEl = document.getElementById('replayVarVal');
    const key = keyEl.value.trim();
    const val = valEl.value;
    if (!key) return;
    replayState.variables[key] = val;
    saveVariables();
    renderVariables();
    highlightUndefinedVars();
    keyEl.value = '';
    valEl.value = '';
  });

  // Builtin var chips — insert on click
  document.querySelectorAll('.replay-var-chip[data-var]').forEach(chip => {
    chip.addEventListener('click', () => insertVarAtFocus(chip.dataset.var));
  });

  // Live undefined var highlighting on input
  ['replayUrl', 'replayBody'].forEach(id => {
    document.getElementById(id).addEventListener('input', highlightUndefinedVars);
  });
}
```

- [ ] **Step 3: Add header row management**

```js
function setupHeaderRows() {
  document.getElementById('replayAddHeader').addEventListener('click', () => {
    addHeaderRow();
  });
  document.getElementById('replayHeaders').addEventListener('click', e => {
    const del = e.target.closest('.replay-hdr-del');
    if (del) del.closest('.replay-header-row').remove();
  });
}

function addHeaderRow(key = '', val = '') {
  const container = document.getElementById('replayHeaders');
  const row = document.createElement('div');
  row.className = 'replay-header-row';
  row.innerHTML = `
    <input type="text" class="replay-hdr-key" placeholder="Header name" value="${escapeHtml(key)}" />
    <input type="text" class="replay-hdr-val" placeholder="Value" value="${escapeHtml(val)}" />
    <button class="btn btn-ghost btn-sm replay-hdr-del" title="删除">&times;</button>
  `;
  container.appendChild(row);
}

function collectHeaders() {
  const headers = {};
  document.querySelectorAll('.replay-header-row').forEach(row => {
    const key = row.querySelector('.replay-hdr-key').value.trim();
    const val = applyVariables(row.querySelector('.replay-hdr-val').value);
    if (key) headers[key] = val;
  });
  return headers;
}

function setHeaders(headers) {
  const container = document.getElementById('replayHeaders');
  container.innerHTML = '';
  if (headers && typeof headers === 'object') {
    for (const [k, v] of Object.entries(headers)) {
      addHeaderRow(k, v);
    }
  }
  if (!container.children.length) addHeaderRow();
}
```

- [ ] **Step 4: Add send request logic**

```js
async function sendReplayRequest() {
  const undefined = getAllUndefinedVars();
  if (undefined.length) {
    alert(`未定义变量: ${undefined.join(', ')}\n请先在变量面板中定义或使用内置变量。`);
    return;
  }

  const method = document.getElementById('replayMethod').value;
  const rawUrl = document.getElementById('replayUrl').value.trim();
  const url = applyVariables(rawUrl);
  const headers = collectHeaders();
  const rawBody = document.getElementById('replayBody').value;
  const body = rawBody ? applyVariables(rawBody) : null;

  if (!url) { alert('请输入 URL'); return; }

  const statusEl = document.getElementById('replayRespStatus');
  statusEl.innerHTML = '<span class="replay-status-text">发送中...</span>';

  let result;
  try {
    const fetchOpts = { method, headers };
    if (body && method !== 'GET' && method !== 'HEAD') fetchOpts.body = body;
    const start = Date.now();
    const resp = await fetch(url, fetchOpts);
    const duration = Date.now() - start;
    const respHeaders = {};
    resp.headers.forEach((v, k) => { respHeaders[k] = v; });
    let responseBody = '';
    try { responseBody = await resp.text(); } catch { responseBody = '(unreadable)'; }
    result = { responseStatus: resp.status, responseHeaders: respHeaders, responseBody, duration, error: null };
  } catch (directErr) {
    // CORS fallback — route through service worker
    try {
      result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { type: 'REPLAY_REQUEST', method, url, headers, body },
          r => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(r);
          }
        );
      });
    } catch (swErr) {
      result = { responseStatus: 0, responseHeaders: {}, responseBody: '', duration: 0, error: swErr.message || directErr.message };
    }
  }

  // Display response
  displayReplayResponse(result);

  // Save to history
  const record = {
    id: generateId(),
    timestamp: Date.now(),
    method, url: rawUrl,
    headers: collectHeadersRaw(),
    body: rawBody,
    variables: { ...replayState.variables },
    responseStatus: result.responseStatus,
    responseHeaders: result.responseHeaders || {},
    responseBody: result.responseBody || '',
    duration: result.duration || 0,
  };
  await put('replayHistory', record);
  await evictOldest('replayHistory', DB.REPLAY_HISTORY_CAP, DB.REPLAY_HISTORY_EVICT);
  loadReplayHistory();
}

function collectHeadersRaw() {
  const headers = {};
  document.querySelectorAll('.replay-header-row').forEach(row => {
    const key = row.querySelector('.replay-hdr-key').value.trim();
    const val = row.querySelector('.replay-hdr-val').value;
    if (key) headers[key] = val;
  });
  return headers;
}

function displayReplayResponse(result) {
  const statusEl = document.getElementById('replayRespStatus');
  const headersEl = document.getElementById('replayRespHeaders');
  const bodyEl = document.getElementById('replayRespBody');

  if (result.error) {
    statusEl.innerHTML = `<span class="replay-status-text err">错误: ${escapeHtml(result.error)}</span>`;
    headersEl.textContent = '';
    bodyEl.textContent = '';
    return;
  }

  const sc = result.responseStatus >= 200 && result.responseStatus < 300 ? '2xx'
    : result.responseStatus >= 400 ? '4xx' : '0';
  statusEl.innerHTML = `<span class="status-badge status-${sc}">${result.responseStatus}</span>
    <span class="replay-status-text ok" style="margin-left:8px">${result.duration}ms</span>`;

  headersEl.textContent = JSON.stringify(result.responseHeaders, null, 2);

  // Auto-format JSON
  let bodyText = result.responseBody || '';
  try {
    const parsed = JSON.parse(bodyText);
    bodyText = JSON.stringify(parsed, null, 2);
  } catch { /* not JSON, show raw */ }
  bodyEl.textContent = bodyText;
}
```

- [ ] **Step 5: Add load-into-replay function (entry point from other tabs)**

```js
function loadIntoReplay(method, url, headers, body) {
  // Switch to replay tab
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelector('[data-tab="replay"]').classList.add('active');
  document.getElementById('tab-replay').classList.add('active');
  document.getElementById('confidenceSlider').style.display = 'none';

  // Fill editor
  document.getElementById('replayMethod').value = method || 'GET';
  document.getElementById('replayUrl').value = url || '';
  setHeaders(headers);
  document.getElementById('replayBody').value = typeof body === 'string' ? body : (body ? JSON.stringify(body) : '');
  highlightUndefinedVars();
}
```

- [ ] **Step 6: Add JSON format body button**

```js
function setupFormatBody() {
  document.getElementById('replayFormatBody').addEventListener('click', () => {
    const el = document.getElementById('replayBody');
    try {
      const parsed = JSON.parse(el.value);
      el.value = JSON.stringify(parsed, null, 2);
    } catch {
      alert('Body 不是有效的 JSON');
    }
  });
}
```

- [ ] **Step 7: Add collapsible response headers**

```js
function setupRespHeadersCollapse() {
  const toggle = document.getElementById('replayRespHeadersToggle');
  const content = document.getElementById('replayRespHeaders');
  const icon = toggle.querySelector('.replay-collapse-icon');
  toggle.addEventListener('click', () => {
    const visible = content.style.display !== 'none';
    content.style.display = visible ? 'none' : 'block';
    icon.textContent = visible ? '▸' : '▾';
  });
}
```

- [ ] **Step 8: Add response body search**

```js
function setupRespBodySearch() {
  document.getElementById('replayRespSearch').addEventListener('input', e => {
    const query = e.target.value.toLowerCase();
    const bodyEl = document.getElementById('replayRespBody');
    const text = bodyEl.textContent;
    if (!query) {
      bodyEl.textContent = text; // reset
      return;
    }
    // Simple highlight: wrap matches in <mark>
    const idx = text.toLowerCase().indexOf(query);
    if (idx >= 0) {
      const before = escapeHtml(text.slice(0, idx));
      const match = escapeHtml(text.slice(idx, idx + query.length));
      const after = escapeHtml(text.slice(idx + query.length));
      bodyEl.innerHTML = before + '<mark style="background:#fbbf24;color:#1e293b">' + match + '</mark>' + after;
    }
  });
}
```

- [ ] **Step 9: Wire up replay button event delegation in history table**

Add to the existing event delegation handler for `#tableHistory tbody` (which currently handles `[data-hist-id]` for detail buttons). Find this code:

```js
document.querySelector('#tableHistory tbody').addEventListener('click', e => {
  const btn = e.target.closest('[data-hist-id]');
  if (btn) openHistoryDetailModal(btn.dataset.histId);
});
```

Replace with:

```js
document.querySelector('#tableHistory tbody').addEventListener('click', e => {
  const detailBtn = e.target.closest('.btn-detail');
  if (detailBtn) { openHistoryDetailModal(detailBtn.dataset.histId); return; }
  const replayBtn = e.target.closest('.btn-replay');
  if (replayBtn) {
    const id = replayBtn.dataset.histId;
    chrome.runtime.sendMessage({ type: 'GET_HISTORY_DETAIL', id }, r => {
      if (chrome.runtime.lastError || !r || r.error) return;
      loadIntoReplay(r.method, r.url, r.requestHeaders || {}, r.requestBody || '');
    });
    return;
  }
});
```

- [ ] **Step 10: Commit**

```bash
git add dashboard/dashboard.js
git commit -m "feat: add replay editor, send, variables, and response display logic"
```

---

### Task 6: Dashboard JS — history and test cases management

**Files:**
- Modify: `dashboard/dashboard.js`

- [ ] **Step 1: Add replay history load and render**

```js
async function loadReplayHistory() {
  const items = await getAll('replayHistory');
  replayState.history = items.sort((a, b) => b.timestamp - a.timestamp);
  renderReplayHistory();
}

function renderReplayHistory() {
  const tbody = document.getElementById('replayHistoryBody');
  const rows = replayState.history.slice(0, 50);
  tbody.innerHTML = rows.map(r => {
    const fmtTs = new Date(r.timestamp).toLocaleTimeString();
    let urlDisplay = r.url;
    try { urlDisplay = new URL(r.url).pathname + new URL(r.url).search; } catch {}
    return `<tr>
      <td>${methodBadge(r.method)}</td>
      <td title="${escapeHtml(r.url)}">${escapeHtml(urlDisplay)}</td>
      <td><span class="status-badge status-${statusClass(r.responseStatus)}">${r.responseStatus || '-'}</span></td>
      <td>${r.duration >= 0 ? r.duration + 'ms' : '-'}</td>
      <td>${escapeHtml(fmtTs)}</td>
    </tr>`;
  }).join('');

  // Click to load into editor
  tbody.querySelectorAll('tr').forEach((tr, i) => {
    tr.addEventListener('click', () => {
      const r = rows[i];
      document.getElementById('replayMethod').value = r.method || 'GET';
      document.getElementById('replayUrl').value = r.url || '';
      setHeaders(r.headers);
      document.getElementById('replayBody').value = r.body || '';
      highlightUndefinedVars();
    });
  });

  document.getElementById('badgeReplay').textContent = replayState.history.length;
}
```

- [ ] **Step 2: Add test cases load, render, save, delete**

```js
async function loadReplayCases() {
  const items = await getAll('testCases');
  replayState.cases = items.sort((a, b) => b.timestamp - a.timestamp);
  renderReplayCases();
}

function renderReplayCases() {
  const tbody = document.getElementById('replayCasesBody');
  tbody.innerHTML = replayState.cases.map(c => {
    let urlDisplay = c.url;
    try { urlDisplay = new URL(c.url).pathname; } catch {}
    return `<tr>
      <td class="case-name" data-case-id="${escapeHtml(c.id)}">${escapeHtml(c.name)}</td>
      <td>${methodBadge(c.method)}</td>
      <td title="${escapeHtml(c.url)}">${escapeHtml(urlDisplay)}</td>
      <td>
        <button class="btn-detail case-delete" data-case-id="${escapeHtml(c.id)}" title="删除">删除</button>
      </td>
    </tr>`;
  }).join('');

  // Click row to load
  tbody.querySelectorAll('tr').forEach((tr, i) => {
    tr.addEventListener('click', e => {
      if (e.target.closest('.case-delete')) return;
      if (e.target.closest('.case-name')) return;
      const c = replayState.cases[i];
      loadIntoReplay(c.method, c.url, c.headers, c.body);
    });
  });

  // Double-click name to rename
  tbody.querySelectorAll('.case-name').forEach(td => {
    td.addEventListener('dblclick', () => {
      const id = td.dataset.caseId;
      const c = replayState.cases.find(x => x.id === id);
      if (!c) return;
      const newName = prompt('重命名用例:', c.name);
      if (newName && newName.trim()) {
        c.name = newName.trim();
        put('testCases', c).then(() => loadReplayCases());
      }
    });
  });

  // Delete
  tbody.querySelectorAll('.case-delete').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('确认删除此用例?')) return;
      const id = btn.dataset.caseId;
      const db = await openDb();
      await new Promise((resolve, reject) => {
        const t = db.transaction('testCases', 'readwrite');
        t.objectStore('testCases').delete(id);
        t.oncomplete = () => resolve();
        t.onerror = () => reject(t.error);
      });
      loadReplayCases();
    });
  });
}

function setupSaveCase() {
  const modal = document.getElementById('saveCaseModal');
  const nameInput = document.getElementById('saveCaseName');
  document.getElementById('replaySaveCase').addEventListener('click', () => {
    const method = document.getElementById('replayMethod').value;
    const url = document.getElementById('replayUrl').value;
    let defaultName = `${method} `;
    try { defaultName += new URL(url).pathname; } catch { defaultName += url; }
    nameInput.value = defaultName;
    modal.style.display = 'flex';
    nameInput.focus();
    nameInput.select();
  });
  document.getElementById('saveCaseModalClose').addEventListener('click', () => {
    modal.style.display = 'none';
  });
  modal.addEventListener('click', e => {
    if (e.target === modal) modal.style.display = 'none';
  });
  document.getElementById('saveCaseConfirm').addEventListener('click', async () => {
    const name = nameInput.value.trim() || 'Unnamed';
    const case_ = {
      id: generateId(),
      name,
      timestamp: Date.now(),
      method: document.getElementById('replayMethod').value,
      url: document.getElementById('replayUrl').value,
      headers: collectHeadersRaw(),
      body: document.getElementById('replayBody').value,
      variables: { ...replayState.variables },
    };
    await put('testCases', case_);
    modal.style.display = 'none';
    loadReplayCases();
  });
}
```

- [ ] **Step 3: Add export cases**

```js
function setupExportCases() {
  document.getElementById('replayExportCases').addEventListener('click', () => {
    const out = replayState.cases.map(c => ({
      name: c.name, method: c.method, url: c.url,
      headers: c.headers, body: c.body, variables: c.variables,
    }));
    const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `test-cases-${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
  });
}
```

- [ ] **Step 4: Add bottom tab switching**

```js
function setupReplayBottomTabs() {
  document.querySelectorAll('.replay-bottom-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.replay-bottom-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.replay-bottom-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(tab.dataset.replayTab === 'history' ? 'replayHistoryPanel' : 'replayCasesPanel').classList.add('active');
    });
  });
}
```

- [ ] **Step 5: Wire everything up in the startup flow**

In the existing startup health check block at the bottom of `dashboard.js`, find the `setInterval` callback inside the PING success handler. After the existing `load()` and `loadHistory()` calls, add initialization of the replay tab. Find this block:

```js
    load();
    loadHistory();
    setInterval(() => {
      load();
      const histTab = document.querySelector('[data-tab="history"]');
      if (histTab && histTab.classList.contains('active')) loadHistory();
    }, 5000);
```

After `loadHistory();`, add:

```js
    loadVariables();
    loadReplayHistory();
    loadReplayCases();
    setupHeaderRows();
    setupFormatBody();
    setupVariableInteractions();
    setupRespHeadersCollapse();
    setupRespBodySearch();
    setupSaveCase();
    setupExportCases();
    setupReplayBottomTabs();
    document.getElementById('replaySend').addEventListener('click', sendReplayRequest);
```

Also add `loadReplayHistory()` and `loadReplayCases()` into the `setInterval` callback, alongside the existing `loadHistory()` call. Find:

```js
      if (histTab && histTab.classList.contains('active')) loadHistory();
```

After it, add:

```js
      const replayTab = document.querySelector('[data-tab="replay"]');
      if (replayTab && replayTab.classList.contains('active')) {
        loadReplayHistory();
        loadReplayCases();
      }
```

- [ ] **Step 6: Commit**

```bash
git add dashboard/dashboard.js
git commit -m "feat: add replay history, test cases, and bottom panel management"
```

---

### Task 7: Behavior mapping replay button

**Files:**
- Modify: `dashboard/dashboard.js`

- [ ] **Step 1: Add replay buttons to behavior mapping API cells**

In the `renderBehaviors` function, find where mapped API paths are rendered in `<td>` cells. Find this pattern inside the `validMappings.map(m => ...)` template:

```js
      <td>${methodBadge(m.method)} ${escapeHtml(m.urlPath)}</td>
```

Replace with:

```js
      <td>${methodBadge(m.method)} ${escapeHtml(m.urlPath)} <button class="btn-replay btn-replay-behavior" data-replay-url="${escapeHtml(m.urlPath)}" data-replay-method="${escapeHtml(m.method)}">重放</button></td>
```

- [ ] **Step 2: Add event delegation for behavior replay buttons**

After the existing `#tableBehaviors tbody` click handler (the one for `.btn-records`), add:

```js
document.querySelector('#tableBehaviors tbody').addEventListener('click', e => {
  const replayBtn = e.target.closest('.btn-replay-behavior');
  if (!replayBtn) return;
  const method = replayBtn.dataset.replayMethod;
  const urlPath = replayBtn.dataset.replayUrl;
  // Find full URL from apiAssets (host + urlPath) or fall back to raw requests
  const apiMatch = data.apiAssets.find(a => a.method === method && a.urlPath === urlPath);
  let url = urlPath;
  if (apiMatch && apiMatch.host) {
    try { url = `https://${apiMatch.host}${urlPath}`; } catch {}
  }
  const headers = apiMatch?.sampleRequestHeaders || {};
  const body = apiMatch?.sampleRequestBody || '';
  loadIntoReplay(method, url, headers, body);
});
```

Note: this requires the existing `data.apiAssets` array from `GET_EXPORT` which already contains `sampleRequestHeaders` and `sampleRequestBody`.

- [ ] **Step 3: Commit**

```bash
git add dashboard/dashboard.js
git commit -m "feat: add replay buttons to behavior mapping table"
```

---

### Task 8: Manual smoke test

**Files:** None (testing only)

- [ ] **Step 1: Load extension and verify**

1. Open `chrome://extensions/`, click reload on the extension
2. Open Dashboard, verify "请求重放" tab appears in sidebar
3. Click the tab — verify left/right split layout renders
4. Navigate to any web app, capture some API requests
5. Go to 请求历史 tab, click "重放" on a request — verify it switches to replay tab with data filled
6. Click "发送" — verify response displays on the right
7. Define a variable (e.g., `userId = 1`), use `{{userId}}` in URL, send — verify variable is replaced
8. Use `{{timestamp}}` in body, send — verify builtin variable works
9. Click "保存用例", name it, verify it appears in bottom panel
10. Click the saved case — verify it loads into editor
11. Double-click case name to rename
12. Click "导出" — verify JSON file downloads
13. Click "重放此请求" in history detail modal — verify it works

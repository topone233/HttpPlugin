let data = { apiAssets: [], pageApiMap: [], behaviorApiMap: [], mappings: [] };
let minConf = 0.15;
let filterText = '';

// ===== Replay State =====
const replayState = {
  history: [],
  cases: [],
  variables: {},
  _lastFocusEl: null,
};

const BUILTIN_VARS = {
  timestamp: () => String(Date.now()),
  random: () => String(Math.floor(Math.random() * 10000)),
};

function loadVariables() {
  chrome.storage.local.get('replayVariables', r => {
    replayState.variables = r.replayVariables || {};
    renderVariables();
  });
}

function saveVariables() {
  chrome.storage.local.set({ replayVariables: replayState.variables });
}

function applyVariables(text) {
  return text.replace(/\{\{(\w+)\}\}/g, (match, key) => {
    if (BUILTIN_VARS[key]) return BUILTIN_VARS[key]();
    if (replayState.variables[key] != null) return replayState.variables[key];
    return match;
  });
}

function findUndefinedVars(text) {
  const matches = text.match(/\{\{(\w+)\}\}/g) || [];
  return matches.map(m => m.slice(2, -2)).filter(k => !BUILTIN_VARS[k] && replayState.variables[k] == null);
}

function getAllUndefinedVars() {
  const url = document.getElementById('replayUrl').value;
  const body = document.getElementById('replayBody').value;
  const headerVals = [...document.querySelectorAll('.replay-hdr-val')].map(el => el.value);
  const texts = [url, body, ...headerVals];
  const all = new Set();
  for (const t of texts) {
    for (const v of findUndefinedVars(t)) all.add(v);
  }
  return [...all];
}

function highlightUndefinedVars() {
  const undefinedVars = getAllUndefinedVars();
  document.getElementById('replayUrl').classList.remove('var-undefined');
  document.getElementById('replayBody').classList.remove('var-undefined');
  document.querySelectorAll('.replay-hdr-val').forEach(el => el.classList.remove('var-undefined'));
  if (!undefinedVars.length) return;
  if (findUndefinedVars(document.getElementById('replayUrl').value).length)
    document.getElementById('replayUrl').classList.add('var-undefined');
  if (findUndefinedVars(document.getElementById('replayBody').value).length)
    document.getElementById('replayBody').classList.add('var-undefined');
  document.querySelectorAll('.replay-hdr-val').forEach(el => {
    if (findUndefinedVars(el.value).length) el.classList.add('var-undefined');
  });
}

function renderVariables() {
  const list = document.getElementById('replayVarsList');
  list.innerHTML = Object.entries(replayState.variables).map(([k, v]) => `
    <div class="replay-var-row">
      <span class="var-name">${escapeHtml(k)}</span>
      <span class="var-eq">=</span>
      <span class="var-val">${escapeHtml(v)}</span>
      <button class="var-del" data-var-key="${escapeHtml(k)}" title="删除">&times;</button>
    </div>
  `).join('');
  list.querySelectorAll('.var-del').forEach(btn => {
    btn.addEventListener('click', () => {
      delete replayState.variables[btn.dataset.varKey];
      saveVariables();
      renderVariables();
      highlightUndefinedVars();
    });
  });
}

function insertVarAtFocus(varName) {
  const text = `{{${varName}}}`;
  const el = replayState._lastFocusEl;
  if (el && (el.id === 'replayUrl' || el.id === 'replayBody' || el.classList.contains('replay-hdr-val'))) {
    const start = el.selectionStart;
    const end = el.selectionEnd;
    el.value = el.value.slice(0, start) + text + el.value.slice(end);
    el.selectionStart = el.selectionEnd = start + text.length;
    el.focus();
  }
  highlightUndefinedVars();
}

function setupVariableInteractions() {
  document.getElementById('replayVarsToggle').addEventListener('click', () => {
    const panel = document.getElementById('replayVarsPanel');
    const hint = document.getElementById('replayVarsHint');
    const visible = panel.style.display !== 'none';
    panel.style.display = visible ? 'none' : 'block';
    hint.textContent = visible ? '点击展开' : '点击收起';
  });

  const trackFocus = e => {
    if (e.target.id === 'replayUrl' || e.target.id === 'replayBody' || e.target.classList.contains('replay-hdr-val')) {
      replayState._lastFocusEl = e.target;
    }
  };
  document.addEventListener('focusin', trackFocus);

  document.getElementById('replayAddVar').addEventListener('click', () => {
    const keyEl = document.getElementById('replayVarKey');
    const valEl = document.getElementById('replayVarVal');
    const key = keyEl.value.trim();
    const val = valEl.value;
    if (!key) return;
    replayState.variables[key] = val;
    saveVariables();
    renderVariables();
    highlightUndefinedVars();
    keyEl.value = '';
    valEl.value = '';
  });

  document.querySelectorAll('.replay-var-chip[data-var]').forEach(chip => {
    chip.addEventListener('click', () => insertVarAtFocus(chip.dataset.var));
  });

  ['replayUrl', 'replayBody'].forEach(id => {
    document.getElementById(id).addEventListener('input', highlightUndefinedVars);
  });
}

function setupHeaderRows() {
  document.getElementById('replayAddHeader').addEventListener('click', () => {
    addHeaderRow();
  });
  document.getElementById('replayHeaders').addEventListener('click', e => {
    const del = e.target.closest('.replay-hdr-del');
    if (del) del.closest('.replay-header-row').remove();
  });
}

function addHeaderRow(key = '', val = '') {
  const container = document.getElementById('replayHeaders');
  const row = document.createElement('div');
  row.className = 'replay-header-row';
  row.innerHTML = `
    <input type="text" class="replay-hdr-key" placeholder="Header name" value="${escapeHtml(key)}" />
    <input type="text" class="replay-hdr-val" placeholder="Value" value="${escapeHtml(val)}" />
    <button class="btn btn-ghost btn-sm replay-hdr-del" title="删除">&times;</button>
  `;
  container.appendChild(row);
}

function collectHeaders() {
  const headers = {};
  document.querySelectorAll('.replay-header-row').forEach(row => {
    const key = row.querySelector('.replay-hdr-key').value.trim();
    const val = applyVariables(row.querySelector('.replay-hdr-val').value);
    if (key) headers[key] = val;
  });
  return headers;
}

function collectHeadersRaw() {
  const headers = {};
  document.querySelectorAll('.replay-header-row').forEach(row => {
    const key = row.querySelector('.replay-hdr-key').value.trim();
    const val = row.querySelector('.replay-hdr-val').value;
    if (key) headers[key] = val;
  });
  return headers;
}

function setHeaders(headers) {
  const container = document.getElementById('replayHeaders');
  container.innerHTML = '';
  if (headers && typeof headers === 'object') {
    for (const [k, v] of Object.entries(headers)) {
      addHeaderRow(k, v);
    }
  }
  if (!container.children.length) addHeaderRow();
}

async function sendReplayRequest() {
  const undefinedVars = getAllUndefinedVars();
  if (undefinedVars.length) {
    alert(`未定义变量: ${undefinedVars.join(', ')}\n请先在变量面板中定义或使用内置变量。`);
    return;
  }

  const method = document.getElementById('replayMethod').value;
  const rawUrl = document.getElementById('replayUrl').value.trim();
  const url = applyVariables(rawUrl);
  const headers = collectHeaders();
  const rawBody = document.getElementById('replayBody').value;
  const body = rawBody ? applyVariables(rawBody) : null;

  if (!url) { alert('请输入 URL'); return; }

  const statusEl = document.getElementById('replayRespStatus');
  statusEl.innerHTML = '<span class="replay-status-text">发送中...</span>';

  let result;
  try {
    const fetchOpts = { method, headers, credentials: 'include' };
    if (body && method !== 'GET' && method !== 'HEAD') fetchOpts.body = body;
    const start = Date.now();
    const resp = await fetch(url, fetchOpts);
    const duration = Date.now() - start;
    const respHeaders = {};
    resp.headers.forEach((v, k) => { respHeaders[k] = v; });
    let responseBody = '';
    try { responseBody = await resp.text(); } catch { responseBody = '(unreadable)'; }
    result = { responseStatus: resp.status, responseHeaders: respHeaders, responseBody, duration, error: null };
  } catch (directErr) {
    try {
      result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { type: 'REPLAY_REQUEST', method, url, headers, body },
          r => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(r);
          }
        );
      });
    } catch (swErr) {
      result = { responseStatus: 0, responseHeaders: {}, responseBody: '', duration: 0, error: swErr.message || directErr.message };
    }
  }

  displayReplayResponse(result);

  const record = {
    id: generateId(),
    timestamp: Date.now(),
    method, url: rawUrl,
    headers: collectHeadersRaw(),
    body: rawBody,
    variables: { ...replayState.variables },
    responseStatus: result.responseStatus,
    responseHeaders: result.responseHeaders || {},
    responseBody: result.responseBody || '',
    duration: result.duration || 0,
  };
  await put('replayHistory', record);
  await evictOldest('replayHistory', DB.REPLAY_HISTORY_CAP, DB.REPLAY_HISTORY_EVICT);
  loadReplayHistory();
}

function displayReplayResponse(result) {
  const statusEl = document.getElementById('replayRespStatus');
  const headersEl = document.getElementById('replayRespHeaders');
  const bodyEl = document.getElementById('replayRespBody');

  if (result.error) {
    statusEl.innerHTML = `<span class="replay-status-text err">错误: ${escapeHtml(result.error)}</span>`;
    headersEl.textContent = '';
    bodyEl.textContent = '';
    return;
  }

  const sc = result.responseStatus >= 200 && result.responseStatus < 300 ? '2xx'
    : result.responseStatus >= 400 ? '4xx' : '0';
  statusEl.innerHTML = `<span class="status-badge status-${sc}">${result.responseStatus}</span>
    <span class="replay-status-text ok" style="margin-left:8px">${result.duration}ms</span>`;

  headersEl.textContent = JSON.stringify(result.responseHeaders, null, 2);

  let bodyText = result.responseBody || '';
  try {
    const parsed = JSON.parse(bodyText);
    bodyText = JSON.stringify(parsed, null, 2);
  } catch { /* not JSON, show raw */ }
  bodyEl.textContent = bodyText;
}

function loadIntoReplay(method, url, headers, body) {
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelector('[data-tab="replay"]').classList.add('active');
  document.getElementById('tab-replay').classList.add('active');
  document.getElementById('confidenceSlider').style.display = 'none';

  document.getElementById('replayMethod').value = method || 'GET';
  document.getElementById('replayUrl').value = url || '';
  setHeaders(headers);
  document.getElementById('replayBody').value = typeof body === 'string' ? body : (body ? JSON.stringify(body) : '');
  highlightUndefinedVars();
}

function setupFormatBody() {
  document.getElementById('replayFormatBody').addEventListener('click', () => {
    const el = document.getElementById('replayBody');
    try {
      const parsed = JSON.parse(el.value);
      el.value = JSON.stringify(parsed, null, 2);
    } catch {
      alert('Body 不是有效的 JSON');
    }
  });
}

function setupRespHeadersCollapse() {
  const toggle = document.getElementById('replayRespHeadersToggle');
  const content = document.getElementById('replayRespHeaders');
  const icon = toggle.querySelector('.replay-collapse-icon');
  toggle.addEventListener('click', () => {
    const visible = content.style.display !== 'none';
    content.style.display = visible ? 'none' : 'block';
    icon.textContent = visible ? '▸' : '▾';
  });
}

function setupRespBodySearch() {
  document.getElementById('replayRespSearch').addEventListener('input', e => {
    const query = e.target.value.toLowerCase();
    const bodyEl = document.getElementById('replayRespBody');
    const text = bodyEl.textContent;
    if (!query) {
      bodyEl.textContent = text;
      return;
    }
    const idx = text.toLowerCase().indexOf(query);
    if (idx >= 0) {
      const before = escapeHtml(text.slice(0, idx));
      const match = escapeHtml(text.slice(idx, idx + query.length));
      const after = escapeHtml(text.slice(idx + query.length));
      bodyEl.innerHTML = before + '<mark style="background:#fbbf24;color:#1e293b">' + match + '</mark>' + after;
    }
  });
}

// ===== Replay History & Test Cases =====
async function loadReplayHistory() {
  const items = await getAll('replayHistory');
  replayState.history = items.sort((a, b) => b.timestamp - a.timestamp);
  renderReplayHistory();
}

function renderReplayHistory() {
  const tbody = document.getElementById('replayHistoryBody');
  const rows = replayState.history.slice(0, 50);
  tbody.innerHTML = rows.map(r => {
    const fmtTs = new Date(r.timestamp).toLocaleTimeString();
    let urlDisplay = r.url;
    try { urlDisplay = new URL(r.url).pathname + new URL(r.url).search; } catch {}
    return `<tr>
      <td>${methodBadge(r.method)}</td>
      <td title="${escapeHtml(r.url)}">${escapeHtml(urlDisplay)}</td>
      <td><span class="status-badge status-${statusClass(r.responseStatus)}">${r.responseStatus || '-'}</span></td>
      <td>${r.duration >= 0 ? r.duration + 'ms' : '-'}</td>
      <td>${escapeHtml(fmtTs)}</td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('tr').forEach((tr, i) => {
    tr.addEventListener('click', () => {
      const r = rows[i];
      document.getElementById('replayMethod').value = r.method || 'GET';
      document.getElementById('replayUrl').value = r.url || '';
      setHeaders(r.headers);
      document.getElementById('replayBody').value = r.body || '';
      highlightUndefinedVars();
    });
  });

  document.getElementById('badgeReplay').textContent = replayState.history.length;
}

async function loadReplayCases() {
  const items = await getAll('testCases');
  replayState.cases = items.sort((a, b) => b.timestamp - a.timestamp);
  renderReplayCases();
}

function renderReplayCases() {
  const tbody = document.getElementById('replayCasesBody');
  tbody.innerHTML = replayState.cases.map(c => {
    let urlDisplay = c.url;
    try { urlDisplay = new URL(c.url).pathname; } catch {}
    return `<tr>
      <td class="case-name" data-case-id="${escapeHtml(c.id)}">${escapeHtml(c.name)}</td>
      <td>${methodBadge(c.method)}</td>
      <td title="${escapeHtml(c.url)}">${escapeHtml(urlDisplay)}</td>
      <td>
        <button class="btn-detail case-delete" data-case-id="${escapeHtml(c.id)}" title="删除">删除</button>
      </td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('tr').forEach((tr, i) => {
    tr.addEventListener('click', e => {
      if (e.target.closest('.case-delete')) return;
      if (e.target.closest('.case-name')) return;
      const c = replayState.cases[i];
      loadIntoReplay(c.method, c.url, c.headers, c.body);
    });
  });

  tbody.querySelectorAll('.case-name').forEach(td => {
    td.addEventListener('dblclick', () => {
      const id = td.dataset.caseId;
      const c = replayState.cases.find(x => x.id === id);
      if (!c) return;
      const newName = prompt('重命名用例:', c.name);
      if (newName && newName.trim()) {
        c.name = newName.trim();
        put('testCases', c).then(() => loadReplayCases());
      }
    });
  });

  tbody.querySelectorAll('.case-delete').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('确认删除此用例?')) return;
      const id = btn.dataset.caseId;
      const db = await openDb();
      await new Promise((resolve, reject) => {
        const t = db.transaction('testCases', 'readwrite');
        t.objectStore('testCases').delete(id);
        t.oncomplete = () => resolve();
        t.onerror = () => reject(t.error);
      });
      loadReplayCases();
    });
  });
}

function setupSaveCase() {
  const modal = document.getElementById('saveCaseModal');
  const nameInput = document.getElementById('saveCaseName');
  document.getElementById('replaySaveCase').addEventListener('click', () => {
    const method = document.getElementById('replayMethod').value;
    const url = document.getElementById('replayUrl').value;
    let defaultName = `${method} `;
    try { defaultName += new URL(url).pathname; } catch { defaultName += url; }
    nameInput.value = defaultName;
    modal.style.display = 'flex';
    nameInput.focus();
    nameInput.select();
  });
  document.getElementById('saveCaseModalClose').addEventListener('click', () => {
    modal.style.display = 'none';
  });
  modal.addEventListener('click', e => {
    if (e.target === modal) modal.style.display = 'none';
  });
  document.getElementById('saveCaseConfirm').addEventListener('click', async () => {
    const name = nameInput.value.trim() || 'Unnamed';
    const case_ = {
      id: generateId(),
      name,
      timestamp: Date.now(),
      method: document.getElementById('replayMethod').value,
      url: document.getElementById('replayUrl').value,
      headers: collectHeadersRaw(),
      body: document.getElementById('replayBody').value,
      variables: { ...replayState.variables },
    };
    await put('testCases', case_);
    modal.style.display = 'none';
    loadReplayCases();
  });
}

function setupExportCases() {
  document.getElementById('replayExportCases').addEventListener('click', () => {
    const out = replayState.cases.map(c => ({
      name: c.name, method: c.method, url: c.url,
      headers: c.headers, body: c.body, variables: c.variables,
    }));
    const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `test-cases-${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
  });
}

function setupReplayBottomTabs() {
  document.querySelectorAll('.replay-bottom-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.replay-bottom-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.replay-bottom-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(tab.dataset.replayTab === 'history' ? 'replayHistoryPanel' : 'replayCasesPanel').classList.add('active');
    });
  });
}

// History state
const hist = {
  page: 0, pageSize: 50, sort: { field: 'timestamp', dir: 'desc' },
  filter: { method: '', statusClass: '', resourceType: 'xmlhttprequest,fetch', search: '' },
  total: 0, items: [],
};
// RESOURCE_MAP loaded from shared/constants.js

const HTML_ESCAPE = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function escapeHtml(s) {
  return s == null ? '' : String(s).replace(/[&<>"']/g, c => HTML_ESCAPE[c]);
}

function confClass(c) { return c >= 0.7 ? 'high' : c >= 0.4 ? 'mid' : 'low'; }
function methodBadge(m) { const e = escapeHtml(m); return `<span class="method ${e}">${e}</span>`; }

function renderPages() {
  const tbody = document.querySelector('#tablePages tbody');
  const rows = data.pageApiMap.filter(p => !filterText || p.page.includes(filterText));
  tbody.innerHTML = rows.map(p => `
    <tr>
      <td><strong>${escapeHtml(p.page)}</strong></td>
      <td>${escapeHtml(p.pageTitle || '')}</td>
      <td><ul class="actions-list">${(p.actions || []).map(a =>
        `<li>${methodBadge(a.method)} ${escapeHtml(a.name)} &rarr; ${escapeHtml(a.api)}</li>`).join('')}</ul></td>
      <td>${(p.apis || []).map(a => `${methodBadge(a.method)} ${escapeHtml(a.urlPath)}`).join('<br>')}</td>
    </tr>`).join('');
}

function renderBehaviors() {
  const tbody = document.querySelector('#tableBehaviors tbody');
  let rows = data.behaviorApiMap.filter(b =>
    !filterText || (b.behavior?.text || '').includes(filterText)
  );
  // Sort: mapped first (by highest confidence), then unmapped, then by occurrences
  rows.sort((a, b) => {
    const aMax = Math.max(0, ...a.mappings.map(m => m.confidence));
    const bMax = Math.max(0, ...b.mappings.map(m => m.confidence));
    if (bMax !== aMax) return bMax - aMax;
    return (b.occurrences || 0) - (a.occurrences || 0);
  });

  tbody.innerHTML = rows.flatMap(b => {
    const validMappings = b.mappings.filter(m => m.confidence >= minConf);
    const recordsBtn = b.occurrences > 1
      ? `<button class="btn-records" data-behavior-key="${escapeHtml((b.behavior?.text || '') + ':' + (b.behavior?.page || ''))}">查看清单(${b.occurrences})</button>`
      : '';
    if (!validMappings.length) {
      return `<tr>
        <td><strong>${escapeHtml(b.behavior?.text || '(no text)')}</strong> ${recordsBtn}</td>
        <td>${escapeHtml(b.behavior?.page || '')}</td>
        <td colspan="3" style="color:#94a3b8;text-align:center">No correlated API</td>
      </tr>`;
    }
    return validMappings.map(m => `
    <tr>
      <td><strong>${escapeHtml(b.behavior?.text || '')}</strong> ${recordsBtn}</td>
      <td>${escapeHtml(b.behavior?.page || '')}</td>
      <td>${methodBadge(m.method)} ${escapeHtml(m.urlPath)} <button class="btn-replay btn-replay-behavior" data-replay-url="${escapeHtml(m.urlPath)}" data-replay-method="${escapeHtml(m.method)}">重放</button></td>
      <td><span class="conf ${confClass(m.confidence)}">${m.confidence.toFixed(2)}</span></td>
      <td>
        <div class="evidence-bar">
          <span class="evidence-item">T:<strong>${m.evidence?.temporal?.toFixed(2)}</strong></span>
          <span class="evidence-item">S:<strong>${m.evidence?.semantic?.toFixed(2)}</strong></span>
          <span class="evidence-item">P:<strong>${m.evidence?.param?.toFixed(2)}</strong></span>
        </div>
      </td>
    </tr>`);
  }).join('');
}

function updateStats() {
  const raw = data._raw || {};
  document.getElementById('statRequests').textContent = raw.totalRequests ?? 0;
  document.getElementById('statPages').textContent = data.pageApiMap.length;
  document.getElementById('statBehaviors').textContent = data.behaviorApiMap.length;
  document.getElementById('badgePages').textContent = data.pageApiMap.length;
  document.getElementById('badgeBehaviors').textContent = data.behaviorApiMap.length;
}

function render() { renderPages(); renderBehaviors(); updateStats(); }

// ===== History =====
function statusClass(s) {
  if (s >= 200 && s < 300) return '2xx';
  if (s >= 300 && s < 400) return '3xx';
  if (s >= 400 && s < 500) return '4xx';
  if (s >= 500) return '5xx';
  return '0';
}

function loadHistory() {
  const msg = {
    type: 'GET_HISTORY',
    page: hist.page,
    pageSize: hist.pageSize,
    sort: hist.sort,
    filter: hist.filter,
  };
  chrome.runtime.sendMessage(msg, r => {
    if (chrome.runtime.lastError || !r) return;
    hist.items = r.items || [];
    hist.total = r.total || 0;
    renderHistory();
  });
}

function renderHistory() {
  const tbody = document.querySelector('#tableHistory tbody');
  const fmtTs = ts => {
    const d = new Date(ts);
    return `${d.toLocaleDateString()} ${d.toLocaleTimeString()}.${String(d.getMilliseconds()).padStart(3,'0')}`;
  };
  const fmtDur = d => d >= 0 ? `${d}ms` : '-';
  const fmtUrl = url => {
    try { const u = new URL(url); return u.pathname + u.search; } catch { return url; }
  };

  tbody.innerHTML = hist.items.map(r => {
    const sc = statusClass(r.responseStatus);
    const rt = RESOURCE_MAP[r.resourceType] || r.resourceType || '-';
    return `<tr>
      <td class="hist-ts">${escapeHtml(fmtTs(r.timestamp))}</td>
      <td>${methodBadge(r.method)}</td>
      <td class="hist-url" title="${escapeHtml(r.url || '')}">${escapeHtml(fmtUrl(r.url || ''))}</td>
      <td><span class="status-badge status-${sc}">${r.responseStatus || '-'}</span></td>
      <td><span class="type-tag">${escapeHtml(rt)}</span></td>
      <td>${escapeHtml(fmtDur(r.duration))}</td>
      <td>${escapeHtml(r.pageContext?.path || r.pageUrl || '-')}</td>
      <td>
        <button class="btn-detail" data-hist-id="${escapeHtml(r.id)}">查看详情</button>
        <button class="btn-replay" data-hist-id="${escapeHtml(r.id)}">重放</button>
      </td>
    </tr>`;
  }).join('');

  // Count & pagination
  document.getElementById('histCount').textContent = `${hist.total} 条`;
  document.getElementById('badgeHistory').textContent = hist.total;
  const totalPages = Math.max(1, Math.ceil(hist.total / hist.pageSize));
  document.getElementById('histPageInfo').textContent = `${hist.page + 1} / ${totalPages}`;
  document.getElementById('histPrev').disabled = hist.page <= 0;
  document.getElementById('histNext').disabled = hist.page >= totalPages - 1;

  // Empty state
  const empty = document.getElementById('emptyHistory');
  empty.style.display = hist.items.length === 0 ? 'flex' : 'none';
}

// History detail modal
function openHistoryDetailModal(id) {
  chrome.runtime.sendMessage({ type: 'GET_HISTORY_DETAIL', id }, r => {
    if (chrome.runtime.lastError || !r || r.error) return;
    const isXhr = r.resourceType === 'xmlhttprequest' || r.resourceType === 'fetch';
    document.getElementById('histDetailTitle').textContent = `${r.method} ${r.url}`;
    document.getElementById('histDetailReqLine').innerHTML =
      `${methodBadge(r.method)} <span style="margin-left:8px">${escapeHtml(r.url)}</span>`;
    document.getElementById('histDetailReqHeaders').textContent =
      r.requestHeaders && Object.keys(r.requestHeaders).length
        ? JSON.stringify(r.requestHeaders, null, 2) : '(无)';
    const reqBodyEl = document.getElementById('histDetailReqBody');
    if (isXhr) {
      reqBodyEl.textContent = r.requestBody || '(无)';
      reqBodyEl.className = 'modal-pre';
    } else {
      reqBodyEl.textContent = '仅 fetch/XHR 请求支持查看请求体';
      reqBodyEl.className = 'modal-pre hist-body-hint';
    }
    const sc = statusClass(r.responseStatus);
    document.getElementById('histDetailRespLine').innerHTML =
      `<span class="status-badge status-${sc}">${r.responseStatus || '-'}</span>
       <span style="margin-left:8px">耗时: ${r.duration >= 0 ? r.duration + 'ms' : '-'}</span>`;
    const respBodyEl = document.getElementById('histDetailRespBody');
    if (isXhr) {
      respBodyEl.textContent = r.responseBody || '(无)';
      respBodyEl.className = 'modal-pre';
    } else {
      respBodyEl.textContent = '仅 fetch/XHR 请求支持查看响应体';
      respBodyEl.className = 'modal-pre hist-body-hint';
    }
    document.getElementById('histDetailReplay').onclick = () => {
      closeHistoryDetailModal();
      loadIntoReplay(r.method, r.url, r.requestHeaders || {}, r.requestBody || '');
    };
    document.getElementById('historyDetailModal').style.display = 'flex';
  });
}
function closeHistoryDetailModal() {
  document.getElementById('historyDetailModal').style.display = 'none';
}
document.getElementById('histDetailClose').addEventListener('click', closeHistoryDetailModal);
document.getElementById('historyDetailModal').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeHistoryDetailModal();
});

// History event delegation — detail & replay buttons
document.querySelector('#tableHistory tbody').addEventListener('click', e => {
  const detailBtn = e.target.closest('.btn-detail');
  if (detailBtn) { openHistoryDetailModal(detailBtn.dataset.histId); return; }
  const replayBtn = e.target.closest('.btn-replay');
  if (replayBtn) {
    const id = replayBtn.dataset.histId;
    chrome.runtime.sendMessage({ type: 'GET_HISTORY_DETAIL', id }, r => {
      if (chrome.runtime.lastError || !r || r.error) return;
      loadIntoReplay(r.method, r.url, r.requestHeaders || {}, r.requestBody || '');
    });
    return;
  }
});

// History filters
document.getElementById('histMethodFilter').addEventListener('change', e => {
  hist.filter.method = e.target.value;
  hist.page = 0;
  loadHistory();
});
document.getElementById('histStatusFilter').addEventListener('change', e => {
  hist.filter.statusClass = e.target.value;
  hist.page = 0;
  loadHistory();
});
document.getElementById('histTypeFilter').addEventListener('change', e => {
  hist.filter.resourceType = e.target.value;
  hist.page = 0;
  loadHistory();
});

// History search — reuse main filterInput
const origFilterInputHandler = document.getElementById('filterInput').oninput;

// History sort — click column headers
document.querySelectorAll('#tableHistory th.sortable').forEach(th => {
  th.addEventListener('click', () => {
    const field = th.dataset.sort;
    if (hist.sort.field === field) {
      hist.sort.dir = hist.sort.dir === 'desc' ? 'asc' : 'desc';
    } else {
      hist.sort.field = field;
      hist.sort.dir = 'desc';
    }
    // Update header indicators
    document.querySelectorAll('#tableHistory th.sortable').forEach(h => {
      h.textContent = h.textContent.replace(/ [↑↓]$/, '');
    });
    const label = th.textContent.replace(/ [↑↓]$/, '');
    th.textContent = label + (hist.sort.dir === 'desc' ? ' ↓' : ' ↑');
    hist.page = 0;
    loadHistory();
  });
});

// History pagination
document.getElementById('histPrev').addEventListener('click', () => {
  if (hist.page > 0) { hist.page--; loadHistory(); }
});
document.getElementById('histNext').addEventListener('click', () => {
  const totalPages = Math.ceil(hist.total / hist.pageSize);
  if (hist.page < totalPages - 1) { hist.page++; loadHistory(); }
});

function load() {
  chrome.runtime.sendMessage({ type: 'GET_EXPORT' }, r => {
    const err = chrome.runtime.lastError;
    if (err) {
      console.error('[Dashboard] sendMessage error:', err.message);
      return;
    }
    if (r && r.error) {
      console.error('[Dashboard] GET_EXPORT returned error:', r.error);
      return;
    }
    if (r) {
      data = r;
      console.log('[Dashboard] load: apiAssets=%d pageApiMap=%d behaviorApiMap=%d',
        (r.apiAssets || []).length, (r.pageApiMap || []).length, (r.behaviorApiMap || []).length);
      // Fetch raw counts separately for consistent stat display
      chrome.runtime.sendMessage({ type: 'GET_STATS' }, stats => {
        if (stats) data._raw = stats;
        render();
      });
      updateCaptureStatus();
    } else {
      console.warn('[Dashboard] load: empty response');
    }
  });
}

function updateCaptureStatus() {
  chrome.storage.session.get('capturing', s => {
    const el = document.getElementById('captureStatus');
    const on = s.capturing !== false;
    el.textContent = on ? '● 采集中' : '○ 已暂停';
    el.className = 'capture-status ' + (on ? 'on' : 'off');
  });
}

// Tab switching
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
    const slider = document.getElementById('confidenceSlider');
    slider.style.display = btn.dataset.tab === 'behaviors' ? 'flex' : 'none';
    if (btn.dataset.tab === 'history') loadHistory();
  });
});

// History search
document.getElementById('histSearchInput').addEventListener('input', e => {
  hist.filter.search = e.target.value;
  document.getElementById('histSearchClear').style.visibility = e.target.value ? 'visible' : 'hidden';
  hist.page = 0;
  loadHistory();
});
document.getElementById('histSearchClear').addEventListener('click', () => {
  document.getElementById('histSearchInput').value = '';
  hist.filter.search = '';
  document.getElementById('histSearchClear').style.visibility = 'hidden';
  hist.page = 0;
  loadHistory();
});
document.getElementById('histSearchClear').style.visibility = 'hidden';

// Search (pages / behaviors)
document.getElementById('filterInput').addEventListener('input', e => {
  filterText = e.target.value;
  document.getElementById('clearFilter').style.visibility = filterText ? 'visible' : 'hidden';
  render();
});
document.getElementById('clearFilter').addEventListener('click', () => {
  document.getElementById('filterInput').value = '';
  filterText = '';
  document.getElementById('clearFilter').style.visibility = 'hidden';
  render();
});
document.getElementById('clearFilter').style.visibility = 'hidden';

// Confidence slider
document.getElementById('confSlider').addEventListener('input', e => {
  minConf = e.target.value / 100;
  document.getElementById('confVal').textContent = minConf.toFixed(2);
  render();
});

document.getElementById('refreshBtn').addEventListener('click', load);

// Export
document.getElementById('exportBtn').addEventListener('click', () => {
  const out = {
    apiAssets: data.apiAssets,
    pageApiMap: data.pageApiMap,
    behaviorApiMap: data.behaviorApiMap,
  };
  const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `sec-cap-${Date.now()}.json`; a.click();
  URL.revokeObjectURL(url);
});

// Event delegation for behavior records & replay buttons
document.querySelector('#tableBehaviors tbody').addEventListener('click', e => {
  const recordsBtn = e.target.closest('.btn-records');
  if (recordsBtn) {
    const key = recordsBtn.dataset.behaviorKey;
    if (!key) return;
    const entry = data.behaviorApiMap.find(b => `${b.behavior?.text || ''}:${b.behavior?.page || ''}` === key);
    if (entry) openRecordsModal(entry.records, entry.behavior?.text || '行为');
    return;
  }
  const replayBtn = e.target.closest('.btn-replay-behavior');
  if (replayBtn) {
    const method = replayBtn.dataset.replayMethod;
    const urlPath = replayBtn.dataset.replayUrl;
    const apiMatch = data.apiAssets.find(a => a.method === method && a.urlPath === urlPath);
    let url = urlPath;
    if (apiMatch && apiMatch.host) {
      try { url = `https://${apiMatch.host}${urlPath}`; } catch {}
    }
    const headers = apiMatch?.sampleRequestHeaders || {};
    const body = apiMatch?.sampleRequestBody || '';
    loadIntoReplay(method, url, headers, body);
  }
});

// Records modal
function openRecordsModal(records, title) {
  const el = document.getElementById('recordsModal');
  document.getElementById('recordsTitle').textContent = `调用清单 — ${escapeHtml(title)}`;
  if (!records || !records.length) {
    document.getElementById('recordsTableBody').innerHTML = '<tr><td colspan="5" style="color:#94a3b8;text-align:center">无记录</td></tr>';
    el.style.display = 'flex';
    return;
  }
  const tbody = document.getElementById('recordsTableBody');
  const isApi = 'method' in records[0];
  if (isApi) {
    tbody.innerHTML = records.map(r => `<tr>
      <td>${escapeHtml(new Date(r.timestamp).toLocaleTimeString())}</td>
      <td>${methodBadge(r.method)}</td>
      <td>${escapeHtml(r.status || '-')}</td>
      <td>${escapeHtml(r.pageUrl || '-')}</td>
      <td><pre>${escapeHtml(r.bodyPreview || '-')}</pre></td>
    </tr>`).join('');
  } else {
    tbody.innerHTML = records.map(r => `<tr>
      <td>${escapeHtml(new Date(r.timestamp).toLocaleTimeString())}</td>
      <td>${escapeHtml(r.type || '-')}</td>
      <td>${escapeHtml(r.elementText || '-')}</td>
      <td>${escapeHtml(r.pageUrl || '-')}</td>
    </tr>`).join('');
  }
  el.style.display = 'flex';
}
function closeRecordsModal() {
  document.getElementById('recordsModal').style.display = 'none';
}
document.getElementById('recordsModalClose').addEventListener('click', closeRecordsModal);
document.getElementById('recordsModal').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeRecordsModal();
});

// Startup health check
chrome.runtime.sendMessage({ type: 'PING' }, r => {
  const err = chrome.runtime.lastError;
  if (err) {
    console.error('[Dashboard] Service worker unreachable:', err.message);
    document.getElementById('captureStatus').textContent = '⚠ 无法连接 Service Worker';
    document.getElementById('captureStatus').className = 'capture-status off';
  } else {
    console.log('[Dashboard] Service worker reachable, pong=%o', r);
    load();
    loadHistory();
    loadVariables();
    loadReplayHistory();
    loadReplayCases();
    setupHeaderRows();
    setupFormatBody();
    setupVariableInteractions();
    setupRespHeadersCollapse();
    setupRespBodySearch();
    setupSaveCase();
    setupExportCases();
    setupReplayBottomTabs();
    document.getElementById('replaySend').addEventListener('click', sendReplayRequest);
    setInterval(() => {
      load();
      // Refresh history if active
      const histTab = document.querySelector('[data-tab="history"]');
      if (histTab && histTab.classList.contains('active')) loadHistory();
      const replayTab = document.querySelector('[data-tab="replay"]');
      if (replayTab && replayTab.classList.contains('active')) {
        loadReplayHistory();
        loadReplayCases();
      }
    }, 5000);
  }
});

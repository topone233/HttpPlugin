(function () {
  const PREFIX = '__SEC_CAP_CTX__';
  const BREADCRUMB_SELS = [
    '.el-breadcrumb__item', '.ant-breadcrumb-link', '.arco-breadcrumb-item',
    '[aria-label="breadcrumb"] li', 'nav ol li', '.breadcrumb-item',
  ];
  const MENU_SELS = [
    '.el-menu-item.is-active', '.ant-menu-item-selected', '.arco-menu-item-selected',
    '[role="menuitem"][aria-selected="true"]', '.menu-item.active', '.nav-item.active',
  ];
  const MENU_DEPTH_LIMIT = 10;
  const MENU_PARENT_SEL = [
    '.el-sub-menu', '.el-submenu', '.ant-menu-submenu', '.arco-sub-menu',
    '.menu-group', '.nav-group', 'li', '[role="treeitem"]',
  ].join(',');
  const MENU_TITLE_SELS = [
    ':scope > .el-sub-menu__title', ':scope > .el-submenu__title',
    ':scope > .ant-menu-submenu-title', ':scope > .arco-menu-title',
    ':scope > .menu-title', ':scope > .nav-title', ':scope > a', ':scope > span',
  ];
  const QUERY_KEYS = ['id', 'code', 'key', 'type', 'tab', 'page', 'menu', 'route'];

  function cleanText(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
  }

  function textList(selector) {
    return [...document.querySelectorAll(selector)]
      .map(el => cleanText(el.textContent))
      .filter(Boolean);
  }

  function directText(el) {
    const chunks = [];
    for (const node of el.childNodes) {
      if (node.nodeType === Node.TEXT_NODE) {
        chunks.push(node.textContent);
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        const child = node;
        if (child.matches('ul,ol,[role="menu"],[role="group"],.el-menu,.ant-menu,.arco-menu')) continue;
        if (child.matches('svg,i,.icon,[class*="icon"]')) continue;
        chunks.push(child.textContent);
      }
    }
    return cleanText(chunks.join(' '));
  }

  function menuLabel(el) {
    for (const sel of MENU_TITLE_SELS) {
      const title = el.querySelector(sel);
      const text = cleanText(title?.textContent);
      if (text) return text;
    }
    return directText(el) || cleanText(el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent);
  }

  function parentMenuNode(el) {
    let node = el.parentElement;
    while (node && node !== document.body) {
      if (node.matches(MENU_PARENT_SEL) && menuLabel(node)) return node;
      node = node.parentElement;
    }
    return null;
  }

  function menuPathFromActive(el) {
    const path = [];
    let node = el;
    while (node && node !== document.body && path.length < MENU_DEPTH_LIMIT) {
      const label = menuLabel(node);
      if (label && !path.includes(label)) path.unshift(label);
      node = parentMenuNode(node);
    }
    return path.slice(-MENU_DEPTH_LIMIT);
  }

  function extractBreadcrumb() {
    for (const sel of BREADCRUMB_SELS) {
      const items = textList(sel);
      if (items.length > 1) return items;
    }
    return [];
  }

  function extractMenuPath() {
    for (const sel of MENU_SELS) {
      const activeItems = [...document.querySelectorAll(sel)];
      for (const item of activeItems) {
        const path = menuPathFromActive(item);
        if (path.length) return path;
      }
      const items = textList(sel);
      if (items.length) return [...new Set(items)].slice(0, MENU_DEPTH_LIMIT);
    }
    return [];
  }

  function normalizedSearch() {
    const params = new URLSearchParams(location.search);
    const selected = [];
    for (const key of QUERY_KEYS) {
      if (params.has(key)) selected.push(`${key}=${params.get(key)}`);
    }
    return selected.length ? `?${selected.join('&')}` : '';
  }

  function currentPageKey(ctx) {
    const hash = location.hash && location.hash !== '#' ? location.hash : '';
    const menu = ctx.menuPath?.length ? `|menu:${ctx.menuPath.join('/')}` : '';
    const crumb = ctx.breadcrumb?.length ? `|bc:${ctx.breadcrumb.join('/')}` : '';
    return `${ctx.path}${normalizedSearch()}${hash}${menu || crumb}`;
  }

  function getCurrentContext() {
    const ctx = {
      path: location.pathname,
      search: location.search,
      hash: location.hash,
      title: document.title,
      breadcrumb: extractBreadcrumb(),
      menuPath: extractMenuPath(),
      url: location.href,
    };
    ctx.pageKey = currentPageKey(ctx);
    return ctx;
  }

  function postContext() {
    window.postMessage({ __type: PREFIX, data: getCurrentContext() }, '*');
  }

  window.__SEC_CAP_CTX__ = getCurrentContext;
  postContext();

  let debounceTimer = 0;
  let lastSerialized = '';
  const notify = () => {
    if (debounceTimer) return;
    debounceTimer = setTimeout(() => {
      debounceTimer = 0;
      const ctx = getCurrentContext();
      const serialized = JSON.stringify(ctx);
      if (serialized === lastSerialized) return;
      lastSerialized = serialized;
      window.__SEC_CAP_CTX__ = getCurrentContext;
      window.postMessage({ __type: PREFIX, data: ctx }, '*');
    }, 300);
  };

  const origPush = history.pushState;
  const origReplace = history.replaceState;
  history.pushState = function (...a) { origPush.apply(this, a); notify(); };
  history.replaceState = function (...a) { origReplace.apply(this, a); notify(); };
  window.addEventListener('popstate', notify);
  window.addEventListener('hashchange', notify);

  function startObserver() {
    if (!document.body) return;
    new MutationObserver(notify).observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  if (document.body) {
    startObserver();
  } else {
    document.addEventListener('DOMContentLoaded', startObserver, { once: true });
  }
})();

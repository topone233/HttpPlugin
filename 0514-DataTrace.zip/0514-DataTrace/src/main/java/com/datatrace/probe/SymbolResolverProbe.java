package com.datatrace.probe;

import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.resolution.UnsolvedSymbolException;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 探针：统计 JavaSymbolSolver 在目标项目上的类型解析成功率。
 * 用法：java -jar datatrace.jar <目标项目src/main/java路径>
 */
public class SymbolResolverProbe {

    public static void main(String[] args) throws IOException {
        if (args.length == 0) {
            System.err.println("用法: java -jar datatrace.jar <src/main/java路径> [路径2] [路径3] ...");
            System.exit(1);
        }

        // 支持多模块：收集所有源码根目录
        List<Path> srcRoots = new ArrayList<>();
        for (String arg : args) {
            Path p = Paths.get(arg).toAbsolutePath();
            if (!Files.isDirectory(p)) { System.err.println("跳过（不存在）: " + p); continue; }
            srcRoots.add(p);
            System.out.println("源码根: " + p);
        }
        if (srcRoots.isEmpty()) { System.err.println("没有有效路径"); System.exit(1); }

        System.out.println("正在收集 .java 文件...");
        List<Path> javaFiles = new ArrayList<>();
        for (Path r : srcRoots) javaFiles.addAll(collectJavaFiles(r));
        System.out.println("共找到 " + javaFiles.size() + " 个 .java 文件\n");

        CombinedTypeSolver typeSolver = new CombinedTypeSolver(new ReflectionTypeSolver(false));
        for (Path r : srcRoots) typeSolver.add(new JavaParserTypeSolver(r));
        JavaSymbolSolver symbolSolver = new JavaSymbolSolver(typeSolver);
        ParserConfiguration config = new ParserConfiguration().setSymbolResolver(symbolSolver);
        StaticJavaParser.setConfiguration(config);

        AtomicInteger totalExpressions = new AtomicInteger();
        AtomicInteger resolved = new AtomicInteger();
        AtomicInteger unsolvedSymbol = new AtomicInteger();
        AtomicInteger otherFailure = new AtomicInteger();
        AtomicInteger parseError = new AtomicInteger();

        Map<String, Integer> unsolvedByType = new LinkedHashMap<>();

        for (Path file : javaFiles) {
            CompilationUnit cu;
            try {
                cu = StaticJavaParser.parse(file);
            } catch (Exception e) {
                parseError.incrementAndGet();
                System.err.println("  [PARSE ERROR] " + file + ": " + e.getMessage());
                continue;
            }

            // 对每个方法调用表达式尝试解析类型
            cu.findAll(MethodCallExpr.class).forEach(expr -> {
                totalExpressions.incrementAndGet();
                try {
                    expr.resolve();
                    resolved.incrementAndGet();
                } catch (UnsolvedSymbolException e) {
                    unsolvedSymbol.incrementAndGet();
                    String key = e.getName() != null ? e.getName() : "unknown";
                    unsolvedByType.merge(key, 1, Integer::sum);
                } catch (Exception e) {
                    otherFailure.incrementAndGet();
                }
            });

            // 对字段访问表达式尝试解析类型
            cu.findAll(FieldAccessExpr.class).forEach(expr -> {
                totalExpressions.incrementAndGet();
                try {
                    expr.resolve();
                    resolved.incrementAndGet();
                } catch (UnsolvedSymbolException e) {
                    unsolvedSymbol.incrementAndGet();
                    String key = e.getName() != null ? e.getName() : "unknown";
                    unsolvedByType.merge(key, 1, Integer::sum);
                } catch (Exception e) {
                    otherFailure.incrementAndGet();
                }
            });
        }

        int total = totalExpressions.get();
        int failed = unsolvedSymbol.get() + otherFailure.get();
        double resolveRate = total == 0 ? 0 : (resolved.get() * 100.0 / total);
        double unsolvedRate = total == 0 ? 0 : (unsolvedSymbol.get() * 100.0 / total);

        System.out.println("========== JavaSymbolSolver 解析率报告 ==========");
        System.out.printf("解析文件数:       %d  (解析失败: %d)%n", javaFiles.size(), parseError.get());
        System.out.printf("总表达式数:       %d%n", total);
        System.out.printf("解析成功:         %d  (%.1f%%)%n", resolved.get(), resolveRate);
        System.out.printf("UnsolvedSymbol:   %d  (%.1f%%)%n", unsolvedSymbol.get(), unsolvedRate);
        System.out.printf("其他失败:         %d  (%.1f%%)%n", otherFailure.get(), total == 0 ? 0 : otherFailure.get() * 100.0 / total);
        System.out.println();

        // 判定
        if (resolveRate >= 90) {
            System.out.println("结论: [PASS] 解析率 >= 90%，过程间分析可信，可以继续。");
        } else if (resolveRate >= 70) {
            System.out.println("结论: [WARN] 解析率 70%~90%，需要降级策略（保守标记污点）。");
        } else {
            System.out.println("结论: [FAIL] 解析率 < 70%，过程间分析不可信，建议考虑字节码分析方案。");
        }

        // 输出 Top 10 未解析符号
        if (!unsolvedByType.isEmpty()) {
            System.out.println("\nTop 未解析符号（按频次）:");
            unsolvedByType.entrySet().stream()
                    .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                    .limit(10)
                    .forEach(e -> System.out.printf("  %-40s %d 次%n", e.getKey(), e.getValue()));
        }
    }

    private static List<Path> collectJavaFiles(Path root) throws IOException {
        List<Path> files = new ArrayList<>();
        Files.walkFileTree(root, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (file.toString().endsWith(".java")) files.add(file);
                return FileVisitResult.CONTINUE;
            }
        });
        return files;
    }
}

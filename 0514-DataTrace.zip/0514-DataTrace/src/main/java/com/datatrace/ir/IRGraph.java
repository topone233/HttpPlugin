package com.datatrace.ir;

import java.util.*;

public class IRGraph {
    public final Map<String, IRNode> nodes = new LinkedHashMap<>();
    public final List<IREdge> edges = new ArrayList<>();

    public IRNode addNode(IRNode node) {
        nodes.putIfAbsent(node.id, node);
        return nodes.get(node.id);
    }

    public void addEdge(IRNode from, IRNode to, EdgeType type, String metadata) {
        edges.add(new IREdge(from, to, type, metadata));
    }

    public List<IREdge> inEdges(IRNode node) {
        List<IREdge> result = new ArrayList<>();
        for (IREdge e : edges) if (e.to == node) result.add(e);
        return result;
    }
}

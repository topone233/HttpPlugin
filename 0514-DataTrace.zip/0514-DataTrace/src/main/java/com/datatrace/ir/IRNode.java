package com.datatrace.ir;

public class IRNode {
    public final String id;
    public final NodeType type;
    public final String ownerClass;
    public final String fieldName;
    public final String sourceType;
    public String level;
    public boolean tainted;

    public IRNode(String id, NodeType type, String ownerClass, String fieldName, String sourceType) {
        this.id = id;
        this.type = type;
        this.ownerClass = ownerClass;
        this.fieldName = fieldName;
        this.sourceType = sourceType;
    }

    @Override public String toString() { return ownerClass + "." + fieldName; }
}

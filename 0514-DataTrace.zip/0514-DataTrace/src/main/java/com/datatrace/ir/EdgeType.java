package com.datatrace.ir;

public enum EdgeType {
    MAP_TO, ASSIGN, COPY, CALL, RETURN, SERIALIZE, LOG_OUTPUT
}

package com.datatrace.ir;

public enum NodeType {
    DB_FIELD, JAVA_FIELD, METHOD_PARAM, OBJECT, LOG_SINK, JSON_SINK
}

package com.datatrace.ir;

public class IREdge {
    public final IRNode from;
    public final IRNode to;
    public final EdgeType type;
    public final String metadata;

    public IREdge(IRNode from, IRNode to, EdgeType type, String metadata) {
        this.from = from;
        this.to = to;
        this.type = type;
        this.metadata = metadata;
    }
}

package com.datatrace.model;

public class AssetField {
    public final String table;
    public final String column;
    public final String level;

    public AssetField(String table, String column, String level) {
        this.table = table;
        this.column = column;
        this.level = level;
    }

    @Override public String toString() { return table + "." + column + "[" + level + "]"; }
}

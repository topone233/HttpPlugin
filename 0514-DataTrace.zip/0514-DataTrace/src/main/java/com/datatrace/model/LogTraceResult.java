package com.datatrace.model;

import java.util.List;

public class LogTraceResult {
    public String dbField;
    public String javaField;
    public String sink;
    public String file;
    public int line;
    public List<String> path;
}

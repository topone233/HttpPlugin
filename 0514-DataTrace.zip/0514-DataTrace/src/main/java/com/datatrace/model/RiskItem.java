package com.datatrace.model;

import java.util.List;

public class RiskItem {
    public String riskLevel;
    public String sink;
    public String file;
    public int line;
    public String taintedObject;
    public String sourceField;
    public List<String> path;
}

package com.datatrace.module;

import com.datatrace.model.AssetField;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/** 模块A：从JSON文件导入数据库机密字段清单 */
public class AssetImportModule {

    public List<AssetField> load(Path jsonFile) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        List<Map<String, String>> raw = mapper.readValue(jsonFile.toFile(),
                new TypeReference<>() {});
        return raw.stream()
                .map(m -> new AssetField(m.get("table"), m.get("column"), m.get("level")))
                .toList();
    }
}

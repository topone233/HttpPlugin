package com.datatrace.module;

import com.datatrace.ir.*;
import com.datatrace.model.LogTraceResult;

import java.util.*;

public class LogTraceModule {

    public List<LogTraceResult> trace(IRGraph graph, String fieldHint) {
        // Build outEdges index (IRGraph only exposes inEdges)
        Map<IRNode, List<IREdge>> outEdges = new HashMap<>();
        for (IREdge e : graph.edges)
            outEdges.computeIfAbsent(e.from, k -> new ArrayList<>()).add(e);

        // Seed: DB_FIELD nodes matching the hint
        Queue<IRNode> queue = new ArrayDeque<>();
        Set<IRNode> visited = new HashSet<>();
        for (IRNode n : graph.nodes.values()) {
            if (n.type == NodeType.DB_FIELD && matchesHint(n, fieldHint)) {
                queue.add(n);
                visited.add(n);
            }
        }

        // BFS forward through propagation edges
        List<LogTraceResult> results = new ArrayList<>();
        while (!queue.isEmpty()) {
            IRNode cur = queue.poll();
            List<IREdge> outs = outEdges.getOrDefault(cur, List.of());
            for (IREdge e : outs) {
                if (e.type == EdgeType.LOG_OUTPUT) {
                    results.add(buildResult(graph, cur, e));
                } else if (isPropagation(e.type) && visited.add(e.to)) {
                    queue.add(e.to);
                }
            }
        }
        return results;
    }

    private LogTraceResult buildResult(IRGraph graph, IRNode node, IREdge logEdge) {
        LogTraceResult r = new LogTraceResult();
        r.dbField = findDbSource(graph, node);
        r.javaField = node.toString();
        r.sink = logEdge.to.fieldName;
        r.file = parseFile(logEdge.metadata);
        r.line = parseLine(logEdge.metadata);
        r.path = buildPath(graph, node, logEdge.to);
        return r;
    }

    private boolean matchesHint(IRNode n, String hint) {
        if (hint.contains("."))
            return (n.ownerClass + "." + n.fieldName).equalsIgnoreCase(hint);
        String col = n.fieldName;
        return col.equalsIgnoreCase(hint)
                || col.equalsIgnoreCase(toSnakeCase(hint))
                || col.equalsIgnoreCase(toCamelCase(hint));
    }

    private boolean isPropagation(EdgeType t) {
        return t == EdgeType.ASSIGN || t == EdgeType.COPY
                || t == EdgeType.MAP_TO || t == EdgeType.SERIALIZE;
    }

    private String findDbSource(IRGraph graph, IRNode node) {
        Set<String> visited = new HashSet<>();
        IRNode cur = node;
        while (cur != null && visited.add(cur.id)) {
            if (cur.type == NodeType.DB_FIELD) return cur.toString();
            cur = graph.inEdges(cur).stream().map(e -> e.from).filter(n -> n.tainted).findFirst().orElse(null);
        }
        return node.toString();
    }

    private List<String> buildPath(IRGraph graph, IRNode tainted, IRNode sink) {
        List<String> path = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        IRNode cur = tainted;
        while (cur != null && visited.add(cur.id)) {
            path.add(0, cur.toString());
            cur = graph.inEdges(cur).stream().map(e -> e.from).filter(n -> n.tainted).findFirst().orElse(null);
        }
        path.add(sink.fieldName);
        return path;
    }

    private static String toCamelCase(String snake) {
        StringBuilder sb = new StringBuilder();
        boolean upper = false;
        for (char c : snake.toCharArray()) {
            if (c == '_') { upper = true; }
            else { sb.append(upper ? Character.toUpperCase(c) : c); upper = false; }
        }
        return sb.toString();
    }

    private static String toSnakeCase(String camel) {
        StringBuilder sb = new StringBuilder();
        for (char c : camel.toCharArray()) {
            if (Character.isUpperCase(c)) { sb.append('_').append(Character.toLowerCase(c)); }
            else { sb.append(c); }
        }
        return sb.toString();
    }

    private static String parseFile(String metadata) {
        if (metadata == null) return "";
        int i = metadata.lastIndexOf(':');
        return i > 0 ? metadata.substring(0, i) : metadata;
    }

    private static int parseLine(String metadata) {
        if (metadata == null) return 0;
        int i = metadata.lastIndexOf(':');
        if (i < 0) return 0;
        try { return Integer.parseInt(metadata.substring(i + 1)); } catch (NumberFormatException e) { return 0; }
    }
}

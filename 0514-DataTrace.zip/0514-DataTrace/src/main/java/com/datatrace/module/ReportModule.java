package com.datatrace.module;

import com.datatrace.model.RiskItem;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.nio.file.Path;
import java.util.List;

/** 模块G：输出 JSON 和 Excel 报告 */
public class ReportModule {

    public void writeJson(List<RiskItem> risks, Path out) throws IOException {
        new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT)
                .writeValue(out.toFile(), risks);
    }

    public void writeExcel(List<RiskItem> risks, Path out) throws IOException {
        try (Workbook wb = new XSSFWorkbook()) {
            Sheet sheet = wb.createSheet("风险报告");
            String[] headers = {"风险等级", "Sink", "文件", "行号", "污染对象", "来源字段", "传播路径"};
            Row header = sheet.createRow(0);
            for (int i = 0; i < headers.length; i++) header.createCell(i).setCellValue(headers[i]);

            int rowNum = 1;
            for (RiskItem r : risks) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(r.riskLevel);
                row.createCell(1).setCellValue(r.sink);
                row.createCell(2).setCellValue(r.file);
                row.createCell(3).setCellValue(r.line);
                row.createCell(4).setCellValue(r.taintedObject);
                row.createCell(5).setCellValue(r.sourceField);
                row.createCell(6).setCellValue(String.join(" → ", r.path));
            }
            try (FileOutputStream fos = new FileOutputStream(out.toFile())) { wb.write(fos); }
        }
    }
}

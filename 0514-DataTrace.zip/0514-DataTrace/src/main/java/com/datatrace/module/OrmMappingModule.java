package com.datatrace.module;

import com.datatrace.ir.*;
import com.datatrace.model.AssetField;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.select.*;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.expression.Expression;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

/**
 * 模块B：ORM/SQL字段映射恢复
 * 支持：MyBatis ResultMap、SQL alias、mapUnderscoreToCamelCase
 */
public class OrmMappingModule {

    private final IRGraph graph;
    private final boolean camelCase;
    private TypeIndexModule typeIndex;

    public OrmMappingModule(IRGraph graph, boolean camelCase) {
        this.graph = graph;
        this.camelCase = camelCase;
    }

    public OrmMappingModule withTypeIndex(TypeIndexModule typeIndex) {
        this.typeIndex = typeIndex;
        return this;
    }

    /**
     * 处理资产字段列表，扫描mapper.xml，生成 DB_FIELD → JAVA_FIELD 的 MAP_TO 边。
     * @param assets 机密字段清单
     * @param srcRoots 源码根目录（用于查找mapper.xml）
     */
    public void process(List<AssetField> assets, List<Path> srcRoots) throws IOException {
        // table.column -> AssetField
        Map<String, AssetField> assetMap = new HashMap<>();
        for (AssetField a : assets) assetMap.put(key(a.table, a.column), a);

        // 收集所有mapper.xml
        List<Path> xmlFiles = new ArrayList<>();
        for (Path root : srcRoots) {
            Path res = root.getParent().resolve("resources");
            if (Files.isDirectory(res)) collectXml(res, xmlFiles);
            collectXml(root, xmlFiles);
        }

        for (Path xml : xmlFiles) processXml(xml, assetMap);

        // camelCase 推导：对没有被 ResultMap 覆盖的资产字段做自动推导
        for (AssetField a : assets) {
            String javaField = camelCase ? toCamelCase(a.column) : a.column;
            String nodeId = "db:" + a.table + "." + a.column;
            if (!graph.nodes.containsKey(nodeId)) {
                IRNode dbNode = dbNode(a, nodeId);
                // 用类型索引查找哪个Java类有这个字段，找不到才用表名占位
                String ownerClass = findOwnerClass(javaField, a.table);
                IRNode javaNode = javaNode(ownerClass, javaField, "CAMEL_CASE");
                graph.addNode(dbNode);
                graph.addNode(javaNode);
                graph.addEdge(dbNode, javaNode, EdgeType.MAP_TO, "camelCase");
            }
        }
    }

    private void processXml(Path xml, Map<String, AssetField> assetMap) {
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xml.toFile());
            String namespace = attr(doc.getDocumentElement(), "namespace");

            // ResultMap
            NodeList resultMaps = doc.getElementsByTagName("resultMap");
            for (int i = 0; i < resultMaps.getLength(); i++) {
                Element rm = (Element) resultMaps.item(i);
                String javaType = simpleType(attr(rm, "type"));
                NodeList results = rm.getElementsByTagName("result");
                for (int j = 0; j < results.getLength(); j++) {
                    Element r = (Element) results.item(j);
                    String col = attr(r, "column");
                    String prop = attr(r, "property");
                    if (col.isEmpty() || prop.isEmpty()) continue;
                    // 找匹配的资产字段（不知道表名，按列名匹配）
                    AssetField asset = findByColumn(assetMap, col);
                    if (asset == null) continue;
                    String nodeId = "db:" + asset.table + "." + asset.column;
                    IRNode dbNode = graph.addNode(dbNode(asset, nodeId));
                    IRNode javaNode = graph.addNode(javaNode(javaType, prop, "XML_RESULTMAP"));
                    graph.addEdge(dbNode, javaNode, EdgeType.MAP_TO, "resultMap:" + xml.getFileName());
                }
            }

            // SQL alias（select语句中的 col as alias）
            NodeList selects = doc.getElementsByTagName("select");
            for (int i = 0; i < selects.getLength(); i++) {
                String sql = selects.item(i).getTextContent();
                processAlias(sql, assetMap, namespace);
            }
        } catch (Exception ignored) {}
    }

    private void processAlias(String sql, Map<String, AssetField> assetMap, String namespace) {
        try {
            // 清理MyBatis占位符，避免JSQLParser报错
            String cleaned = sql.replaceAll("#\\{[^}]+}", "?").replaceAll("\\$\\{[^}]+}", "?")
                    .replaceAll("<[^>]+>", " ").trim();
            net.sf.jsqlparser.statement.Statement stmt = CCJSqlParserUtil.parse(cleaned);
            if (!(stmt instanceof net.sf.jsqlparser.statement.select.Select)) return;
            PlainSelect ps = (PlainSelect) ((Select) stmt).getPlainSelect();
            for (SelectItem<?> item : ps.getSelectItems()) {
                if (item.getAlias() == null) continue;
                String alias = item.getAlias().getName();
                Expression expr = item.getExpression();
                String col = expr instanceof Column ? ((Column) expr).getColumnName() : null;
                if (col == null) continue;
                AssetField asset = findByColumn(assetMap, col);
                if (asset == null) continue;
                String nodeId = "db:" + asset.table + "." + asset.column;
                IRNode dbNode = graph.addNode(dbNode(asset, nodeId));
                IRNode javaNode = graph.addNode(javaNode(simpleType(namespace), alias, "SQL_ALIAS"));
                graph.addEdge(dbNode, javaNode, EdgeType.MAP_TO, "sqlAlias");
            }
        } catch (Exception ignored) {}
    }

    private String findOwnerClass(String fieldName, String tableName) {
        if (typeIndex != null) {
            for (String cls : typeIndex.getSimpleClassNames()) {
                if (typeIndex.getFields(cls).contains(fieldName)) return cls;
            }
        }
        String camel = toCamelCase(tableName);
        return Character.toUpperCase(camel.charAt(0)) + camel.substring(1).replaceAll("s$", "");
    }

    private static AssetField findByColumn(Map<String, AssetField> assetMap, String col) {
        for (Map.Entry<String, AssetField> e : assetMap.entrySet())
            if (e.getValue().column.equalsIgnoreCase(col)) return e.getValue();
        return null;
    }

    private static IRNode dbNode(AssetField a, String id) {
        IRNode n = new IRNode(id, NodeType.DB_FIELD, a.table, a.column, "DB_COLUMN");
        n.level = a.level;
        n.tainted = true;
        return n;
    }

    private static IRNode javaNode(String ownerClass, String fieldName, String sourceType) {
        String id = "java:" + ownerClass + "." + fieldName;
        return new IRNode(id, NodeType.JAVA_FIELD, ownerClass, fieldName, sourceType);
    }

    private static String key(String table, String col) { return table + "." + col; }

    private static String attr(Element e, String name) {
        return e.hasAttribute(name) ? e.getAttribute(name) : "";
    }

    private static String simpleType(String fqn) {
        if (fqn == null || fqn.isEmpty()) return "Unknown";
        int dot = fqn.lastIndexOf('.');
        return dot >= 0 ? fqn.substring(dot + 1) : fqn;
    }

    static String toCamelCase(String snake) {
        StringBuilder sb = new StringBuilder();
        boolean upper = false;
        for (char c : snake.toCharArray()) {
            if (c == '_') { upper = true; }
            else { sb.append(upper ? Character.toUpperCase(c) : c); upper = false; }
        }
        return sb.toString();
    }

    private static void collectXml(Path dir, List<Path> out) throws IOException {
        if (!Files.isDirectory(dir)) return;
        Files.walkFileTree(dir, new SimpleFileVisitor<>() {
            @Override public FileVisitResult visitFile(Path f, BasicFileAttributes a) {
                if (f.toString().endsWith(".xml")) out.add(f);
                return FileVisitResult.CONTINUE;
            }
        });
    }
}

package com.datatrace.module;

import com.datatrace.ir.*;
import com.datatrace.model.RiskItem;

import java.util.*;

/** 模块F：遍历IRGraph，找出所有 tainted节点 → LOG_SINK/JSON_SINK 的路径，生成风险报告 */
public class RiskJudgeModule {

    public List<RiskItem> judge(IRGraph graph) {
        List<RiskItem> risks = new ArrayList<>();

        for (IRNode sink : graph.nodes.values()) {
            if (sink.type != NodeType.LOG_SINK && sink.type != NodeType.JSON_SINK) continue;

            for (IREdge e : graph.inEdges(sink)) {
                if (!e.from.tainted) continue;

                RiskItem item = new RiskItem();
                item.sink = sink.fieldName;
                item.file = parseFile(sink.ownerClass);
                item.line = parseLine(e.metadata);
                item.taintedObject = e.from.ownerClass;
                item.sourceField = findDbSource(graph, e.from);
                item.path = buildPath(graph, e.from, sink);
                item.riskLevel = riskLevel(e.from.level);
                risks.add(item);
            }
        }
        return risks;
    }

    private List<String> buildPath(IRGraph graph, IRNode tainted, IRNode sink) {
        // 反向追溯到 DB_FIELD 根节点
        List<String> path = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        IRNode cur = tainted;
        while (cur != null && visited.add(cur.id)) {
            path.add(0, cur.toString());
            cur = graph.inEdges(cur).stream()
                    .map(e -> e.from)
                    .filter(n -> n.tainted)
                    .findFirst().orElse(null);
        }
        path.add(sink.fieldName);
        return path;
    }

    private String findDbSource(IRGraph graph, IRNode node) {
        Set<String> visited = new HashSet<>();
        IRNode cur = node;
        while (cur != null && visited.add(cur.id)) {
            if (cur.type == NodeType.DB_FIELD) return cur.toString();
            cur = graph.inEdges(cur).stream()
                    .map(e -> e.from)
                    .filter(n -> n.tainted)
                    .findFirst().orElse(null);
        }
        return node.toString();
    }

    private static String riskLevel(String level) {
        if (level == null) return "MEDIUM";
        return switch (level.toUpperCase()) {
            case "SECRET", "TOP_SECRET" -> "HIGH";
            case "CONFIDENTIAL" -> "MEDIUM";
            default -> "LOW";
        };
    }

    private static String parseFile(String ownerClass) {
        return ownerClass.endsWith(".java") ? ownerClass : ownerClass;
    }

    private static int parseLine(String metadata) {
        if (metadata == null) return 0;
        String[] parts = metadata.split(":");
        if (parts.length >= 2) {
            try { return Integer.parseInt(parts[parts.length - 1]); } catch (NumberFormatException ignored) {}
        }
        return 0;
    }
}

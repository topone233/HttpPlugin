package com.datatrace.module;

import com.datatrace.ir.*;

import java.util.*;

/** 模块D：遍历IRGraph，从已标记taint的DB_FIELD节点沿边传播污点 */
public class TaintPropagationModule {

    public void propagate(IRGraph graph) {
        // BFS：从所有已污染节点出发，沿 MAP_TO / ASSIGN / COPY / RETURN 边传播
        Queue<IRNode> queue = new ArrayDeque<>();
        for (IRNode n : graph.nodes.values()) {
            if (n.tainted) queue.add(n);
        }

        Set<String> visited = new HashSet<>();
        while (!queue.isEmpty()) {
            IRNode cur = queue.poll();
            if (!visited.add(cur.id)) continue;
            for (IREdge e : graph.edges) {
                if (e.from == cur && !e.to.tainted) {
                    e.to.tainted = true;
                    if (e.to.level == null) e.to.level = cur.level;
                    queue.add(e.to);
                }
            }
        }
    }
}

package com.datatrace.module;

import com.datatrace.ir.*;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.*;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

public class LogSinkModule {

    private static final Set<String> LOG_METHODS = Set.of("info", "warn", "error", "debug", "trace");
    private static final Set<String> JSON_METHODS = Set.of("toJSONString", "writeValueAsString");

    private final IRGraph graph;

    public LogSinkModule(IRGraph graph) { this.graph = graph; }

    public void process(List<Path> srcRoots) throws IOException {
        for (Path root : srcRoots) {
            Files.walkFileTree(root, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (file.toString().endsWith(".java")) processFile(file);
                    return FileVisitResult.CONTINUE;
                }
            });
        }
    }

    private void processFile(Path file) {
        try {
            CompilationUnit cu = StaticJavaParser.parse(file);
            String fileName = file.getFileName().toString();
            cu.findAll(MethodDeclaration.class).forEach(method -> {
                Map<String, String> varTypes = buildVarTypeMap(method);
                method.findAll(MethodCallExpr.class).forEach(call -> handleCall(call, fileName, varTypes));
            });
        } catch (Exception ignored) {}
    }

    private Map<String, String> buildVarTypeMap(MethodDeclaration method) {
        Map<String, String> map = new HashMap<>();
        method.getParameters().forEach(p -> map.put(p.getNameAsString(), p.getTypeAsString().replaceAll("<.*>", "").trim()));
        method.findAll(VariableDeclarator.class).forEach(vd -> map.put(vd.getNameAsString(), vd.getTypeAsString().replaceAll("<.*>", "").trim()));
        return map;
    }

    private void handleCall(MethodCallExpr call, String fileName, Map<String, String> varTypes) {
        String method = call.getNameAsString();
        String scope = call.getScope().map(Expression::toString).orElse("");

        boolean isLog = LOG_METHODS.contains(method) &&
                (scope.equals("log") || scope.equals("logger") || scope.equals("LOG") || scope.equals("LOGGER"));
        boolean isJson = JSON_METHODS.contains(method);
        boolean isSysout = method.equals("println") && scope.equals("System.out");
        if (!isLog && !isJson && !isSysout) return;

        NodeType sinkType = isJson ? NodeType.JSON_SINK : NodeType.LOG_SINK;
        String sinkLabel = isJson ? method : (isSysout ? "System.out.println" : scope + "." + method);
        int line = call.getBegin().map(p -> p.line).orElse(0);
        String sinkId = "sink:" + fileName + ":" + line + ":" + sinkLabel;
        IRNode sink = graph.addNode(new IRNode(sinkId, sinkType, fileName, sinkLabel, "SINK"));

        for (Expression arg : call.getArguments()) {
            linkArgToSink(arg, sink, fileName, line, varTypes);
        }
    }

    private void linkArgToSink(Expression arg, IRNode sink, String fileName, int line, Map<String, String> varTypes) {
        if (arg instanceof MethodCallExpr mc && mc.getNameAsString().startsWith("get") && mc.getNameAsString().length() > 3) {
            // dto.getEmail() → 查 java:UserDTO.email
            String field = decapitalize(mc.getNameAsString().substring(3));
            String varName = mc.getScope().map(Expression::toString).orElse("");
            String ownerClass = resolveClass(varName, varTypes);
            String nodeId = "java:" + ownerClass + "." + field;
            IRNode src = graph.nodes.get(nodeId);
            if (src != null && src.tainted) {
                graph.addEdge(src, sink, EdgeType.LOG_OUTPUT, fileName + ":" + line);
            }
        } else {
            // dto → 查所有 ownerClass=UserDTO 的污染字段
            String varName = arg.toString().replaceAll("[^a-zA-Z0-9_]", "");
            String ownerClass = resolveClass(varName, varTypes);
            for (IRNode n : graph.nodes.values()) {
                if (n.tainted && n.type == NodeType.JAVA_FIELD && n.ownerClass.equals(ownerClass)) {
                    graph.addEdge(n, sink, EdgeType.LOG_OUTPUT, fileName + ":" + line);
                }
            }
        }
    }

    private String resolveClass(String varName, Map<String, String> varTypes) {
        String type = varTypes.get(varName);
        return type != null ? type : varName;
    }

    private static String decapitalize(String s) {
        return s.isEmpty() ? s : Character.toLowerCase(s.charAt(0)) + s.substring(1);
    }
}

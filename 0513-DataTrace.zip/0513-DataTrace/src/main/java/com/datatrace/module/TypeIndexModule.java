package com.datatrace.module;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.*;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

/**
 * 模块H：预扫描所有.java文件，建立 simpleClassName/fqn → {fieldName → fieldType} 索引。
 * 不依赖 JavaSymbolSolver，仅做语法级扫描。
 */
public class TypeIndexModule {

    // className (simple or FQN) -> fieldName -> declaredType (simple name)
    private final Map<String, Map<String, String>> classFields = new HashMap<>();
    // simpleClassName -> FQN (用于解歧义)
    private final Map<String, String> simpleToFqn = new HashMap<>();

    public void index(List<Path> srcRoots) throws IOException {
        for (Path root : srcRoots) {
            Files.walkFileTree(root, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (file.toString().endsWith(".java")) indexFile(file);
                    return FileVisitResult.CONTINUE;
                }
            });
        }
    }

    private void indexFile(Path file) {
        try {
            CompilationUnit cu = StaticJavaParser.parse(file);
            String pkg = cu.getPackageDeclaration()
                    .map(p -> p.getNameAsString() + ".").orElse("");

            cu.findAll(ClassOrInterfaceDeclaration.class).forEach(cls -> {
                String simple = cls.getNameAsString();
                String fqn = pkg + simple;
                Map<String, String> fields = new LinkedHashMap<>();
                for (FieldDeclaration fd : cls.getFields()) {
                    String typeName = fd.getElementType().asString();
                    for (VariableDeclarator vd : fd.getVariables()) {
                        fields.put(vd.getNameAsString(), typeName);
                    }
                }
                classFields.put(fqn, fields);
                classFields.putIfAbsent(simple, fields);
                simpleToFqn.put(simple, fqn);
            });
        } catch (Exception ignored) {}
    }

    /** 获取某类的所有字段名 */
    public Set<String> getAllClasses() { return classFields.keySet(); }

    /** 只返回简单类名集合（不含FQN） */
    public Set<String> getSimpleClassNames() { return simpleToFqn.keySet(); }

    public Set<String> getFields(String className) {
        Map<String, String> f = classFields.get(className);
        return f != null ? f.keySet() : Collections.emptySet();
    }

    /** 获取某字段的声明类型（simple name） */
    public String getFieldType(String className, String fieldName) {
        Map<String, String> f = classFields.get(className);
        return f != null ? f.get(fieldName) : null;
    }

    public String resolveFqn(String simpleName) {
        return simpleToFqn.getOrDefault(simpleName, simpleName);
    }

    public boolean hasClass(String className) {
        return classFields.containsKey(className);
    }
}

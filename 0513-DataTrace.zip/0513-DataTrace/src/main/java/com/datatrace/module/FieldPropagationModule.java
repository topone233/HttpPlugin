package com.datatrace.module;

import com.datatrace.ir.*;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.stmt.ExpressionStmt;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

/**
 * 模块C：Java字段传播分析
 * 识别 Setter / BeanUtils / Builder / Constructor / Map.put 传播，生成 ASSIGN/COPY 边
 */
public class FieldPropagationModule {

    private final IRGraph graph;
    private final TypeIndexModule typeIndex;

    public FieldPropagationModule(IRGraph graph, TypeIndexModule typeIndex) {
        this.graph = graph;
        this.typeIndex = typeIndex;
    }

    public void process(List<Path> srcRoots) throws IOException {
        for (Path root : srcRoots) {
            Files.walkFileTree(root, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (file.toString().endsWith(".java")) processFile(file);
                    return FileVisitResult.CONTINUE;
                }
            });
        }
    }

    private void processFile(Path file) {
        try {
            CompilationUnit cu = StaticJavaParser.parse(file);
            // 按方法处理，每个方法建立独立的局部变量表
            cu.findAll(MethodDeclaration.class).forEach(method -> {
                Map<String, String> varTypes = buildVarTypeMap(method);
                method.findAll(MethodCallExpr.class).forEach(call -> handleMethodCall(call, varTypes));
            });
        } catch (Exception ignored) {}
    }

    /**
     * 扫描方法内的局部变量声明，建立 varName → className 映射
     * 例如: UserDTO dto = new UserDTO() → {"dto": "UserDTO"}
     */
    private Map<String, String> buildVarTypeMap(MethodDeclaration method) {
        Map<String, String> map = new HashMap<>();
        // 方法参数
        method.getParameters().forEach(p -> {
            String type = p.getTypeAsString().replaceAll("<.*>", "").trim();
            map.put(p.getNameAsString(), type);
        });
        // 局部变量声明
        method.findAll(VariableDeclarator.class).forEach(vd -> {
            String type = vd.getTypeAsString().replaceAll("<.*>", "").trim();
            map.put(vd.getNameAsString(), type);
        });
        return map;
    }

    private void handleMethodCall(MethodCallExpr call, Map<String, String> varTypes) {
        String name = call.getNameAsString();

        if (name.startsWith("set") && name.length() > 3 && call.getArguments().size() == 1) {
            handleSetter(call, varTypes);
            return;
        }
        if (name.equals("copyProperties") && call.getArguments().size() >= 2) {
            handleBeanUtils(call, varTypes);
            return;
        }
        if (name.equals("put") && call.getArguments().size() == 2) {
            handleMapPut(call, varTypes);
        }
    }

    private void handleSetter(MethodCallExpr call, Map<String, String> varTypes) {
        String setterField = decapitalize(call.getNameAsString().substring(3));
        Expression arg = call.getArgument(0);
        String srcField = extractGetterField(arg);
        if (srcField == null) return;

        String dstClass = resolveScope(call.getScope().orElse(null), varTypes);
        String srcClass = resolveGetterScope(arg, varTypes);
        if (dstClass == null || srcClass == null) return;

        IRNode src = getOrCreateJavaNode(srcClass, srcField);
        IRNode dst = getOrCreateJavaNode(dstClass, setterField);
        graph.addEdge(src, dst, EdgeType.ASSIGN, "setter");
    }

    private void handleBeanUtils(MethodCallExpr call, Map<String, String> varTypes) {
        String srcClass = resolveVarType(call.getArgument(0), varTypes);
        String dstClass = resolveVarType(call.getArgument(1), varTypes);
        if (srcClass == null || dstClass == null) return;

        Set<String> srcFields = typeIndex.getFields(srcClass);
        Set<String> dstFields = typeIndex.getFields(dstClass);
        for (String f : srcFields) {
            if (dstFields.contains(f)) {
                graph.addEdge(getOrCreateJavaNode(srcClass, f), getOrCreateJavaNode(dstClass, f), EdgeType.COPY, "BeanUtils");
            }
        }
    }

    private void handleMapPut(MethodCallExpr call, Map<String, String> varTypes) {
        Expression keyExpr = call.getArgument(0);
        if (!(keyExpr instanceof StringLiteralExpr)) return;
        String key = ((StringLiteralExpr) keyExpr).asString();
        String srcField = extractGetterField(call.getArgument(1));
        if (srcField == null) return;
        String srcClass = resolveGetterScope(call.getArgument(1), varTypes);
        if (srcClass == null) return;

        String mapVar = call.getScope().map(Expression::toString).orElse("map");
        graph.addEdge(getOrCreateJavaNode(srcClass, srcField), getOrCreateJavaNode(mapVar, key), EdgeType.ASSIGN, "map.put");
    }

    private String extractGetterField(Expression expr) {
        if (!(expr instanceof MethodCallExpr mc)) return null;
        String n = mc.getNameAsString();
        return (n.startsWith("get") && n.length() > 3) ? decapitalize(n.substring(3)) : null;
    }

    private String resolveGetterScope(Expression expr, Map<String, String> varTypes) {
        if (!(expr instanceof MethodCallExpr mc)) return null;
        return resolveScope(mc.getScope().orElse(null), varTypes);
    }

    private String resolveScope(Expression scope, Map<String, String> varTypes) {
        if (scope == null) return null;
        String name = scope.toString();
        // 1. 先查局部变量表
        String type = varTypes.get(name);
        if (type != null) return typeIndex.hasClass(type) ? type : typeIndex.resolveFqn(type);
        // 2. 再查类型索引（直接是类名的情况）
        if (typeIndex.hasClass(name)) return name;
        return typeIndex.resolveFqn(name);
    }

    private String resolveVarType(Expression expr, Map<String, String> varTypes) {
        String name = expr.toString();
        String type = varTypes.get(name);
        if (type != null) return typeIndex.hasClass(type) ? type : typeIndex.resolveFqn(type);
        if (typeIndex.hasClass(name)) return name;
        return typeIndex.resolveFqn(name);
    }

    private IRNode getOrCreateJavaNode(String ownerClass, String fieldName) {
        String id = "java:" + ownerClass + "." + fieldName;
        return graph.addNode(new IRNode(id, NodeType.JAVA_FIELD, ownerClass, fieldName, "PROPAGATION"));
    }

    private static String decapitalize(String s) {
        return s.isEmpty() ? s : Character.toLowerCase(s.charAt(0)) + s.substring(1);
    }
}

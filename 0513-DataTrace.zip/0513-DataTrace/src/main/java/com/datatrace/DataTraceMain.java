package com.datatrace;

import com.datatrace.ir.IRGraph;
import com.datatrace.model.AssetField;
import com.datatrace.model.RiskItem;
import com.datatrace.module.*;

import java.nio.file.*;
import java.util.*;

/**
 * 用法: java -jar datatrace.jar <assets.json> <output-dir> <src-root1> [src-root2] ...
 */
public class DataTraceMain {

    public static void main(String[] args) throws Exception {
        if (args.length < 3) {
            System.err.println("用法: java -jar datatrace.jar <assets.json> <output-dir> <src-root1> [src-root2] ...");
            System.exit(1);
        }

        Path assetsJson = Paths.get(args[0]);
        Path outputDir = Paths.get(args[1]);
        List<Path> srcRoots = new ArrayList<>();
        for (int i = 2; i < args.length; i++) {
            Path p = Paths.get(args[i]).toAbsolutePath();
            if (Files.isDirectory(p)) srcRoots.add(p);
            else System.err.println("跳过（不存在）: " + p);
        }
        if (srcRoots.isEmpty()) { System.err.println("没有有效源码路径"); System.exit(1); }
        Files.createDirectories(outputDir);

        System.out.println("=== DataTrace 机密数据日志泄露分析 ===");

        // 模块H：类型索引
        System.out.println("[H] 构建类型索引...");
        TypeIndexModule typeIndex = new TypeIndexModule();
        typeIndex.index(srcRoots);

        // 模块A：导入资产
        System.out.println("[A] 导入数据库资产: " + assetsJson);
        List<AssetField> assets = new AssetImportModule().load(assetsJson);
        System.out.println("    共 " + assets.size() + " 个机密字段");

        IRGraph graph = new IRGraph();

        // 模块B：ORM映射（默认开启camelCase）
        System.out.println("[B] ORM/SQL字段映射恢复...");
        new OrmMappingModule(graph, true).withTypeIndex(typeIndex).process(assets, srcRoots);

        // 模块C：字段传播分析
        System.out.println("[C] Java字段传播分析...");
        new FieldPropagationModule(graph, typeIndex).process(srcRoots);

        // 模块D：污点传播
        System.out.println("[D] 污点传播标记...");
        new TaintPropagationModule().propagate(graph);

        // 模块E：日志Sink识别
        System.out.println("[E] 日志Sink识别...");
        new LogSinkModule(graph).process(srcRoots);

        // 调试：打印IRGraph状态
        // 模块F：风险判定
        System.out.println("[F] 风险判定...");
        List<RiskItem> risks = new RiskJudgeModule().judge(graph);

        // 模块G：报告输出
        System.out.println("[G] 输出报告...");
        ReportModule report = new ReportModule();
        report.writeJson(risks, outputDir.resolve("risks.json"));
        report.writeExcel(risks, outputDir.resolve("risks.xlsx"));

        System.out.println("\n=== 分析完成 ===");
        System.out.println("发现风险: " + risks.size() + " 处");
        System.out.println("报告位置: " + outputDir.toAbsolutePath());

        long high = risks.stream().filter(r -> "HIGH".equals(r.riskLevel)).count();
        long medium = risks.stream().filter(r -> "MEDIUM".equals(r.riskLevel)).count();
        System.out.printf("  HIGH: %d  MEDIUM: %d  LOW: %d%n", high, medium, risks.size() - high - medium);
    }
}

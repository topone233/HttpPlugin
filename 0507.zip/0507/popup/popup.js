let capturing = true;

function refreshStats() {
  chrome.runtime.sendMessage({ type: 'GET_STATS' }, r => {
    if (!r) return;
    document.getElementById('cntReq').textContent = r.totalRequests;
    document.getElementById('cntBeh').textContent = r.totalBehaviors;
    document.getElementById('cntMap').textContent = r.totalMappings;
  });
}

function updateToggleBtn() {
  const btn = document.getElementById('toggleBtn');
  btn.textContent = capturing ? 'Capturing ON' : 'Capturing OFF';
  btn.className = capturing ? '' : 'off';
}

document.getElementById('toggleBtn').addEventListener('click', () => {
  capturing = !capturing;
  chrome.storage.session.set({ capturing });
  updateToggleBtn();
});

document.getElementById('exportBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'GET_EXPORT' }, data => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sec-cap-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });
});

document.getElementById('dashboardBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
});

document.getElementById('clearBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CLEAR_DATA' }, () => refreshStats());
});

chrome.storage.session.get('capturing', r => {
  capturing = r.capturing !== false;
  updateToggleBtn();
});

refreshStats();
setInterval(refreshStats, 2000);

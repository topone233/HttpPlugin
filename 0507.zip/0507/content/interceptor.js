(function () {
  if (window.__SEC_CAP_INIT__) return;
  window.__SEC_CAP_INIT__ = true;

  const PREFIX = '__SEC_CAP__';
  const origFetch = window.__SEC_CAP_ORIG_FETCH__ = window.fetch;
  const OrigXHR = window.__SEC_CAP_ORIG_XHR__ = window.XMLHttpRequest;

  function post(data) {
    // Normalize relative URLs to absolute
    if (data.url && !data.url.startsWith('http')) {
      try { data.url = new URL(data.url, location.href).href; } catch {}
    }
    window.postMessage({ __type: PREFIX, data }, '*');
  }

  function readBody(body) {
    if (!body) return null;
    if (typeof body === 'string') return body;
    if (body instanceof URLSearchParams) return body.toString();
    if (body instanceof FormData) {
      const obj = {};
      body.forEach((v, k) => { obj[k] = v; });
      return JSON.stringify(obj);
    }
    return null;
  }

  window.fetch = async function (...args) {
    const [input, init = {}] = args;
    const url = typeof input === 'string' ? input : input.url;
    const method = (init.method || (input.method) || 'GET').toUpperCase();
    const reqBody = readBody(init.body);
    const reqHeaders = {};
    if (init.headers) {
      const h = new Headers(init.headers);
      h.forEach((v, k) => { reqHeaders[k] = v; });
    }
    const ts = Date.now();
    try {
      const resp = await origFetch.apply(this, args);
      const clone = resp.clone();
      clone.text().then(respBody => {
        post({ ts, method, url, reqHeaders, reqBody, status: resp.status, respBody, initiatorType: 'fetch' });
      }).catch(() => {
        post({ ts, method, url, reqHeaders, reqBody, status: resp.status, respBody: null, initiatorType: 'fetch' });
      });
      return resp;
    } catch (err) {
      post({ ts, method, url, reqHeaders, reqBody, status: 0, respBody: null, error: err.message, initiatorType: 'fetch' });
      throw err;
    }
  };

  window.XMLHttpRequest = function () {
    const xhr = new OrigXHR();
    let _method, _url, _reqBody, _reqHeaders = {};
    const origOpen = xhr.open.bind(xhr);
    const origSend = xhr.send.bind(xhr);
    const origSetHeader = xhr.setRequestHeader.bind(xhr);
    xhr.open = function (method, url, ...rest) {
      _method = method.toUpperCase();
      _url = url;
      return origOpen(method, url, ...rest);
    };
    xhr.setRequestHeader = function (k, v) {
      _reqHeaders[k] = v;
      return origSetHeader(k, v);
    };
    xhr.send = function (body) {
      _reqBody = readBody(body);
      const ts = Date.now();
      xhr.addEventListener('loadend', () => {
        post({ ts, method: _method, url: _url, reqHeaders: _reqHeaders, reqBody: _reqBody, status: xhr.status, respBody: xhr.responseText, initiatorType: 'xhr' });
      });
      return origSend(body);
    };
    return xhr;
  };
  window.XMLHttpRequest.prototype = OrigXHR.prototype;
})();

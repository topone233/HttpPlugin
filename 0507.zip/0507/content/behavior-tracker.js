(function () {
  const INTERACTIVE = 'button,[role=button],[data-action],a,[type=submit]';

  function extractRowData(el) {
    let node = el;
    while (node && node !== document.body) {
      if (node.tagName === 'TR' || node.getAttribute('role') === 'row') {
        const data = {};
        node.querySelectorAll('[data-id],[data-key],[data-row-key]').forEach(c => {
          Object.assign(data, Object.fromEntries(
            [...c.attributes].filter(a => a.name.startsWith('data-')).map(a => [a.name, a.value])
          ));
        });
        // also grab data-* from the row itself
        [...node.attributes].filter(a => a.name.startsWith('data-')).forEach(a => { data[a.name] = a.value; });
        return Object.keys(data).length ? data : null;
      }
      node = node.parentElement;
    }
    return null;
  }

  function getLabel(el) {
    // Priority: data-action > other data-* > aria-label > title > textContent
    if (el.dataset.action) return el.dataset.action;
    const dataVals = Object.entries(el.dataset).filter(([k]) => k !== 'v').map(([, v]) => v).filter(Boolean);
    if (dataVals.length) return dataVals[0];
    return el.getAttribute('aria-label') || el.title || el.textContent?.trim() || '';
  }

  function capture(e) {
    const target = e.target.closest(INTERACTIVE);
    if (!target) return;

    const dataAttrs = {};
    [...target.attributes].filter(a => a.name.startsWith('data-')).forEach(a => { dataAttrs[a.name] = a.value; });

    const event = {
      timestamp: Date.now(),
      type: e.type,
      elementText: getLabel(target),
      elementTag: target.tagName.toLowerCase(),
      dataAttrs,
      ariaLabel: target.getAttribute('aria-label'),
      title: target.title || null,
      rowData: extractRowData(target),
      pageUrl: location.href,
      pageContext: null,
    };

    console.log('[BEH] captured:', event.elementText, event.elementTag, 'rowData:', JSON.stringify(event.rowData));
    window.postMessage({ __type: '__SEC_BEH__', data: event }, '*');
  }

  document.addEventListener('click', capture, true);
  document.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') capture(e);
  }, true);
})();

(function () {
  const BREADCRUMB_SELS = [
    '.el-breadcrumb__item', '.ant-breadcrumb-link', '.arco-breadcrumb-item',
    '[aria-label="breadcrumb"] li', 'nav ol li', '.breadcrumb-item',
  ];
  const MENU_SELS = [
    '.el-menu-item.is-active', '.ant-menu-item-selected', '.arco-menu-item-selected',
    '[role="menuitem"][aria-selected="true"]', '.menu-item.active', '.nav-item.active',
  ];

  function extractBreadcrumb() {
    for (const sel of BREADCRUMB_SELS) {
      const items = [...document.querySelectorAll(sel)];
      if (items.length > 1) return items.map(el => el.textContent.trim()).filter(Boolean);
    }
    return [];
  }

  function extractMenuPath() {
    for (const sel of MENU_SELS) {
      const el = document.querySelector(sel);
      if (el) return [el.textContent.trim()];
    }
    return [];
  }

  function getCurrentContext() {
    return {
      path: location.pathname,
      title: document.title,
      breadcrumb: extractBreadcrumb(),
      menuPath: extractMenuPath(),
    };
  }

  function postContext() {
    window.postMessage({ __type: '__SEC_CAP_CTX__', data: getCurrentContext() }, '*');
  }

  window.__SEC_CAP_CTX__ = getCurrentContext;
  postContext();

  // SPA navigation detection — debounced + dedup to avoid flooding on dynamic pages
  let debounceTimer = 0;
  let lastSerialized = '';
  const notify = () => {
    if (debounceTimer) return;
    debounceTimer = setTimeout(() => {
      debounceTimer = 0;
      const ctx = getCurrentContext();
      const serialized = JSON.stringify(ctx);
      if (serialized === lastSerialized) return;
      lastSerialized = serialized;
      window.__SEC_CAP_CTX__ = getCurrentContext;
      window.postMessage({ __type: '__SEC_CAP_CTX__', data: ctx }, '*');
    }, 300);
  };

  const origPush = history.pushState;
  const origReplace = history.replaceState;
  history.pushState = function (...a) { origPush.apply(this, a); notify(); };
  history.replaceState = function (...a) { origReplace.apply(this, a); notify(); };
  window.addEventListener('popstate', notify);

  // MutationObserver — guard against null body at document_start
  function startObserver() {
    if (!document.body) return;
    new MutationObserver(notify).observe(document.body, { childList: true, subtree: true });
  }
  if (document.body) {
    startObserver();
  } else {
    document.addEventListener('DOMContentLoaded', startObserver, { once: true });
  }
})();

const MSG = {
  RAW_REQUEST: 'RAW_REQUEST',
  RAW_BEHAVIOR: 'RAW_BEHAVIOR',
  GET_STATS: 'GET_STATS',
  GET_EXPORT: 'GET_EXPORT',
  CLEAR_DATA: 'CLEAR_DATA',
  SET_CAPTURE: 'SET_CAPTURE',
  GET_CAPTURE: 'GET_CAPTURE',
  GET_HISTORY: 'GET_HISTORY',
  GET_HISTORY_DETAIL: 'GET_HISTORY_DETAIL',
};

const POSTMSG_PREFIX = '__SEC_CAP__';

const CORR = {
  BASE_WINDOW: 2000,
  MAX_WINDOW: 8000,
  THRESHOLD: 0.15,
  W_PARAM: 0.4,
  W_SEMANTIC: 0.25,
  W_TEMPORAL: 0.35,
};

const DB = {
  NAME: 'sec_cap',
  VERSION: 2,
  REQUESTS_CAP: 5000,
  REQUESTS_EVICT: 500,
  BEHAVIORS_CAP: 2000,
  BEHAVIORS_EVICT: 200,
};

const RESOURCE_MAP = {
  main_frame: 'Doc',
  sub_frame: 'Doc',
  stylesheet: 'CSS',
  script: 'JS',
  image: 'Img',
  font: 'Font',
  object: 'Object',
  xmlhttprequest: 'XHR',
  fetch: 'Fetch',
  ping: 'Ping',
  csp_report: 'CSP',
  media: 'Media',
  websocket: 'WS',
  other: 'Other',
};

const ZH_EN = {
  '删除': 'delete', '查询': 'query', '搜索': 'search', '导出': 'export',
  '新增': 'create', '添加': 'add', '编辑': 'edit', '修改': 'update',
  '详情': 'detail', '列表': 'list', '保存': 'save', '下载': 'download',
  '提交': 'submit', '重置': 'reset', '刷新': 'refresh', '导入': 'import',
  '用户': 'user', '角色': 'role', '权限': 'permission', '菜单': 'menu',
  '配置': 'config', '设置': 'setting', '日志': 'log', '任务': 'task',
  '项目': 'project', '订单': 'order', '商品': 'product', '数据': 'data',
  '信息': 'info', '管理': 'manage', '操作': 'operate', '登录': 'login',
  '注册': 'register', '启用': 'enable', '禁用': 'disable', '确认': 'confirm',
  '取消': 'cancel', '关闭': 'close', '审核': 'audit', '审批': 'approve',
  '分配': 'assign', '绑定': 'bind', '上传': 'upload', '预览': 'preview',
  '复制': 'copy', '移动': 'move', '同步': 'sync', '发布': 'publish',
  '撤回': 'revoke', '回退': 'rollback', '执行': 'execute', '暂停': 'pause',
  '恢复': 'recover', '归档': 'archive', '通知': 'notify', '消息': 'message',
  '订阅': 'subscribe', '创建': 'create', '批量': 'batch', '移除': 'remove',
  '授权': 'authorize', '生成': 'generate', '排序': 'sort', '合并': 'merge',
  '拆分': 'split', '锁定': 'lock', '解锁': 'unlock', '激活': 'activate',
  '获取': 'get', '更新': 'update', '关联': 'link', '发送': 'send',
  '验证': 'verify', '校验': 'validate', '统计': 'stat', '分析': 'analyze',
};

const STATIC_EXT = /\.(js|css|png|jpg|gif|svg|ico|woff|woff2|ttf|map|webp|eot)(\?|$)/i;
const NOISE_HOSTS = /google-analytics|doubleclick|gtm\.js|hotjar|sentry|clarity\.ms|facebook\.net/i;
const NOISE_PATHS = /\/(analytics|tracking|beacon|ping|heartbeat|favicon)/i;
const GENERIC_SEGS = new Set(['api', 'v1', 'v2', 'v3', 'rest', 'service', 'services']);

function applyZhEn(text) {
  let result = text;
  for (const [zh, en] of Object.entries(ZH_EN)) result = result.replaceAll(zh, ` ${en} `);
  return result;
}

function splitCamel(s) {
  return s.replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase();
}

function tokenize(text) {
  if (!text) return [];
  const mapped = applyZhEn(text);
  return splitCamel(mapped).split(/[\s\-_/]+/).filter(t => t.length > 1);
}

function tokenizeUrl(url) {
  try {
    const path = new URL(url).pathname;
    return path.split('/').flatMap(seg =>
      splitCamel(seg).split(/[\-_]+/)
    ).filter(t => t.length > 1 && !GENERIC_SEGS.has(t));
  } catch {
    return [];
  }
}

function jaccard(a, b) {
  if (!a.length || !b.length) return 0;
  const sa = new Set(a), sb = new Set(b);
  const inter = [...sa].filter(x => sb.has(x)).length;
  if (!inter) return 0;
  // Use containment (overlap coefficient) instead of pure Jaccard
  // so small label sets aren't diluted by large URL token sets
  return inter / Math.min(sa.size, sb.size);
}

function isApiRequest(url) {
  try {
    const u = new URL(url);
    return !STATIC_EXT.test(u.pathname) && !NOISE_HOSTS.test(u.hostname) && !NOISE_PATHS.test(u.pathname);
  } catch { return false; }
}

function strongMatch(rowData, requestBody) {
  if (!rowData || !requestBody) return 0;
  try {
    const body = typeof requestBody === 'string' ? JSON.parse(requestBody) : requestBody;
    const bodyVals = new Set(Object.values(body).map(String));
    const rowVals = Object.values(rowData).map(String);
    return rowVals.some(v => v && bodyVals.has(v)) ? 1.0 : 0;
  } catch { return 0; }
}

function generateId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

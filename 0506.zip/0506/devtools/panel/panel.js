let data = { apiAssets: [], pageApiMap: [], behaviorApiMap: [], mappings: [] };
let minConf = 0.15;
let filterText = '';
let activeTab = 'apis';

const HTML_ESCAPE = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function escapeHtml(s) {
  return s == null ? '' : String(s).replace(/[&<>"']/g, c => HTML_ESCAPE[c]);
}

function confClass(c) { return c >= 0.7 ? 'high' : c >= 0.4 ? 'mid' : 'low'; }
function methodBadge(m) { const e = escapeHtml(m); return `<span class="method ${e}">${e}</span>`; }

// ===== Render Functions =====

function renderApis() {
  const tbody = document.querySelector('#tableApis tbody');
  const rows = data.apiAssets
    .filter(a => !filterText || a.urlPath.includes(filterText))
    .sort((a, b) => b.callCount - a.callCount);
  tbody.innerHTML = rows.map(a => `
    <tr>
      <td>${methodBadge(a.method)}</td>
      <td>${escapeHtml(a.urlPath)}</td>
      <td><strong>${a.callCount}</strong> ${a.callCount > 1 ? `<button class="btn-records" data-index="${data.apiAssets.indexOf(a)}">Records(${a.callCount})</button>` : ''}</td>
      <td>${escapeHtml((a.pages || []).join(', '))}</td>
      <td><pre>${escapeHtml(a.sampleRequestBody ? a.sampleRequestBody.slice(0, 80) : '')}</pre></td>
    </tr>`).join('');
}

function renderPages() {
  const tbody = document.querySelector('#tablePages tbody');
  const rows = data.pageApiMap.filter(p => !filterText || p.page.includes(filterText));
  tbody.innerHTML = rows.map(p => `
    <tr>
      <td><strong>${escapeHtml(p.page)}</strong></td>
      <td>${escapeHtml(p.pageTitle || '')}</td>
      <td><ul class="actions-list">${(p.actions || []).map(a =>
        `<li>${methodBadge(a.method)} ${escapeHtml(a.name)} &rarr; ${escapeHtml(a.api)}</li>`).join('')}</ul></td>
      <td>${(p.apis || []).map(a => `${methodBadge(a.method)} ${escapeHtml(a.urlPath)}`).join('<br>')}</td>
    </tr>`).join('');
}

function renderBehaviors() {
  const tbody = document.querySelector('#tableBehaviors tbody');
  let rows = data.behaviorApiMap.filter(b =>
    !filterText || (b.behavior?.text || '').includes(filterText)
  );
  // Sort: mapped first (by highest confidence), then unmapped, then by occurrences
  rows.sort((a, b) => {
    const aMax = Math.max(0, ...a.mappings.map(m => m.confidence));
    const bMax = Math.max(0, ...b.mappings.map(m => m.confidence));
    if (bMax !== aMax) return bMax - aMax;
    return (b.occurrences || 0) - (a.occurrences || 0);
  });

  tbody.innerHTML = rows.flatMap(b => {
    const validMappings = b.mappings.filter(m => m.confidence >= minConf);
    const recordsBtn = b.occurrences > 1
      ? `<button class="btn-records" data-behavior-key="${escapeHtml((b.behavior?.text || '') + ':' + (b.behavior?.page || ''))}">Records(${b.occurrences})</button>`
      : '';
    if (!validMappings.length) {
      return `<tr>
        <td><strong>${escapeHtml(b.behavior?.text || '(no text)')}</strong> ${recordsBtn}</td>
        <td>${escapeHtml(b.behavior?.page || '')}</td>
        <td colspan="3" style="color:#94a3b8;text-align:center">No correlated API</td>
      </tr>`;
    }
    return validMappings.map(m => `
    <tr>
      <td><strong>${escapeHtml(b.behavior?.text || '')}</strong> ${recordsBtn}</td>
      <td>${escapeHtml(b.behavior?.page || '')}</td>
      <td>${methodBadge(m.method)} ${escapeHtml(m.urlPath)}</td>
      <td><span class="conf ${confClass(m.confidence)}">${m.confidence.toFixed(2)}</span></td>
      <td>
        <div class="evidence-bar">
          <span class="evidence-item">T:<strong>${m.evidence?.temporal?.toFixed(2)}</strong></span>
          <span class="evidence-item">S:<strong>${m.evidence?.semantic?.toFixed(2)}</strong></span>
          <span class="evidence-item">P:<strong>${m.evidence?.param?.toFixed(2)}</strong></span>
        </div>
      </td>
    </tr>`);
  }).join('');
}

function updateStats() {
  document.getElementById('statApis').textContent = data.apiAssets.length;
  document.getElementById('statPages').textContent = data.pageApiMap.length;
  document.getElementById('statBehaviors').textContent = data.behaviorApiMap.length;
  document.getElementById('badgeApis').textContent = data.apiAssets.length;
  document.getElementById('badgePages').textContent = data.pageApiMap.length;
  document.getElementById('badgeBehaviors').textContent = data.behaviorApiMap.length;
}

function render() {
  renderApis(); renderPages(); renderBehaviors(); updateStats();
}

// ===== Data Loading =====

function load() {
  chrome.runtime.sendMessage({ type: 'GET_EXPORT' }, r => {
    if (r) {
      data = r;
      render();
      updateCaptureStatus(r);
    }
  });
}

function updateCaptureStatus(r) {
  const el = document.getElementById('captureStatus');
  // r._capturing is not sent; check via storage
  chrome.storage.session.get('capturing', s => {
    const capturing = s.capturing !== false;
    el.textContent = capturing ? '● Capturing' : '○ Paused';
    el.className = 'capture-status ' + (capturing ? 'on' : 'off');
  });
}

// ===== Tab Switching =====

document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    activeTab = btn.dataset.tab;
    document.getElementById(`tab-${activeTab}`).classList.add('active');
  });
});

// ===== Toolbar Events =====

document.getElementById('filterInput').addEventListener('input', e => {
  filterText = e.target.value;
  document.getElementById('clearFilter').style.visibility = filterText ? 'visible' : 'hidden';
  render();
});

document.getElementById('clearFilter').addEventListener('click', () => {
  document.getElementById('filterInput').value = '';
  filterText = '';
  document.getElementById('clearFilter').style.visibility = 'hidden';
  render();
});

document.getElementById('confSlider').addEventListener('input', e => {
  minConf = e.target.value / 100;
  document.getElementById('confVal').textContent = minConf.toFixed(2);
  render();
});

document.getElementById('refreshBtn').addEventListener('click', load);

// ===== Export =====

document.getElementById('exportBtn').addEventListener('click', () => {
  const out = {
    apiAssets: data.apiAssets,
    pageApiMap: data.pageApiMap,
    behaviorApiMap: data.behaviorApiMap,
  };
  const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `sec-cap-${Date.now()}.json`; a.click();
  URL.revokeObjectURL(url);
});

// ===== Init =====

load();
setInterval(load, 5000);

// Event delegation for records buttons
document.querySelector('#tableApis tbody').addEventListener('click', e => {
  const btn = e.target.closest('.btn-records');
  if (!btn) return;
  const idx = parseInt(btn.dataset.index);
  if (!isNaN(idx) && data.apiAssets[idx]) {
    openRecordsModal(data.apiAssets[idx].records, `${data.apiAssets[idx].method} ${data.apiAssets[idx].urlPath}`);
  }
});

document.querySelector('#tableBehaviors tbody').addEventListener('click', e => {
  const btn = e.target.closest('.btn-records');
  if (!btn) return;
  const key = btn.dataset.behaviorKey;
  if (!key) return;
  const entry = data.behaviorApiMap.find(b => `${b.behavior?.text || ''}:${b.behavior?.page || ''}` === key);
  if (entry) openRecordsModal(entry.records, entry.behavior?.text || 'Behavior');
});

function openRecordsModal(records, title) {
  const el = document.getElementById('recordsModal');
  document.getElementById('recordsTitle').textContent = `Records — ${escapeHtml(title)}`;
  if (!records || !records.length) {
    document.getElementById('recordsTableBody').innerHTML = '<tr><td colspan="5" style="color:#94a3b8;text-align:center">No records</td></tr>';
    el.style.display = 'flex';
    return;
  }
  const tbody = document.getElementById('recordsTableBody');
  const isApi = 'method' in records[0];
  if (isApi) {
    tbody.innerHTML = records.map(r => `<tr>
      <td>${escapeHtml(new Date(r.timestamp).toLocaleTimeString())}</td>
      <td>${methodBadge(r.method)}</td>
      <td>${escapeHtml(r.status || '-')}</td>
      <td>${escapeHtml(r.pageUrl || '-')}</td>
      <td><pre>${escapeHtml(r.bodyPreview || '-')}</pre></td>
    </tr>`).join('');
  } else {
    tbody.innerHTML = records.map(r => `<tr>
      <td>${escapeHtml(new Date(r.timestamp).toLocaleTimeString())}</td>
      <td>${escapeHtml(r.type || '-')}</td>
      <td>${escapeHtml(r.elementText || '-')}</td>
      <td>${escapeHtml(r.pageUrl || '-')}</td>
    </tr>`).join('');
  }
  el.style.display = 'flex';
}
function closeRecordsModal() {
  document.getElementById('recordsModal').style.display = 'none';
}
document.getElementById('recordsModalClose').addEventListener('click', closeRecordsModal);
document.getElementById('recordsModal').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeRecordsModal();
});

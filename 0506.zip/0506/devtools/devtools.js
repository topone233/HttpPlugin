chrome.devtools.panels.create('API Capture', 'icons/icon16.png', 'devtools/panel/panel.html');

let data = { apiAssets: [], pageApiMap: [], behaviorApiMap: [], mappings: [] };
let minConf = 0.15;
let filterText = '';

// History state
const hist = {
  page: 0, pageSize: 50, sort: { field: 'timestamp', dir: 'desc' },
  filter: { method: '', statusClass: '', resourceType: 'xmlhttprequest,fetch', search: '' },
  total: 0, items: [],
};
const RESOURCE_MAP = {
  main_frame: 'Doc', sub_frame: 'Doc', stylesheet: 'CSS',
  script: 'JS', image: 'Img', font: 'Font', object: 'Object',
  xmlhttprequest: 'XHR', fetch: 'Fetch', ping: 'Ping',
  csp_report: 'CSP', media: 'Media', websocket: 'WS', other: 'Other',
};

const HTML_ESCAPE = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function escapeHtml(s) {
  return s == null ? '' : String(s).replace(/[&<>"']/g, c => HTML_ESCAPE[c]);
}

function confClass(c) { return c >= 0.7 ? 'high' : c >= 0.4 ? 'mid' : 'low'; }
function methodBadge(m) { const e = escapeHtml(m); return `<span class="method ${e}">${e}</span>`; }

function renderApis() {
  const tbody = document.querySelector('#tableApis tbody');
  const rows = data.apiAssets
    .filter(a => !filterText || a.urlPath.includes(filterText))
    .sort((a, b) => b.callCount - a.callCount);
  tbody.innerHTML = rows.map(a => `
    <tr>
      <td>${methodBadge(a.method)}</td>
      <td><span title="${escapeHtml(a.host || '')}">${escapeHtml(a.host || '-')}</span></td>
      <td>${escapeHtml(a.urlPath)}</td>
      <td><span class="resource-type">${escapeHtml(a.resourceType || '-')}</span></td>
      <td><strong>${a.callCount}</strong></td>
      <td>${escapeHtml((a.pages || []).join(', ') || '-')}</td>
      <td>
        ${(a.sampleRequestHeaders || a.sampleRequestBody)
          ? `<button class="btn-detail" data-index="${data.apiAssets.indexOf(a)}">查看详情</button>`
          : '<span style="color:#94a3b8">-</span>'}
        ${a.callCount > 1 ? `<button class="btn-records" data-index="${data.apiAssets.indexOf(a)}">查看清单(${a.callCount})</button>` : ''}
      </td>
    </tr>`).join('');
}

function renderPages() {
  const tbody = document.querySelector('#tablePages tbody');
  const rows = data.pageApiMap.filter(p => !filterText || p.page.includes(filterText));
  tbody.innerHTML = rows.map(p => `
    <tr>
      <td><strong>${escapeHtml(p.page)}</strong></td>
      <td>${escapeHtml(p.pageTitle || '')}</td>
      <td><ul class="actions-list">${(p.actions || []).map(a =>
        `<li>${methodBadge(a.method)} ${escapeHtml(a.name)} &rarr; ${escapeHtml(a.api)}</li>`).join('')}</ul></td>
      <td>${(p.apis || []).map(a => `${methodBadge(a.method)} ${escapeHtml(a.urlPath)}`).join('<br>')}</td>
    </tr>`).join('');
}

function renderBehaviors() {
  const tbody = document.querySelector('#tableBehaviors tbody');
  let rows = data.behaviorApiMap.filter(b =>
    !filterText || (b.behavior?.text || '').includes(filterText)
  );
  // Sort: mapped first (by highest confidence), then unmapped, then by occurrences
  rows.sort((a, b) => {
    const aMax = Math.max(0, ...a.mappings.map(m => m.confidence));
    const bMax = Math.max(0, ...b.mappings.map(m => m.confidence));
    if (bMax !== aMax) return bMax - aMax;
    return (b.occurrences || 0) - (a.occurrences || 0);
  });

  tbody.innerHTML = rows.flatMap(b => {
    const validMappings = b.mappings.filter(m => m.confidence >= minConf);
    const recordsBtn = b.occurrences > 1
      ? `<button class="btn-records" data-behavior-key="${escapeHtml((b.behavior?.text || '') + ':' + (b.behavior?.page || ''))}">查看清单(${b.occurrences})</button>`
      : '';
    if (!validMappings.length) {
      return `<tr>
        <td><strong>${escapeHtml(b.behavior?.text || '(no text)')}</strong> ${recordsBtn}</td>
        <td>${escapeHtml(b.behavior?.page || '')}</td>
        <td colspan="3" style="color:#94a3b8;text-align:center">No correlated API</td>
      </tr>`;
    }
    return validMappings.map(m => `
    <tr>
      <td><strong>${escapeHtml(b.behavior?.text || '')}</strong> ${recordsBtn}</td>
      <td>${escapeHtml(b.behavior?.page || '')}</td>
      <td>${methodBadge(m.method)} ${escapeHtml(m.urlPath)}</td>
      <td><span class="conf ${confClass(m.confidence)}">${m.confidence.toFixed(2)}</span></td>
      <td>
        <div class="evidence-bar">
          <span class="evidence-item">T:<strong>${m.evidence?.temporal?.toFixed(2)}</strong></span>
          <span class="evidence-item">S:<strong>${m.evidence?.semantic?.toFixed(2)}</strong></span>
          <span class="evidence-item">P:<strong>${m.evidence?.param?.toFixed(2)}</strong></span>
        </div>
      </td>
    </tr>`);
  }).join('');
}

function updateStats() {
  const raw = data._raw || {};
  document.getElementById('statApis').textContent = data.apiAssets.length;
  document.getElementById('statPages').textContent = data.pageApiMap.length;
  document.getElementById('statBehaviors').textContent = data.behaviorApiMap.length;
  document.getElementById('badgeApis').textContent = data.apiAssets.length;
  document.getElementById('badgePages').textContent = data.pageApiMap.length;
  document.getElementById('badgeBehaviors').textContent = data.behaviorApiMap.length;
}

function render() { renderApis(); renderPages(); renderBehaviors(); updateStats(); }

// ===== History =====
function statusClass(s) {
  if (s >= 200 && s < 300) return '2xx';
  if (s >= 300 && s < 400) return '3xx';
  if (s >= 400 && s < 500) return '4xx';
  if (s >= 500) return '5xx';
  return '0';
}

function loadHistory() {
  const msg = {
    type: 'GET_HISTORY',
    page: hist.page,
    pageSize: hist.pageSize,
    sort: hist.sort,
    filter: hist.filter,
  };
  chrome.runtime.sendMessage(msg, r => {
    if (chrome.runtime.lastError || !r) return;
    hist.items = r.items || [];
    hist.total = r.total || 0;
    renderHistory();
  });
}

function renderHistory() {
  const tbody = document.querySelector('#tableHistory tbody');
  const fmtTs = ts => {
    const d = new Date(ts);
    return `${d.toLocaleDateString()} ${d.toLocaleTimeString()}.${String(d.getMilliseconds()).padStart(3,'0')}`;
  };
  const fmtDur = d => d >= 0 ? `${d}ms` : '-';
  const fmtUrl = url => {
    try { const u = new URL(url); return u.pathname + u.search; } catch { return url; }
  };

  tbody.innerHTML = hist.items.map(r => {
    const sc = statusClass(r.responseStatus);
    const rt = RESOURCE_MAP[r.resourceType] || r.resourceType || '-';
    return `<tr>
      <td class="hist-ts">${escapeHtml(fmtTs(r.timestamp))}</td>
      <td>${methodBadge(r.method)}</td>
      <td class="hist-url" title="${escapeHtml(r.url || '')}">${escapeHtml(fmtUrl(r.url || ''))}</td>
      <td><span class="status-badge status-${sc}">${r.responseStatus || '-'}</span></td>
      <td><span class="type-tag">${escapeHtml(rt)}</span></td>
      <td>${escapeHtml(fmtDur(r.duration))}</td>
      <td>${escapeHtml(r.pageContext?.path || r.pageUrl || '-')}</td>
      <td><button class="btn-detail" data-hist-id="${escapeHtml(r.id)}">查看详情</button></td>
    </tr>`;
  }).join('');

  // Count & pagination
  document.getElementById('histCount').textContent = `${hist.total} 条`;
  document.getElementById('badgeHistory').textContent = hist.total;
  const totalPages = Math.max(1, Math.ceil(hist.total / hist.pageSize));
  document.getElementById('histPageInfo').textContent = `${hist.page + 1} / ${totalPages}`;
  document.getElementById('histPrev').disabled = hist.page <= 0;
  document.getElementById('histNext').disabled = hist.page >= totalPages - 1;

  // Empty state
  const empty = document.getElementById('emptyHistory');
  empty.style.display = hist.items.length === 0 ? 'flex' : 'none';
}

// History detail modal
function openHistoryDetailModal(id) {
  chrome.runtime.sendMessage({ type: 'GET_HISTORY_DETAIL', id }, r => {
    if (chrome.runtime.lastError || !r || r.error) return;
    const isXhr = r.resourceType === 'xmlhttprequest' || r.resourceType === 'fetch';
    document.getElementById('histDetailTitle').textContent = `${r.method} ${r.url}`;
    document.getElementById('histDetailReqLine').innerHTML =
      `${methodBadge(r.method)} <span style="margin-left:8px">${escapeHtml(r.url)}</span>`;
    document.getElementById('histDetailReqHeaders').textContent =
      r.requestHeaders && Object.keys(r.requestHeaders).length
        ? JSON.stringify(r.requestHeaders, null, 2) : '(无)';
    const reqBodyEl = document.getElementById('histDetailReqBody');
    if (isXhr) {
      reqBodyEl.textContent = r.requestBody || '(无)';
      reqBodyEl.className = 'modal-pre';
    } else {
      reqBodyEl.textContent = '仅 fetch/XHR 请求支持查看请求体';
      reqBodyEl.className = 'modal-pre hist-body-hint';
    }
    const sc = statusClass(r.responseStatus);
    document.getElementById('histDetailRespLine').innerHTML =
      `<span class="status-badge status-${sc}">${r.responseStatus || '-'}</span>
       <span style="margin-left:8px">耗时: ${r.duration >= 0 ? r.duration + 'ms' : '-'}</span>`;
    const respBodyEl = document.getElementById('histDetailRespBody');
    if (isXhr) {
      respBodyEl.textContent = r.responseBody || '(无)';
      respBodyEl.className = 'modal-pre';
    } else {
      respBodyEl.textContent = '仅 fetch/XHR 请求支持查看响应体';
      respBodyEl.className = 'modal-pre hist-body-hint';
    }
    document.getElementById('historyDetailModal').style.display = 'flex';
  });
}
function closeHistoryDetailModal() {
  document.getElementById('historyDetailModal').style.display = 'none';
}
document.getElementById('histDetailClose').addEventListener('click', closeHistoryDetailModal);
document.getElementById('historyDetailModal').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeHistoryDetailModal();
});

// History event delegation — detail buttons
document.querySelector('#tableHistory tbody').addEventListener('click', e => {
  const btn = e.target.closest('[data-hist-id]');
  if (btn) openHistoryDetailModal(btn.dataset.histId);
});

// History filters
document.getElementById('histMethodFilter').addEventListener('change', e => {
  hist.filter.method = e.target.value;
  hist.page = 0;
  loadHistory();
});
document.getElementById('histStatusFilter').addEventListener('change', e => {
  hist.filter.statusClass = e.target.value;
  hist.page = 0;
  loadHistory();
});
document.getElementById('histTypeFilter').addEventListener('change', e => {
  hist.filter.resourceType = e.target.value;
  hist.page = 0;
  loadHistory();
});

// History search — reuse main filterInput
const origFilterInputHandler = document.getElementById('filterInput').oninput;

// History sort — click column headers
document.querySelectorAll('#tableHistory th.sortable').forEach(th => {
  th.addEventListener('click', () => {
    const field = th.dataset.sort;
    if (hist.sort.field === field) {
      hist.sort.dir = hist.sort.dir === 'desc' ? 'asc' : 'desc';
    } else {
      hist.sort.field = field;
      hist.sort.dir = 'desc';
    }
    // Update header indicators
    document.querySelectorAll('#tableHistory th.sortable').forEach(h => {
      h.textContent = h.textContent.replace(/ [↑↓]$/, '');
    });
    const label = th.textContent.replace(/ [↑↓]$/, '');
    th.textContent = label + (hist.sort.dir === 'desc' ? ' ↓' : ' ↑');
    hist.page = 0;
    loadHistory();
  });
});

// History pagination
document.getElementById('histPrev').addEventListener('click', () => {
  if (hist.page > 0) { hist.page--; loadHistory(); }
});
document.getElementById('histNext').addEventListener('click', () => {
  const totalPages = Math.ceil(hist.total / hist.pageSize);
  if (hist.page < totalPages - 1) { hist.page++; loadHistory(); }
});

function load() {
  chrome.runtime.sendMessage({ type: 'GET_EXPORT' }, r => {
    const err = chrome.runtime.lastError;
    if (err) {
      console.error('[Dashboard] sendMessage error:', err.message);
      return;
    }
    if (r && r.error) {
      console.error('[Dashboard] GET_EXPORT returned error:', r.error);
      return;
    }
    if (r) {
      data = r;
      console.log('[Dashboard] load: apiAssets=%d pageApiMap=%d behaviorApiMap=%d',
        (r.apiAssets || []).length, (r.pageApiMap || []).length, (r.behaviorApiMap || []).length);
      // Fetch raw counts separately for consistent stat display
      chrome.runtime.sendMessage({ type: 'GET_STATS' }, stats => {
        if (stats) data._raw = stats;
        render();
      });
      updateCaptureStatus();
    } else {
      console.warn('[Dashboard] load: empty response');
    }
  });
}

function updateCaptureStatus() {
  chrome.storage.session.get('capturing', s => {
    const el = document.getElementById('captureStatus');
    const on = s.capturing !== false;
    el.textContent = on ? '● 采集中' : '○ 已暂停';
    el.className = 'capture-status ' + (on ? 'on' : 'off');
  });
}

// Tab switching
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
    const slider = document.getElementById('confidenceSlider');
    slider.style.display = btn.dataset.tab === 'behaviors' ? 'flex' : 'none';
    // Hide main search for history tab (has its own filters)
    document.querySelector('.search-box').style.visibility = btn.dataset.tab === 'history' ? 'hidden' : 'visible';
    if (btn.dataset.tab === 'history') loadHistory();
  });
});

// Search
document.getElementById('filterInput').addEventListener('input', e => {
  filterText = e.target.value;
  document.getElementById('clearFilter').style.visibility = filterText ? 'visible' : 'hidden';
  // If history tab is active, also filter history
  const histTab = document.querySelector('[data-tab="history"]');
  if (histTab && histTab.classList.contains('active')) {
    hist.filter.search = filterText;
    hist.page = 0;
    loadHistory();
    return;
  }
  render();
});
document.getElementById('clearFilter').addEventListener('click', () => {
  document.getElementById('filterInput').value = '';
  filterText = '';
  document.getElementById('clearFilter').style.visibility = 'hidden';
  render();
});
document.getElementById('clearFilter').style.visibility = 'hidden';

// Confidence slider
document.getElementById('confSlider').addEventListener('input', e => {
  minConf = e.target.value / 100;
  document.getElementById('confVal').textContent = minConf.toFixed(2);
  render();
});

document.getElementById('refreshBtn').addEventListener('click', load);

// Export
document.getElementById('exportBtn').addEventListener('click', () => {
  const out = {
    apiAssets: data.apiAssets,
    pageApiMap: data.pageApiMap,
    behaviorApiMap: data.behaviorApiMap,
  };
  const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `sec-cap-${Date.now()}.json`; a.click();
  URL.revokeObjectURL(url);
});

// Modal
function openDetailModal(api) {
  const headers = api.sampleRequestHeaders || {};
  const body = api.sampleRequestBody || '';
  document.getElementById('modalHeaders').textContent = Object.keys(headers).length
    ? JSON.stringify(headers, null, 2) : '(无)';
  document.getElementById('modalBody').textContent = body || '(无)';
  document.getElementById('detailModal').style.display = 'flex';
}
function closeDetailModal() {
  document.getElementById('detailModal').style.display = 'none';
}
document.getElementById('modalClose').addEventListener('click', closeDetailModal);
document.getElementById('detailModal').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeDetailModal();
});
// Event delegation for detail buttons
document.querySelector('#tableApis tbody').addEventListener('click', e => {
  const detailBtn = e.target.closest('.btn-detail');
  if (detailBtn) {
    const idx = parseInt(detailBtn.dataset.index);
    if (!isNaN(idx) && data.apiAssets[idx]) openDetailModal(data.apiAssets[idx]);
    return;
  }
  const recordsBtn = e.target.closest('.btn-records');
  if (recordsBtn) {
    const idx = parseInt(recordsBtn.dataset.index);
    if (!isNaN(idx) && data.apiAssets[idx]) {
      openRecordsModal(data.apiAssets[idx].records, `${data.apiAssets[idx].method} ${data.apiAssets[idx].urlPath}`);
    }
  }
});

// Event delegation for behavior records buttons
document.querySelector('#tableBehaviors tbody').addEventListener('click', e => {
  const recordsBtn = e.target.closest('.btn-records');
  if (!recordsBtn) return;
  const key = recordsBtn.dataset.behaviorKey;
  if (!key) return;
  const entry = data.behaviorApiMap.find(b => `${b.behavior?.text || ''}:${b.behavior?.page || ''}` === key);
  if (entry) openRecordsModal(entry.records, entry.behavior?.text || '行为');
});

// Records modal
function openRecordsModal(records, title) {
  const el = document.getElementById('recordsModal');
  document.getElementById('recordsTitle').textContent = `调用清单 — ${escapeHtml(title)}`;
  if (!records || !records.length) {
    document.getElementById('recordsTableBody').innerHTML = '<tr><td colspan="5" style="color:#94a3b8;text-align:center">无记录</td></tr>';
    el.style.display = 'flex';
    return;
  }
  const tbody = document.getElementById('recordsTableBody');
  const isApi = 'method' in records[0];
  if (isApi) {
    tbody.innerHTML = records.map(r => `<tr>
      <td>${escapeHtml(new Date(r.timestamp).toLocaleTimeString())}</td>
      <td>${methodBadge(r.method)}</td>
      <td>${escapeHtml(r.status || '-')}</td>
      <td>${escapeHtml(r.pageUrl || '-')}</td>
      <td><pre>${escapeHtml(r.bodyPreview || '-')}</pre></td>
    </tr>`).join('');
  } else {
    tbody.innerHTML = records.map(r => `<tr>
      <td>${escapeHtml(new Date(r.timestamp).toLocaleTimeString())}</td>
      <td>${escapeHtml(r.type || '-')}</td>
      <td>${escapeHtml(r.elementText || '-')}</td>
      <td>${escapeHtml(r.pageUrl || '-')}</td>
    </tr>`).join('');
  }
  el.style.display = 'flex';
}
function closeRecordsModal() {
  document.getElementById('recordsModal').style.display = 'none';
}
document.getElementById('recordsModalClose').addEventListener('click', closeRecordsModal);
document.getElementById('recordsModal').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeRecordsModal();
});

// Startup health check
chrome.runtime.sendMessage({ type: 'PING' }, r => {
  const err = chrome.runtime.lastError;
  if (err) {
    console.error('[Dashboard] Service worker unreachable:', err.message);
    document.getElementById('captureStatus').textContent = '⚠ 无法连接 Service Worker';
    document.getElementById('captureStatus').className = 'capture-status off';
  } else {
    console.log('[Dashboard] Service worker reachable, pong=%o', r);
    load();
    setInterval(() => {
      load();
      // Refresh history if active
      const histTab = document.querySelector('[data-tab="history"]');
      if (histTab && histTab.classList.contains('active')) loadHistory();
    }, 5000);
  }
});

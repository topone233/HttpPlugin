# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Chrome extension (Manifest V3) that captures HTTP requests and user behavior in web applications for security testing. It correlates user actions (clicks, keyboard events) with API calls, producing a mapping of UI behaviors → API endpoints.

## Development

No build tools or package manager — plain JavaScript loaded directly by Chrome.

To test: load the `plugin/` directory as an unpacked extension at `chrome://extensions/`. After making changes, click the reload button on the extension card in `chrome://extensions/`.

## Architecture

### Message Flow

```
[injected scripts] --postMessage--> [content-main.js] --chrome.runtime.sendMessage--> [service-worker.js] --chrome.runtime.sendMessage--> [dashboard]
```

Three injection points in content scripts (all in `content/`, injected via manifest `content_scripts`):

1. **`interceptor.js`** — Runs in the page's MAIN world. Monkey-patches `window.fetch` and `window.XMLHttpRequest` to intercept all HTTP traffic. Posts captured requests via `window.postMessage`.
2. **`page-context.js`** — Runs in MAIN world. Extracts page context (path, title, breadcrumb, menu path) and detects SPA navigation via `history.pushState` patching + `MutationObserver`.
3. **`behavior-tracker.js`** — Runs in MAIN world. Captures click/keyboard events on interactive elements, extracts element text/data-attributes/row-data, posts via `window.postMessage`.

**`content-main.js`** — Runs in the content script's isolated world. Acts as bridge: injects the three MAIN-world scripts as `<script>` tags, listens for their `window.postMessage` events, and forwards to the service worker via `chrome.runtime.sendMessage`.

### Service Worker (`background/service-worker.js`)

Central message hub. Handles message types: `RAW_REQUEST`, `RAW_BEHAVIOR`, `GET_STATS`, `GET_EXPORT`, `CLEAR_DATA`, `GET_HISTORY`, `GET_HISTORY_DETAIL`, `REPLAY_REQUEST`.

Key logic — **behavior-API correlation**: When a behavior (click) arrives, it searches buffered requests (last 30s) within a dynamic time window. Scoring uses three evidence dimensions defined in `shared/constants.js` (`CORR`):
- **Param** (weight 0.4): exact match between request body values and element data-* attributes
- **Semantic** (weight 0.25): overlap coefficient between behavior text tokens and URL path tokens, using Chinese-English mapping (`ZH_EN` dictionary) and camelCase splitting
- **Temporal** (weight 0.35): inverse linear decay within the correlation window

Also performs **re-correlation**: buffered behaviors are re-checked whenever new requests arrive, handling race conditions where requests reach the SW after the behavior.

### Data Storage (`shared/db.js`)

IndexedDB (`sec_cap`) with five object stores:
- **requests** — capped at 5000 entries (evicts 500 oldest)
- **behaviors** — capped at 2000 entries (evicts 200 oldest)
- **mappings** — correlation results linking behaviors to requests
- **replayHistory** — capped at 500 entries (evicts 50 oldest)
- **testCases** — persisted test cases for replay

All stores have `timestamp` and `pageUrl` indexes. `mappings` additionally indexes `behaviorId` and `confidence`.

### UI Components

- **Dashboard** (`dashboard/dashboard.html`) — Full-page app with sidebar, three tabbed tables (API assets, page→API mapping, behavior→API mapping), search, confidence slider, detail modal, JSON export, and replay tab. Polls service worker every 5s.
- **Popup** (`popup/popup.html`) — Compact toolbar with capture toggle, quick stats, dashboard link, export/clear buttons. Polls stats every 2s.

### Shared Modules

Loaded via `importScripts` in the service worker; injected as `<script>` tags in content scripts (except `db.js` which is SW-only):

- **`shared/constants.js`** — Message type constants (`MSG`), correlation parameters (`CORR`), DB config (`DB`)
- **`shared/utils.js`** — URL parsing, tokenization (Chinese-English mapping, camelCase split), Jaccard similarity, static resource filtering (`isApiRequest`), noise domain/path filtering, ID generation.

### Key Patterns

- Messages between injected scripts and content-main.js use `window.postMessage` with `__type` discriminator fields (`__SEC_CAP__`, `__SEC_BEH__`, `__SEC_CAP_CTX__`)
- Service worker message responses use `sendResponse` return value; async responses require `return true` to keep the channel open
- Content scripts inject into MAIN world by creating `<script>` elements pointing to `chrome.runtime.getURL()` — these must be listed in `web_accessible_resources` in manifest.json
- The interceptor includes an anti-overwrite guard (`setInterval` every 2s) that detects if page code replaces the patched fetch/XHR

## Deployment

No build step. Load directory as unpacked extension. The extension uses `storage.session` for the capture toggle, so it auto-enables on extension startup.

<!-- gitnexus:start -->
# GitNexus — Code Intelligence

This project is indexed by GitNexus as **plugin** (455 symbols, 746 relationships, 32 execution flows). Use the GitNexus MCP tools to understand code, assess impact, and navigate safely.

> If any GitNexus tool warns the index is stale, run `npx gitnexus analyze` in terminal first.

## Always Do

- **MUST run impact analysis before editing any symbol.** Before modifying a function, class, or method, run `gitnexus_impact({target: "symbolName", direction: "upstream"})` and report the blast radius (direct callers, affected processes, risk level) to the user.
- **MUST run `gitnexus_detect_changes()` before committing** to verify your changes only affect expected symbols and execution flows.
- **MUST warn the user** if impact analysis returns HIGH or CRITICAL risk before proceeding with edits.
- When exploring unfamiliar code, use `gitnexus_query({query: "concept"})` to find execution flows instead of grepping. It returns process-grouped results ranked by relevance.
- When you need full context on a specific symbol — callers, callees, which execution flows it participates in — use `gitnexus_context({name: "symbolName"})`.

## Never Do

- NEVER edit a function, class, or method without first running `gitnexus_impact` on it.
- NEVER ignore HIGH or CRITICAL risk warnings from impact analysis.
- NEVER rename symbols with find-and-replace — use `gitnexus_rename` which understands the call graph.
- NEVER commit changes without running `gitnexus_detect_changes()` to check affected scope.

## Resources

| Resource | Use for |
|----------|---------|
| `gitnexus://repo/plugin/context` | Codebase overview, check index freshness |
| `gitnexus://repo/plugin/clusters` | All functional areas |
| `gitnexus://repo/plugin/processes` | All execution flows |
| `gitnexus://repo/plugin/process/{name}` | Step-by-step execution trace |

## CLI

| Task | Read this skill file |
|------|---------------------|
| Understand architecture / "How does X work?" | `.claude/skills/gitnexus/gitnexus-exploring/SKILL.md` |
| Blast radius / "What breaks if I change X?" | `.claude/skills/gitnexus/gitnexus-impact-analysis/SKILL.md` |
| Trace bugs / "Why is X failing?" | `.claude/skills/gitnexus/gitnexus-debugging/SKILL.md` |
| Rename / extract / split / refactor | `.claude/skills/gitnexus/gitnexus-refactoring/SKILL.md` |
| Tools, resources, schema reference | `.claude/skills/gitnexus/gitnexus-guide/SKILL.md` |
| Index, status, clean, wiki CLI commands | `.claude/skills/gitnexus/gitnexus-cli/SKILL.md` |

<!-- gitnexus:end -->

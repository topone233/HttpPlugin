(function () {
  const PREFIX = '__SEC_CAP__';
  const DEBUG = false;
  let cachedContext = null;

  // Inject interceptor into MAIN world (needs real window.fetch)
  const s = document.createElement('script');
  s.src = chrome.runtime.getURL('content/interceptor.js');
  (document.head || document.documentElement).appendChild(s);
  s.onload = () => s.remove();
  s.onerror = () => console.error('[CM] failed to load interceptor.js');

  // Load page-context and behavior-tracker
  [
    chrome.runtime.getURL('content/page-context.js'),
    chrome.runtime.getURL('content/behavior-tracker.js'),
  ].forEach(src => {
    const el = document.createElement('script');
    el.src = src;
    (document.head || document.documentElement).appendChild(el);
    el.onload = () => el.remove();
    el.onerror = () => console.error('[CM] failed to load', src);
  });

  window.addEventListener('message', e => {
    if (!e.data) return;
    if (e.data.__type === PREFIX) {
      const raw = e.data.data;
      if (!raw?.url) return;
      chrome.runtime.sendMessage({
        type: 'RAW_REQUEST',
        payload: { ...raw, pageUrl: location.href, pageContext: cachedContext },
      }).catch(err => console.error('[CM] sendMsg RAW_REQUEST failed:', err));
    } else if (e.data.__type === '__SEC_BEH__') {
      if (DEBUG) console.log('[CM] forwarding behavior:', e.data.data.elementText);
      chrome.runtime.sendMessage({
        type: 'RAW_BEHAVIOR',
        payload: { ...e.data.data, pageContext: e.data.data.pageContext || cachedContext },
      }).catch(err => console.error('[CM] sendMsg behavior failed:', err));
    } else if (e.data.__type === '__SEC_CAP_CTX__') {
      cachedContext = e.data.data;
    }
  });
})();

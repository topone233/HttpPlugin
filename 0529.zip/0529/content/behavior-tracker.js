(function () {
  const PREFIX = '__SEC_BEH__';
  const DEBUG = false;
  const INTERACTIVE = 'button,[role=button],[data-action],a,[type=submit],input[type=button],input[type=submit]';
  const INPUT_SELECTOR = 'input:not([type=hidden]):not([type=password]),textarea,select';
  const STABLE_ATTRS = ['data-action', 'data-testid', 'data-test', 'data-id', 'data-key', 'name', 'aria-label', 'title', 'id'];

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
    return String(value).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
  }

  function attrSelector(el) {
    for (const name of STABLE_ATTRS) {
      const value = el.getAttribute(name);
      if (value) return `${el.tagName.toLowerCase()}[${name}="${cssEscape(value)}"]`;
    }
    return el.tagName.toLowerCase();
  }

  function stableSelector(el) {
    const parts = [];
    let node = el;
    while (node && node.nodeType === 1 && node !== document.body && parts.length < 5) {
      parts.unshift(attrSelector(node));
      if (node.id) break;
      node = node.parentElement;
    }
    return parts.join(' > ');
  }

  function extractDataAttrs(el) {
    const data = {};
    [...el.attributes].filter(a => a.name.startsWith('data-')).forEach(a => { data[a.name] = a.value; });
    return data;
  }

  function nearestForm(el) {
    return el.closest('form,[role=form],.el-form,.ant-form,.arco-form');
  }

  function extractFormData(el) {
    const form = nearestForm(el);
    if (!form) return null;
    const data = {};
    form.querySelectorAll(INPUT_SELECTOR).forEach(input => {
      const key = input.name || input.id || input.getAttribute('aria-label') || input.placeholder;
      if (!key) return;
      if (input.type === 'checkbox' || input.type === 'radio') {
        if (!input.checked) return;
      }
      const value = input.value;
      if (value != null && String(value).trim() !== '') data[key] = String(value).slice(0, 120);
    });
    return Object.keys(data).length ? data : null;
  }

  function extractRowData(el) {
    let node = el;
    while (node && node !== document.body) {
      if (node.tagName === 'TR' || node.getAttribute('role') === 'row' || node.classList.contains('ant-table-row') || node.classList.contains('el-table__row')) {
        const data = {};
        Object.assign(data, extractDataAttrs(node));
        node.querySelectorAll('[data-id],[data-key],[data-row-key],[data-value]').forEach(c => {
          Object.assign(data, extractDataAttrs(c));
        });
        const cells = [...node.querySelectorAll('td,[role=cell]')].slice(0, 12);
        cells.forEach((cell, index) => {
          const text = cell.textContent?.trim();
          if (text) data[`cell_${index}`] = text.slice(0, 120);
        });
        return Object.keys(data).length ? data : null;
      }
      node = node.parentElement;
    }
    return null;
  }

  function getLabel(el) {
    if (el.dataset.action) return el.dataset.action;
    const dataVals = Object.entries(el.dataset).filter(([k]) => !k.startsWith('v-')).map(([, v]) => v).filter(Boolean);
    if (dataVals.length) return dataVals[0];
    return el.getAttribute('aria-label') || el.title || el.value || el.textContent?.trim() || '';
  }

  function getContextText(el) {
    const texts = [];
    const container = el.closest('td,li,.el-dialog,.ant-modal,.arco-modal,.drawer,.panel,.card,section,form');
    if (container) {
      const heading = container.querySelector('h1,h2,h3,h4,.title,.modal-title,.el-dialog__title,.ant-modal-title');
      if (heading?.textContent?.trim()) texts.push(heading.textContent.trim());
      const nearby = container.textContent?.trim();
      if (nearby) texts.push(nearby.slice(0, 300));
    }
    return [...new Set(texts)].join(' ');
  }

  function capture(e) {
    const target = e.target.closest(INTERACTIVE);
    if (!target) return;

    let pageContext = null;
    if (typeof window.__SEC_CAP_CTX__ === 'function') {
      try { pageContext = window.__SEC_CAP_CTX__(); } catch {}
    }

    const event = {
      timestamp: Date.now(),
      type: e.type,
      elementText: getLabel(target),
      elementTag: target.tagName.toLowerCase(),
      elementRole: target.getAttribute('role') || null,
      elementName: target.getAttribute('name') || null,
      selector: stableSelector(target),
      contextText: getContextText(target),
      dataAttrs: extractDataAttrs(target),
      ariaLabel: target.getAttribute('aria-label'),
      title: target.title || null,
      rowData: extractRowData(target),
      formData: extractFormData(target),
      pageUrl: location.href,
      pageContext,
    };

    if (DEBUG) console.log('[BEH] captured:', event.elementText, event.elementTag, 'rowData:', JSON.stringify(event.rowData));
    window.postMessage({ __type: PREFIX, data: event }, '*');
  }

  document.addEventListener('click', capture, true);
  document.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') capture(e);
  }, true);
})();

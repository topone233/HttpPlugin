(function () {
  const PREFIX = '__SEC_CAP_CTX__';
  const BREADCRUMB_SELS = [
    '.el-breadcrumb__item', '.ant-breadcrumb-link', '.arco-breadcrumb-item',
    '[aria-label="breadcrumb"] li', 'nav ol li', '.breadcrumb-item',
  ];
  const MENU_SELS = [
    '.el-menu-item.is-active', '.ant-menu-item-selected', '.arco-menu-item-selected',
    '[role="menuitem"][aria-selected="true"]', '.menu-item.active', '.nav-item.active',
  ];
  const QUERY_KEYS = ['id', 'code', 'key', 'type', 'tab', 'page', 'menu', 'route'];

  function textList(selector) {
    return [...document.querySelectorAll(selector)]
      .map(el => el.textContent.trim())
      .filter(Boolean);
  }

  function extractBreadcrumb() {
    for (const sel of BREADCRUMB_SELS) {
      const items = textList(sel);
      if (items.length > 1) return items;
    }
    return [];
  }

  function extractMenuPath() {
    for (const sel of MENU_SELS) {
      const items = textList(sel);
      if (items.length) return items.slice(0, 3);
    }
    return [];
  }

  function normalizedSearch() {
    const params = new URLSearchParams(location.search);
    const selected = [];
    for (const key of QUERY_KEYS) {
      if (params.has(key)) selected.push(`${key}=${params.get(key)}`);
    }
    return selected.length ? `?${selected.join('&')}` : '';
  }

  function currentPageKey(ctx) {
    const hash = location.hash && location.hash !== '#' ? location.hash : '';
    const menu = ctx.menuPath?.length ? `|menu:${ctx.menuPath.join('/')}` : '';
    const crumb = ctx.breadcrumb?.length ? `|bc:${ctx.breadcrumb.join('/')}` : '';
    return `${ctx.path}${normalizedSearch()}${hash}${menu || crumb}`;
  }

  function getCurrentContext() {
    const ctx = {
      path: location.pathname,
      search: location.search,
      hash: location.hash,
      title: document.title,
      breadcrumb: extractBreadcrumb(),
      menuPath: extractMenuPath(),
      url: location.href,
    };
    ctx.pageKey = currentPageKey(ctx);
    return ctx;
  }

  function postContext() {
    window.postMessage({ __type: PREFIX, data: getCurrentContext() }, '*');
  }

  window.__SEC_CAP_CTX__ = getCurrentContext;
  postContext();

  let debounceTimer = 0;
  let lastSerialized = '';
  const notify = () => {
    if (debounceTimer) return;
    debounceTimer = setTimeout(() => {
      debounceTimer = 0;
      const ctx = getCurrentContext();
      const serialized = JSON.stringify(ctx);
      if (serialized === lastSerialized) return;
      lastSerialized = serialized;
      window.__SEC_CAP_CTX__ = getCurrentContext;
      window.postMessage({ __type: PREFIX, data: ctx }, '*');
    }, 300);
  };

  const origPush = history.pushState;
  const origReplace = history.replaceState;
  history.pushState = function (...a) { origPush.apply(this, a); notify(); };
  history.replaceState = function (...a) { origReplace.apply(this, a); notify(); };
  window.addEventListener('popstate', notify);
  window.addEventListener('hashchange', notify);

  function startObserver() {
    if (!document.body) return;
    new MutationObserver(notify).observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  if (document.body) {
    startObserver();
  } else {
    document.addEventListener('DOMContentLoaded', startObserver, { once: true });
  }
})();

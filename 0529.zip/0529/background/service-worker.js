importScripts('../shared/constants.js', '../shared/utils.js', '../shared/db.js');

const DEBUG = false;

// Capture toggle, mirrored from chrome.storage.session.capturing.
// Start false until storage is read to avoid capturing before user preference is known.
let capturing = false;
chrome.storage.session.get('capturing', r => {
  capturing = r.capturing !== false;
  setBadge(capturing);
});

// In-memory buffer for correlation: last 30s of requests per tab
const reqBuffer = new Map(); // tabId -> [{...}]
const pendingBehaviors = new Map(); // tabId -> [{behavior, enqueuedAt}]
const recentPageContext = new Map(); // tabId -> { context, seenAt }

// webRequest capture: pending requests + interceptor body cache
const wrPending = new Map(); // requestId -> { tabId, method, url, urlPath, startTime, reqHeaders, resourceType, pageUrl }
const BODY_CACHE_MAX = 200;

function getBuffer(map, tabId) {
  if (!map.has(tabId)) map.set(tabId, []);
  return map.get(tabId);
}

function pruneBuffer(buf, windowMs = 30000) {
  const cutoff = Date.now() - windowMs;
  while (buf.length && buf[0].ts < cutoff) buf.shift();
}

// Dynamic window: extend for export/download actions
function dynamicWindow(behaviorText) {
  const t = (behaviorText || '').toLowerCase();
  let w = CORR.BASE_WINDOW;
  if (/export|导出|download|下载/.test(t)) w += 1000;
  return Math.min(w + 2000, CORR.MAX_WINDOW); // +2000 for chain
}

function correlate(behavior, requests) {
  const win = dynamicWindow(behavior.elementText);
  const T = behavior.timestamp;

  // Stage 1: candidate filtering — include requests from 500ms BEFORE click too
  // (some requests start just before click event fires due to event loop)
  const candidates = requests.filter(r =>
    r.ts >= T - 1000 && r.ts <= T + win && isApiRequest(r.url)
  );

  if (DEBUG) console.log('[SW] correlate:', behavior.elementText, 'T=', T, 'win=', win,
    'totalBuf=', requests.length, 'candidates=', candidates.length,
    candidates.map(r => `${r.method} ${r.url} ts=${r.ts}`));

  if (!candidates.length) return [];

  const bTokens = tokenize(behavior.elementText || behavior.ariaLabel || behavior.title || '');
  const isMutation = ['POST', 'PUT', 'DELETE', 'PATCH'];
  const results = [];

  for (const req of candidates) {
    const rTokens = tokenizeUrl(req.url);

    const temporal = Math.max(0, 1 - Math.max(0, req.ts - T) / win);
    const semantic = overlap(bTokens, rTokens);
    const param = strongMatch(behavior.rowData, req.reqBody);

    // Method boost: mutation methods are stronger action signals
    const methodBoost = isMutation.includes(req.method) ? 0.1 : 0;

    const confidence = CORR.W_PARAM * param + CORR.W_SEMANTIC * semantic + CORR.W_TEMPORAL * temporal + methodBoost;

    if (DEBUG) console.log('[SW]   candidate:', req.method, req.url,
      'temporal=', temporal.toFixed(3), 'semantic=', semantic.toFixed(3), 'param=', param,
      'confidence=', confidence.toFixed(3), 'threshold=', CORR.THRESHOLD);

    if (confidence < CORR.THRESHOLD) continue;

    // Classify type
    let reqType = 'unknown';
    if (param === 1.0) reqType = 'action';
    else if (isMutation.includes(req.method) && temporal >= 0.5) reqType = 'action';
    else if (['OPTIONS', 'HEAD'].includes(req.method)) reqType = 'precheck';
    else if (req.method === 'GET' && semantic < 0.1 && param === 0) reqType = 'refresh';
    else if (confidence >= 0.5) reqType = 'action';

    results.push({
      id: generateId(),
      behaviorId: behavior.id,
      behavior: { type: behavior.type, text: behavior.elementText, page: behavior.pageContext?.path },
      request: { method: req.method, urlPath: new URL(req.url).pathname, url: req.url },
      confidence: Math.round(confidence * 100) / 100,
      evidence: {
        temporal: Math.round(temporal * 100) / 100,
        semantic: Math.round(semantic * 100) / 100,
        param,
      },
      reqType,
      timestamp: req.ts,
    });
  }

  return results.sort((a, b) => b.confidence - a.confidence);
}

function dynamicWindow(behaviorText) {
  const t = (behaviorText || '').toLowerCase();
  let w = CORR.BASE_WINDOW;
  if (/export|导出|download|下载|import|导入|upload|上传/.test(t)) w += 1000;
  return Math.min(w + 2000, CORR.MAX_WINDOW);
}

function roundScore(v) {
  return Math.round(Math.max(0, Math.min(1, v)) * 100) / 100;
}

function confidenceLevel(confidence) {
  if (confidence >= 0.7) return 'high';
  if (confidence >= 0.35) return 'medium';
  if (confidence >= CORR.THRESHOLD) return 'low';
  return 'candidate';
}

function mappingStatus(confidence) {
  if (confidence >= 0.7) return 'confirmed';
  if (confidence >= CORR.THRESHOLD) return 'candidate';
  return 'unmapped';
}

function pageKeyOf(ctx) {
  return ctx?.pageKey || ctx?.path || '';
}

function contextTokens(behavior) {
  return tokenize([
    behavior.elementText,
    behavior.ariaLabel,
    behavior.title,
    behavior.elementName,
    behavior.elementRole,
    behavior.selector,
    behavior.contextText,
    behavior.pageContext?.title,
    ...(behavior.pageContext?.breadcrumb || []),
    ...(behavior.pageContext?.menuPath || []),
  ].filter(Boolean).join(' '));
}

function pageConsistency(behavior, req) {
  const bKey = pageKeyOf(behavior.pageContext);
  const rKey = pageKeyOf(req.pageContext);
  if (bKey && rKey) return bKey === rKey ? 1 : 0;
  if (behavior.pageUrl && req.pageUrl) {
    try {
      const b = new URL(behavior.pageUrl);
      const r = new URL(req.pageUrl);
      if (b.origin === r.origin && b.pathname === r.pathname) return 0.7;
    } catch {}
  }
  return 0.3;
}

function requestNoisePenalty(req) {
  if (['OPTIONS', 'HEAD'].includes(req.method)) return 0.25;
  try {
    const path = new URL(req.url).pathname;
    if (/\/(list|page|tree|dict|option|options|count|stats|refresh|poll|heartbeat)(\/|$)/i.test(path) && req.method === 'GET') return 0.12;
  } catch {}
  return 0;
}

function requestPath(url) {
  try {
    const u = new URL(url);
    return `${u.pathname}${u.search}`;
  } catch {
    return url;
  }
}

function classifyRequest(req, evidence, confidence) {
  const isMutation = ['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method);
  if (evidence.param === 1) return 'action';
  if (['OPTIONS', 'HEAD'].includes(req.method)) return 'precheck';
  if (isMutation && evidence.temporal >= 0.35) return 'action';
  if (req.method === 'GET' && evidence.semantic < 0.1 && evidence.param === 0) return 'refresh';
  if (confidence >= 0.5) return 'action';
  return 'candidate';
}

function dedupeMappings(mappings) {
  const seen = new Set();
  const out = [];
  for (const m of mappings) {
    const key = `${m.request.method}:${m.request.urlPath}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(m);
  }
  return out;
}

function correlate(behavior, requests) {
  const win = dynamicWindow(behavior.elementText);
  const T = behavior.timestamp;
  const candidates = requests.filter(r =>
    r.ts >= T - 1000 && r.ts <= T + win && isApiRequest(r.url)
  );

  if (!candidates.length) return [];

  const bTokens = contextTokens(behavior);
  const mutationMethods = ['POST', 'PUT', 'DELETE', 'PATCH'];
  const scored = [];

  for (const req of candidates) {
    const rTokens = tokenizeUrl(req.url);
    const temporal = Math.max(0, 1 - Math.max(0, req.ts - T) / win);
    const semantic = overlap(bTokens, rTokens);
    const param = Math.max(
      strongMatch(behavior.rowData, req.reqBody, req.url),
      strongMatch(behavior.formData, req.reqBody, req.url)
    );
    const page = pageConsistency(behavior, req);
    const method = mutationMethods.includes(req.method) ? 1 : (req.method === 'GET' ? 0.35 : 0.1);
    const noisePenalty = requestNoisePenalty(req);
    const confidence = roundScore(
      CORR.W_PARAM * param +
      CORR.W_SEMANTIC * semantic +
      CORR.W_TEMPORAL * temporal +
      0.12 * page +
      0.08 * method -
      noisePenalty
    );

    if (confidence < 0.05) continue;

    const evidence = {
      temporal: roundScore(temporal),
      semantic: roundScore(semantic),
      param: roundScore(param),
      page: roundScore(page),
      method: roundScore(method),
      noisePenalty: roundScore(noisePenalty),
    };

    scored.push({
      id: generateId(),
      behaviorId: behavior.id,
      behavior: {
        type: behavior.type,
        text: behavior.elementText,
        page: behavior.pageContext?.path,
        pageKey: pageKeyOf(behavior.pageContext),
      },
      request: { method: req.method, urlPath: requestPath(req.url), url: req.url },
      confidence,
      confidenceLevel: confidenceLevel(confidence),
      mappingStatus: mappingStatus(confidence),
      evidence,
      reqType: classifyRequest(req, evidence, confidence),
      timestamp: req.ts,
    });
  }

  return dedupeMappings(scored.sort((a, b) => b.confidence - a.confidence))
    .map((m, index) => ({
      ...m,
      rank: index + 1,
      isPrimary: index === 0 && m.confidence >= CORR.THRESHOLD,
    }))
    .slice(0, 3);
}

async function saveWebRequestRecord(details) {
  const { requestId, tabId, method, url, statusCode, resourceType, startTime, reqHeaders, pageUrl, duration } = details;
  const urlPath = (() => { try { return new URL(url).pathname; } catch { return url; } })();
  const recent = recentPageContext.get(tabId);
  const inferredContext = recent && Date.now() - recent.seenAt < 30000 ? recent.context : null;

  const record = {
    id: generateId(),
    timestamp: startTime || Date.now(),
    tabId,
    method: method || 'GET',
    url,
    urlPath,
    resourceType: resourceType || 'other',
    requestHeaders: reqHeaders || {},
    requestBody: null,
    responseStatus: statusCode || 0,
    responseBody: null,
    pageUrl: pageUrl || '',
    pageContext: inferredContext,
    pageContextInferred: !!inferredContext,
    duration: duration ?? -1,
  };
  await put('requests', record);
  await backupAndEvictRequests(DB.REQUESTS_CAP, DB.REQUESTS_EVICT);
  return record;
}

async function getOldestRequests(limit) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction('requests', 'readonly');
    const s = t.objectStore('requests');
    const idx = s.index('timestamp');
    const req = idx.openCursor(null, 'next');
    const records = [];
    req.onsuccess = e => {
      const cursor = e.target.result;
      if (!cursor || records.length >= limit) {
        resolve(records);
        return;
      }
      records.push(cursor.value);
      cursor.continue();
    };
    req.onerror = () => reject(req.error);
  });
}

async function deleteRequestsById(ids) {
  if (!ids.length) return;
  const db = await openDb();
  await new Promise((resolve, reject) => {
    const t = db.transaction('requests', 'readwrite');
    const s = t.objectStore('requests');
    for (const id of ids) s.delete(id);
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

function requestBackupFilename(now = new Date()) {
  const pad = n => String(n).padStart(2, '0');
  const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
  return `api-capture-backup-${stamp}.json`;
}

function buildRequestBackup(requests, behaviors, mappings) {
  const requestKeys = new Set(requests.map(r => `${r.method}:${r.urlPath}:${r.url}`));
  const relatedMappings = mappings.filter(m => {
    const req = m.request || {};
    return requestKeys.has(`${req.method}:${req.urlPath}:${req.url}`);
  });
  const behaviorIds = new Set(relatedMappings.map(m => m.behaviorId).filter(Boolean));
  const relatedBehaviors = behaviors.filter(b => behaviorIds.has(b.id));
  return {
    exportedAt: new Date().toISOString(),
    type: 'requests-overflow',
    count: requests.length,
    requests,
    mappings: relatedMappings,
    behaviors: relatedBehaviors,
  };
}

async function downloadJsonBackup(payload) {
  const json = JSON.stringify(payload, null, 2);
  const url = `data:application/json;charset=utf-8,${encodeURIComponent(json)}`;
  await chrome.downloads.download({
    url,
    filename: requestBackupFilename(),
    saveAs: false,
    conflictAction: 'uniquify',
  });
}

async function backupAndEvictRequests(cap, evictCount) {
  const n = await count('requests');
  if (n <= cap) return;
  const overflow = Math.min(evictCount, n);
  const requests = await getOldestRequests(overflow);
  if (!requests.length) return;
  const [behaviors, mappings] = await Promise.all([getAll('behaviors'), getAll('mappings')]);
  await downloadJsonBackup(buildRequestBackup(requests, behaviors, mappings));
  await deleteRequestsById(requests.map(r => r.id));
}

// webRequest listeners
chrome.webRequest.onBeforeSendHeaders.addListener(
  details => {
    if (!capturing) return;
    if (details.tabId < 0) return;
    // Prune stale entries (requests that never completed)
    const now = Date.now();
    for (const [id, p] of wrPending) {
      if (now - p.startTime > 60000) wrPending.delete(id);
    }
    const reqHeaders = {};
    if (details.requestHeaders) details.requestHeaders.forEach(h => { reqHeaders[h.name] = h.value; });
    wrPending.set(details.requestId, {
      requestId: details.requestId,
      tabId: details.tabId,
      method: details.method,
      url: details.url,
      startTime: details.timeStamp,
      reqHeaders,
      resourceType: details.type,
      pageUrl: details.initiator || '',
    });
  },
  { urls: ['<all_urls>'] },
  ['requestHeaders']
);

chrome.webRequest.onCompleted.addListener(
  details => {
    const pending = wrPending.get(details.requestId);
    if (!pending) return;
    wrPending.delete(details.requestId);
    pending.statusCode = details.statusCode;
    pending.duration = details.timeStamp - (pending.startTime || details.timeStamp);
    saveWebRequestRecord(pending);
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

chrome.webRequest.onErrorOccurred.addListener(
  details => {
    const pending = wrPending.get(details.requestId);
    if (!pending) return;
    wrPending.delete(details.requestId);
    pending.statusCode = 0;
    pending.duration = -1;
    saveWebRequestRecord(pending);
  },
  { urls: ['<all_urls>'] }
);

// Periodic cleanup: prune wrPending entries older than 2 minutes
setInterval(() => {
  const now = Date.now();
  for (const [id, p] of wrPending) {
    if (now - p.startTime > 120000) wrPending.delete(id);
  }
}, 60000);

// ===== Monitor: alarm helpers =====
function scheduleMonitor(monitor) {
  const alarmName = `monitor_${monitor.id}`;
  chrome.alarms.clear(alarmName, () => {
    if (!monitor.enabled) return;

    if (monitor.scheduleType === 'cron' && monitor.cronExpression) {
      const nextTime = cronNextTime(monitor.cronExpression);
      if (nextTime) {
        chrome.alarms.create(alarmName, { when: nextTime.getTime() });
      }
    } else {
      // interval mode (default, backward-compatible with old data lacking scheduleType)
      const seconds = monitor.intervalSeconds || 60;
      const periodInMinutes = Math.max(1 / 60, seconds / 60);
      chrome.alarms.create(alarmName, { periodInMinutes });
    }
  });
}

async function rearmAllMonitors() {
  const allAlarms = await chrome.alarms.getAll();
  for (const alarm of allAlarms) {
    if (alarm.name.startsWith('monitor_')) {
      await chrome.alarms.clear(alarm.name);
    }
  }
  try {
    const monitors = await getAll('monitors');
    for (const m of monitors) {
      if (m.enabled) scheduleMonitor(m);
    }
  } catch (err) {
    console.error('[SW] rearmAllMonitors failed:', err);
  }
}

async function clearMonitorAlarms() {
  const allAlarms = await chrome.alarms.getAll();
  await Promise.all(
    allAlarms
      .filter(alarm => alarm.name.startsWith('monitor_'))
      .map(alarm => chrome.alarms.clear(alarm.name))
  );
}

// ===== Monitor: execution engine =====
function applyVarsToHeaders(headersArray, vars) {
  const result = {};
  for (const h of (headersArray || [])) {
    if (h.key) result[h.key] = applyMonitorVariables(h.value, vars);
  }
  return result;
}

async function executeMonitor(monitorId) {
  let monitor;
  try {
    monitor = await getById('monitors', monitorId);
  } catch (err) {
    console.error('[SW] executeMonitor: failed to load', monitorId, err);
    return;
  }
  if (!monitor || !monitor.enabled) return;

  const result = {
    id: generateId(),
    monitorId,
    timestamp: Date.now(),
    success: false,
    preResponseStatus: null,
    preResponseBody: null,
    preDuration: null,
    responseStatus: 0,
    responseHeaders: {},
    responseBody: '',
    duration: 0,
    error: null,
    extractedVars: {},
  };

  let vars = {};

  // Step 1: Pre-request (auth refresh)
  if (monitor.preRequest) {
    try {
      const preHeaders = applyVarsToHeaders(monitor.preRequest.headers, vars);
      const preUrl = applyMonitorVariables(monitor.preRequest.url, vars);
      const preBody = applyMonitorVariables(monitor.preRequest.body, vars);

      const preOpts = {
        method: monitor.preRequest.method || 'GET',
        headers: preHeaders,
        credentials: 'include',
      };
      if (preBody && preOpts.method !== 'GET' && preOpts.method !== 'HEAD') {
        preOpts.body = preBody;
      }

      const preStart = Date.now();
      const preResp = await fetch(preUrl, preOpts);
      result.preDuration = Date.now() - preStart;
      result.preResponseStatus = preResp.status;

      const preRespHeaders = {};
      preResp.headers.forEach((v, k) => { preRespHeaders[k] = v; });

      result.preResponseBody = await preResp.text();

      if (monitor.preRequest.extractRules && monitor.preRequest.extractRules.length) {
        const extracted = extractFromResponse(preRespHeaders, result.preResponseBody, monitor.preRequest.extractRules);
        result.extractedVars = extracted;
        vars = { ...vars, ...extracted };
      }
    } catch (err) {
      result.error = `Pre-request failed: ${err.message}`;
    }
  }

  // Step 2: Main request
  try {
    const mainHeaders = applyVarsToHeaders(monitor.mainRequest.headers, vars);
    const mainUrl = applyMonitorVariables(monitor.mainRequest.url, vars);
    const mainBody = applyMonitorVariables(monitor.mainRequest.body, vars);

    const mainOpts = {
      method: monitor.mainRequest.method || 'GET',
      headers: mainHeaders,
      credentials: 'include',
    };
    if (mainBody && mainOpts.method !== 'GET' && mainOpts.method !== 'HEAD') {
      mainOpts.body = mainBody;
    }

    const mainStart = Date.now();
    const mainResp = await fetch(mainUrl, mainOpts);
    result.duration = Date.now() - mainStart;
    result.responseStatus = mainResp.status;

    mainResp.headers.forEach((v, k) => { result.responseHeaders[k] = v; });
    result.responseBody = await mainResp.text();
    result.success = mainResp.status >= 200 && mainResp.status < 400;
  } catch (err) {
    result.error = result.error ? `${result.error}; Main request: ${err.message}` : err.message;
    result.success = false;
  }

  // Save result
  try {
    await put('monitorResults', result);
    await evictOldest('monitorResults', DB.MONITOR_RESULTS_CAP, DB.MONITOR_RESULTS_EVICT);
  } catch (err) {
    console.error('[SW] executeMonitor: failed to save result', err);
  }

  // Notify dashboard
  chrome.runtime.sendMessage({ type: MSG.MONITOR_RESULT, result }).catch(() => {});

  // Reschedule cron monitors (one-shot alarm, must be recreated)
  if (monitor.scheduleType === 'cron' && monitor.cronExpression) {
    const nextTime = cronNextTime(monitor.cronExpression);
    if (nextTime) {
      chrome.alarms.create(`monitor_${monitorId}`, { when: nextTime.getTime() });
    }
  }
}

// Alarm listener
chrome.alarms.onAlarm.addListener(alarm => {
  if (!alarm.name.startsWith('monitor_')) return;
  const monitorId = alarm.name.slice('monitor_'.length);
  executeMonitor(monitorId).catch(err => console.error('[SW] onAlarm failed:', err));
});

// Clean up per-tab state when a tab is closed
chrome.tabs.onRemoved.addListener(tabId => {
  for (const [id, p] of wrPending) {
    if (p.tabId === tabId) wrPending.delete(id);
  }
  reqBuffer.delete(tabId);
  pendingBehaviors.delete(tabId);
  recentPageContext.delete(tabId);
});

async function saveBehavior(payload) {
  const record = {
    id: generateId(),
    timestamp: payload.timestamp || Date.now(),
    type: payload.type,
    elementText: payload.elementText,
    elementTag: payload.elementTag,
    elementRole: payload.elementRole || null,
    elementName: payload.elementName || null,
    selector: payload.selector || '',
    contextText: payload.contextText || '',
    dataAttrs: payload.dataAttrs || {},
    ariaLabel: payload.ariaLabel,
    title: payload.title,
    rowData: payload.rowData || {},
    formData: payload.formData || {},
    pageContext: payload.pageContext || null,
    pageUrl: payload.pageUrl,
  };
  await put('behaviors', record);
  await evictOldest('behaviors', DB.BEHAVIORS_CAP, DB.BEHAVIORS_EVICT);
  return record;
}

function setBadge(capturing) {
  chrome.action.setBadgeText({ text: capturing ? 'ON' : 'OFF' });
  chrome.action.setBadgeBackgroundColor({ color: capturing ? '#4ec94e' : '#e04e4e' });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'session' && 'capturing' in changes) {
    capturing = changes.capturing.newValue !== false;
    setBadge(capturing);
  }
});

chrome.runtime.onInstalled.addListener(() => {
  setBadge(true);
  rearmAllMonitors().catch(err => console.error('[SW] rearmAllMonitors onInstalled failed:', err));
});
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.session.get('capturing', r => setBadge(r.capturing !== false));
  rearmAllMonitors().catch(err => console.error('[SW] rearmAllMonitors onStartup failed:', err));
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  if (msg.type === 'RAW_REQUEST') {
    if (!capturing) return;
    const payload = { ...msg.payload, tabId };
    if (!isApiRequest(payload.url)) return;
    if (payload.pageContext) recentPageContext.set(tabId, { context: payload.pageContext, seenAt: Date.now() });

    // Backfill: find the webRequest-saved record that lacks responseBody and update it
    if (tabId && payload.respBody != null) {
      const ts = payload.ts || Date.now();
      findAndBackfill('requests', payload.url, ts, {
        reqBody: payload.reqBody,
        respBody: payload.respBody,
        reqHeaders: payload.reqHeaders,
        status: payload.status,
        pageContext: payload.pageContext,
      }).then(found => {
        if (DEBUG) console.log('[SW] backfill: updated', payload.method, payload.url, 'with responseBody');
      }).catch(err => console.error('[SW] backfill failed:', err));
    }

    // Also push to correlation buffer (for behavior-API correlation)
    const buf = getBuffer(reqBuffer, tabId);
    pruneBuffer(buf);
    buf.push({ ...payload, ts: payload.ts || Date.now() });

    // Re-correlate pending behaviors
    const pending = getBuffer(pendingBehaviors, tabId);
    const now = Date.now();
    while (pending.length && now - pending[0].enqueuedAt > CORR.MAX_WINDOW) pending.shift();

    if (DEBUG && pending.length) console.log('[SW] re-correlate: new request', payload.method, payload.url, 'against', pending.length, 'pending behaviors');
    (async () => {
      for (const { behavior } of pending) {
        const mappings = correlate(behavior, buf);
        if (DEBUG && mappings.length) console.log('[SW] re-correlate found', mappings.length, 'mappings for', behavior.elementText);
        for (const m of mappings) {
          await put('mappings', m);
        }
      }
    })().catch(err => console.error('[SW] re-correlate failed:', err));
    return;
  }

  if (msg.type === 'RAW_BEHAVIOR') {
    if (!capturing) return;
    const payload = { ...msg.payload, tabId };
    if (payload.pageContext) recentPageContext.set(tabId, { context: payload.pageContext, seenAt: Date.now() });
    if (DEBUG) console.log('[SW] RAW_BEHAVIOR received:', payload.elementText, 'tabId:', tabId, 'rowData:', JSON.stringify(payload.rowData));
    saveBehavior(payload).then(async behavior => {
      const buf = getBuffer(reqBuffer, tabId);
      pruneBuffer(buf);
      if (DEBUG) console.log('[SW] correlating behavior', behavior.elementText, 'against', buf.length, 'buffered requests');
      const mappings = correlate(behavior, buf);
      if (DEBUG) console.log('[SW] correlation result:', mappings.length, 'mappings');
      for (const m of mappings) {
        await put('mappings', m);
      }
      // Also add to pending for re-correlation when later requests arrive
      getBuffer(pendingBehaviors, tabId).push({ behavior, enqueuedAt: Date.now() });
    }).catch(err => console.error('[SW] saveBehavior/correlate failed:', err));
    return;
  }

  if (msg.type === 'GET_STATS') {
    Promise.all([count('requests'), count('behaviors'), count('mappings')])
      .then(([r, b, m]) => sendResponse({ totalRequests: r, totalBehaviors: b, totalMappings: m }))
      .catch(err => {
        console.error('[SW] GET_STATS failed:', err);
        sendResponse({ totalRequests: 0, totalBehaviors: 0, totalMappings: 0 });
      });
    return true;
  }

  if (msg.type === 'GET_EXPORT') {
    Promise.all([getAll('requests'), getAll('behaviors'), getAll('mappings')])
      .then(([requests, behaviors, mappings]) => {
        const outputs = buildOutputs(requests, behaviors, mappings);
        if (DEBUG) console.log('[SW] GET_EXPORT: requests=%d behaviors=%d mappings=%d apiAssets=%d pageApiMap=%d behaviorApiMap=%d',
          requests.length, behaviors.length, mappings.length,
          outputs.apiAssets.length, outputs.pageApiMap.length, outputs.behaviorApiMap.length);
        sendResponse({ requests, behaviors, mappings, ...outputs });
      })
      .catch(err => {
        console.error('[SW] GET_EXPORT failed:', err);
        sendResponse({ error: err.message, apiAssets: [], pageApiMap: [], behaviorApiMap: [] });
      });
    return true;
  }

  if (msg.type === 'GET_HISTORY') {
    const { page = 0, pageSize = 50, sort = { field: 'timestamp', dir: 'desc' }, filter = {} } = msg;
    const sortDir = sort.dir === 'asc' ? 'next' : 'prev';
    const filterFn = (record) => {
      if (filter.method && record.method !== filter.method) return false;
      if (filter.statusClass) {
        const s = record.responseStatus || 0;
        const cls = s >= 200 && s < 300 ? '2xx' : s >= 300 && s < 400 ? '3xx' : s >= 400 && s < 500 ? '4xx' : s >= 500 ? '5xx' : '';
        if (cls !== filter.statusClass) return false;
      }
      if (filter.resourceType) {
        const types = filter.resourceType.split(',');
        const rt = (record.resourceType || '').toLowerCase();
        if (!types.some(t => rt === t.trim().toLowerCase())) return false;
      }
      if (filter.search) {
        const url = (record.url || '').toLowerCase();
        if (!url.includes(filter.search.toLowerCase())) return false;
      }
      return true;
    };
    getPaged('requests', { page, pageSize, sortDir, filterFn })
      .then(result => {
        const items = result.items.map(r => ({
          id: r.id, timestamp: r.timestamp, method: r.method,
          url: r.url, urlPath: r.urlPath,
          responseStatus: r.responseStatus, resourceType: r.resourceType,
          duration: r.duration ?? -1, pageUrl: r.pageUrl,
          pageContext: r.pageContext,
        }));
        sendResponse({ items, total: result.total, page: result.page, pageSize: result.pageSize });
      })
      .catch(err => {
        console.error('[SW] GET_HISTORY failed:', err);
        sendResponse({ items: [], total: 0, page, pageSize, error: err.message });
      });
    return true;
  }

  if (msg.type === 'GET_HISTORY_DETAIL') {
    const { id } = msg;
    getById('requests', id)
      .then(record => {
        if (!record) { sendResponse({ error: 'Not found' }); return; }
        sendResponse({
          id: record.id, method: record.method, url: record.url,
          requestHeaders: record.requestHeaders || null,
          requestBody: record.requestBody || null,
          responseStatus: record.responseStatus,
          responseBody: record.responseBody || null,
          resourceType: record.resourceType,
          duration: record.duration ?? -1,
          timestamp: record.timestamp,
        });
      })
      .catch(err => {
        console.error('[SW] GET_HISTORY_DETAIL failed:', err);
        sendResponse({ error: err.message });
      });
    return true;
  }

  if (msg.type === 'REPLAY_REQUEST') {
    const { method, url, headers, body } = msg;
    const start = Date.now();
    const fetchOpts = { method: method || 'GET', headers: headers || {}, credentials: 'include' };
    if (body && method !== 'GET' && method !== 'HEAD') fetchOpts.body = body;
    fetch(url, fetchOpts).then(async resp => {
      const duration = Date.now() - start;
      const respHeaders = {};
      resp.headers.forEach((v, k) => { respHeaders[k] = v; });
      let responseBody = '';
      try { responseBody = await resp.text(); } catch { responseBody = '(unreadable)'; }
      sendResponse({
        responseStatus: resp.status,
        responseHeaders: respHeaders,
        responseBody,
        duration,
      });
    }).catch(err => {
      sendResponse({ error: err.message, responseStatus: 0, duration: Date.now() - start });
    });
    return true;
  }

  if (msg.type === 'PING') {
    sendResponse({ pong: true });
    return true;
  }

  // ===== Monitor handlers =====
  if (msg.type === MSG.LIST_MONITORS) {
    getAll('monitors')
      .then(monitors => sendResponse({ monitors }))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (msg.type === MSG.GET_MONITOR) {
    getById('monitors', msg.id)
      .then(monitor => sendResponse({ monitor }))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (msg.type === MSG.SAVE_MONITOR) {
    const monitor = { ...msg.monitor };
    if (!monitor.id) monitor.id = generateId();
    monitor.createdAt = monitor.createdAt || Date.now();
    put('monitors', monitor)
      .then(() => {
        scheduleMonitor(monitor);
        sendResponse({ ok: true, id: monitor.id });
      })
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (msg.type === MSG.DELETE_MONITOR) {
    Promise.all([
      deleteById('monitors', msg.id),
      new Promise(resolve => chrome.alarms.clear(`monitor_${msg.id}`, resolve)),
    ]).then(() => sendResponse({ ok: true }))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (msg.type === MSG.TOGGLE_MONITOR) {
    getById('monitors', msg.id)
      .then(monitor => {
        if (!monitor) { sendResponse({ error: 'Not found' }); return; }
        monitor.enabled = msg.enabled;
        return put('monitors', monitor).then(() => {
          scheduleMonitor(monitor);
          sendResponse({ ok: true });
        });
      })
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (msg.type === MSG.RUN_MONITOR_NOW) {
    executeMonitor(msg.id)
      .then(() => sendResponse({ ok: true }))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (msg.type === MSG.GET_MONITOR_RESULTS) {
    const sortDir = msg.sortDir || 'prev';
    getPaged('monitorResults', {
      page: msg.page || 0,
      pageSize: msg.pageSize || 50,
      sortDir,
      filterFn: r => r.monitorId === msg.monitorId,
    })
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ error: err.message }));
    return true;
  }

  if (msg.type === 'CLEAR_DATA') {
    Promise.all([
      clearMonitorAlarms(),
      clear('requests'),
      clear('behaviors'),
      clear('mappings'),
      clear('replayHistory'),
      clear('testCases'),
      clear('monitors'),
      clear('monitorResults'),
    ])
      .then(() => sendResponse({ ok: true }))
      .catch(err => {
        console.error('[SW] CLEAR_DATA failed:', err);
        sendResponse({ error: err.message });
      });
    return true;
  }
});

function buildOutputs(requests, behaviors, mappings) {
  // Output 1: API asset list
  const apiMap = new Map();
  for (const r of requests) {
    const key = `${r.method}:${r.urlPath}`;
    if (!apiMap.has(key)) {
      let host = '';
      try { host = new URL(r.url).host; } catch { host = ''; }
      apiMap.set(key, { method: r.method, urlPath: r.urlPath, host, resourceType: r.resourceType || r.initiatorType || '-', callCount: 0,
        firstSeen: r.timestamp, lastSeen: r.timestamp,
        sampleRequestHeaders: r.requestHeaders, sampleRequestBody: r.requestBody,
        sampleResponseBody: r.responseBody, pages: new Set(), records: [] });
    }
    const e = apiMap.get(key);
    e.callCount++;
    e.lastSeen = Math.max(e.lastSeen, r.timestamp);
    if (r.pageContext?.path) e.pages.add(r.pageContext.path);
    e.records.push({ timestamp: r.timestamp, method: r.method, status: r.responseStatus, pageUrl: r.pageUrl,
      bodyPreview: typeof r.requestBody === 'string' ? r.requestBody.slice(0, 200) : '' });
  }
  const apiAssets = [...apiMap.values()].map(e => ({ ...e, pages: [...e.pages] }));

  // Output 2: page → API mapping
  const pageMap = new Map();
  for (const r of requests) {
    const path = r.pageContext?.path;
    if (!path) continue;
    if (!pageMap.has(path)) {
      pageMap.set(path, { page: path, pageTitle: r.pageContext?.title,
        breadcrumb: r.pageContext?.breadcrumb || [], apis: new Map() });
    }
    const key = `${r.method}:${r.urlPath}`;
    const p = pageMap.get(path);
    if (!p.apis.has(key)) p.apis.set(key, { method: r.method, urlPath: r.urlPath, callCount: 0 });
    p.apis.get(key).callCount++;
  }

  // Enrich with behavior action names from mappings
  for (const m of mappings) {
    const path = m.behavior?.page;
    if (!path || !pageMap.has(path)) continue;
    const p = pageMap.get(path);
    if (!p.actions) p.actions = [];
    if (m.confidence >= 0.5 && !p.actions.find(a => a.api === m.request.urlPath)) {
      p.actions.push({ name: m.behavior.text, api: m.request.urlPath, method: m.request.method });
    }
  }

  const pageApiMap = [...pageMap.values()].map(p => ({
    ...p, apis: [...p.apis.values()], actions: p.actions || [],
  }));

  // Output 3: behavior → API mapping (include unmapped behaviors too)
  const behaviorMap = new Map();
  // First: add all behaviors from DB
  for (const b of behaviors) {
    const key = `${b.elementText || ''}:${b.pageContext?.path || ''}`;
    if (!behaviorMap.has(key)) {
      behaviorMap.set(key, {
        behavior: { type: b.type, text: b.elementText, page: b.pageContext?.path },
        mappings: [], occurrences: 0, records: []
      });
    }
    const entry = behaviorMap.get(key);
    entry.occurrences++;
    entry.records.push({ timestamp: b.timestamp, type: b.type, elementText: b.elementText, pageUrl: b.pageUrl });
  }
  // Then: add mapped results
  for (const m of mappings) {
    const key = `${m.behavior?.text}:${m.behavior?.page}`;
    if (!behaviorMap.has(key)) {
      behaviorMap.set(key, { behavior: m.behavior, mappings: [], occurrences: 0 });
    }
    const b = behaviorMap.get(key);
    if (!b.mappings.find(x => x.urlPath === m.request.urlPath)) {
      b.mappings.push({ method: m.request.method, urlPath: m.request.urlPath,
        confidence: m.confidence, evidence: m.evidence });
    }
  }
  const behaviorApiMap = [...behaviorMap.values()];

  return { apiAssets, pageApiMap, behaviorApiMap };
}

function outputPageKey(record) {
  const ctx = record.pageContext;
  if (ctx?.pageKey) return ctx.pageKey;
  if (ctx?.path) return ctx.path;
  if (record.pageUrl) {
    try {
      const u = new URL(record.pageUrl);
      return `${u.pathname}${u.hash || ''}`;
    } catch {}
  }
  return '';
}

function mappingSort(a, b) {
  if ((b.isPrimary ? 1 : 0) !== (a.isPrimary ? 1 : 0)) return (b.isPrimary ? 1 : 0) - (a.isPrimary ? 1 : 0);
  return (b.confidence || 0) - (a.confidence || 0);
}

function summarizeStatus(mappings) {
  const best = mappings[0];
  if (!best) return { mappingStatus: 'unmapped', confidenceLevel: 'unmapped' };
  return {
    mappingStatus: best.mappingStatus || mappingStatus(best.confidence || 0),
    confidenceLevel: best.confidenceLevel || confidenceLevel(best.confidence || 0),
  };
}

function buildOutputs(requests, behaviors, mappings) {
  const apiMap = new Map();
  for (const r of requests) {
    const urlPath = r.urlPath || requestPath(r.url);
    const key = `${r.method}:${urlPath}`;
    if (!apiMap.has(key)) {
      let host = '';
      try { host = new URL(r.url).host; } catch { host = ''; }
      apiMap.set(key, {
        method: r.method, urlPath, host,
        resourceType: r.resourceType || r.initiatorType || '-',
        callCount: 0,
        firstSeen: r.timestamp,
        lastSeen: r.timestamp,
        sampleRequestHeaders: r.requestHeaders,
        sampleRequestBody: r.requestBody,
        sampleResponseBody: r.responseBody,
        pages: new Set(),
        pageKeys: new Set(),
        records: [],
      });
    }
    const e = apiMap.get(key);
    e.callCount++;
    e.lastSeen = Math.max(e.lastSeen, r.timestamp);
    const pKey = outputPageKey(r);
    if (r.pageContext?.path) e.pages.add(r.pageContext.path);
    if (pKey) e.pageKeys.add(pKey);
    e.records.push({
      timestamp: r.timestamp,
      method: r.method,
      status: r.responseStatus,
      pageUrl: r.pageUrl,
      pageKey: pKey,
      pageContextInferred: !!r.pageContextInferred,
      bodyPreview: typeof r.requestBody === 'string' ? r.requestBody.slice(0, 200) : '',
    });
  }
  const apiAssets = [...apiMap.values()].map(e => ({ ...e, pages: [...e.pages], pageKeys: [...e.pageKeys] }));

  const pageMap = new Map();
  for (const r of requests) {
    const pKey = outputPageKey(r);
    if (!pKey) continue;
    const ctx = r.pageContext || {};
    if (!pageMap.has(pKey)) {
      pageMap.set(pKey, {
        page: ctx.path || pKey,
        pageKey: pKey,
        pageTitle: ctx.title,
        breadcrumb: ctx.breadcrumb || [],
        menuPath: ctx.menuPath || [],
        mappingStatus: r.pageContextInferred ? 'inferred' : 'observed',
        apis: new Map(),
        actions: [],
      });
    }
    const key = `${r.method}:${r.urlPath || requestPath(r.url)}`;
    const p = pageMap.get(pKey);
    if (!p.apis.has(key)) p.apis.set(key, { method: r.method, urlPath: r.urlPath || requestPath(r.url), callCount: 0 });
    p.apis.get(key).callCount++;
    if (!r.pageContextInferred) p.mappingStatus = 'observed';
  }

  for (const m of mappings) {
    const pKey = m.behavior?.pageKey || m.behavior?.page;
    if (!pKey || !pageMap.has(pKey)) continue;
    const p = pageMap.get(pKey);
    const status = m.mappingStatus || mappingStatus(m.confidence || 0);
    if ((m.confidence || 0) >= CORR.THRESHOLD && !p.actions.find(a => a.api === m.request.urlPath && a.name === m.behavior.text)) {
      p.actions.push({
        name: m.behavior.text,
        api: m.request.urlPath,
        method: m.request.method,
        confidence: m.confidence,
        confidenceLevel: m.confidenceLevel || confidenceLevel(m.confidence || 0),
        mappingStatus: status,
      });
    }
  }

  const pageApiMap = [...pageMap.values()].map(p => ({
    ...p,
    apis: [...p.apis.values()],
    actions: p.actions.sort(mappingSort),
  }));

  const behaviorMap = new Map();
  for (const b of behaviors) {
    const pageKey = outputPageKey(b);
    const key = `${b.elementText || ''}:${pageKey}`;
    if (!behaviorMap.has(key)) {
      behaviorMap.set(key, {
        behavior: { type: b.type, text: b.elementText, page: b.pageContext?.path, pageKey },
        mappings: [],
        alternatives: [],
        occurrences: 0,
        records: [],
        mappingStatus: 'unmapped',
        confidenceLevel: 'unmapped',
      });
    }
    const entry = behaviorMap.get(key);
    entry.occurrences++;
    entry.records.push({
      timestamp: b.timestamp,
      type: b.type,
      elementText: b.elementText,
      pageUrl: b.pageUrl,
      pageKey,
      selector: b.selector,
      rowData: b.rowData,
      formData: b.formData,
    });
  }

  for (const m of mappings) {
    const key = `${m.behavior?.text || ''}:${m.behavior?.pageKey || m.behavior?.page || ''}`;
    if (!behaviorMap.has(key)) {
      behaviorMap.set(key, {
        behavior: m.behavior,
        mappings: [],
        alternatives: [],
        occurrences: 0,
        records: [],
      });
    }
    const entry = behaviorMap.get(key);
    const normalized = {
      method: m.request.method,
      urlPath: m.request.urlPath,
      url: m.request.url,
      confidence: m.confidence,
      confidenceLevel: m.confidenceLevel || confidenceLevel(m.confidence || 0),
      mappingStatus: m.mappingStatus || mappingStatus(m.confidence || 0),
      evidence: m.evidence,
      reqType: m.reqType,
      rank: m.rank,
      isPrimary: !!m.isPrimary,
    };
    if (!entry.mappings.find(x => x.method === normalized.method && x.urlPath === normalized.urlPath)) {
      entry.mappings.push(normalized);
    }
  }

  const behaviorApiMap = [...behaviorMap.values()].map(entry => {
    entry.mappings.sort(mappingSort);
    const visible = entry.mappings.filter(m => (m.confidence || 0) >= CORR.THRESHOLD);
    const alternatives = entry.mappings.filter(m => (m.confidence || 0) < CORR.THRESHOLD).slice(0, 3);
    const status = summarizeStatus(visible);
    return {
      ...entry,
      mappings: visible,
      alternatives,
      mappingStatus: status.mappingStatus,
      confidenceLevel: status.confidenceLevel,
    };
  });

  const coverage = behaviorApiMap.reduce((acc, b) => {
    acc.total++;
    if (b.mappingStatus === 'confirmed') acc.confirmed++;
    else if (b.mappingStatus === 'candidate') acc.candidate++;
    else acc.unmapped++;
    return acc;
  }, { total: 0, confirmed: 0, candidate: 0, unmapped: 0 });

  return { apiAssets, pageApiMap, behaviorApiMap, coverage };
}

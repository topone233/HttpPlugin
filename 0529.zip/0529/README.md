# Security API Capture

Security API Capture 是一个 Chrome Manifest V3 扩展，用于在安全测试、接口梳理和业务行为分析场景中采集 Web 应用的 HTTP 请求与用户操作行为，并自动关联「页面行为 -> API 调用」。

项目不依赖构建工具，全部代码为原生 JavaScript、HTML、CSS，可直接以未打包扩展加载到 Chrome。

## 功能特性

- 捕获页面中的 `fetch` 和 `XMLHttpRequest` 请求，包括请求方法、URL、请求头、请求体、响应状态、响应体和耗时。
- 捕获用户点击和键盘确认行为，并提取按钮文本、`data-*` 属性、表格行数据和页面上下文。
- 通过时间、语义和参数匹配对用户行为与 API 请求进行置信度关联。
- 在 Dashboard 中查看 API 资产、页面到 API 的映射、行为到 API 的映射和请求历史。
- 支持按方法、状态码、资源类型和 URL 搜索请求历史。
- 支持请求重放、变量替换、响应查看、重放历史和测试用例保存。
- 支持 API 定时监控，可配置前置请求、变量提取、主请求和执行计划。
- 支持 JSON 导出采集数据、映射结果和测试用例。

## 快速开始

1. 打开 Chrome，进入 `chrome://extensions/`。
2. 开启右上角的「开发者模式」。
3. 点击「加载已解压的扩展程序」。
4. 选择本项目目录。
5. 打开目标 Web 应用并保持扩展处于 `Capturing ON`。
6. 点击扩展图标查看快速统计，或点击 `Open Dashboard` 打开完整控制台。

修改源码后，需要回到 `chrome://extensions/`，点击该扩展卡片上的刷新按钮重新加载。

## 使用方式

### Popup

扩展弹窗提供轻量操作入口：

- `Capturing ON/OFF`：开启或暂停采集。
- `Open Dashboard`：打开完整 Dashboard。
- `Export JSON`：导出当前采集数据。
- `Clear Data`：清空请求、行为和映射数据。

### Dashboard

Dashboard 是主要工作界面，包含以下视图：

- 页面映射：按页面展示关联 API 和推断出的页面操作。
- 行为映射：展示用户行为与 API 的关联关系、置信度和证据分数。
- 请求历史：分页查看请求记录，支持筛选、详情查看和重放。
- 请求重放：编辑 method、URL、headers、body 后发送请求，查看响应，并保存为测试用例。
- 定时监控：保存可重复执行的 API 检查任务，并查看执行结果。

### 请求重放变量

重放器支持 `{{variableName}}` 语法，可用于 URL、Header 值和 Body。

内置变量：

- `{{timestamp}}`：当前毫秒时间戳。
- `{{random}}`：随机整数。

自定义变量会保存到 `chrome.storage.local`，可跨会话保留。

## 架构概览

整体消息链路：

```text
injected scripts
  -> window.postMessage
content/content-main.js
  -> chrome.runtime.sendMessage
background/service-worker.js
  -> IndexedDB / Dashboard / Popup
```

核心模块：

- `manifest.json`：Chrome 扩展清单，声明权限、后台脚本、内容脚本和可访问资源。
- `content/content-main.js`：内容脚本桥接层，负责注入页面脚本并转发消息。
- `content/interceptor.js`：运行在页面主环境，代理 `fetch` 和 `XMLHttpRequest`。
- `content/behavior-tracker.js`：采集点击和键盘确认行为。
- `content/page-context.js`：提取页面路径、标题、面包屑、菜单路径，并监听 SPA 导航变化。
- `background/service-worker.js`：后台中心，负责请求保存、行为保存、关联算法、导出、重放和监控任务。
- `shared/db.js`：IndexedDB 封装和数据淘汰逻辑。
- `shared/utils.js`：URL 过滤、分词、语义匹配、变量提取、Cron 解析等工具。
- `shared/constants.js`：消息类型、数据库配置、关联算法权重和资源类型映射。
- `popup/`：扩展弹窗。
- `dashboard/`：完整控制台。

## 数据存储

扩展使用 IndexedDB，数据库名为 `sec_cap`。当前主要 object store：

- `requests`：请求记录，默认最多保留 5000 条。
- `behaviors`：用户行为记录，默认最多保留 2000 条。
- `mappings`：行为与请求的关联结果。
- `replayHistory`：请求重放历史，默认最多保留 500 条。
- `testCases`：保存的重放测试用例。
- `monitors`：定时监控任务配置。
- `monitorResults`：定时监控执行结果，默认最多保留 500 条。

数据保存在本地浏览器中，导出时会生成 JSON 文件。

## 关联算法

后台 Service Worker 会维护最近请求和行为的短期缓冲区。行为到 API 的关联使用三个维度打分：

- 参数匹配：行为所在表格行的 `data-*` 值是否出现在请求体中。
- 语义匹配：按钮文本、标签、URL path token 的重叠度。
- 时间匹配：请求发生时间与行为时间的接近程度。

得分达到阈值后会生成 mapping，并给出 temporal、semantic、param 三类证据。

## 项目目录

```text
.
├── background/
│   └── service-worker.js
├── content/
│   ├── behavior-tracker.js
│   ├── content-main.js
│   ├── interceptor.js
│   └── page-context.js
├── dashboard/
│   ├── dashboard.css
│   ├── dashboard.html
│   └── dashboard.js
├── docs/
│   └── superpowers/
├── icons/
├── popup/
│   ├── popup.html
│   └── popup.js
├── shared/
│   ├── constants.js
│   ├── db.js
│   └── utils.js
├── manifest.json
└── README.md
```

## 开发说明

- 无需安装依赖，无需构建。
- 直接修改源码后，在 `chrome://extensions/` 重新加载扩展。
- Service Worker 使用 `importScripts` 加载 `shared/` 下的脚本。
- 注入到页面主环境的脚本必须配置在 `manifest.json` 的 `web_accessible_resources` 中。
- 异步 `chrome.runtime.onMessage` 响应必须 `return true`，否则消息通道会提前关闭。
- 修改 IndexedDB 结构时需要提升 `DB.VERSION` 并在 `onupgradeneeded` 中做增量迁移。

## 权限说明

扩展声明了以下关键权限：

- `webRequest`：捕获网络请求元信息。
- `storage`：保存采集开关、重放变量和本地状态。
- `tabs` / `activeTab`：打开 Dashboard、获取标签页上下文。
- `alarms`：执行定时监控任务。
- `<all_urls>`：允许在目标页面注入采集脚本并重放跨站请求。

由于该扩展会采集请求和响应内容，请仅在授权的测试环境或明确允许的目标系统中使用。

## 导出数据

Popup 和 Dashboard 均支持 JSON 导出。典型导出内容包括：

- `requests`：原始请求记录。
- `behaviors`：用户行为记录。
- `mappings`：行为到请求的关联结果。
- `apiAssets`：按 method + path 聚合后的 API 资产。
- `pageApiMap`：页面到 API 的映射。
- `behaviorApiMap`：行为到 API 的映射。

## 注意事项

- 对响应体的捕获依赖页面环境中的 `fetch` / `XMLHttpRequest` 代理；部分页面若主动覆盖这些 API，可能影响采集完整性。
- `webRequest` 能补充请求元信息，但 Manifest V3 下无法直接读取响应体，因此响应体主要来自注入脚本。
- 请求重放会携带扩展上下文权限和 `credentials: include`，请确认目标请求的副作用。
- Dashboard 中部分历史中文文案如出现乱码，通常是源码历史编码问题，不影响核心逻辑运行。

(function () {
  const HTML_ESCAPE = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

  function escapeHtml(s) {
    return s == null ? '' : String(s).replace(/[&<>"']/g, c => HTML_ESCAPE[c]);
  }

  function confClass(c) {
    return c >= 0.7 ? 'high' : c >= 0.4 ? 'mid' : 'low';
  }

  function methodBadge(m) {
    const e = escapeHtml(m);
    return `<span class="method ${e}">${e}</span>`;
  }

  function statusClass(s) {
    if (s >= 200 && s < 300) return '2xx';
    if (s >= 300 && s < 400) return '3xx';
    if (s >= 400 && s < 500) return '4xx';
    if (s >= 500) return '5xx';
    return '0';
  }

  window.escapeHtml = escapeHtml;
  window.confClass = confClass;
  window.methodBadge = methodBadge;
  window.statusClass = statusClass;
})();

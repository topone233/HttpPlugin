(function () {
  function sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, response => {
        const err = chrome.runtime.lastError;
        if (err) {
          reject(new Error(err.message));
          return;
        }
        if (response && response.error) {
          reject(new Error(response.error));
          return;
        }
        resolve(response);
      });
    });
  }

  window.DashboardApi = {
    sendMessage,
    ping() {
      return sendMessage({ type: 'PING' });
    },
    getStats() {
      return sendMessage({ type: 'GET_STATS' });
    },
    getExport() {
      return sendMessage({ type: 'GET_EXPORT' });
    },
    getHistory(params) {
      return sendMessage({ type: 'GET_HISTORY', ...params });
    },
    getHistoryDetail(id) {
      return sendMessage({ type: 'GET_HISTORY_DETAIL', id });
    },
  };
})();

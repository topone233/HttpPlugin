(function () {
  function getActiveTab() {
    return document.querySelector('.nav-item.active')?.dataset.tab || 'history';
  }

  function setupAutoRefresh(handlers, intervalMs) {
    return setInterval(() => {
      handlers.refreshStats();
      const active = getActiveTab();
      if (active === 'pages' || active === 'behaviors') handlers.loadOverview();
      if (active === 'history') handlers.loadHistory();
      if (active === 'replay') handlers.loadReplay();
      if (active === 'monitor') handlers.loadMonitors();
    }, intervalMs);
  }

  window.DashboardRefresh = {
    getActiveTab,
    setupAutoRefresh,
  };
})();

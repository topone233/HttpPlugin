let data = { apiAssets: [], pageApiMap: [], behaviorApiMap: [], mappings: [] };
let minConf = 0.15;
let filterText = '';

// ===== Replay State =====
const replayState = {
  history: [],
  cases: [],
  variables: {},
  _lastFocusEl: null,
};

function loadVariables() {
  chrome.storage.local.get('replayVariables', r => {
    replayState.variables = r.replayVariables || {};
    renderVariables();
  });
}

function saveVariables() {
  chrome.storage.local.set({ replayVariables: replayState.variables });
}

function applyVariables(text) {
  return text.replace(/\{\{(\w+)\}\}/g, (match, key) => {
    if (BUILTIN_VARS[key]) return BUILTIN_VARS[key]();
    if (replayState.variables[key] != null) return replayState.variables[key];
    return match;
  });
}

function findUndefinedVars(text) {
  const matches = text.match(/\{\{(\w+)\}\}/g) || [];
  return matches.map(m => m.slice(2, -2)).filter(k => !BUILTIN_VARS[k] && replayState.variables[k] == null);
}

function getAllUndefinedVars() {
  const url = document.getElementById('replayUrl').value;
  const body = document.getElementById('replayBody').value;
  const headerVals = [...document.querySelectorAll('.replay-hdr-val')].map(el => el.value);
  const texts = [url, body, ...headerVals];
  const all = new Set();
  for (const t of texts) {
    for (const v of findUndefinedVars(t)) all.add(v);
  }
  return [...all];
}

function highlightUndefinedVars() {
  const undefinedVars = getAllUndefinedVars();
  document.getElementById('replayUrl').classList.remove('var-undefined');
  document.getElementById('replayBody').classList.remove('var-undefined');
  document.querySelectorAll('.replay-hdr-val').forEach(el => el.classList.remove('var-undefined'));
  if (!undefinedVars.length) return;
  if (findUndefinedVars(document.getElementById('replayUrl').value).length)
    document.getElementById('replayUrl').classList.add('var-undefined');
  if (findUndefinedVars(document.getElementById('replayBody').value).length)
    document.getElementById('replayBody').classList.add('var-undefined');
  document.querySelectorAll('.replay-hdr-val').forEach(el => {
    if (findUndefinedVars(el.value).length) el.classList.add('var-undefined');
  });
}

function renderVariables() {
  const list = document.getElementById('replayVarsList');
  list.innerHTML = Object.entries(replayState.variables).map(([k, v]) => `
    <div class="replay-var-row">
      <span class="var-name">${escapeHtml(k)}</span>
      <span class="var-eq">=</span>
      <span class="var-val">${escapeHtml(v)}</span>
      <button class="var-del" data-var-key="${escapeHtml(k)}" title="删除">&times;</button>
    </div>
  `).join('');
  list.querySelectorAll('.var-del').forEach(btn => {
    btn.addEventListener('click', () => {
      delete replayState.variables[btn.dataset.varKey];
      saveVariables();
      renderVariables();
      highlightUndefinedVars();
    });
  });
}

function insertVarAtFocus(varName) {
  const text = `{{${varName}}}`;
  const el = replayState._lastFocusEl;
  if (el && (el.id === 'replayUrl' || el.id === 'replayBody' || el.classList.contains('replay-hdr-val'))) {
    const start = el.selectionStart;
    const end = el.selectionEnd;
    el.value = el.value.slice(0, start) + text + el.value.slice(end);
    el.selectionStart = el.selectionEnd = start + text.length;
    el.focus();
  }
  highlightUndefinedVars();
}

function setupVariableInteractions() {
  document.getElementById('replayVarsToggle').addEventListener('click', () => {
    const panel = document.getElementById('replayVarsPanel');
    const hint = document.getElementById('replayVarsHint');
    const visible = panel.style.display !== 'none';
    panel.style.display = visible ? 'none' : 'block';
    hint.textContent = visible ? '点击展开' : '点击收起';
  });

  const trackFocus = e => {
    if (e.target.id === 'replayUrl' || e.target.id === 'replayBody' || e.target.classList.contains('replay-hdr-val')) {
      replayState._lastFocusEl = e.target;
    }
  };
  document.addEventListener('focusin', trackFocus);

  document.getElementById('replayAddVar').addEventListener('click', () => {
    const keyEl = document.getElementById('replayVarKey');
    const valEl = document.getElementById('replayVarVal');
    const key = keyEl.value.trim();
    const val = valEl.value;
    if (!key) return;
    replayState.variables[key] = val;
    saveVariables();
    renderVariables();
    highlightUndefinedVars();
    keyEl.value = '';
    valEl.value = '';
  });

  document.querySelectorAll('.replay-var-chip[data-var]').forEach(chip => {
    chip.addEventListener('click', () => insertVarAtFocus(chip.dataset.var));
  });

  ['replayUrl', 'replayBody'].forEach(id => {
    document.getElementById(id).addEventListener('input', highlightUndefinedVars);
  });
}

function setupHeaderRows() {
  document.getElementById('replayAddHeader').addEventListener('click', () => {
    addHeaderRow();
  });
  document.getElementById('replayHeaders').addEventListener('click', e => {
    const del = e.target.closest('.replay-hdr-del');
    if (del) del.closest('.replay-header-row').remove();
  });
}

function addHeaderRow(key = '', val = '') {
  const container = document.getElementById('replayHeaders');
  const row = document.createElement('div');
  row.className = 'replay-header-row';
  row.innerHTML = `
    <input type="text" class="replay-hdr-key" placeholder="Header name" value="${escapeHtml(key)}" />
    <input type="text" class="replay-hdr-val" placeholder="Value" value="${escapeHtml(val)}" />
    <button class="btn btn-ghost btn-sm replay-hdr-del" title="删除">&times;</button>
  `;
  container.appendChild(row);
}

function collectHeaders() {
  const headers = {};
  document.querySelectorAll('.replay-header-row').forEach(row => {
    const key = row.querySelector('.replay-hdr-key').value.trim();
    const val = applyVariables(row.querySelector('.replay-hdr-val').value);
    if (key) headers[key] = val;
  });
  return headers;
}

function collectHeadersRaw() {
  const headers = {};
  document.querySelectorAll('.replay-header-row').forEach(row => {
    const key = row.querySelector('.replay-hdr-key').value.trim();
    const val = row.querySelector('.replay-hdr-val').value;
    if (key) headers[key] = val;
  });
  return headers;
}

function setHeaders(headers) {
  const container = document.getElementById('replayHeaders');
  container.innerHTML = '';
  if (headers && typeof headers === 'object') {
    for (const [k, v] of Object.entries(headers)) {
      addHeaderRow(k, v);
    }
  }
  if (!container.children.length) addHeaderRow();
}

async function sendReplayRequest() {
  const undefinedVars = getAllUndefinedVars();
  if (undefinedVars.length) {
    alert(`未定义变量: ${undefinedVars.join(', ')}\n请先在变量面板中定义或使用内置变量。`);
    return;
  }

  const method = document.getElementById('replayMethod').value;
  const rawUrl = document.getElementById('replayUrl').value.trim();
  const url = applyVariables(rawUrl);
  const headers = collectHeaders();
  const rawBody = document.getElementById('replayBody').value;
  const body = rawBody ? applyVariables(rawBody) : null;

  if (!url) { alert('请输入 URL'); return; }

  const statusEl = document.getElementById('replayRespStatus');
  statusEl.innerHTML = '<span class="replay-status-text">发送中...</span>';

  let result;
  try {
    const fetchOpts = { method, headers, credentials: 'include' };
    if (body && method !== 'GET' && method !== 'HEAD') fetchOpts.body = body;
    const start = Date.now();
    const resp = await fetch(url, fetchOpts);
    const duration = Date.now() - start;
    const respHeaders = {};
    resp.headers.forEach((v, k) => { respHeaders[k] = v; });
    let responseBody = '';
    try { responseBody = await resp.text(); } catch { responseBody = '(unreadable)'; }
    result = { responseStatus: resp.status, responseHeaders: respHeaders, responseBody, duration, error: null };
  } catch (directErr) {
    try {
      result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { type: 'REPLAY_REQUEST', method, url, headers, body },
          r => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(r);
          }
        );
      });
    } catch (swErr) {
      result = { responseStatus: 0, responseHeaders: {}, responseBody: '', duration: 0, error: swErr.message || directErr.message };
    }
  }

  displayReplayResponse(result);

  const record = {
    id: generateId(),
    timestamp: Date.now(),
    method, url: rawUrl,
    headers: collectHeadersRaw(),
    body: rawBody,
    variables: { ...replayState.variables },
    responseStatus: result.responseStatus,
    responseHeaders: result.responseHeaders || {},
    responseBody: result.responseBody || '',
    duration: result.duration || 0,
  };
  await put('replayHistory', record);
  await evictOldest('replayHistory', DB.REPLAY_HISTORY_CAP, DB.REPLAY_HISTORY_EVICT);
  loadReplayHistory();
}

function displayReplayResponse(result) {
  const statusEl = document.getElementById('replayRespStatus');
  const headersEl = document.getElementById('replayRespHeaders');
  const bodyEl = document.getElementById('replayRespBody');

  if (result.error) {
    statusEl.innerHTML = `<span class="replay-status-text err">错误: ${escapeHtml(result.error)}</span>`;
    headersEl.textContent = '';
    bodyEl.textContent = '';
    return;
  }

  const sc = result.responseStatus >= 200 && result.responseStatus < 300 ? '2xx'
    : result.responseStatus >= 400 ? '4xx' : '0';
  statusEl.innerHTML = `<span class="status-badge status-${sc}">${result.responseStatus}</span>
    <span class="replay-status-text ok" style="margin-left:8px">${result.duration}ms</span>`;

  headersEl.textContent = JSON.stringify(result.responseHeaders, null, 2);

  let bodyText = result.responseBody || '';
  try {
    const parsed = JSON.parse(bodyText);
    bodyText = JSON.stringify(parsed, null, 2);
  } catch { /* not JSON, show raw */ }
  bodyEl.textContent = bodyText;
}

function loadIntoReplay(method, url, headers, body) {
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.querySelector('[data-tab="replay"]').classList.add('active');
  document.getElementById('tab-replay').classList.add('active');
  document.getElementById('confidenceSlider').style.display = 'none';

  document.getElementById('replayMethod').value = method || 'GET';
  document.getElementById('replayUrl').value = url || '';
  setHeaders(headers);
  document.getElementById('replayBody').value = typeof body === 'string' ? body : (body ? JSON.stringify(body) : '');
  highlightUndefinedVars();
}

function setupFormatBody() {
  document.getElementById('replayFormatBody').addEventListener('click', () => {
    const el = document.getElementById('replayBody');
    try {
      const parsed = JSON.parse(el.value);
      el.value = JSON.stringify(parsed, null, 2);
    } catch {
      alert('Body 不是有效的 JSON');
    }
  });
}

function setupRespHeadersCollapse() {
  const toggle = document.getElementById('replayRespHeadersToggle');
  const content = document.getElementById('replayRespHeaders');
  const icon = toggle.querySelector('.replay-collapse-icon');
  toggle.addEventListener('click', () => {
    const visible = content.style.display !== 'none';
    content.style.display = visible ? 'none' : 'block';
    icon.textContent = visible ? '▸' : '▾';
  });
}

function setupRespBodySearch() {
  document.getElementById('replayRespSearch').addEventListener('input', e => {
    const query = e.target.value.toLowerCase();
    const bodyEl = document.getElementById('replayRespBody');
    const text = bodyEl.textContent;
    if (!query) {
      bodyEl.textContent = text;
      return;
    }
    const idx = text.toLowerCase().indexOf(query);
    if (idx >= 0) {
      const before = escapeHtml(text.slice(0, idx));
      const match = escapeHtml(text.slice(idx, idx + query.length));
      const after = escapeHtml(text.slice(idx + query.length));
      bodyEl.innerHTML = before + '<mark style="background:#fbbf24;color:#1e293b">' + match + '</mark>' + after;
    }
  });
}

// ===== Replay History & Test Cases =====
async function loadReplayHistory() {
  const items = await getAll('replayHistory');
  replayState.history = items.sort((a, b) => b.timestamp - a.timestamp);
  renderReplayHistory();
}

function renderReplayHistory() {
  const tbody = document.getElementById('replayHistoryBody');
  const rows = replayState.history.slice(0, 50);
  tbody.innerHTML = rows.map(r => {
    const fmtTs = new Date(r.timestamp).toLocaleTimeString();
    let urlDisplay = r.url;
    try { urlDisplay = new URL(r.url).pathname + new URL(r.url).search; } catch {}
    return `<tr>
      <td>${methodBadge(r.method)}</td>
      <td title="${escapeHtml(r.url)}">${escapeHtml(urlDisplay)}</td>
      <td><span class="status-badge status-${statusClass(r.responseStatus)}">${r.responseStatus || '-'}</span></td>
      <td>${r.duration >= 0 ? r.duration + 'ms' : '-'}</td>
      <td>${escapeHtml(fmtTs)}</td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('tr').forEach((tr, i) => {
    tr.addEventListener('click', () => {
      const r = rows[i];
      document.getElementById('replayMethod').value = r.method || 'GET';
      document.getElementById('replayUrl').value = r.url || '';
      setHeaders(r.headers);
      document.getElementById('replayBody').value = r.body || '';
      highlightUndefinedVars();
    });
  });

  document.getElementById('badgeReplay').textContent = replayState.history.length;
}

async function loadReplayCases() {
  const items = await getAll('testCases');
  replayState.cases = items.sort((a, b) => b.timestamp - a.timestamp);
  renderReplayCases();
}

function renderReplayCases() {
  const tbody = document.getElementById('replayCasesBody');
  tbody.innerHTML = replayState.cases.map(c => {
    let urlDisplay = c.url;
    try { urlDisplay = new URL(c.url).pathname; } catch {}
    return `<tr>
      <td class="case-name" data-case-id="${escapeHtml(c.id)}">${escapeHtml(c.name)}</td>
      <td>${methodBadge(c.method)}</td>
      <td title="${escapeHtml(c.url)}">${escapeHtml(urlDisplay)}</td>
      <td>
        <button class="btn-detail case-delete" data-case-id="${escapeHtml(c.id)}" title="删除">删除</button>
      </td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('tr').forEach((tr, i) => {
    tr.addEventListener('click', e => {
      if (e.target.closest('.case-delete')) return;
      if (e.target.closest('.case-name')) return;
      const c = replayState.cases[i];
      loadIntoReplay(c.method, c.url, c.headers, c.body);
    });
  });

  tbody.querySelectorAll('.case-name').forEach(td => {
    td.addEventListener('dblclick', () => {
      const id = td.dataset.caseId;
      const c = replayState.cases.find(x => x.id === id);
      if (!c) return;
      const newName = prompt('重命名用例:', c.name);
      if (newName && newName.trim()) {
        c.name = newName.trim();
        put('testCases', c).then(() => loadReplayCases());
      }
    });
  });

  tbody.querySelectorAll('.case-delete').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('确认删除此用例?')) return;
      const id = btn.dataset.caseId;
      const db = await openDb();
      await new Promise((resolve, reject) => {
        const t = db.transaction('testCases', 'readwrite');
        t.objectStore('testCases').delete(id);
        t.oncomplete = () => resolve();
        t.onerror = () => reject(t.error);
      });
      loadReplayCases();
    });
  });
}

function setupSaveCase() {
  const modal = document.getElementById('saveCaseModal');
  const nameInput = document.getElementById('saveCaseName');
  document.getElementById('replaySaveCase').addEventListener('click', () => {
    const method = document.getElementById('replayMethod').value;
    const url = document.getElementById('replayUrl').value;
    let defaultName = `${method} `;
    try { defaultName += new URL(url).pathname; } catch { defaultName += url; }
    nameInput.value = defaultName;
    modal.style.display = 'flex';
    nameInput.focus();
    nameInput.select();
  });
  document.getElementById('saveCaseModalClose').addEventListener('click', () => {
    modal.style.display = 'none';
  });
  modal.addEventListener('click', e => {
    if (e.target === modal) modal.style.display = 'none';
  });
  document.getElementById('saveCaseConfirm').addEventListener('click', async () => {
    const name = nameInput.value.trim() || 'Unnamed';
    const case_ = {
      id: generateId(),
      name,
      timestamp: Date.now(),
      method: document.getElementById('replayMethod').value,
      url: document.getElementById('replayUrl').value,
      headers: collectHeadersRaw(),
      body: document.getElementById('replayBody').value,
      variables: { ...replayState.variables },
    };
    await put('testCases', case_);
    modal.style.display = 'none';
    loadReplayCases();
  });
}

function setupExportCases() {
  document.getElementById('replayExportCases').addEventListener('click', () => {
    const out = replayState.cases.map(c => ({
      name: c.name, method: c.method, url: c.url,
      headers: c.headers, body: c.body, variables: c.variables,
    }));
    const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `test-cases-${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
  });
}

function setupReplayBottomTabs() {
  document.querySelectorAll('.replay-bottom-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.replay-bottom-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.replay-bottom-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(tab.dataset.replayTab === 'history' ? 'replayHistoryPanel' : 'replayCasesPanel').classList.add('active');
    });
  });
}

// ===== Monitor State =====
const monitorState = {
  monitors: [],
  selectedId: null,
  results: [],
};

function getIntervalSeconds(val, unit) {
  const v = parseFloat(val) || 60;
  if (unit === 'hours') return Math.round(v * 3600);
  if (unit === 'minutes') return Math.round(v * 60);
  return Math.max(MONITOR_MIN_INTERVAL, Math.min(MONITOR_MAX_INTERVAL, Math.round(v)));
}

function getIntervalDisplay(seconds) {
  if (seconds >= 3600) return `${(seconds / 3600).toFixed(1)}时`;
  if (seconds >= 60) return `${Math.round(seconds / 60)}分`;
  return `${seconds}秒`;
}

function getScheduleDisplay(monitor) {
  if (monitor.scheduleType === 'cron' && monitor.cronExpression) {
    return describeCron(monitor.cronExpression);
  }
  return `每 ${getIntervalDisplay(monitor.intervalSeconds || 60)}`;
}

function getCronPreviewHtml(expression) {
  if (!expression || !expression.trim()) return '';
  const valid = validateCron(expression);
  if (!valid.valid) return `<span style="color:#dc2626">${escapeHtml(valid.error)}</span>`;
  const next = cronNextTime(expression);
  if (!next) return '<span style="color:#dc2626">无法计算下次执行时间</span>';
  const desc = describeCron(expression);
  return `<span style="color:#16a34a">${escapeHtml(desc)}</span> &mdash; 下次: ${next.toLocaleString('zh-CN')}`;
}

// ===== Monitor: Data =====
async function loadMonitors(opts = {}) {
  chrome.runtime.sendMessage({ type: 'LIST_MONITORS' }, r => {
    if (chrome.runtime.lastError || !r || r.error) return;
    monitorState.monitors = r.monitors || [];
    renderMonitorList();
    if (!opts.skipForm && monitorState.selectedId) {
      const m = monitorState.monitors.find(x => x.id === monitorState.selectedId);
      if (m) { renderMonitorForm(m); return; }
      monitorState.selectedId = null;
      document.getElementById('monitorDetail').innerHTML = '<div class="monitor-placeholder">选择一个监控任务查看详情</div>';
    }
    document.getElementById('badgeMonitor').textContent = monitorState.monitors.length;
  });
}

async function loadMonitorResults(monitorId) {
  chrome.runtime.sendMessage({
    type: 'GET_MONITOR_RESULTS', monitorId, page: 0, pageSize: 50, sortDir: 'prev',
  }, r => {
    if (chrome.runtime.lastError || !r || r.error) return;
    monitorState.results = r.items || [];
    renderMonitorResults();
  });
}

// ===== Monitor: List =====
function renderMonitorList() {
  const container = document.getElementById('monitorList');
  const empty = document.getElementById('monitorEmpty');
  if (!monitorState.monitors.length) {
    container.innerHTML = '';
    empty.style.display = 'flex';
    return;
  }
  empty.style.display = 'none';
  container.innerHTML = monitorState.monitors.map(m => {
    let dotClass = 'monitor-dot-gray';
    if (m._lastResult) dotClass = m._lastResult.success ? 'monitor-dot-green' : 'monitor-dot-red';
    let urlDisplay = m.mainRequest.url;
    try { urlDisplay = new URL(m.mainRequest.url).pathname; } catch {}
    const selected = m.id === monitorState.selectedId ? ' monitor-card-selected' : '';
    return `<div class="monitor-card${selected}" data-monitor-id="${escapeHtml(m.id)}">
      <div class="monitor-card-top">
        <span class="monitor-dot ${dotClass}"></span>
        <span class="monitor-card-name">${escapeHtml(m.name)}</span>
        <div class="monitor-toggle-switch" title="${m.enabled ? '已启用' : '已禁用'}">
          <input type="checkbox" ${m.enabled ? 'checked' : ''} data-toggle-id="${escapeHtml(m.id)}" />
          <span class="toggle-slider"></span>
        </div>
      </div>
      <div class="monitor-card-meta">
        ${methodBadge(m.mainRequest.method)} <span class="monitor-card-url" title="${escapeHtml(m.mainRequest.url)}">${escapeHtml(urlDisplay)}</span>
      </div>
      <div class="monitor-card-footer">
        <span class="monitor-card-interval">${getScheduleDisplay(m)}</span>
        <button class="btn-detail monitor-card-delete" data-delete-id="${escapeHtml(m.id)}">删除</button>
      </div>
    </div>`;
  }).join('');
}

// List event delegation
document.getElementById('monitorList').addEventListener('click', e => {
  const card = e.target.closest('.monitor-card');
  const toggleLabel = e.target.closest('.monitor-toggle-switch');
  const toggle = e.target.closest('input[data-toggle-id]')
    || (toggleLabel ? toggleLabel.querySelector('input[data-toggle-id]') : null);
  const delBtn = e.target.closest('.monitor-card-delete');

  if (delBtn) {
    e.stopPropagation();
    const id = delBtn.dataset.deleteId;
    if (!confirm('确认删除此监控任务？')) return;
    chrome.runtime.sendMessage({ type: 'DELETE_MONITOR', id }, r => {
      if (!chrome.runtime.lastError && r && r.ok) {
        if (monitorState.selectedId === id) {
          monitorState.selectedId = null;
          document.getElementById('monitorDetail').innerHTML = '<div class="monitor-placeholder">选择一个监控任务查看详情</div>';
        }
        loadMonitors();
      }
    });
    return;
  }

  if (toggle) {
    e.stopPropagation();
    const id = toggle.dataset.toggleId;
    const m = monitorState.monitors.find(x => x.id === id);
    const newEnabled = m ? !m.enabled : toggle.checked;
    if (m) m.enabled = newEnabled;
    toggle.checked = newEnabled;
    chrome.runtime.sendMessage({ type: 'TOGGLE_MONITOR', id, enabled: newEnabled });
    if (monitorState.selectedId === id) {
      const cbInterval = document.getElementById('mfEnabled');
      const cbCron = document.getElementById('mfEnabledCron');
      if (cbInterval) cbInterval.checked = newEnabled;
      if (cbCron) cbCron.checked = newEnabled;
    }
    return;
  }

  if (card) {
    const id = card.dataset.monitorId;
    monitorState.selectedId = id;
    renderMonitorList();
    const m = monitorState.monitors.find(x => x.id === id);
    if (m) renderMonitorForm(m);
  }
});

// ===== Monitor: Form =====
function collectHeaders(containerId) {
  const headers = [];
  document.querySelectorAll(`#${containerId} .monitor-header-row`).forEach(row => {
    const key = row.querySelector('.monitor-hdr-key').value.trim();
    const val = row.querySelector('.monitor-hdr-val').value;
    if (key) headers.push({ key, value: val });
  });
  return headers;
}

function collectExtractRules() {
  const rules = [];
  document.querySelectorAll('#mfExtractRules .monitor-extract-row').forEach(row => {
    const source = row.querySelector('.extract-source').value;
    const path = row.querySelector('.extract-path').value.trim();
    const cookieName = row.querySelector('.extract-cookie-name').value.trim();
    const variableName = row.querySelector('.extract-var-name').value.trim();
    if (variableName && path) {
      rules.push({ source, path, cookieName: source === 'cookie' ? cookieName : undefined, variableName });
    }
  });
  return rules;
}

function addMonitorHeaderRow(containerId) {
  const container = document.getElementById(containerId);
  const row = document.createElement('div');
  row.className = 'monitor-header-row';
  row.innerHTML = `
    <input type="text" class="monitor-input monitor-hdr-key" placeholder="Header name" />
    <input type="text" class="monitor-input monitor-hdr-val" placeholder="Value" />
    <button class="btn btn-ghost btn-sm monitor-hdr-del" title="删除">&times;</button>
  `;
  container.appendChild(row);
}

function addMonitorExtractRow() {
  const container = document.getElementById('mfExtractRules');
  const row = document.createElement('div');
  row.className = 'monitor-extract-row';
  row.innerHTML = `
    <select class="monitor-input extract-source" style="width:80px">
      <option value="header">Header</option>
      <option value="body">Body</option>
      <option value="cookie">Cookie</option>
    </select>
    <input type="text" class="monitor-input extract-path" placeholder="Header名" style="flex:1" />
    <input type="text" class="monitor-input extract-cookie-name" placeholder="Cookie名" style="width:90px;display:none" />
    <span style="font-size:12px;color:#64748b">→</span>
    <input type="text" class="monitor-input extract-var-name" placeholder="变量名" style="width:100px" />
    <button class="btn btn-ghost btn-sm monitor-extract-del" title="删除">&times;</button>
  `;
  container.appendChild(row);
}

function renderMonitorForm(monitor) {
  const container = document.getElementById('monitorDetail');
  const intervalUnit = monitor.intervalSeconds >= 3600 ? 'hours' : monitor.intervalSeconds >= 60 ? 'minutes' : 'seconds';
  const intervalVal = intervalUnit === 'hours' ? (monitor.intervalSeconds / 3600).toFixed(1)
    : intervalUnit === 'minutes' ? monitor.intervalSeconds / 60 : monitor.intervalSeconds;
  const preReq = monitor.preRequest || { method: 'GET', url: '', headers: [], body: '', extractRules: [] };
  const preHeaders = preReq.headers && preReq.headers.length ? preReq.headers : [{ key: '', value: '' }];
  const mainHeaders = monitor.mainRequest.headers && monitor.mainRequest.headers.length ? monitor.mainRequest.headers : [{ key: '', value: '' }];

  container.innerHTML = `<div class="monitor-form">
    <div class="monitor-form-section">
      <div class="monitor-section-title">基本信息</div>
      <div class="monitor-field">
        <label>名称</label>
        <input id="mfName" type="text" class="monitor-input" value="${escapeHtml(monitor.name)}" placeholder="监控任务名称" />
      </div>
      <div class="monitor-field">
        <label>调度模式</label>
        <div class="schedule-type-toggle" id="scheduleTypeToggle">
          <label class="schedule-type-option ${monitor.scheduleType !== 'cron' ? 'active' : ''}">
            <input type="radio" name="scheduleType" value="interval" ${monitor.scheduleType !== 'cron' ? 'checked' : ''} />
            <span>间隔执行</span>
          </label>
          <label class="schedule-type-option ${monitor.scheduleType === 'cron' ? 'active' : ''}">
            <input type="radio" name="scheduleType" value="cron" ${monitor.scheduleType === 'cron' ? 'checked' : ''} />
            <span>Cron 定时</span>
          </label>
        </div>
      </div>
      <div class="monitor-field-row" id="intervalRow" style="display:${monitor.scheduleType === 'cron' ? 'none' : ''}">
        <div class="monitor-field" style="flex:1">
          <label>执行间隔</label>
          <div style="display:flex;gap:8px">
            <input id="mfInterval" type="number" class="monitor-input" value="${intervalVal}" min="1" style="width:100px" />
            <select id="mfIntervalUnit" class="monitor-input" style="width:80px">
              <option value="seconds" ${intervalUnit === 'seconds' ? 'selected' : ''}>秒</option>
              <option value="minutes" ${intervalUnit === 'minutes' ? 'selected' : ''}>分</option>
              <option value="hours" ${intervalUnit === 'hours' ? 'selected' : ''}>时</option>
            </select>
          </div>
        </div>
        <div class="monitor-field">
          <label>启用</label>
          <label class="monitor-toggle-switch" style="margin-top:4px">
            <input type="checkbox" id="mfEnabled" ${monitor.enabled ? 'checked' : ''} />
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>
      <div class="monitor-field cron-input-wrap" id="cronRow" style="display:${monitor.scheduleType === 'cron' ? '' : 'none'}">
        <label>Cron 表达式</label>
        <div style="display:flex;gap:8px">
          <input id="mfCron" type="text" class="monitor-input" style="flex:1;font-family:monospace" value="${escapeHtml(monitor.cronExpression || '')}" placeholder="分 时 日 月 周，如 0 10 * * *" />
        </div>
        <div class="cron-preview" id="cronPreview" style="margin-top:6px;font-size:12px;color:#64748b">${getCronPreviewHtml(monitor.cronExpression)}</div>
        <div class="cron-presets" style="margin-top:6px;display:flex;gap:4px;flex-wrap:wrap">
          <button class="btn btn-ghost btn-sm cron-preset" data-cron="*/5 * * * *">每5分钟</button>
          <button class="btn btn-ghost btn-sm cron-preset" data-cron="*/30 * * * *">每30分钟</button>
          <button class="btn btn-ghost btn-sm cron-preset" data-cron="0 0 * * *">每天0点</button>
          <button class="btn btn-ghost btn-sm cron-preset" data-cron="0 10 * * *">每天10点</button>
          <button class="btn btn-ghost btn-sm cron-preset" data-cron="0 9 * * 1-5">工作日9点</button>
        </div>
        <div class="monitor-field" style="margin-top:12px">
          <label>启用</label>
          <label class="monitor-toggle-switch" style="margin-top:4px">
            <input type="checkbox" id="mfEnabledCron" ${monitor.enabled ? 'checked' : ''} />
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>
    </div>

    <div class="monitor-form-section">
      <div class="monitor-section-title collapsible" id="monitorPreToggle" style="cursor:pointer">
        前置请求（鉴权刷新） <span style="font-size:11px;color:#94a3b8;font-weight:400">${preReq.url ? '已配置' : '可选'}</span>
      </div>
      <div id="monitorPrePanel" style="display:${preReq.url ? 'block' : 'none'}">
        <div style="display:flex;gap:8px;margin-bottom:8px">
          <select id="mfPreMethod" class="monitor-input" style="width:100px">
            <option value="GET" ${preReq.method === 'GET' ? 'selected' : ''}>GET</option>
            <option value="POST" ${preReq.method === 'POST' ? 'selected' : ''}>POST</option>
            <option value="PUT" ${preReq.method === 'PUT' ? 'selected' : ''}>PUT</option>
            <option value="DELETE" ${preReq.method === 'DELETE' ? 'selected' : ''}>DELETE</option>
            <option value="PATCH" ${preReq.method === 'PATCH' ? 'selected' : ''}>PATCH</option>
          </select>
          <input id="mfPreUrl" type="text" class="monitor-input" style="flex:1" value="${escapeHtml(preReq.url)}" placeholder="https://api.example.com/auth" />
        </div>
        <div class="monitor-sub-title">Headers</div>
        <div id="mfPreHeaders" class="monitor-headers-list">
          ${preHeaders.map(h => `
            <div class="monitor-header-row">
              <input type="text" class="monitor-input monitor-hdr-key" placeholder="Header name" value="${escapeHtml(h.key)}" />
              <input type="text" class="monitor-input monitor-hdr-val" placeholder="Value" value="${escapeHtml(h.value)}" />
              <button class="btn btn-ghost btn-sm monitor-hdr-del" title="删除">&times;</button>
            </div>`).join('')}
        </div>
        <button id="mfPreAddHeader" class="btn btn-ghost btn-sm" style="margin-top:4px">+ 添加 Header</button>
        <div class="monitor-sub-title" style="margin-top:12px">Body</div>
        <textarea id="mfPreBody" class="monitor-textarea" placeholder='{"key": "value"}'>${escapeHtml(preReq.body || '')}</textarea>
        <div class="monitor-sub-title" style="margin-top:12px">提取规则</div>
        <div id="mfExtractRules" class="monitor-extract-list">
          ${(preReq.extractRules || []).map(rule => `
            <div class="monitor-extract-row">
              <select class="monitor-input extract-source" style="width:80px">
                <option value="header" ${rule.source === 'header' ? 'selected' : ''}>Header</option>
                <option value="body" ${rule.source === 'body' ? 'selected' : ''}>Body</option>
                <option value="cookie" ${rule.source === 'cookie' ? 'selected' : ''}>Cookie</option>
              </select>
              <input type="text" class="monitor-input extract-path" placeholder="${rule.source === 'cookie' ? 'Set-Cookie' : rule.source === 'body' ? 'data.token' : 'Header名'}" value="${escapeHtml(rule.path || '')}" style="flex:1" />
              <input type="text" class="monitor-input extract-cookie-name" placeholder="Cookie名" value="${escapeHtml(rule.cookieName || '')}" style="width:90px;display:${rule.source === 'cookie' ? '' : 'none'}" />
              <span style="font-size:12px;color:#64748b">→</span>
              <input type="text" class="monitor-input extract-var-name" placeholder="变量名" value="${escapeHtml(rule.variableName || '')}" style="width:100px" />
              <button class="btn btn-ghost btn-sm monitor-extract-del" title="删除">&times;</button>
            </div>`).join('')}
        </div>
        <div style="margin-top:4px;display:flex;gap:8px">
          <button id="mfAddExtractRule" class="btn btn-ghost btn-sm">+ 添加提取规则</button>
          <button id="mfTestPre" class="btn btn-ghost btn-sm">测试前置请求</button>
        </div>
        <div id="mfPreTestResult" class="monitor-test-result" style="display:none"></div>
      </div>
    </div>

    <div class="monitor-form-section">
      <div class="monitor-section-title">目标请求（监控 API）</div>
      <div style="display:flex;gap:8px;margin-bottom:8px">
        <select id="mfMainMethod" class="monitor-input" style="width:100px">
          <option value="GET" ${monitor.mainRequest.method === 'GET' ? 'selected' : ''}>GET</option>
          <option value="POST" ${monitor.mainRequest.method === 'POST' ? 'selected' : ''}>POST</option>
          <option value="PUT" ${monitor.mainRequest.method === 'PUT' ? 'selected' : ''}>PUT</option>
          <option value="DELETE" ${monitor.mainRequest.method === 'DELETE' ? 'selected' : ''}>DELETE</option>
          <option value="PATCH" ${monitor.mainRequest.method === 'PATCH' ? 'selected' : ''}>PATCH</option>
        </select>
        <input id="mfMainUrl" type="text" class="monitor-input" style="flex:1" value="${escapeHtml(monitor.mainRequest.url)}" placeholder="https://api.example.com/endpoint" />
      </div>
      <div class="monitor-sub-title">Headers</div>
      <div id="mfMainHeaders" class="monitor-headers-list">
        ${mainHeaders.map(h => `
          <div class="monitor-header-row">
            <input type="text" class="monitor-input monitor-hdr-key" placeholder="Header name" value="${escapeHtml(h.key)}" />
            <input type="text" class="monitor-input monitor-hdr-val" placeholder="Value" value="${escapeHtml(h.value)}" />
            <button class="btn btn-ghost btn-sm monitor-hdr-del" title="删除">&times;</button>
          </div>`).join('')}
      </div>
      <button id="mfMainAddHeader" class="btn btn-ghost btn-sm" style="margin-top:4px">+ 添加 Header</button>
      <div class="monitor-sub-title" style="margin-top:12px">Body</div>
      <textarea id="mfMainBody" class="monitor-textarea" placeholder='{"key": "value"}'>${escapeHtml(monitor.mainRequest.body || '')}</textarea>
      <div style="margin-top:8px;font-size:11px;color:#94a3b8">
        可用变量：<code>{{timestamp}}</code> <code>{{random}}</code>
      </div>
    </div>

    <div class="monitor-form-actions">
      <button id="mfSave" class="btn btn-primary">保存</button>
      <button id="mfRunNow" class="btn btn-ghost">立即执行</button>
      <button id="mfCancel" class="btn btn-ghost" style="color:#dc2626">取消</button>
    </div>
  </div>
  <div class="monitor-results-panel" id="monitorResultsPanel">
    <div class="monitor-section-title">执行历史</div>
    <table class="monitor-results-table">
      <thead><tr><th>时间</th><th>前置状态</th><th>目标状态</th><th>耗时</th></tr></thead>
      <tbody id="monitorResultsBody"><tr><td colspan="4" style="color:#94a3b8;text-align:center">加载中...</td></tr></tbody>
    </table>
  </div>`;

  setupMonitorFormEvents(monitor);
  loadMonitorResults(monitor.id);
}

function setupMonitorFormEvents(monitor) {
  // Pre-request collapse toggle
  document.getElementById('monitorPreToggle').addEventListener('click', () => {
    const panel = document.getElementById('monitorPrePanel');
    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
  });

  // Schedule type toggle
  const intervalRow = document.getElementById('intervalRow');
  const cronRow = document.getElementById('cronRow');
  document.querySelectorAll('input[name="scheduleType"]').forEach(radio => {
    radio.addEventListener('change', () => {
      const isCron = radio.value === 'cron';
      intervalRow.style.display = isCron ? 'none' : '';
      cronRow.style.display = isCron ? '' : 'none';
      document.querySelectorAll('.schedule-type-option').forEach(opt => {
        opt.classList.toggle('active', opt.querySelector('input').checked);
      });
    });
  });

  // Sync enabled checkboxes and persist state
  const enabledInterval = document.getElementById('mfEnabled');
  const enabledCron = document.getElementById('mfEnabledCron');
  if (enabledInterval && enabledCron) {
    const syncToggle = (newVal) => {
      enabledInterval.checked = newVal;
      enabledCron.checked = newVal;
      const m = monitorState.monitors.find(x => x.id === monitor.id);
      if (m) m.enabled = newVal;
      chrome.runtime.sendMessage({ type: 'TOGGLE_MONITOR', id: monitor.id, enabled: newVal });
      const listToggle = document.querySelector(`input[data-toggle-id="${monitor.id}"]`);
      if (listToggle) listToggle.checked = newVal;
    };
    enabledInterval.addEventListener('change', () => syncToggle(enabledInterval.checked));
    enabledCron.addEventListener('change', () => syncToggle(enabledCron.checked));
  }

  // Cron live preview
  const cronInput = document.getElementById('mfCron');
  if (cronInput) {
    cronInput.addEventListener('input', () => {
      document.getElementById('cronPreview').innerHTML = getCronPreviewHtml(cronInput.value);
    });
  }

  // Cron preset buttons
  document.getElementById('monitorDetail').addEventListener('click', e => {
    const preset = e.target.closest('.cron-preset');
    if (preset) {
      const expr = preset.dataset.cron;
      document.getElementById('mfCron').value = expr;
      document.getElementById('cronPreview').innerHTML = getCronPreviewHtml(expr);
    }
  });

  // Add header buttons
  document.getElementById('mfPreAddHeader').addEventListener('click', () => addMonitorHeaderRow('mfPreHeaders'));
  document.getElementById('mfMainAddHeader').addEventListener('click', () => addMonitorHeaderRow('mfMainHeaders'));

  // Header delete delegation
  document.getElementById('monitorDetail').addEventListener('click', e => {
    const del = e.target.closest('.monitor-hdr-del');
    if (del) { del.closest('.monitor-header-row').remove(); return; }
    const extDel = e.target.closest('.monitor-extract-del');
    if (extDel) { extDel.closest('.monitor-extract-row').remove(); return; }
  });

  // Extract source change → show/hide cookie name input
  document.getElementById('monitorDetail').addEventListener('change', e => {
    if (e.target.classList.contains('extract-source')) {
      const row = e.target.closest('.monitor-extract-row');
      const cookieInput = row.querySelector('.extract-cookie-name');
      const pathInput = row.querySelector('.extract-path');
      cookieInput.style.display = e.target.value === 'cookie' ? '' : 'none';
      pathInput.placeholder = e.target.value === 'cookie' ? 'Set-Cookie' : e.target.value === 'body' ? 'data.token' : 'Header名';
    }
  });

  // Add extract rule
  document.getElementById('mfAddExtractRule').addEventListener('click', () => addMonitorExtractRow());

  // Test pre-request
  document.getElementById('mfTestPre').addEventListener('click', async () => {
    const method = document.getElementById('mfPreMethod').value;
    const url = document.getElementById('mfPreUrl').value.trim();
    const headers = {};
    document.querySelectorAll('#mfPreHeaders .monitor-header-row').forEach(row => {
      const k = row.querySelector('.monitor-hdr-key').value.trim();
      const v = row.querySelector('.monitor-hdr-val').value;
      if (k) headers[k] = v;
    });
    const body = document.getElementById('mfPreBody').value;
    const rules = collectExtractRules();

    if (!url) { alert('请输入前置请求 URL'); return; }

    const resultEl = document.getElementById('mfPreTestResult');
    resultEl.style.display = 'block';
    resultEl.innerHTML = '<span style="color:#64748b">发送中...</span>';

    try {
      const fetchOpts = { method, headers, credentials: 'include' };
      if (body && method !== 'GET' && method !== 'HEAD') fetchOpts.body = body;
      const start = Date.now();
      const resp = await fetch(url, fetchOpts);
      const duration = Date.now() - start;
      const respHeaders = {};
      resp.headers.forEach((v, k) => { respHeaders[k] = v; });
      const respBody = await resp.text();

      const extracted = extractFromResponse(respHeaders, respBody, rules);
      const extractedStr = Object.entries(extracted).map(([k, v]) =>
        `<code>{{${escapeHtml(k)}}}</code> = <strong>${escapeHtml(v || '(null)')}</strong>`
      ).join('<br>') || '(无)';

      resultEl.innerHTML = `<span style="color:${resp.ok ? '#16a34a' : '#dc2626'}">状态: ${resp.status} (${duration}ms)</span>
        <div style="margin-top:4px">提取变量:<br>${extractedStr}</div>`;
    } catch (err) {
      resultEl.innerHTML = `<span style="color:#dc2626">错误: ${escapeHtml(err.message)}</span>`;
    }
  });

  // Save
  document.getElementById('mfSave').addEventListener('click', () => {
    const name = document.getElementById('mfName').value.trim();
    if (!name) { alert('请输入监控名称'); return; }

    const scheduleType = document.querySelector('input[name="scheduleType"]:checked')?.value || 'interval';
    let intervalSeconds = 60;
    let cronExpression = '';

    if (scheduleType === 'cron') {
      cronExpression = document.getElementById('mfCron').value.trim();
      const cronCheck = validateCron(cronExpression);
      if (!cronCheck.valid) { alert('Cron 表达式无效: ' + cronCheck.error); return; }
    } else {
      intervalSeconds = getIntervalSeconds(
        document.getElementById('mfInterval').value,
        document.getElementById('mfIntervalUnit').value
      );
    }

    const enabled = scheduleType === 'cron'
      ? document.getElementById('mfEnabledCron').checked
      : document.getElementById('mfEnabled').checked;
    const preUrl = document.getElementById('mfPreUrl').value.trim();
    const preRequest = preUrl ? {
      method: document.getElementById('mfPreMethod').value,
      url: preUrl,
      headers: collectHeaders('mfPreHeaders'),
      body: document.getElementById('mfPreBody').value,
      extractRules: collectExtractRules(),
    } : null;

    const monitorData = {
      id: monitor.id,
      name,
      scheduleType,
      intervalSeconds,
      cronExpression,
      enabled,
      createdAt: monitor.createdAt || Date.now(),
      preRequest,
      mainRequest: {
        method: document.getElementById('mfMainMethod').value,
        url: document.getElementById('mfMainUrl').value.trim(),
        headers: collectHeaders('mfMainHeaders'),
        body: document.getElementById('mfMainBody').value,
      },
    };

    chrome.runtime.sendMessage({ type: 'SAVE_MONITOR', monitor: monitorData }, r => {
      if (chrome.runtime.lastError || !r || r.error) return;
      if (r.id) monitorState.selectedId = r.id;
      loadMonitors();
    });
  });

  // Run now
  document.getElementById('mfRunNow').addEventListener('click', () => {
    document.getElementById('monitorResultsBody').innerHTML =
      '<tr><td colspan="4" style="color:#64748b;text-align:center">执行中...</td></tr>';
    chrome.runtime.sendMessage({ type: 'RUN_MONITOR_NOW', id: monitor.id }, r => {
      if (!chrome.runtime.lastError && r && r.ok) {
        setTimeout(() => loadMonitorResults(monitor.id), 2000);
      }
    });
  });

  // Cancel
  document.getElementById('mfCancel').addEventListener('click', () => {
    monitorState.selectedId = null;
    renderMonitorList();
    document.getElementById('monitorDetail').innerHTML = '<div class="monitor-placeholder">选择一个监控任务查看详情</div>';
  });
}

function renderMonitorResults() {
  const tbody = document.getElementById('monitorResultsBody');
  if (!monitorState.results.length) {
    tbody.innerHTML = '<tr><td colspan="4" style="color:#94a3b8;text-align:center">暂无执行记录</td></tr>';
    return;
  }
  tbody.innerHTML = monitorState.results.map(r => {
    const ts = new Date(r.timestamp).toLocaleTimeString();
    const preStatus = r.preResponseStatus != null
      ? `<span class="status-badge status-${statusClass(r.preResponseStatus)}">${r.preResponseStatus}</span>`
      : '<span style="color:#94a3b8">-</span>';
    const mainStatus = `<span class="status-badge status-${statusClass(r.responseStatus)}">${r.responseStatus || (r.error ? 'ERR' : '-')}</span>`;
    const duration = r.duration >= 0 ? `${r.duration}ms` : '-';
    return `<tr class="monitor-result-row" data-result-id="${escapeHtml(r.id)}">
      <td>${escapeHtml(ts)}</td>
      <td>${preStatus}</td>
      <td>${mainStatus}</td>
      <td>${escapeHtml(duration)}</td>
    </tr>
    <tr class="monitor-result-detail" id="resultDetail_${escapeHtml(r.id)}" style="display:none">
      <td colspan="4">
        ${r.error ? `<div style="color:#dc2626;margin-bottom:4px">错误: ${escapeHtml(r.error)}</div>` : ''}
        ${r.extractedVars && Object.keys(r.extractedVars).length ? `<div style="margin-bottom:4px;font-size:11px;color:#64748b">提取变量: ${Object.entries(r.extractedVars).map(([k,v]) => `<code>{{${escapeHtml(k)}}}</code>=${escapeHtml(v)}`).join(' ')}</div>` : ''}
        <pre style="max-height:200px;overflow:auto;background:#1e293b;color:#e2e8f0;padding:8px;border-radius:4px;font-size:11px">${escapeHtml(r.responseBody || '(无响应体)')}</pre>
      </td>
    </tr>`;
  }).join('');

  // Click to expand result detail
  tbody.querySelectorAll('.monitor-result-row').forEach(row => {
    row.addEventListener('click', () => {
      const detail = document.getElementById('resultDetail_' + row.dataset.resultId);
      detail.style.display = detail.style.display === 'none' ? '' : 'none';
    });
  });
}

// Monitor: "Add from history" handler
function importMonitorFromHistory(method, url, headers, body) {
  let name = `${method} `;
  try { name += new URL(url).pathname; } catch { name += url; }

  const monitorData = {
    id: generateId(),
    name,
    scheduleType: 'interval',
    intervalSeconds: 60,
    enabled: false,
    createdAt: Date.now(),
    preRequest: null,
    mainRequest: {
      method,
      url,
      headers: headers && typeof headers === 'object' ? Object.entries(headers).map(([k, v]) => ({ key: k, value: String(v) })) : [],
      body: body || '',
    },
  };

  chrome.runtime.sendMessage({ type: 'SAVE_MONITOR', monitor: monitorData }, r => {
    if (chrome.runtime.lastError || !r || r.error) return;
    if (r.id) monitorState.selectedId = r.id;
    // Switch to monitor tab
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelector('[data-tab="monitor"]').classList.add('active');
    document.getElementById('tab-monitor').classList.add('active');
    document.getElementById('confidenceSlider').style.display = 'none';
    loadMonitors();
  });
}

// Monitor: add event delegation for "添加监控" button in history table
document.querySelector('#tableHistory tbody').addEventListener('click', e => {
  const monitorBtn = e.target.closest('.btn-add-monitor');
  if (monitorBtn) {
    const id = monitorBtn.dataset.histId;
    chrome.runtime.sendMessage({ type: 'GET_HISTORY_DETAIL', id }, r => {
      if (chrome.runtime.lastError || !r || r.error) return;
      importMonitorFromHistory(r.method, r.url, r.requestHeaders || {}, r.requestBody || '');
    });
    return;
  }
});

// Monitor: add button to history table rows
const origRenderHistory = renderHistory;
renderHistory = function () {
  origRenderHistory();
  // Add "添加监控" button to each row after render
  document.querySelectorAll('#tableHistory tbody .btn-replay').forEach(btn => {
    if (btn.nextElementSibling && btn.nextElementSibling.classList.contains('btn-add-monitor')) return;
    const monitorBtn = document.createElement('button');
    monitorBtn.className = 'btn-add-monitor';
    monitorBtn.textContent = '添加监控';
    monitorBtn.dataset.histId = btn.dataset.histId;
    btn.insertAdjacentElement('afterend', monitorBtn);
  });
};

// Monitor: "添加监控" button in toolbar
document.getElementById('monitorAddBtn').addEventListener('click', () => {
  const newMonitor = {
    id: null,
    name: '',
    scheduleType: 'interval',
    intervalSeconds: 60,
    enabled: false,
    createdAt: Date.now(),
    preRequest: null,
    mainRequest: { method: 'GET', url: '', headers: [], body: '' },
  };
  monitorState.selectedId = null;
  renderMonitorList();
  renderMonitorForm(newMonitor);
});

// Monitor: refresh button
document.getElementById('monitorRefreshBtn').addEventListener('click', () => {
  loadMonitors();
  if (monitorState.selectedId) loadMonitorResults(monitorState.selectedId);
});

// Monitor: listen for new results from SW
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'MONITOR_RESULT' && msg.result) {
    // Update the last result on the matching monitor card
    const m = monitorState.monitors.find(x => x.id === msg.result.monitorId);
    if (m) {
      m._lastResult = msg.result;
      renderMonitorList();
    }
    // Refresh results panel if viewing this monitor
    if (monitorState.selectedId === msg.result.monitorId) {
      loadMonitorResults(msg.result.monitorId);
    }
  }
});

// History state
const hist = {
  page: 0, pageSize: 50, sort: { field: 'timestamp', dir: 'desc' },
  filter: { method: '', statusClass: '', resourceType: 'xmlhttprequest,fetch', search: '' },
  total: 0, items: [],
};
// RESOURCE_MAP loaded from shared/constants.js

function renderPages() {
  const tbody = document.querySelector('#tablePages tbody');
  const rows = data.pageApiMap.filter(p => !filterText || p.page.includes(filterText));
  tbody.innerHTML = rows.map(p => `
    <tr>
      <td><strong>${escapeHtml(p.page)}</strong></td>
      <td>${escapeHtml(p.pageTitle || '')}</td>
      <td><ul class="actions-list">${(p.actions || []).map(a =>
        `<li>${methodBadge(a.method)} ${escapeHtml(a.name)} &rarr; ${escapeHtml(a.api)}</li>`).join('')}</ul></td>
      <td>${(p.apis || []).map(a => `${methodBadge(a.method)} ${escapeHtml(a.urlPath)}`).join('<br>')}</td>
    </tr>`).join('');
}

function renderBehaviors() {
  const tbody = document.querySelector('#tableBehaviors tbody');
  let rows = data.behaviorApiMap.filter(b =>
    !filterText || (b.behavior?.text || '').includes(filterText)
  );
  // Sort: mapped first (by highest confidence), then unmapped, then by occurrences
  rows.sort((a, b) => {
    const aMax = Math.max(0, ...a.mappings.map(m => m.confidence));
    const bMax = Math.max(0, ...b.mappings.map(m => m.confidence));
    if (bMax !== aMax) return bMax - aMax;
    return (b.occurrences || 0) - (a.occurrences || 0);
  });

  tbody.innerHTML = rows.flatMap(b => {
    const validMappings = b.mappings.filter(m => m.confidence >= minConf);
    const recordsBtn = b.occurrences > 1
      ? `<button class="btn-records" data-behavior-key="${escapeHtml((b.behavior?.text || '') + ':' + (b.behavior?.page || ''))}">查看清单(${b.occurrences})</button>`
      : '';
    if (!validMappings.length) {
      return `<tr>
        <td><strong>${escapeHtml(b.behavior?.text || '(no text)')}</strong> ${recordsBtn}</td>
        <td>${escapeHtml(b.behavior?.page || '')}</td>
        <td colspan="3" style="color:#94a3b8;text-align:center">No correlated API</td>
      </tr>`;
    }
    return validMappings.map(m => `
    <tr>
      <td><strong>${escapeHtml(b.behavior?.text || '')}</strong> ${recordsBtn}</td>
      <td>${escapeHtml(b.behavior?.page || '')}</td>
      <td>${methodBadge(m.method)} ${escapeHtml(m.urlPath)} <button class="btn-replay btn-replay-behavior" data-replay-url="${escapeHtml(m.urlPath)}" data-replay-method="${escapeHtml(m.method)}">重放</button></td>
      <td><span class="conf ${confClass(m.confidence)}">${m.confidence.toFixed(2)}</span></td>
      <td>
        <div class="evidence-bar">
          <span class="evidence-item">T:<strong>${m.evidence?.temporal?.toFixed(2)}</strong></span>
          <span class="evidence-item">S:<strong>${m.evidence?.semantic?.toFixed(2)}</strong></span>
          <span class="evidence-item">P:<strong>${m.evidence?.param?.toFixed(2)}</strong></span>
        </div>
      </td>
    </tr>`);
  }).join('');
}

function updateStats() {
  const raw = data._raw || {};
  document.getElementById('statRequests').textContent = raw.totalRequests ?? 0;
  document.getElementById('statPages').textContent = data.pageApiMap.length || raw.totalMappings || 0;
  document.getElementById('statBehaviors').textContent = data.behaviorApiMap.length || raw.totalBehaviors || 0;
  document.getElementById('badgePages').textContent = data.pageApiMap.length || raw.totalMappings || 0;
  document.getElementById('badgeBehaviors').textContent = data.behaviorApiMap.length || raw.totalBehaviors || 0;
}

function render() { renderPages(); renderBehaviors(); updateStats(); }

async function loadStatsOnly() {
  try {
    const stats = await DashboardApi.getStats();
    data._raw = stats || {};
    updateStats();
    updateCaptureStatus();
  } catch (err) {
    console.error('[Dashboard] GET_STATS failed:', err.message);
  }
}

function loadHistory() {
  const msg = {
    page: hist.page,
    pageSize: hist.pageSize,
    sort: hist.sort,
    filter: hist.filter,
  };
  DashboardApi.getHistory(msg).then(r => {
    hist.items = r.items || [];
    hist.total = r.total || 0;
    renderHistory();
  }).catch(err => console.error('[Dashboard] GET_HISTORY failed:', err.message));
}

function renderHistory() {
  const tbody = document.querySelector('#tableHistory tbody');
  const fmtTs = ts => {
    const d = new Date(ts);
    return `${d.toLocaleDateString()} ${d.toLocaleTimeString()}.${String(d.getMilliseconds()).padStart(3,'0')}`;
  };
  const fmtDur = d => d >= 0 ? `${d}ms` : '-';
  const fmtUrl = url => {
    try { const u = new URL(url); return u.pathname + u.search; } catch { return url; }
  };

  tbody.innerHTML = hist.items.map(r => {
    const sc = statusClass(r.responseStatus);
    const rt = RESOURCE_MAP[r.resourceType] || r.resourceType || '-';
    return `<tr>
      <td class="hist-ts">${escapeHtml(fmtTs(r.timestamp))}</td>
      <td>${methodBadge(r.method)}</td>
      <td class="hist-url" title="${escapeHtml(r.url || '')}">${escapeHtml(fmtUrl(r.url || ''))}</td>
      <td><span class="status-badge status-${sc}">${r.responseStatus || '-'}</span></td>
      <td><span class="type-tag">${escapeHtml(rt)}</span></td>
      <td>${escapeHtml(fmtDur(r.duration))}</td>
      <td>${escapeHtml(r.pageContext?.path || r.pageUrl || '-')}</td>
      <td>
        <button class="btn-detail" data-hist-id="${escapeHtml(r.id)}">查看详情</button>
        <button class="btn-replay" data-hist-id="${escapeHtml(r.id)}">重放</button>
      </td>
    </tr>`;
  }).join('');

  // Count & pagination
  document.getElementById('histCount').textContent = `${hist.total} 条`;
  document.getElementById('badgeHistory').textContent = hist.total;
  const totalPages = Math.max(1, Math.ceil(hist.total / hist.pageSize));
  document.getElementById('histPageInfo').textContent = `${hist.page + 1} / ${totalPages}`;
  document.getElementById('histPrev').disabled = hist.page <= 0;
  document.getElementById('histNext').disabled = hist.page >= totalPages - 1;

  // Empty state
  const empty = document.getElementById('emptyHistory');
  empty.style.display = hist.items.length === 0 ? 'flex' : 'none';
}

// History detail modal
function openHistoryDetailModal(id) {
  chrome.runtime.sendMessage({ type: 'GET_HISTORY_DETAIL', id }, r => {
    if (chrome.runtime.lastError || !r || r.error) return;
    const isXhr = r.resourceType === 'xmlhttprequest' || r.resourceType === 'fetch';
    document.getElementById('histDetailTitle').textContent = `${r.method} ${r.url}`;
    document.getElementById('histDetailReqLine').innerHTML =
      `${methodBadge(r.method)} <span style="margin-left:8px">${escapeHtml(r.url)}</span>`;
    document.getElementById('histDetailReqHeaders').textContent =
      r.requestHeaders && Object.keys(r.requestHeaders).length
        ? JSON.stringify(r.requestHeaders, null, 2) : '(无)';
    const reqBodyEl = document.getElementById('histDetailReqBody');
    if (isXhr) {
      reqBodyEl.textContent = r.requestBody || '(无)';
      reqBodyEl.className = 'modal-pre';
    } else {
      reqBodyEl.textContent = '仅 fetch/XHR 请求支持查看请求体';
      reqBodyEl.className = 'modal-pre hist-body-hint';
    }
    const sc = statusClass(r.responseStatus);
    document.getElementById('histDetailRespLine').innerHTML =
      `<span class="status-badge status-${sc}">${r.responseStatus || '-'}</span>
       <span style="margin-left:8px">耗时: ${r.duration >= 0 ? r.duration + 'ms' : '-'}</span>`;
    const respBodyEl = document.getElementById('histDetailRespBody');
    if (isXhr) {
      respBodyEl.textContent = r.responseBody || '(无)';
      respBodyEl.className = 'modal-pre';
    } else {
      respBodyEl.textContent = '仅 fetch/XHR 请求支持查看响应体';
      respBodyEl.className = 'modal-pre hist-body-hint';
    }
    document.getElementById('histDetailReplay').onclick = () => {
      closeHistoryDetailModal();
      loadIntoReplay(r.method, r.url, r.requestHeaders || {}, r.requestBody || '');
    };
    document.getElementById('historyDetailModal').style.display = 'flex';
  });
}
function closeHistoryDetailModal() {
  document.getElementById('historyDetailModal').style.display = 'none';
}
document.getElementById('histDetailClose').addEventListener('click', closeHistoryDetailModal);
document.getElementById('historyDetailModal').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeHistoryDetailModal();
});

// History event delegation — detail & replay buttons
document.querySelector('#tableHistory tbody').addEventListener('click', e => {
  const detailBtn = e.target.closest('.btn-detail');
  if (detailBtn) { openHistoryDetailModal(detailBtn.dataset.histId); return; }
  const replayBtn = e.target.closest('.btn-replay');
  if (replayBtn) {
    const id = replayBtn.dataset.histId;
    chrome.runtime.sendMessage({ type: 'GET_HISTORY_DETAIL', id }, r => {
      if (chrome.runtime.lastError || !r || r.error) return;
      loadIntoReplay(r.method, r.url, r.requestHeaders || {}, r.requestBody || '');
    });
    return;
  }
});

// History filters
document.getElementById('histMethodFilter').addEventListener('change', e => {
  hist.filter.method = e.target.value;
  hist.page = 0;
  loadHistory();
});
document.getElementById('histStatusFilter').addEventListener('change', e => {
  hist.filter.statusClass = e.target.value;
  hist.page = 0;
  loadHistory();
});
document.getElementById('histTypeFilter').addEventListener('change', e => {
  hist.filter.resourceType = e.target.value;
  hist.page = 0;
  loadHistory();
});

// History search — reuse main filterInput
const origFilterInputHandler = document.getElementById('filterInput').oninput;

// History sort — click column headers
document.querySelectorAll('#tableHistory th.sortable').forEach(th => {
  th.addEventListener('click', () => {
    const field = th.dataset.sort;
    if (hist.sort.field === field) {
      hist.sort.dir = hist.sort.dir === 'desc' ? 'asc' : 'desc';
    } else {
      hist.sort.field = field;
      hist.sort.dir = 'desc';
    }
    // Update header indicators
    document.querySelectorAll('#tableHistory th.sortable').forEach(h => {
      h.textContent = h.textContent.replace(/ [↑↓]$/, '');
    });
    const label = th.textContent.replace(/ [↑↓]$/, '');
    th.textContent = label + (hist.sort.dir === 'desc' ? ' ↓' : ' ↑');
    hist.page = 0;
    loadHistory();
  });
});

// History pagination
document.getElementById('histPrev').addEventListener('click', () => {
  if (hist.page > 0) { hist.page--; loadHistory(); }
});
document.getElementById('histNext').addEventListener('click', () => {
  const totalPages = Math.ceil(hist.total / hist.pageSize);
  if (hist.page < totalPages - 1) { hist.page++; loadHistory(); }
});

function load() {
  DashboardApi.getExport().then(r => {
    if (r) {
      data = r;
      console.log('[Dashboard] load: apiAssets=%d pageApiMap=%d behaviorApiMap=%d',
        (r.apiAssets || []).length, (r.pageApiMap || []).length, (r.behaviorApiMap || []).length);
      // Fetch raw counts separately for consistent stat display
      DashboardApi.getStats().then(stats => {
        data._raw = stats || {};
        render();
      }).catch(() => render());
      updateCaptureStatus();
    } else {
      console.warn('[Dashboard] load: empty response');
    }
  }).catch(err => console.error('[Dashboard] GET_EXPORT failed:', err.message));
}

function updateCaptureStatus() {
  chrome.storage.session.get('capturing', s => {
    const el = document.getElementById('captureStatus');
    const on = s.capturing !== false;
    el.textContent = on ? '● 采集中' : '○ 已暂停';
    el.className = 'capture-status ' + (on ? 'on' : 'off');
  });
}

// Tab switching
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
    const slider = document.getElementById('confidenceSlider');
    slider.style.display = btn.dataset.tab === 'behaviors' ? 'flex' : 'none';
    if (btn.dataset.tab === 'pages' || btn.dataset.tab === 'behaviors') load();
    if (btn.dataset.tab === 'history') loadHistory();
    if (btn.dataset.tab === 'monitor') loadMonitors();
  });
});

// History search
document.getElementById('histSearchInput').addEventListener('input', e => {
  hist.filter.search = e.target.value;
  document.getElementById('histSearchClear').style.visibility = e.target.value ? 'visible' : 'hidden';
  hist.page = 0;
  loadHistory();
});
document.getElementById('histSearchClear').addEventListener('click', () => {
  document.getElementById('histSearchInput').value = '';
  hist.filter.search = '';
  document.getElementById('histSearchClear').style.visibility = 'hidden';
  hist.page = 0;
  loadHistory();
});
document.getElementById('histSearchClear').style.visibility = 'hidden';

// Search (pages / behaviors)
document.getElementById('filterInput').addEventListener('input', e => {
  filterText = e.target.value;
  document.getElementById('clearFilter').style.visibility = filterText ? 'visible' : 'hidden';
  render();
});
document.getElementById('clearFilter').addEventListener('click', () => {
  document.getElementById('filterInput').value = '';
  filterText = '';
  document.getElementById('clearFilter').style.visibility = 'hidden';
  render();
});
document.getElementById('clearFilter').style.visibility = 'hidden';

// Confidence slider
document.getElementById('confSlider').addEventListener('input', e => {
  minConf = e.target.value / 100;
  document.getElementById('confVal').textContent = minConf.toFixed(2);
  render();
});

document.getElementById('refreshBtn').addEventListener('click', () => {
  const active = DashboardRefresh.getActiveTab();
  if (active === 'pages' || active === 'behaviors') load();
  else if (active === 'history') { loadStatsOnly(); loadHistory(); }
  else if (active === 'replay') { loadStatsOnly(); loadReplayHistory(); loadReplayCases(); }
  else if (active === 'monitor') { loadStatsOnly(); loadMonitors(); }
});

// Export
document.getElementById('exportBtn').addEventListener('click', async () => {
  try {
    const exportData = await DashboardApi.getExport();
    const out = {
      apiAssets: exportData.apiAssets,
      pageApiMap: exportData.pageApiMap,
      behaviorApiMap: exportData.behaviorApiMap,
    };
    const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `sec-cap-${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
  } catch (err) {
    console.error('[Dashboard] export failed:', err.message);
    alert('瀵煎嚭澶辫触: ' + err.message);
  }
});

// Event delegation for behavior records & replay buttons
document.querySelector('#tableBehaviors tbody').addEventListener('click', e => {
  const recordsBtn = e.target.closest('.btn-records');
  if (recordsBtn) {
    const key = recordsBtn.dataset.behaviorKey;
    if (!key) return;
    const entry = data.behaviorApiMap.find(b => `${b.behavior?.text || ''}:${b.behavior?.pageKey || b.behavior?.page || ''}` === key);
    if (entry) openRecordsModal(entry.records, entry.behavior?.text || '行为');
    return;
  }
  const replayBtn = e.target.closest('.btn-replay-behavior');
  if (replayBtn) {
    const method = replayBtn.dataset.replayMethod;
    const urlPath = replayBtn.dataset.replayUrl;
    const apiMatch = data.apiAssets.find(a => a.method === method && a.urlPath === urlPath);
    let url = urlPath;
    if (apiMatch && apiMatch.host) {
      try { url = `https://${apiMatch.host}${urlPath}`; } catch {}
    }
    const headers = apiMatch?.sampleRequestHeaders || {};
    const body = apiMatch?.sampleRequestBody || '';
    loadIntoReplay(method, url, headers, body);
  }
});

// Records modal
function openRecordsModal(records, title) {
  const el = document.getElementById('recordsModal');
  document.getElementById('recordsTitle').textContent = `调用清单 — ${escapeHtml(title)}`;
  if (!records || !records.length) {
    document.getElementById('recordsTableBody').innerHTML = '<tr><td colspan="5" style="color:#94a3b8;text-align:center">无记录</td></tr>';
    el.style.display = 'flex';
    return;
  }
  const tbody = document.getElementById('recordsTableBody');
  const isApi = 'method' in records[0];
  if (isApi) {
    tbody.innerHTML = records.map(r => `<tr>
      <td>${escapeHtml(new Date(r.timestamp).toLocaleTimeString())}</td>
      <td>${methodBadge(r.method)}</td>
      <td>${escapeHtml(r.status || '-')}</td>
      <td>${escapeHtml(r.pageUrl || '-')}</td>
      <td><pre>${escapeHtml(r.bodyPreview || '-')}</pre></td>
    </tr>`).join('');
  } else {
    tbody.innerHTML = records.map(r => `<tr>
      <td>${escapeHtml(new Date(r.timestamp).toLocaleTimeString())}</td>
      <td>${escapeHtml(r.type || '-')}</td>
      <td>${escapeHtml(r.elementText || '-')}</td>
      <td>${escapeHtml(r.pageUrl || '-')}</td>
    </tr>`).join('');
  }
  el.style.display = 'flex';
}
function closeRecordsModal() {
  document.getElementById('recordsModal').style.display = 'none';
}
document.getElementById('recordsModalClose').addEventListener('click', closeRecordsModal);
document.getElementById('recordsModal').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeRecordsModal();
});

// Startup health check
chrome.runtime.sendMessage({ type: 'PING' }, r => {
  const err = chrome.runtime.lastError;
  if (err) {
    console.error('[Dashboard] Service worker unreachable:', err.message);
    document.getElementById('captureStatus').textContent = '⚠ 无法连接 Service Worker';
    document.getElementById('captureStatus').className = 'capture-status off';
  } else {
    console.log('[Dashboard] Service worker reachable, pong=%o', r);
    loadStatsOnly();
    loadHistory();
    loadVariables();
    loadReplayHistory();
    loadReplayCases();
    setupHeaderRows();
    setupFormatBody();
    setupVariableInteractions();
    setupRespHeadersCollapse();
    setupRespBodySearch();
    setupSaveCase();
    setupExportCases();
    setupReplayBottomTabs();
    document.getElementById('replaySend').addEventListener('click', sendReplayRequest);
    DashboardRefresh.setupAutoRefresh({
      refreshStats: loadStatsOnly,
      loadOverview: load,
      loadHistory,
      loadReplay() {
        loadReplayHistory();
        loadReplayCases();
      },
      loadMonitors() {
        loadMonitors({ skipForm: true });
      },
    }, 5000);
  }
});

function statusBadge(status) {
  const labels = {
    confirmed: '高可信',
    candidate: '待确认',
    unmapped: '未映射',
    inferred: '推断',
    observed: '已观测',
  };
  const cls = status || 'unmapped';
  return `<span class="mapping-status mapping-${escapeHtml(cls)}">${escapeHtml(labels[cls] || cls)}</span>`;
}

function evidenceHtml(evidence) {
  const e = evidence || {};
  return `<div class="evidence-bar">
    <span class="evidence-item">T:<strong>${Number(e.temporal || 0).toFixed(2)}</strong></span>
    <span class="evidence-item">S:<strong>${Number(e.semantic || 0).toFixed(2)}</strong></span>
    <span class="evidence-item">P:<strong>${Number(e.param || 0).toFixed(2)}</strong></span>
    <span class="evidence-item">Pg:<strong>${Number(e.page || 0).toFixed(2)}</strong></span>
    <span class="evidence-item">M:<strong>${Number(e.method || 0).toFixed(2)}</strong></span>
  </div>`;
}

function renderPages() {
  const tbody = document.querySelector('#tablePages tbody');
  const rows = data.pageApiMap.filter(p => {
    const haystack = `${p.page || ''} ${p.pageKey || ''} ${p.pageTitle || ''}`;
    return !filterText || haystack.includes(filterText);
  });
  tbody.innerHTML = rows.map(p => `
    <tr>
      <td>
        <strong>${escapeHtml(p.pageKey || p.page)}</strong>
        <div class="muted-line">${escapeHtml(p.page || '')} ${statusBadge(p.mappingStatus)}</div>
      </td>
      <td>${escapeHtml(p.pageTitle || '')}</td>
      <td><ul class="actions-list">${(p.actions || []).map(a =>
        `<li>${methodBadge(a.method)} ${escapeHtml(a.name || '(no text)')} &rarr; ${escapeHtml(a.api)} ${statusBadge(a.mappingStatus)}</li>`).join('')}</ul></td>
      <td>${(p.apis || []).map(a => `${methodBadge(a.method)} ${escapeHtml(a.urlPath)} <span class="muted-line">x${a.callCount || 0}</span>`).join('<br>')}</td>
    </tr>`).join('');
}

function renderBehaviors() {
  const tbody = document.querySelector('#tableBehaviors tbody');
  let rows = data.behaviorApiMap.filter(b => {
    const haystack = `${b.behavior?.text || ''} ${b.behavior?.page || ''} ${b.behavior?.pageKey || ''}`;
    return !filterText || haystack.includes(filterText);
  });
  rows.sort((a, b) => {
    const aMax = Math.max(0, ...a.mappings.map(m => m.confidence));
    const bMax = Math.max(0, ...b.mappings.map(m => m.confidence));
    if (bMax !== aMax) return bMax - aMax;
    return (b.occurrences || 0) - (a.occurrences || 0);
  });

  tbody.innerHTML = rows.flatMap(b => {
    const validMappings = b.mappings.filter(m => m.confidence >= minConf);
    const alternatives = b.alternatives || [];
    const behaviorKey = `${b.behavior?.text || ''}:${b.behavior?.pageKey || b.behavior?.page || ''}`;
    const recordsBtn = b.occurrences > 1
      ? `<button class="btn-records" data-behavior-key="${escapeHtml(behaviorKey)}">查看清单(${b.occurrences})</button>`
      : '';
    if (!validMappings.length) {
      const altHtml = alternatives.length
        ? `<div class="alt-list">候选：${alternatives.map(a => `${methodBadge(a.method)} ${escapeHtml(a.urlPath)} <span class="conf low">${Number(a.confidence || 0).toFixed(2)}</span>`).join('<br>')}</div>`
        : '<span class="muted-line">No correlated API</span>';
      return `<tr>
        <td><strong>${escapeHtml(b.behavior?.text || '(no text)')}</strong> ${recordsBtn}<div>${statusBadge('unmapped')}</div></td>
        <td>${escapeHtml(b.behavior?.pageKey || b.behavior?.page || '')}</td>
        <td colspan="3">${altHtml}</td>
      </tr>`;
    }
    return validMappings.map(m => `
    <tr>
      <td><strong>${escapeHtml(b.behavior?.text || '')}</strong> ${recordsBtn}<div>${statusBadge(m.mappingStatus || b.mappingStatus)}</div></td>
      <td>${escapeHtml(b.behavior?.pageKey || b.behavior?.page || '')}</td>
      <td>${methodBadge(m.method)} ${escapeHtml(m.urlPath)}
        <button class="btn-replay btn-replay-behavior" data-replay-url="${escapeHtml(m.url || m.urlPath)}" data-replay-method="${escapeHtml(m.method)}">重放</button>
        ${(m.reqType && m.reqType !== 'action') ? `<span class="type-tag">${escapeHtml(m.reqType)}</span>` : ''}
      </td>
      <td><span class="conf ${confClass(m.confidence)}">${Number(m.confidence || 0).toFixed(2)}</span></td>
      <td>${evidenceHtml(m.evidence)}</td>
    </tr>`);
  }).join('');
}

function updateStats() {
  const raw = data._raw || {};
  const coverage = data.coverage || {};
  document.getElementById('statRequests').textContent = raw.totalRequests ?? 0;
  document.getElementById('statPages').textContent = data.pageApiMap.length || raw.totalMappings || 0;
  document.getElementById('statBehaviors').textContent = data.behaviorApiMap.length || raw.totalBehaviors || 0;
  document.getElementById('badgePages').textContent = data.pageApiMap.length || raw.totalMappings || 0;
  document.getElementById('badgeBehaviors').textContent =
    coverage.total != null ? `${coverage.confirmed || 0}/${coverage.total}` : (data.behaviorApiMap.length || raw.totalBehaviors || 0);
}

function render() { renderPages(); renderBehaviors(); updateStats(); }

let _db = null;

function openDb() {
  if (_db) return Promise.resolve(_db);
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB.NAME, DB.VERSION);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('requests')) {
        const s = db.createObjectStore('requests', { keyPath: 'id' });
        s.createIndex('timestamp', 'timestamp');
        s.createIndex('pageUrl', 'pageUrl');
        s.createIndex('urlPath', 'urlPath');
        s.createIndex('resourceType', 'resourceType');
      }
      // v2: add resourceType index if upgrading from v1
      if (e.oldVersion < 2 && db.objectStoreNames.contains('requests')) {
        const s = e.target.transaction.objectStore('requests');
        if (!s.indexNames.contains('resourceType')) s.createIndex('resourceType', 'resourceType');
      }
      if (!db.objectStoreNames.contains('behaviors')) {
        const s = db.createObjectStore('behaviors', { keyPath: 'id' });
        s.createIndex('timestamp', 'timestamp');
        s.createIndex('pageUrl', 'pageUrl');
      }
      if (!db.objectStoreNames.contains('mappings')) {
        const s = db.createObjectStore('mappings', { keyPath: 'id' });
        s.createIndex('behaviorId', 'behaviorId');
        s.createIndex('confidence', 'confidence');
        s.createIndex('timestamp', 'timestamp');
      }
      if (!db.objectStoreNames.contains('replayHistory')) {
        const s = db.createObjectStore('replayHistory', { keyPath: 'id' });
        s.createIndex('timestamp', 'timestamp');
      }
      if (!db.objectStoreNames.contains('testCases')) {
        const s = db.createObjectStore('testCases', { keyPath: 'id' });
        s.createIndex('timestamp', 'timestamp');
        s.createIndex('name', 'name');
      }
      if (!db.objectStoreNames.contains('monitors')) {
        const s = db.createObjectStore('monitors', { keyPath: 'id' });
        s.createIndex('timestamp', 'timestamp');
      }
      if (!db.objectStoreNames.contains('monitorResults')) {
        const s = db.createObjectStore('monitorResults', { keyPath: 'id' });
        s.createIndex('monitorId', 'monitorId');
        s.createIndex('timestamp', 'timestamp');
      }
    };
    req.onsuccess = e => {
      _db = e.target.result;
      _db.onclose = () => { _db = null; };
      _db.onversionchange = () => { _db.close(); _db = null; };
      resolve(_db);
    };
    req.onerror = () => reject(req.error);
  });
}

function tx(store, mode, fn) {
  return openDb().then(db => new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const s = t.objectStore(store);
    const req = fn(s);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  }));
}

function put(store, record) {
  return tx(store, 'readwrite', s => s.put(record));
}

function getAll(store) {
  return tx(store, 'readonly', s => s.getAll());
}

function count(store) {
  return tx(store, 'readonly', s => s.count());
}

function clear(store) {
  return tx(store, 'readwrite', s => s.clear());
}

function getById(store, id) {
  return tx(store, 'readonly', s => s.get(id));
}

function deleteById(store, id) {
  return tx(store, 'readwrite', s => s.delete(id));
}

function findAndBackfill(store, url, ts, bodyData) {
  return openDb().then(db => new Promise((resolve, reject) => {
    const t = db.transaction(store, 'readwrite');
    const s = t.objectStore(store);
    const idx = s.index('timestamp');
    const range = IDBKeyRange.bound(ts - 5000, ts + 5000);
    const cursorReq = idx.openCursor(range, 'prev');
    let found = false;
    cursorReq.onsuccess = e => {
      const cursor = e.target.result;
      if (!cursor) return; // let oncomplete fire
      if (found) return;
      const record = cursor.value;
      if (record.url === url && !record.responseBody && (record.resourceType === 'xmlhttprequest' || record.resourceType === 'fetch')) {
        record.requestBody = record.requestBody || bodyData.reqBody;
        record.responseBody = bodyData.respBody;
        if (bodyData.reqHeaders && Object.keys(bodyData.reqHeaders).length) {
          record.requestHeaders = { ...record.requestHeaders, ...bodyData.reqHeaders };
        }
        record.responseStatus = record.responseStatus || bodyData.status;
        if (bodyData.pageContext) {
          record.pageContext = bodyData.pageContext;
        }
        cursor.update(record);
        found = true;
        return;
      }
      cursor.continue();
    };
    cursorReq.onerror = () => reject(cursorReq.error);
    t.oncomplete = () => resolve(found);
  }));
}

function getPaged(store, opts) {
  const { page = 0, pageSize = 50, sortDir = 'prev', filterFn } = opts;
  return openDb().then(db => new Promise((resolve, reject) => {
    const t = db.transaction(store, 'readonly');
    const s = t.objectStore(store);
    const idx = s.index('timestamp');
    const dir = sortDir === 'next' ? 'next' : 'prev';

    // Fast path: no filter — use count() for total, stop cursor when page filled
    if (!filterFn) {
      const countReq = idx.count();
      countReq.onsuccess = () => {
        const total = countReq.result;
        const items = [];
        let cursorIdx = 0;
        const skipCount = page * pageSize;
        const cursorReq = idx.openCursor(null, dir);
        cursorReq.onsuccess = e => {
          const cursor = e.target.result;
          if (!cursor || items.length >= pageSize) {
            resolve({ items, total, page, pageSize });
            return;
          }
          if (cursorIdx >= skipCount) items.push(cursor.value);
          cursorIdx++;
          cursor.continue();
        };
        cursorReq.onerror = () => reject(cursorReq.error);
      };
      countReq.onerror = () => reject(countReq.error);
      return;
    }

    // Filtered path: must iterate all to get accurate total
    const cursorReq = idx.openCursor(null, dir);
    const items = [];
    let matchIndex = 0;
    let totalMatched = 0;
    const skipCount = page * pageSize;
    let pageFilled = false;
    cursorReq.onsuccess = e => {
      const cursor = e.target.result;
      if (!cursor) {
        resolve({ items, total: totalMatched, page, pageSize });
        return;
      }
      const record = cursor.value;
      if (filterFn(record)) {
        totalMatched++;
        if (!pageFilled && matchIndex >= skipCount && items.length < pageSize) {
          items.push(record);
          if (items.length >= pageSize) pageFilled = true;
        }
        matchIndex++;
      }
      cursor.continue();
    };
    cursorReq.onerror = () => reject(cursorReq.error);
  }));
}

async function evictOldest(store, cap, evictCount) {
  const n = await count(store);
  if (n <= cap) return;
  const db = await openDb();
  await new Promise((resolve, reject) => {
    const t = db.transaction(store, 'readwrite');
    const s = t.objectStore(store);
    const idx = s.index('timestamp');
    const req = idx.openCursor(null, 'next');
    let deleted = 0;
    req.onsuccess = e => {
      const cursor = e.target.result;
      if (cursor && deleted < evictCount) {
        cursor.delete();
        deleted++;
        cursor.continue();
      }
      // let oncomplete fire once cursor exhausts or target reached
    };
    req.onerror = () => reject(req.error);
    t.oncomplete = () => resolve();
  });
}

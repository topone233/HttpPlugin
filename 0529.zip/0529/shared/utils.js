const ZH_EN = {
  '删除': 'delete', '查询': 'query', '搜索': 'search', '导出': 'export',
  '新增': 'create', '添加': 'add', '编辑': 'edit', '修改': 'update',
  '详情': 'detail', '列表': 'list', '保存': 'save', '下载': 'download',
  '提交': 'submit', '重置': 'reset', '刷新': 'refresh', '导入': 'import',
  '用户': 'user', '角色': 'role', '权限': 'permission', '菜单': 'menu',
  '配置': 'config', '设置': 'setting', '日志': 'log', '任务': 'task',
  '项目': 'project', '订单': 'order', '商品': 'product', '数据': 'data',
  '信息': 'info', '管理': 'manage', '操作': 'operate', '登录': 'login',
  '注册': 'register', '启用': 'enable', '禁用': 'disable', '确认': 'confirm',
  '取消': 'cancel', '关闭': 'close', '审核': 'audit', '审批': 'approve',
  '分配': 'assign', '绑定': 'bind', '上传': 'upload', '预览': 'preview',
  '复制': 'copy', '移动': 'move', '同步': 'sync', '发布': 'publish',
  '撤回': 'revoke', '回退': 'rollback', '执行': 'execute', '暂停': 'pause',
  '恢复': 'recover', '归档': 'archive', '通知': 'notify', '消息': 'message',
  '订阅': 'subscribe', '创建': 'create', '批量': 'batch', '移除': 'remove',
  '授权': 'authorize', '生成': 'generate', '排序': 'sort', '合并': 'merge',
  '拆分': 'split', '锁定': 'lock', '解锁': 'unlock', '激活': 'activate',
  '获取': 'get', '更新': 'update', '关联': 'link', '发送': 'send',
  '验证': 'verify', '校验': 'validate', '统计': 'stat', '分析': 'analyze',
  '查看': 'view', '选择': 'select', '确定': 'confirm', '清空': 'clear',
  '领取': 'claim', '退回': 'return', '上架': 'online', '下架': 'offline',
};

const STATIC_EXT = /\.(js|css|png|jpg|gif|svg|ico|woff|woff2|ttf|map|webp|eot)(\?|$)/i;
const NOISE_HOSTS = /google-analytics|doubleclick|gtm\.js|hotjar|sentry|clarity\.ms|facebook\.net/i;
const NOISE_PATHS = /\/(analytics|tracking|beacon|ping|heartbeat|favicon|polling|sockjs|hmr|hot-update)/i;
const GENERIC_SEGMENTS = new Set(['api', 'v1', 'v2', 'v3', 'rest', 'service', 'services']);

const ZH_EN_RE = new RegExp(Object.keys(ZH_EN).join('|'), 'g');
function applyZhEn(text) {
  return String(text || '').replace(ZH_EN_RE, zh => ` ${ZH_EN[zh]} `);
}

function splitCamel(s) {
  return String(s || '').replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase();
}

function tokenize(text) {
  if (!text) return [];
  const mapped = applyZhEn(text);
  return splitCamel(mapped)
    .split(/[\s\-_/.,:;?&=()[\]{}'"`<>|]+/)
    .map(t => t.trim().toLowerCase())
    .filter(t => t.length > 1);
}

function tokenizeUrl(url) {
  try {
    const u = new URL(url);
    const searchKeys = [...u.searchParams.keys()].join(' ');
    return splitCamel(`${u.pathname} ${searchKeys}`)
      .split(/[\s\-_/]+/)
      .map(t => t.toLowerCase())
      .filter(t => t.length > 1 && !GENERIC_SEGMENTS.has(t));
  } catch {
    return [];
  }
}

function overlap(a, b) {
  if (!a.length || !b.length) return 0;
  const sa = new Set(a), sb = new Set(b);
  const inter = [...sa].filter(x => sb.has(x)).length;
  if (!inter) return 0;
  return inter / Math.min(sa.size, sb.size);
}

function isApiRequest(url) {
  try {
    const u = new URL(url);
    return !STATIC_EXT.test(u.pathname) && !NOISE_HOSTS.test(u.hostname) && !NOISE_PATHS.test(u.pathname);
  } catch { return false; }
}

function flattenValues(input, out = []) {
  if (input == null) return out;
  if (typeof input !== 'object') {
    out.push(String(input));
    return out;
  }
  if (Array.isArray(input)) {
    input.forEach(v => flattenValues(v, out));
    return out;
  }
  Object.values(input).forEach(v => flattenValues(v, out));
  return out;
}

function parseBodyLike(value) {
  if (!value) return null;
  try {
    let body = value;
    if (typeof body === 'string') {
      const trimmed = body.trim();
      if (!trimmed) return null;
      if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
        body = JSON.parse(trimmed);
      } else {
        body = Object.fromEntries(new URLSearchParams(trimmed).entries());
      }
    }
    return body;
  } catch {
    return null;
  }
}

function strongMatch(rowData, requestBody, url) {
  if (!rowData) return 0;
  const body = parseBodyLike(requestBody) || {};
  const params = {};
  if (url) {
    try {
      new URL(url).searchParams.forEach((v, k) => { params[k] = v; });
    } catch {}
  }
  const reqVals = new Set(flattenValues({ body, params }).map(String).filter(Boolean));
  const rowVals = flattenValues(rowData).map(String).filter(Boolean);
  if (!rowVals.length || !reqVals.size) return 0;
  return rowVals.some(v => reqVals.has(v)) ? 1.0 : 0;
}

function generateId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

// ===== Monitor: built-in variables =====
const BUILTIN_VARS = {
  timestamp: () => String(Date.now()),
  random: () => String(Math.floor(Math.random() * 10000)),
};

// ===== Monitor: extraction engine =====
function extractJsonPath(obj, path) {
  const parts = path.split('.');
  let cur = obj;
  for (const p of parts) {
    if (cur == null || typeof cur !== 'object') return null;
    cur = cur[p];
  }
  return cur != null ? String(cur) : null;
}

function parseCookieValue(setCookieHeader, cookieName) {
  if (!setCookieHeader) return null;
  const escaped = cookieName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const match = setCookieHeader.match(new RegExp(`(?:^|;\\s*)${escaped}=([^;]*)`));
  return match ? match[1] : null;
}

function extractFromResponse(responseHeaders, responseBody, rules) {
  const vars = {};
  for (const rule of rules) {
    try {
      if (rule.source === 'header') {
        vars[rule.variableName] = responseHeaders[rule.path] || null;
      } else if (rule.source === 'body') {
        let body = responseBody;
        if (typeof body === 'string') {
          try { body = JSON.parse(body); } catch { /* not JSON */ }
        }
        vars[rule.variableName] = extractJsonPath(body, rule.path);
      } else if (rule.source === 'cookie') {
        const setCookie = responseHeaders['set-cookie'] || responseHeaders['Set-Cookie'] || '';
        vars[rule.variableName] = parseCookieValue(setCookie, rule.cookieName);
      }
    } catch {
      vars[rule.variableName] = null;
    }
  }
  return vars;
}

function applyMonitorVariables(text, extractedVars) {
  if (!text) return text;
  return text.replace(/\{\{(\w+)\}\}/g, (match, key) => {
    if (extractedVars[key] != null) return extractedVars[key];
    if (BUILTIN_VARS[key]) return BUILTIN_VARS[key]();
    return match;
  });
}

// ===== Cron expression parser =====
const CRON_FIELD_RANGES = [
  { name: 'minute', min: 0, max: 59 },
  { name: 'hour', min: 0, max: 23 },
  { name: 'dayOfMonth', min: 1, max: 31 },
  { name: 'month', min: 1, max: 12 },
  { name: 'dayOfWeek', min: 0, max: 6 },
];

const DAY_NAMES = ['日', '一', '二', '三', '四', '五', '六'];

function parseField(field, range) {
  if (field === '*') return { values: null, step: 1, rangeMin: range.min };
  if (field.startsWith('*/')) {
    const step = parseInt(field.slice(2), 10);
    if (isNaN(step) || step < 1) return null;
    return { values: null, step, rangeMin: range.min };
  }

  const values = new Set();
  const parts = field.split(',');
  for (const part of parts) {
    if (part.includes('/')) {
      const [rng, stepStr] = part.split('/');
      const step = parseInt(stepStr, 10);
      if (isNaN(step) || step < 1) return null;
      const [low, high] = rng.split('-').map(Number);
      if (isNaN(low) || isNaN(high) || low < range.min || high > range.max || low > high) return null;
      for (let i = low; i <= high; i += step) values.add(i);
    } else if (part.includes('-')) {
      const [low, high] = part.split('-').map(Number);
      if (isNaN(low) || isNaN(high) || low < range.min || high > range.max || low > high) return null;
      for (let i = low; i <= high; i++) values.add(i);
    } else {
      const val = parseInt(part, 10);
      if (isNaN(val) || val < range.min || val > range.max) return null;
      values.add(val);
    }
  }
  return { values, step: 1 };
}

function fieldMatches(value, parsed) {
  if (!parsed) return false;
  if (parsed.values === null) {
    if (parsed.step === 1) return true;
    return (value - parsed.rangeMin) % parsed.step === 0;
  }
  return parsed.values.has(value);
}

function validateCron(expression) {
  if (!expression || typeof expression !== 'string') return { valid: false, error: '表达式不能为空' };
  const fields = expression.trim().split(/\s+/);
  if (fields.length !== 5) return { valid: false, error: '需要 5 个字段：分 时 日 月 周' };

  for (let i = 0; i < 5; i++) {
    const parsed = parseField(fields[i], CRON_FIELD_RANGES[i]);
    if (!parsed) return { valid: false, error: `字段 "${CRON_FIELD_RANGES[i].name}" 无效: ${fields[i]}` };
  }
  return { valid: true };
}

function cronNextTime(expression, fromDate) {
  const fields = expression.trim().split(/\s+/);
  if (fields.length !== 5) return null;

  const parsed = fields.map((f, i) => parseField(f, CRON_FIELD_RANGES[i]));
  if (parsed.some(p => !p)) return null;

  const from = fromDate ? new Date(fromDate) : new Date();
  const candidate = new Date(from);
  candidate.setSeconds(0, 0);
  candidate.setMinutes(candidate.getMinutes() + 1);

  const limit = new Date(candidate);
  limit.setFullYear(limit.getFullYear() + 2);

  while (candidate <= limit) {
    const minute = candidate.getMinutes();
    const hour = candidate.getHours();
    const dom = candidate.getDate();
    const month = candidate.getMonth() + 1;
    const dow = candidate.getDay();

    if (
      fieldMatches(minute, parsed[0]) &&
      fieldMatches(hour, parsed[1]) &&
      fieldMatches(dom, parsed[2]) &&
      fieldMatches(month, parsed[3]) &&
      fieldMatches(dow, parsed[4])
    ) {
      return candidate;
    }

    candidate.setMinutes(candidate.getMinutes() + 1);
  }

  return null;
}

function describeCron(expression) {
  const fields = expression.trim().split(/\s+/);
  if (fields.length !== 5) return expression;

  const m = fields[0], h = fields[1], dom = fields[2], mon = fields[3], dow = fields[4];

  if (m === '0' && h === '0' && dom === '*' && mon === '*' && dow === '*') return '每天 00:00';
  if (/^\d+$/.test(m) && /^\d+$/.test(h) && dom === '*' && mon === '*' && dow === '*') {
    return `每天 ${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
  }
  if (/^\d+$/.test(m) && /^\d+$/.test(h) && dom === '*' && mon === '*' && /^[0-6,]+$/.test(dow)) {
    const days = dow.split(',').map(d => `周${DAY_NAMES[parseInt(d, 10)]}`).join('、');
    return `${days} ${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
  }
  if (m.startsWith('*/') && h === '*' && dom === '*' && mon === '*' && dow === '*') {
    return `每 ${m.slice(2)} 分钟`;
  }
  if (m === '0' && h.startsWith('*/') && dom === '*' && mon === '*' && dow === '*') {
    return `每 ${h.slice(2)} 小时`;
  }

  return expression;
}
